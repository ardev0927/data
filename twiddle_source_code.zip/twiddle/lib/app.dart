import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/album_bloc.dart';
import 'package:twiddle/blocs/blocked_user_bloc.dart';
import 'package:twiddle/blocs/chat_room_bloc.dart';
import 'package:twiddle/blocs/chats_bloc.dart';
import 'package:twiddle/blocs/follow_setting_bloc.dart';
import 'package:twiddle/blocs/friends_bloc.dart';
import 'package:twiddle/blocs/gifs_bloc.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:twiddle/blocs/group_request_members_bloc.dart';
import 'package:twiddle/blocs/group_pinned_bloc.dart';
import 'package:twiddle/blocs/all_group_post_bloc.dart';
import 'package:twiddle/blocs/group_posts_bloc.dart';
import 'package:twiddle/blocs/help_support_bloc.dart';
import 'package:twiddle/blocs/interest_bloc.dart';
import 'package:twiddle/blocs/likes_bloc.dart';
import 'package:twiddle/blocs/my_friends_bloc.dart';
import 'package:twiddle/blocs/my_group_bloc.dart';
import 'package:twiddle/blocs/my_group_post_bloc.dart';
import 'package:twiddle/blocs/my_joined_group_bloc.dart';
import 'package:twiddle/blocs/my_post_bloc.dart';
import 'package:twiddle/blocs/notification_bloc.dart';
import 'package:twiddle/blocs/one_group_post_bloc.dart';
import 'package:twiddle/blocs/other_group_bloc.dart';
import 'package:twiddle/blocs/post_friends_bloc.dart';
import 'package:twiddle/blocs/post_pinned_bloc.dart';
import 'package:twiddle/blocs/post_tag_bloc.dart';
import 'package:twiddle/blocs/post_type_bloc.dart';
import 'package:twiddle/blocs/post_user_bloc.dart';
import 'package:twiddle/blocs/posts_bloc.dart';
import 'package:twiddle/blocs/request_bloc.dart';
import 'package:twiddle/blocs/shares_bloc.dart';
import 'package:twiddle/blocs/stories_bloc.dart';
import 'package:twiddle/blocs/story_details_bloc.dart';
import 'package:twiddle/blocs/suggest_group_bloc.dart';
import 'package:twiddle/blocs/suggestion_bloc.dart';
import 'package:twiddle/blocs/tab_index_bloc.dart';
import 'package:twiddle/blocs/tag_friends_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/blocs/your_group_bloc.dart';

import 'blocs/comment_bloc.dart';
import 'blocs/group_follow_bloc.dart';
import 'blocs/group_manage_bloc.dart';
import 'blocs/group_report_bloc.dart';
import 'blocs/sign_in_bloc.dart';
import 'blocs/theme_bloc.dart';
import 'models/theme_model.dart';
import 'pages/post/live/log_sink.dart';
import 'pages/splash_page.dart';

final FirebaseAnalytics firebaseAnalytics = FirebaseAnalytics.instance;
final FirebaseAnalyticsObserver firebaseObserver =
    FirebaseAnalyticsObserver(analytics: firebaseAnalytics);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ThemeBloc>(
      create: (_) => ThemeBloc(),
      child: Consumer<ThemeBloc>(
        builder: (_, mode, child) {
          return MultiProvider(
            providers: [
              ChangeNotifierProvider<SignInBloc>(
                  create: (context) => SignInBloc()),
              ChangeNotifierProvider<PostsBloc>(
                  create: (context) => PostsBloc()),
              ChangeNotifierProvider<PostUserBloc>(
                  create: (context) => PostUserBloc()),
              ChangeNotifierProvider<PostTypeBloc>(
                  create: (context) => PostTypeBloc()),
              ChangeNotifierProvider<TabIndexBloc>(
                  create: (context) => TabIndexBloc()),
              ChangeNotifierProvider<FriendsBloc>(
                  create: (context) => FriendsBloc()),
              ChangeNotifierProvider<SuggestionBloc>(
                  create: (context) => SuggestionBloc()),
              ChangeNotifierProvider<UserBlock>(
                  create: (context) => UserBlock()),
              ChangeNotifierProvider<RequestBloc>(
                  create: (context) => RequestBloc()),
              ChangeNotifierProvider<InterestBloc>(
                  create: (context) => InterestBloc()),
              ChangeNotifierProvider<LikesBloc>(
                  create: (context) => LikesBloc()),
              ChangeNotifierProvider<SharesBloc>(
                  create: (context) => SharesBloc()),
              ChangeNotifierProvider<CommentBloc>(
                  create: (context) => CommentBloc()),
              ChangeNotifierProvider<GifsBloc>(create: (context) => GifsBloc()),
              ChangeNotifierProvider<AlbumBloc>(
                  create: (context) => AlbumBloc()),
              ChangeNotifierProvider<GroupBloc>(
                  create: (context) => GroupBloc()),
              ChangeNotifierProvider<AllGroupPostBloc>(
                  create: (context) => AllGroupPostBloc()),
              ChangeNotifierProvider<GroupPinnedBloc>(
                  create: (context) => GroupPinnedBloc()),
              ChangeNotifierProvider<MyGroupBloc>(
                  create: (context) => MyGroupBloc()),
              ChangeNotifierProvider<OtherGroupBloc>(
                  create: (context) => OtherGroupBloc()),
              ChangeNotifierProvider<SuggestedGroupBloc>(
                  create: (context) => SuggestedGroupBloc()),
              ChangeNotifierProvider<OneGroupPostBloc>(
                  create: (context) => OneGroupPostBloc()),
              ChangeNotifierProvider<GroupReportBloc>(
                  create: (context) => GroupReportBloc()),
              ChangeNotifierProvider<GroupPostsBloc>(
                  create: (context) => GroupPostsBloc()),
              ChangeNotifierProvider<GroupRequestMembersBloc>(
                  create: (context) => GroupRequestMembersBloc()),
              ChangeNotifierProvider<YourGroupBloc>(
                  create: (context) => YourGroupBloc()),
              ChangeNotifierProvider<MyJoinedGroupBloc>(
                  create: (context) => MyJoinedGroupBloc()),
              ChangeNotifierProvider<ChatRoomBloc>(
                  create: (context) => ChatRoomBloc()),
              ChangeNotifierProvider<ChatsBloc>(
                  create: (context) => ChatsBloc()),
              ChangeNotifierProvider<NotificationBloc>(
                  create: (context) => NotificationBloc()),
              ChangeNotifierProvider<StoriesBloc>(
                  create: (context) => StoriesBloc()),
              ChangeNotifierProvider<StoryDetialBloc>(
                  create: (context) => StoryDetialBloc()),
              // ChangeNotifierProvider<LogSink>(
              //   create: (context) => LogSink(),
              // ),
              ChangeNotifierProvider<MyFriendsBloc>(
                  create: (context) => MyFriendsBloc()),
              ChangeNotifierProvider<PostFriendsBloc>(
                  create: (context) => PostFriendsBloc()),
              ChangeNotifierProvider<PostPinnedBloc>(
                  create: (context) => PostPinnedBloc()),
              ChangeNotifierProvider<GroupManageBloc>(
                  create: (context) => GroupManageBloc()),
              ChangeNotifierProvider<MyGroupPostsBloc>(
                  create: (context) => MyGroupPostsBloc()),
              ChangeNotifierProvider<MyPostBloc>(
                  create: (context) => MyPostBloc()),
              ChangeNotifierProvider<PostTagBloc>(
                  create: (context) => PostTagBloc()),
              ChangeNotifierProvider<BlockedUserBloc>(
                  create: (context) => BlockedUserBloc()),
              ChangeNotifierProvider<HelpSupportBloc>(
                  create: (context) => HelpSupportBloc()),
              ChangeNotifierProvider<GroupFollowBloc>(
                  create: (context) => GroupFollowBloc()),
              ChangeNotifierProvider<TagFriendsBloc>(
                  create: (context) => TagFriendsBloc()),
              ChangeNotifierProvider<FollowSettingBloc>(
                  create: (context) => FollowSettingBloc()),
            ],
            child: MaterialApp(
                supportedLocales: context.supportedLocales,
                localizationsDelegates: context.localizationDelegates,
                locale: context.locale,
                navigatorObservers: [firebaseObserver],
                theme: ThemeModel().lightMode,
                darkTheme: ThemeModel().darkMode,
                themeMode:
                    mode.darkTheme == true ? ThemeMode.dark : ThemeMode.light,
                debugShowCheckedModeBanner: false,
                home: SplashPage()),
          );
        },
      ),
    );
  }
}
