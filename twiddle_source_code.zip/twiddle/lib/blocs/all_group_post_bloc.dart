import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/post.dart';

class AllGroupPostBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Post> _data = [];
  List<Post> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _isLiked = false;
  bool get isLiked => _isLiked;

  bool _isShared = false;
  bool get isShared => _isShared;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Post? _post;
  Post? get post => _post;

  bool _isPinned = false;
  bool get isPinned => _isPinned;

  Future<Null> getData(uid, mounted, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('posts')
          .where('group_post', isEqualTo: true)
          .where('uid', isEqualTo: uid)
          .orderBy(orderBy, descending: true)
          .limit(5)
          .get();
    } else {
      rawData = await firestore
          .collection('posts')
          .where('group_post', isEqualTo: true)
          .where('uid', isEqualTo: uid)
          .orderBy(orderBy, descending: true)
          .startAfter([_lastVisible![orderBy]])
          .limit(5)
          .get();
    }

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Post.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {}

  afterPopSelection(uid, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(uid, mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, mounted, orderBy);
    notifyListeners();
  }

  Future deletePost(Post p) async {
    try {
      // delete post id
      await firestore
          .collection('posts')
          .doc(p.postId)
          .delete()
          .whenComplete(() {
        print('===== deleted post =====');
        // decrease point count
        decreasePostCount()
            .whenComplete(() => print('===== decrease post count ====='));
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future pinUnpinPost(Post p) async {
    try {
      print('===== ${p.postId} =====');
      bool pinned = !p.pinned!;
      // pin/unpin post
      await firestore
          .collection('posts')
          .doc(p.postId)
          .update({'pinned': pinned}).whenComplete(() {
        print('===== pinned/unpinned post =====');
        // decrease point count
        _hasError = false;
        _isPinned = pinned;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<int> getTotalPostsCount() async {
    const String fieldName = 'count';
    final DocumentReference ref =
        FirebaseFirestore.instance.collection('item_count').doc('posts_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount + 1});
    });
  }

  Future decreasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount - 1});
    });
  }

  Future setLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isLiked = false;
          print('===== unlike =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isLiked = true;
          print('===== like =====');
        });
      }
    });
    notifyListeners();
  }

  Future getLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        _isLiked = true;
      } else {
        _isLiked = false;
      }
    });
    notifyListeners();
  }

  Future setShare(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['shares']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isShared = false;
          print('===== unshare =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isShared = true;
          print('===== share =====');
        });
      }
    });
    notifyListeners();
  }

  Future getShare(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['shares']);
      if (likes.contains(uid)) {
        _isShared = true;
      } else {
        _isShared = false;
      }
    });
    notifyListeners();
  }
}
