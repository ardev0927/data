import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/user.dart';

class BlockedUserBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  List<WUser> _data = [];
  List<WUser> get data => _data;

  Future<void> getData(myUid, blockedUids, mounted) async {
    _snap.clear();
    _data.clear();

    if (blockedUids.isEmpty) {
      _isLoading = false;
      _hasData = false;
      notifyListeners();
      return;
    }

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('users')
        .doc(myUid)
        .collection('blocked_users')
        .limit(10)
        .get();
    if (rawData.docs.isNotEmpty) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => WUser.fromFirestore(e)).toList();
        _data.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, uids, mounted) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, uids, mounted);
    notifyListeners();
  }
}
