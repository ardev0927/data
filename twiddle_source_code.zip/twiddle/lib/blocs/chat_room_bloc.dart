import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/chat_room.dart';
import 'package:twiddle/models/message.dart';

class ChatRoomBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<ChatRoom> _data = [];
  List<ChatRoom> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  ChatRoom? _chatRoom;
  ChatRoom? get chatRoom => _chatRoom;

  Future getRoom(uid1, uid2) async {
    QuerySnapshot rawData;

    // _snap.clear();
    // _data.clear();

    try {
      rawData = await firestore
          .collection('chats')
          .where('uids', isEqualTo: [uid1, uid2]).get();

      if (rawData.docs.isNotEmpty) {
        _chatRoom = ChatRoom.fromFirestore(rawData.docs[0]);
      } else {
        print('no items');
        rawData = await firestore
            .collection('chats')
            .where('uids', isEqualTo: [uid2, uid1]).get();
        if (rawData.docs.isNotEmpty) {
          _chatRoom = ChatRoom.fromFirestore(rawData.docs[0]);
        } else {
          // print('no items');
          _chatRoom = null;
        }
      }

      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<void> getRooms(uid, mounted) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('chats')
          .where('uids', arrayContains: uid)
          // .orderBy('last_message')
          .orderBy('timestamp', descending: true)
          .limit(10)
          .get();
    } else {
      rawData = await firestore
          .collection('chats')
          .where('uids', arrayContains: uid)
          // .orderBy('last_message')
          .orderBy('timestamp', descending: true)
          .startAfter([_lastVisible!['timestamp']])
          // .startAfter(
          //     [_lastVisible!['last_message'], _lastVisible!['timestamp']])
          .limit(10)
          .get();
    }

    print('===== ${rawData.docs.length} =====');

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => ChatRoom.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {
    _isLoading = false;
    _hasData = false;
    _lastVisible = null;
    _snap.clear();
    _data.clear();
  }

  afterPopSelection(uid, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(uid, mounted);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, mounted) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getRooms(uid, mounted);
    notifyListeners();
  }

  Future createChatRoom(
      String ownerUid,
      String otherUid,
      String ownerAvatar,
      String otherAvatar,
      String ownerName,
      String otherName,
      String timestamp) async {
    var data = {
      'id': '',
      'uids': [ownerUid, otherUid],
      'avatars': [ownerAvatar, otherAvatar],
      'names': [ownerName, otherName],
      'timestamp': timestamp
    };

    try {
      var chatroom = await firestore.collection('chats').add(data);
      //
      print('===== Created Chat room =====');
      print('===== Chat room id ${chatroom.id} =====');

      //
      await firestore
          .collection('chats')
          .doc(chatroom.id)
          .update({'id': chatroom.id});
      var ret = await chatroom.get();
      _chatRoom = ChatRoom.fromFirestore(ret);

      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateRoom(String groupChatId, String key, String value) async {
    await firestore.collection('chats').doc(groupChatId).update({key: value});
  }

  Future updateRoomType(String groupChatId, String key, int value) async {
    await firestore.collection('chats').doc(groupChatId).update({key: value});
  }

  Future<int> getUnreads(String groupChatId) async {
    int count = 0;

    // var chatRoom = await firestore.collection('chats').doc(groupChatId).get();
    // var cr = ChatRoom.fromFirestore(chatRoom);
    // count = cr.unreads!;

    return count;
  }

  Future updateUnreadCount(String groupChatId, String key, int value) async {
    await firestore.collection('chats').doc(groupChatId).update({key: value});
  }
}
