import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/chat_room.dart';
import 'package:twiddle/models/message.dart';

class ChatsBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Message> _data = [];
  List<Message> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Message? _msg;
  Message? get msg => _msg;

  ChatRoom? _chatRoom;
  ChatRoom? get chatRoom => _chatRoom;

  Future<Null> getData(groupChatId, mounted, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('chats')
          .doc(groupChatId)
          .collection('messages')
          .orderBy(orderBy, descending: true)
          .limit(10)
          .get();
    } else {
      rawData = await firestore
          .collection('chats')
          .doc(groupChatId)
          .collection('messages')
          .orderBy(orderBy, descending: true)
          .startAfter([_lastVisible![orderBy]])
          .limit(10)
          .get();
    }

    print('===== ${rawData.docs.length} =====');

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Message.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  Future<Message?> getLastMessage(groupChatId, mounted, String orderBy) async {
    QuerySnapshot rawData;
    try {
      rawData = await firestore
          .collection('chats')
          .doc(groupChatId)
          .collection('messages')
          .orderBy(orderBy, descending: true)
          .get();
      if (rawData.docs.length > 0) {
        _lastVisible = rawData.docs[0];
        var msg = Message.fromFirestore(rawData.docs[0]);
        notifyListeners();
        return msg;
      } else {
        print('no items');
        return null;
      }
    } catch (e) {
      print(e.toString());
      notifyListeners();
    }
    return null;
  }

  onInit() {}

  afterPopSelection(groupChatId, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(groupChatId, mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(groupChatId, mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(groupChatId, mounted, orderBy);
    notifyListeners();
  }

  Future createMessage(
    String groupId,
    String sendUid,
    String sendName,
    String sendAvatar,
    String recvUid,
    String recvName,
    String recvAvatar,
    String message,
    int type,
    String timestamp,
  ) async {
    var msgData = {
      'id': '',
      'group_id': groupId,
      'send_uid': sendUid,
      'send_name': sendName,
      'send_avatar': sendAvatar,
      'recv_uid': recvUid,
      'recv_name': recvName,
      'recv_avatar': recvAvatar,
      'message': message,
      'type': type,
      'read': false,
      'timestamp': timestamp,
    };

    try {
      var msg = await firestore
          .collection('chats')
          .doc(groupId)
          .collection('messages')
          .add(msgData);

      //
      await firestore
          .collection('chats')
          .doc(groupId)
          .collection('messages')
          .doc(msg.id)
          .update({'id': msg.id});
      var ret = await msg.get();
      _msg = Message.fromFirestore(ret);

      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateMessageRead(bool read, String groupId, String msgId) async {
    try {
      await firestore
          .collection('chats')
          .doc(groupId)
          .collection('messages')
          .doc(msgId)
          .update({
        'read': read,
      });
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future setMessage(Message message, bool read) async {
    try {
      message.read = read;
      await firestore
          .collection('chats')
          .doc(message.recvUid)
          .collection('messages')
          .doc(message.sendUid)
          .collection('messages')
          .doc(message.id)
          .set(message.toJson());

      // Set last message
      await firestore
          .collection('chats')
          .doc(message.recvUid)
          .collection('messages')
          .doc(message.sendUid)
          .collection('last_message')
          .doc('message')
          .set(message.toJson());

      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future setLastMessage(Message message, bool read) async {
    try {
      message.read = read;
      await firestore
          .collection('chats')
          .doc(message.recvUid)
          .collection('messages')
          .doc(message.sendUid)
          .collection('last_message')
          .doc('message')
          .set(message.toJson());

      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }
}
