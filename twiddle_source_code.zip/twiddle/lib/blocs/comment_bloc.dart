import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/comment.dart';

import '../models/post.dart';

class CommentBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  List<Comment> _data = [];
  List<Comment> get data => _data;

  // List<String> _uids = [];
  // List<String> get uids => _uids;

  Future<void> getData(postId, orderBy, mounted) async {
    _snap.clear();
    _data.clear();

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('posts')
        .doc(postId)
        .collection('comments')
        .orderBy(orderBy, descending: true)
        .limit(10)
        .get();
    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Comment.fromFirestore(e)).toList();
        _data.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(postId, orderBy, mounted) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(postId, orderBy, mounted);
    notifyListeners();
  }

  Future addComment(Post? post, uid, username, useravatar, comment) async {
    DateTime now = DateTime.now();
    String timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
    var data = {
      'post_id': post!.postId,
      'uid': uid,
      'username': username,
      'useravatar': useravatar,
      'type': 'text',
      'comment': comment,
      'likes': 0,
      'replies': [],
      'timestamp': timestamp,
    };

    await firestore
        .collection('posts')
        .doc(post.postId)
        .collection('comments')
        .add(data)
        .whenComplete(() async {
      var snapshot = await firestore.collection('posts').doc(post.postId).get();
      int comments = snapshot['comments'];
      await firestore
          .collection('posts')
          .doc(post.postId)
          .update({'comments': comments + 1});
    });
    notifyListeners();
  }
}
