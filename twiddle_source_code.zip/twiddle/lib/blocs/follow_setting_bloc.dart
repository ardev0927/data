import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/follow_setting.dart';

import '../utils/format_time.dart';

class FollowSettingBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  bool? _hasError = false;
  bool? get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  FollowSetting? _followSetting;
  FollowSetting? get followSetting => _followSetting;

  Future<void> getData(uid, mounted) async {
    try {
      _hasError = false;
      _errorCode = '';

      var snapshot =
          await firestore.collection('follow_setting').doc(uid).get();

      if (snapshot.exists) {
        if (mounted) {
          _followSetting = FollowSetting.fromFirestore(snapshot);
          _hasError = false;
          _errorCode = '';
        }
      } else {
        _hasError = true;
        _errorCode = 'setting_no_exist';
      }
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
    }
    notifyListeners();
  }

  Future<void> updateUserFollowSetting(String uid, String? followMe,
      String? seePeople, String? seeStory, String? seeFriendList) async {
    try {
      _hasError = false;
      _errorCode = '';

      var data = {
        'follow_me': followMe ?? 'Public',
        'see_people': seePeople ?? 'Public',
        'see_story': seeStory ?? 'Friends',
        'see_friend_list': seeFriendList ?? 'Public',
      };

      await firestore
          .collection('follow_setting')
          .doc(uid)
          .update(data)
          .then((value) {
        _hasError = false;
        _errorCode = '';
        print('===== Saved follow setting =====');
        notifyListeners();
      });
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      print('===== $_errorCode =====');

      notifyListeners();
    }
  }

  Future<void> createData(String uid, String? followMe, String? seePeople,
      String? seeStory, String? seeFriendList) async {
    try {
      _hasError = false;
      _errorCode = '';

      // Create time now
      DateTime now = DateTime.now();
      DateTime utc = now.toUtc();
      var timestamp = formatISOTime(utc);

      var data = {
        'uid': uid,
        'follow_me': followMe ?? 'Public',
        'see_people': seePeople ?? 'Public',
        'see_story': seeStory ?? 'Friends',
        'see_friend_list': seeFriendList ?? 'Public',
        'timestamp': timestamp,
      };

      var d = await firestore.collection('follow_setting').doc(uid).set(data);

      _hasError = false;
      _errorCode = '';

      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      print('===== $_errorCode =====');

      notifyListeners();
    }
  }
}
