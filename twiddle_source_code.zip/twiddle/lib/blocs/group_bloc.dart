import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/user.dart';

import '../models/group.dart';
import '../models/post.dart';

class GroupBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Group> _data = [];
  List<Group> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Group? _group;
  Group? get group => _group;

  bool _isPinned = false;
  bool get isPinned => _isPinned;

  Future<Null> getData(mounted, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('groups')
          // .where('content type', isEqualTo: 'video')
          .orderBy(orderBy, descending: true)
          .limit(5)
          .get();
    } else {
      rawData = await firestore
          .collection('groups')
          // .where('content type', isEqualTo: 'video')
          .orderBy(orderBy, descending: true)
          .startAfter([_lastVisible![orderBy]])
          .limit(5)
          .get();
    }

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Group.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {}

  afterPopSelection(value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(mounted, orderBy);
    notifyListeners();
  }

  Future createGroup(
    SignInBloc sb,
    String name,
    String desc,
    String privacy,
    String week,
    String openTime,
    String closeTime,
    String coverPhoto,
    String timestamp,
  ) async {
    var groupData = {
      'id': '',
      'name': name,
      'privacy': privacy,
      'description': desc,
      'cover_photo': coverPhoto,
      'week': week,
      'hours_open': openTime,
      'hours_close': closeTime,
      'owner_uid': sb.uid,
      'owner_name': sb.name,
      'owner_avatar': sb.imageUrl,
      'members': [],
      'posts': [],
      'pinned': false,
      'timestamp': timestamp,
    };

    try {
      var g = await firestore.collection('groups').add(groupData);
      print('===== created group =====');
      print('===== group id ${g.id} =====');
      // update post id
      await firestore.collection('groups').doc(g.id).update({'id': g.id});
      var ret = await g.get();
      _group = Group.fromFirestore(ret);
      // increase group count
      increaseGroupCount().whenComplete(() {
        print('===== increase group count =====');
      });
      updateGroupList(g.id, 'members', sb.uid!, true);
      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateGroup(String gid, String key, String value) async {
    try {
      // update group data
      await firestore
          .collection('groups')
          .doc(gid)
          .update({key: value}).whenComplete(() {
        print('===== updated group data =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateGroupList(
      String gid, String key, String value, bool isAdd) async {
    try {
      // update group list data
      await firestore.collection('groups').doc(gid).update({
        key: isAdd == true
            ? FieldValue.arrayUnion([value])
            : FieldValue.arrayRemove([value])
      }).whenComplete(() {
        print('===== updated group list data =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future getGroup(String gid) async {
    try {
      await firestore.collection('groups').doc(gid).get().then((value) {
        _group = Group.fromFirestore(value);
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deleteGroup(Group g) async {
    try {
      // delete group id
      await firestore.collection('groups').doc(g.id).delete().whenComplete(() {
        print('===== deleted group =====');
        // decrease group count
        decreaseGroupCount()
            .whenComplete(() => print('===== decrease group count ====='));
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future pinUnpinGroup(Group g) async {
    try {
      print('===== ${g.id} =====');
      bool pinned = !g.pinned!;
      // pin/unpin post
      await firestore
          .collection('groups')
          .doc(g.id)
          .update({'pinned': pinned}).whenComplete(() {
        print('===== pinned/unpinned group =====');
        _hasError = false;
        _isPinned = pinned;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<int> getTotalGroupsCount() async {
    const String fieldName = 'count';
    final DocumentReference ref =
        FirebaseFirestore.instance.collection('item_count').doc('groups_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increaseGroupCount() async {
    await getTotalGroupsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('groups_count')
          .update({'count': documentCount + 1});
    });
  }

  Future decreaseGroupCount() async {
    await getTotalGroupsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('groups_count')
          .update({'count': documentCount - 1});
    });
  }

  Future addPostOnGroup(String groupId, Post post) async {
    try {
      await firestore
          .collection('groups')
          .doc(groupId)
          .collection('posts')
          .doc(post.postId)
          .set(post.toJson())
          .then((value) {
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<bool> inviteUser(Group g, WUser u) async {
    bool invited = false;
    try {
      await firestore
          .collection('groups')
          .doc(g.id)
          .collection('invite_users')
          .doc(u.uid)
          .set(u.toJson())
          .then((value) {
        invited = true;
      }).onError((error, stackTrace) {});
    } catch (e) {
      print(e.toString());
    }
    return invited;
  }

  Future joinGroup(Group g, String uid) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'invite_groups': FieldValue.arrayRemove([g.id])
      }).then((value) async {
        print('===== removed group to users collection =====');
        await firestore.collection('groups').doc(g.id).update({
          'invite_users': FieldValue.arrayRemove([uid])
        }).then((value) async {
          print('===== removed users to groups collection =====');
          await firestore.collection('groups').doc(g.id).update({
            'members': FieldValue.arrayUnion([uid])
          }).then((value) {
            notifyListeners();
          });
        });
      });
    } catch (e) {
      print(e);
      _errorCode = e.toString();
      notifyListeners();
    }
  }
}
