import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/user.dart';

import '../models/group.dart';
import '../models/post.dart';

class GroupFollowBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Group> _data = [];
  List<Group> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Group? _group;
  Group? get group => _group;

  Future getGroups(mounted, String uid, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('groups')
          .where('owner_uid', whereNotIn: [uid])
          .orderBy('owner_uid')
          .orderBy(orderBy, descending: true)
          .limit(5)
          .get();
    } else {
      rawData = await firestore
          .collection('groups')
          .where('owner_uid', whereNotIn: [uid])
          .orderBy('owner_uid')
          .orderBy(orderBy, descending: true)
          .startAfter([_lastVisible!['owner_uid'], _lastVisible![orderBy]])
          .limit(5)
          .get();
    }

    if (rawData.docs.isNotEmpty) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Group.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {}

  afterPopSelection(value, mounted, uid, orderBy) {
    _popSelection = value;
    onRefresh(mounted, uid, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(mounted, uid, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getGroups(mounted, uid, orderBy);
    notifyListeners();
  }

  Future updateGroupList(
      String gid, String key, String value, bool isAdd) async {
    try {
      // update group list data
      await firestore.collection('groups').doc(gid).update({
        key: isAdd == true
            ? FieldValue.arrayUnion([value])
            : FieldValue.arrayRemove([value])
      }).whenComplete(() {
        print('===== updated group list data =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future getGroup(String gid) async {
    try {
      await firestore.collection('groups').doc(gid).get().then((value) {
        _group = Group.fromFirestore(value);
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }
}
