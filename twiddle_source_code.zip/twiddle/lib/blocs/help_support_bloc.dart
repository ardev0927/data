import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HelpSupportBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  bool _hasError = false;
  bool? get hasError => _hasError;

  Future submit(String uid, String name, String issue, String describe) async {
    try {
      var data = {
        'uid': uid,
        'name': name,
        'issue_type': issue,
        'issue_describe': describe,
      };

      var support = await firestore.collection('help_support').add(data);

      await firestore
          .collection('help_support')
          .doc(support.id)
          .update({'id': support.id}).then((value) {
        _hasError = false;
      });

      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      notifyListeners();
    }
    return null;
  }
}
