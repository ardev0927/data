import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/interest.dart';
import 'package:twiddle/models/user.dart';

class InterestBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  List<Interest> _data = [];
  List<Interest> get data => _data;

  List<Interest> _myInterests = [];
  List<Interest> get myInterests => _myInterests;

  bool? _isJoined;
  bool? get isJoined => _isJoined;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Future<void> getData(mounted) async {
    _snap.clear();
    _data.clear();

    QuerySnapshot rawData;
    rawData = await firestore.collection('interests').limit(10).get();
    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Interest.fromFirestore(e)).toList();
        _data.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  Future<void> filterDataWithName(List<String> names, mounted) async {
    List<DocumentSnapshot> snap = [];
    _myInterests.clear();

    if (names.isEmpty) {
      _isLoading = false;
      _hasData = false;
      return;
    }

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('interests')
        .where('name', whereIn: names)
        .limit(10)
        .get();

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        snap.addAll(rawData.docs);
        _myInterests = snap.map((e) => Interest.fromFirestore(e)).toList();
        _myInterests.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  Future<void> getMyData(uid, mounted) async {
    List<DocumentSnapshot> snap = [];
    _myInterests.clear();

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('interests')
        .where('uids', arrayContains: uid)
        .limit(10)
        .get();

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        snap.addAll(rawData.docs);
        _myInterests = snap.map((e) => Interest.fromFirestore(e)).toList();
        _myInterests.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(mounted) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(mounted);
    notifyListeners();
  }

  Future joinOrLeft(docId, uid) async {
    try {
      var interest = await firestore.collection('interests').doc(docId).get();

      if (List.from(interest['uids']).contains(uid)) {
        await firestore.collection('interests').doc(docId).update({
          'uids': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isJoined = false;
          _hasError = false;
        });
      } else {
        await firestore.collection('interests').doc(docId).update({
          'uids': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isJoined = true;
          _hasError = false;
        });
      }
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<List<String>> getSuggestionUid(uid) async {
    List<String> uids = [];
    await firestore.collection('users').doc(uid).get().then((snap) {
      final List<String> requests = List.from(snap['friend_request']);
      final List<String> friends = List.from(snap['friends']);

      uids.addAll(requests);
      uids.addAll(friends);
      uids.add(uid);
    });
    notifyListeners();
    return uids;
  }
}
