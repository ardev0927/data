import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twiddle/models/notification.dart';

class NotificationBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  bool? _subscribed;
  bool? get subscribed => _subscribed;

  int _notificationLength = 0;
  int get notificationLength => _notificationLength;

  int _savedNlength = 0;
  int get savedNlength => _savedNlength;

  int _notificationFinalLength = 0;
  int get notificationFinalLength => _notificationFinalLength;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];

  List<NotificationModel> _data = [];
  List<NotificationModel> get data => _data;

  Future<Null> getData(uid, mounted, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('notifications')
          .doc(uid)
          .collection('user_notification')
          .orderBy(orderBy, descending: true)
          .limit(10)
          .get();
    } else {
      rawData = await firestore
          .collection('notifications')
          .doc(uid)
          .collection('user_notification')
          .orderBy(orderBy, descending: true)
          .limit(10)
          .get();
    }

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => NotificationModel.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
  }

  afterPopSelection(uid, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(uid, mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, mounted, orderBy);
    notifyListeners();
  }

  Future addNotification(String uid, String title, int type, String typedata,
      String useravatar, String timestamp) async {
    var data = {
      'notificaion_id': '',
      'title': title,
      'type': type,
      'typedata': typedata,
      'uid': uid,
      'useravatar': useravatar,
      'timestamp': timestamp,
    };
    try {
      var notification = await firestore
          .collection('notifications')
          .doc(uid)
          .collection('user_notification')
          .add(data);
      print('===== Added notification =====');
      print('===== notification id ${notification.id} =====');
      // update notification id
      await firestore
          .collection('notifications')
          .doc(uid)
          .collection('user_notification')
          .doc(notification.id)
          .update({'notificaion_id': notification.id});
      var ret = await notification.get();
      increaseNotificationCount(uid)
          .whenComplete(() => print('Increased notification count'));
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deleteNotification(NotificationModel nm) async {
    try {
      // delete post id
      await firestore
          .collection('notifications')
          .doc(nm.uid)
          .collection('user_notification')
          .doc(nm.id)
          .delete()
          .whenComplete(() {
        print('===== deleted notification =====');
        // decrease point count
        decreaseNotificationCount(nm.uid!).whenComplete(
            () => print('===== decrease notification count ====='));
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<int> getTotalNotificationsCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increaseNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount + 1});
    });
  }

  Future firstNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount});
    });
  }

  Future decreaseNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      if (documentCount > 0) {
        await FirebaseFirestore.instance
            .collection('notifications')
            .doc(uid)
            .collection('count')
            .doc('notification_count')
            .update({'count': documentCount - 1});
      }
    });
  }

  Future handleNotificationlength() async {
    await getNlengthFromSP().then((value) {
      getNotificationLengthFromDatabase().then((_length) {
        _notificationLength = _length;
        _notificationFinalLength = _notificationLength - savedNlength;
        notifyListeners();
      });
    });
  }

  Future<int> getNotificationLengthFromDatabase() async {
    final DocumentReference ref =
        firestore.collection('item_count').doc('notifications_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemlength = snap['count'] ?? 0;
      return itemlength;
    } else {
      return 0;
    }
  }

  Future getNlengthFromSP() async {
    final SharedPreferences sp = await SharedPreferences.getInstance();
    int _savedLength = sp.get('saved length') as int? ?? 0;
    _savedNlength = _savedLength;
    notifyListeners();
  }

  Future saveNlengthToSP() async {
    final SharedPreferences sp = await SharedPreferences.getInstance();
    sp.setInt('saved length', _notificationLength);
    _savedNlength = _notificationLength;
    handleNotificationlength();
    notifyListeners();
  }

  Future _handleIosNotificationPermissaion() async {
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      print('User granted provisional permission');
    } else {
      print('User declined or has not accepted permission');
    }
  }

  Future initFirebasePushNotification(context) async {
    // if (Platform.isIOS) {
    _handleIosNotificationPermissaion();
    // }
    // handleFcmSubscribtion();
    String? _token = await _fcm.getToken();
    print('User FCM Token : $_token');

    SharedPreferences sp = await SharedPreferences.getInstance();
    sp.setString('fcm_token', _token!);

    // RemoteMessage? initialMessage = await _fcm.getInitialMessage();
    // print('inittal message : $initialMessage');
    // if (initialMessage != null) {
    //   nextScreen(context, NotificationsPage());
    // }

    // FirebaseMessaging.onBackgroundMessage((message) async {
    //   print("===== background message received =====");
    //   print(message.notification!.title);
    //   print(message.notification!.body);
    // });

    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      print("onMessage: $message");
      // showinAppDialog(context, message.notification!.title, message.notification!.body);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      // nextScreen(context, NotificationsPage());
    });
    notifyListeners();
  }
}
