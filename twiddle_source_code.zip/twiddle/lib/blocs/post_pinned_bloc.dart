import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../models/post.dart';

class PostPinnedBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Post> _data = [];
  List<Post> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool? _isLiked;
  bool? get isLiked => _isLiked;

  bool? _isShared;
  bool? get isShared => _isShared;

  Post? _post;
  Post? get post => _post;

  Future getData(uid, mounted, String orderBy) async {
    try {
      _hasData = true;
      QuerySnapshot rawData;

      if (_lastVisible == null) {
        rawData = await firestore
            .collection('posts')
            .where('uid', isEqualTo: uid)
            .where('pinned', isEqualTo: true)
            .orderBy(orderBy, descending: true)
            .limit(10)
            .get();
      } else {
        rawData = await firestore
            .collection('posts')
            .where('uid', isEqualTo: uid)
            .where('pinned', isEqualTo: true)
            .orderBy(orderBy, descending: true)
            .startAfter([_lastVisible![orderBy]])
            .limit(10)
            .get();
      }

      if (rawData.docs.length > 0) {
        _lastVisible = rawData.docs[rawData.docs.length - 1];
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Post.fromFirestore(e)).toList();
      } else {
        if (_lastVisible == null) {
          _isLoading = false;
          _hasData = false;
          print('no items');
        } else {
          _isLoading = false;
          _hasData = true;
          print('no more items');
        }
      }

      notifyListeners();
    } catch (e) {
      print(e.toString());
      notifyListeners();
    }
    return null;
  }

  afterPopSelection(uid, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(uid, mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onInit() {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    // notifyListeners();
  }

  onRefresh(uid, mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, mounted, orderBy);
    notifyListeners();
  }

  Future setLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isLiked = false;
          print('===== unlike =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isLiked = true;
          print('===== like =====');
        });
      }
    });
    notifyListeners();
  }
}
