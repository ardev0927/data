import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/post.dart';

class PostTagBloc extends ChangeNotifier {
  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Post> _data = [];
  List<Post> get data => _data;

  // bool? _hasData;
  // bool? get hasData => _hasData;

  bool? _isLiked;
  bool? get isLiked => _isLiked;

  bool? _isShared;
  bool? get isShared => _isShared;

  Post? _post;
  Post? get post => _post;

  bool? _hasError;
  bool? get hasError => _hasError;

  Future getMyData(uid, mounted, String orderBy) async {
    try {
      _data.clear();
      _snap.clear();

      _hasError = false;
      QuerySnapshot rawData;

      rawData = await firestore
          .collection('posts')
          .where('uid', isEqualTo: uid)
          .where('hide', isEqualTo: false)
          .where('has_tag', isEqualTo: true)
          .orderBy(orderBy, descending: true)
          .get();

      if (rawData.docs.isNotEmpty) {
        if (mounted) {
          _isLoading = false;
          _snap.addAll(rawData.docs);
          _data = _snap.map((e) => Post.fromFirestore(e)).toList();
        }
      } else {
        _isLoading = false;
        _hasError = true;
        print('no items');
      }

      notifyListeners();
    } catch (e) {
      print(e.toString());
      _isLoading = false;
      _hasError = true;
      notifyListeners();
    }
    return null;
  }

  Future setLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isLiked = false;
          print('===== unlike =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isLiked = true;
          print('===== like =====');
        });
      }
    });
    notifyListeners();
  }

  Future setShare(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['shares']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isShared = false;
          print('===== unshare =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isShared = true;
          print('===== share =====');
        });
      }
    });
    notifyListeners();
  }
}
