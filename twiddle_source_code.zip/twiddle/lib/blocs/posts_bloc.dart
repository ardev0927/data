import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/post.dart';
import 'package:twiddle/utils/enums.dart';

import '../models/group.dart';

class PostsBloc extends ChangeNotifier {
  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Post> _data = [];
  List<Post> get data => _data;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _isHidden = false;
  bool get isHidden => _isHidden;

  bool _isLiked = false;
  bool get isLiked => _isLiked;

  bool _isShared = false;
  bool get isShared => _isShared;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Post? _post;
  Post? get post => _post;

  bool _isPinned = false;
  bool get isPinned => _isPinned;

  Future<Null> getData(mounted, String orderBy) async {
    _hasData = true;
    QuerySnapshot rawData;

    if (_lastVisible == null) {
      rawData = await firestore
          .collection('posts')
          .orderBy('pinned', descending: true)
          .orderBy(orderBy, descending: true)
          .limit(10)
          .get();
    } else {
      rawData = await firestore
          .collection('posts')
          .orderBy('pinned', descending: true)
          .orderBy(orderBy, descending: true)
          .startAfter([_lastVisible!['pinned'], _lastVisible![orderBy]])
          .limit(10)
          .get();
    }

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Post.fromFirestore(e)).toList();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }

    notifyListeners();
    return null;
  }

  onInit() {}

  afterPopSelection(value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(mounted, orderBy);
    notifyListeners();
  }

  Future createPost(
      SignInBloc sb,
      int postType,
      List<String> medias,
      String desc,
      String privacy,
      String timestamp,
      String feelingActivity,
      Map<String, Object?> poll,
      Map<String, dynamic> location,
      String article,
      Map<String, dynamic> group,
      bool isGroupPost,
      List<String> tagFriends,
      Map<String, dynamic> sharedPost,
      {String? contentWarning}) async {
    var postData = {
      'uid': sb.uid,
      'username': sb.name,
      'useravatar': sb.imageUrl,
      'media_type': postType,
      'media_url': medias,
      'description': desc,
      'location': location,
      'article': article,
      'timestamp': timestamp,
      'likes': [],
      'views': [],
      'shares': [],
      'comments': 0,
      'privacy': privacy,
      'post_id': '',
      'feeling_activity': feelingActivity,
      'poll': poll,
      'group_post': group,
      'is_group_post': isGroupPost,
      'pinned': false,
      'tag_friends': tagFriends,
      'shared_post': sharedPost,
      'hide': [],
      'has_tag': false,
      'content_warning': contentWarning ?? '',
    };

    try {
      var p = await firestore.collection('posts').add(postData);
      print('===== post done =====');
      print('===== post id ${p.id} =====');
      // update post id
      await firestore.collection('posts').doc(p.id).update({'post_id': p.id});
      var ret = await p.get();
      _post = Post.fromFirestore(ret);
      // increase point count
      increasePostCount()
          .whenComplete(() => print('===== increase post count ====='));
      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future pollPost(SignInBloc sb, int postType, String privacy, String timestamp,
      String feelingActivity, question, option1, option2) async {
    var collectionData = {
      'question': question,
      'option1': option1,
      'option1_votes': 0,
      'option2': option2,
      'option2_votes': 0,
      'votes': 0,
    };

    try {} catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deletePost(Post p) async {
    try {
      // delete post id
      await firestore
          .collection('posts')
          .doc(p.postId)
          .delete()
          .whenComplete(() {
        print('===== deleted post =====');
        // delete image if type is image
        if (p.mediaType == PostType.image || p.mediaType == PostType.video) {
          p.mediaUrls!.forEach((url) {
            FirebaseStorage.instance.refFromURL(url).delete();
          });
        }
        // decrease point count
        decreasePostCount()
            .whenComplete(() => print('===== decrease post count ====='));
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deleteGroupPost(Post p) async {
    try {
      // delete post id
      await firestore
          .collection('posts')
          .doc(p.postId)
          .delete()
          .whenComplete(() async {
        print('===== deleted post =====');
        // decrease point count
        decreasePostCount()
            .whenComplete(() => print('===== decrease post count ====='));

        var g = await firestore
            .collection('groups')
            .doc(p.group!.id!)
            .collection('posts')
            .doc(p.postId)
            .delete();

        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future hideUnhidePost(Post p, String uid) async {
    try {
      await firestore
          .collection('posts')
          .doc(p.postId)
          .get()
          .then((snap) async {
        List<String> hides = List.from(snap['hide']);
        if (hides.contains(uid)) {
          await firestore.collection('posts').doc(p.postId).update({
            'hide': FieldValue.arrayRemove([uid])
          }).then((value) async {
            print('===== un hidden =====');
            _hasError = false;
            _errorCode = '';
            _isHidden = false;
            notifyListeners();
          });
        } else {
          await firestore.collection('posts').doc(p.postId).update({
            'hide': FieldValue.arrayUnion([uid])
          }).then((value) async {
            _isHidden = true;
            _hasError = false;
            _errorCode = '';
            print('===== hidden =====');
            notifyListeners();
          });
        }
      });
      // notifyListeners();
      // await firestore
      //     .collection('posts')
      //     .doc(p.postId)
      //     .update({'hide': value}).whenComplete(() {
      //   print('===== hided post by =====');
      //   _hasError = false;
      //   notifyListeners();
      // }).onError((error, stackTrace) {
      //   _hasError = true;
      //   _errorCode = error.toString();
      //   notifyListeners();
      // });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future tagPost(Post p, bool value) async {
    try {
      // tag post id
      await firestore
          .collection('posts')
          .doc(p.postId)
          .update({'has_tag': value}).whenComplete(() {
        print('===== Has tagged post =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future pinUnpinPost(Post p) async {
    try {
      print('===== ${p.postId} =====');
      bool pinned = !p.pinned!;
      // pin/unpin post
      await firestore
          .collection('posts')
          .doc(p.postId)
          .update({'pinned': pinned}).whenComplete(() {
        print('===== pinned/unpinned post =====');
        // decrease point count
        _hasError = false;
        _isPinned = pinned;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future addPhotosToAlbum(Post p, List<String> images) async {
    try {
      await firestore.collection('posts').doc(p.postId).update(
          {'media_url': FieldValue.arrayUnion(images)}).whenComplete(() {
        print('===== Added photos to album posts =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<int> getTotalPostsCount() async {
    const String fieldName = 'count';
    final DocumentReference ref =
        FirebaseFirestore.instance.collection('item_count').doc('posts_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount + 1});
    });
  }

  Future decreasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount - 1});
    });
  }

  Future setLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isLiked = false;
          print('===== unlike =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'likes': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isLiked = true;
          print('===== like =====');
        });
      }
    });
    notifyListeners();
  }

  Future getLike(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['likes']);
      if (likes.contains(uid)) {
        _isLiked = true;
      } else {
        _isLiked = false;
      }
    });
    notifyListeners();
  }

  Future setShare(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['shares']);
      if (likes.contains(uid)) {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayRemove([uid])
        }).then((value) async {
          _isShared = false;
          print('===== unshare =====');
        });
      } else {
        await firestore.collection('posts').doc(p.postId).update({
          'shares': FieldValue.arrayUnion([uid])
        }).then((value) async {
          _isShared = true;
          print('===== share =====');
        });
      }
    });
    notifyListeners();
  }

  Future getShare(uid, Post p) async {
    await firestore.collection('posts').doc(p.postId).get().then((snap) async {
      List<String> likes = List.from(snap['shares']);
      if (likes.contains(uid)) {
        _isShared = true;
      } else {
        _isShared = false;
      }
    });
    notifyListeners();
  }

  Future<bool> isReportedPost(Post p) async {
    bool isReported = false;

    try {
      await firestore
          .collection('report_posts')
          .doc(p.postId)
          .get()
          .then((value) {
        var post = Post.fromFirestore(value);
        if (post.reported == true) {
          isReported = true;
        }
      }).onError((error, stackTrace) {});
    } catch (e) {
      print(e.toString());
    }

    return isReported;
  }

  Future reportPost(Post p) async {
    try {
      p.reported = true;
      await firestore
          .collection('report_posts')
          .doc(p.postId)
          .set(p.toJson())
          .then((value) {
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = error.toString();
        notifyListeners();
      });
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }
}
