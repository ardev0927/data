import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/user_story.dart';
import 'package:twiddle/utils/convert_time_ago.dart';

class StoriesBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];

  List<UserStory> _data = [];
  List<UserStory> get data => _data;

  Future<Null> getData(String uid, bool mounted, String orderBy) async {
    try {
      _hasData = true;
      QuerySnapshot rawData;

      List<String> uids = await getFriendsUid(uid);
      uids.add(uid);

      if (_lastVisible == null) {
        rawData = await firestore
            .collection('stories')
            .where('uid', whereIn: uids)
            .orderBy(orderBy, descending: true)
            .limit(10)
            .get();
      } else {
        rawData = await firestore
            .collection('stories')
            .where('uid', whereIn: uids)
            .orderBy(orderBy, descending: true)
            .startAfter([_lastVisible![orderBy]])
            .limit(10)
            .get();
      }

      if (rawData.docs.isNotEmpty) {
        _lastVisible = rawData.docs[rawData.docs.length - 1];
        if (mounted) {
          _isLoading = false;
          _snap.addAll(rawData.docs);
          _data = _snap.map((e) => UserStory.fromFirestore(e)).toList();
        }
      } else {
        if (_lastVisible == null) {
          _isLoading = false;
          _hasData = false;
          print('no items');
        } else {
          _isLoading = false;
          _hasData = true;
          print('no more items');
        }
      }

      notifyListeners();
    } catch (e) {
      print(e.toString());
      notifyListeners();
    }

    return null;
  }

  onInit() {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
  }

  afterPopSelection(uid, value, mounted, orderBy) {
    _popSelection = value;
    onRefresh(uid, mounted, orderBy);
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, mounted, orderBy) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, mounted, orderBy);
    notifyListeners();
  }

  Future addUserStory(
    String uid,
    String username,
    String useravatar,
    String media,
    String timestamp,
  ) async {
    var data = {
      'uid': uid,
      'username': username,
      'useravatar': useravatar,
      'media': media,
      'timestamp': timestamp,
    };
    try {
      var userstory = await firestore.collection('stories').doc(uid).set(data);
      print('===== Added user story =====');
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deleteUserStory(
    String uid,
  ) async {
    try {
      await firestore.collection('stories').doc(uid).delete().whenComplete(() {
        print('===== Successfully deleted user story =====');
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = stackTrace.toString();
        notifyListeners();
      });
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<List<String>> getFriendsUid(uid) async {
    List<String> uids = [];
    await firestore.collection('users').doc(uid).get().then((snap) {
      final List<String> friends = List.from(snap['friends']);

      uids.addAll(friends);
    });
    notifyListeners();
    return uids;
  }
}
