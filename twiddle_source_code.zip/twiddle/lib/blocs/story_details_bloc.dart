import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/story.dart';
import 'package:twiddle/models/user_story.dart';

class StoryDetialBloc extends ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  String _popSelection = 'recent';
  String get popupSelection => _popSelection;

  bool? _hasData;
  bool? get hasData => _hasData;

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  List<DocumentSnapshot> _snap = [];

  List<Story> _data = [];
  List<Story> get data => _data;

  UserStory? _userStory;
  UserStory? get userStory => _userStory;

  Future<Null> getStoriesDetail(uid, String orderBy) async {
    QuerySnapshot rawData;

    _snap.clear();
    _data.clear();

    try {
      rawData = await firestore
          .collection('stories')
          .doc(uid)
          .collection('user_stories')
          .orderBy(orderBy, descending: true)
          .get();

      if (rawData.docs.isNotEmpty) {
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => Story.fromFirestore(e)).toList();
      }

      _hasError = false;
      notifyListeners();
    } catch (e) {
      print(e.toString());
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }

    return null;
  }

  onInit() {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
  }

  Future addStory(
    String uid,
    String username,
    String useravatar,
    String storyType,
    String media,
    String thumbnail,
    String caption,
    String timestamp,
  ) async {
    var data = {
      'id': '',
      'uid': uid,
      'username': username,
      'useravatar': useravatar,
      'story_type': storyType,
      'media': media,
      'thumbnail': thumbnail,
      'caption': caption,
      'views': [],
      'timestamp': timestamp,
    };
    try {
      var story = await firestore
          .collection('stories')
          .doc(uid)
          .collection('user_stories')
          .add(data);
      print('===== Added stories =====');
      print('===== story id ${story.id} =====');
      // update notification id
      await firestore
          .collection('stories')
          .doc(uid)
          .collection('user_stories')
          .doc(story.id)
          .update({'id': story.id});
      var ret = await story.get();
      _userStory = UserStory.fromFirestore(ret);
      increaseStoriesCount(uid)
          .whenComplete(() => print('Increased story count'));
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future deleteUserStory(String uid, String storyId) async {
    try {
      await firestore
          .collection('stories')
          .doc(uid)
          .collection('user_stories')
          .doc(storyId)
          .delete()
          .whenComplete(() {
        print('===== Successfully deleted story =====');
        decreaseStoriesCount(uid);
        _hasError = false;
        notifyListeners();
      }).onError((error, stackTrace) {
        _hasError = true;
        _errorCode = stackTrace.toString();
        notifyListeners();
      });
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<int> getTotalStoriesCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('stories')
        .doc(uid)
        .collection('count')
        .doc('stories_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increaseStoriesCount(String uid) async {
    await getTotalStoriesCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('stories')
          .doc(uid)
          .collection('count')
          .doc('stories_count')
          .update({'count': documentCount + 1});
    });
  }

  Future decreaseStoriesCount(String uid) async {
    await getTotalStoriesCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('stories')
          .doc(uid)
          .collection('count')
          .doc('stories_count')
          .update({'count': documentCount - 1});
    });
  }
}
