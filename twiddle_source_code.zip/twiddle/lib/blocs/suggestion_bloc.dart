import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/user.dart';

class SuggestionBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  List<WUser> _data = [];
  List<WUser> get data => _data;

  Future<void> getData(String uid, mounted) async {
    _snap.clear();
    _data.clear();

    List<String> tempUids = [];
    // tempUids.addAll(uids);
    // tempUids.add(uid);

    tempUids = await getSuggestionUid(uid);

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('users')
        .where('uid', whereNotIn: tempUids)
        .limit(10)
        .get();
    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _data = _snap.map((e) => WUser.fromFirestore(e)).toList();
        _data.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no items');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more items');
      }
    }
    notifyListeners();
  }

  setData(WUser user, int index) {
    if (_data.contains(user)) {
      _data[index] = user;
    }
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRefresh(uid, mounted) {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
    getData(uid, mounted);
    notifyListeners();
  }

  onInit() {
    _isLoading = true;
    _snap.clear();
    _data.clear();
    _lastVisible = null;
  }

  Future<List<String>> getSuggestionUid(uid) async {
    List<String> uids = [];
    await firestore.collection('users').doc(uid).get().then((snap) {
      final List<String> requests = List.from(snap['friend_request']);
      final List<String> friends = List.from(snap['friends']);

      uids.addAll(requests);
      uids.addAll(friends);
      uids.add(uid);
    });
    notifyListeners();
    return uids;
  }
}
