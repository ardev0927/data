import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/relationship.dart';
import 'package:twiddle/models/user.dart';

class TagFriendsBloc with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool? _isRequested;
  bool? get isRequested => _isRequested;

  List<WUser> _users = [];
  List<WUser> get users => _users;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Future<void> getUsers(List<String> uids, mounted) async {
    if (uids.isEmpty) {
      _isLoading = false;
      _hasData = false;
      // notifyListeners();
      return;
    }

    onInit();

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('users')
        .where('uid', whereIn: uids)
        .limit(10)
        .get();

    if (rawData.docs.isNotEmpty) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _users = _snap.map((e) => WUser.fromFirestore(e)).toList();
        _users.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no users');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more users');
      }
    }
    notifyListeners();
  }

  onInit() async {
    _snap.clear();
    _users.clear();
    _isLoading = true;
    _hasData = true;
    _lastVisible = null;
  }
}
