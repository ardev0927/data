import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/relationship.dart';
import 'package:twiddle/models/user.dart';

class UserBlock with ChangeNotifier {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<DocumentSnapshot> _snap = [];

  DocumentSnapshot? _lastVisible;
  DocumentSnapshot? get lastVisible => _lastVisible;

  bool _isLoading = true;
  bool get isLoading => _isLoading;

  bool? _hasData;
  bool? get hasData => _hasData;

  bool _isRequested = false;
  bool? get isRequested => _isRequested;

  bool _isUnrequested = false;
  bool? get isUnrequested => _isUnrequested;

  bool? _isFriend;
  bool? get isFriend => _isFriend;

  WUser? _data;
  WUser? get data => _data;

  List<WUser> _users = [];
  List<WUser> get users => _users;

  bool _hasError = false;
  bool get hasError => _hasError;

  String? _errorCode;
  String? get errorCode => _errorCode;

  Future<WUser?> getWUser(uid) async {
    WUser? user;
    var ret = await firestore.collection('users').doc(uid).get();

    if (ret.exists) {
      user = WUser.fromFirestore(ret);
    }

    notifyListeners();
    return user;
  }

  Future<void> getUser(uid, mounted) async {
    _hasData = true;
    var ret = await firestore.collection('users').doc(uid).get();

    if (ret.exists) {
      if (mounted) {
        _isLoading = false;
        _data = WUser.fromFirestore(ret);
      }
    } else {
      _hasData = false;
      _isLoading = false;
    }

    notifyListeners();
  }

  Future<void> getOwner(uid) async {
    try {
      var ret = await firestore.collection('users').doc(uid).get();
      if (ret.exists) {
        _data = WUser.fromFirestore(ret);
        _hasError = false;
      } else {
        _hasError = true;
      }
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<void> getUsers(List<String> uids, mounted) async {
    _isLoading = true;
    _snap.clear();
    _users.clear();

    if (uids.isEmpty) {
      _isLoading = false;
      _hasData = false;
      // notifyListeners();
      return;
    }

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('users')
        .where('uid', whereIn: uids)
        .limit(10)
        .get();

    if (rawData.docs.isNotEmpty) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _users = _snap.map((e) => WUser.fromFirestore(e)).toList();
        _users.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no users');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more users');
      }
    }
    notifyListeners();
  }

  onInit() async {
    _snap.clear();
    _users.clear();
    _isLoading = false;
    _hasData = false;
    _lastVisible = null;
  }

  Future<void> getRandomUsers(uid, mounted) async {
    _snap.clear();
    _users.clear();

    QuerySnapshot rawData;
    rawData = await firestore
        .collection('users')
        .where('uid', whereNotIn: [uid])
        .limit(10)
        .get();

    if (rawData.docs.length > 0) {
      _lastVisible = rawData.docs[rawData.docs.length - 1];
      if (mounted) {
        _isLoading = false;
        _hasData = true;
        _snap.addAll(rawData.docs);
        _users = _snap.map((e) => WUser.fromFirestore(e)).toList();
        _users.sort((a, b) => b.timestamp!.compareTo(a.timestamp!));
        notifyListeners();
      }
    } else {
      if (_lastVisible == null) {
        _isLoading = false;
        _hasData = false;
        print('no users');
      } else {
        _isLoading = false;
        _hasData = true;
        print('no more users');
      }
    }
    notifyListeners();
  }

  Future<void> setRequestFriend(uid, otherUid) async {
    // QuerySnapshot rawData;
    await firestore.collection('users').doc(uid).update({
      'friend_request': FieldValue.arrayUnion([otherUid])
    }).then((value) async {
      print('===== add friend request =====');
      await firestore.collection('users').doc(otherUid).update({
        'friend_response': FieldValue.arrayUnion([uid])
      }).then((value) {
        _isRequested = true;
        print('===== add friend response =====');
      });
    });
    notifyListeners();
  }

  Future<void> setUnRequestFriend(uid, otherUid) async {
    // QuerySnapshot rawData;
    await firestore.collection('users').doc(uid).update({
      'friend_request': FieldValue.arrayRemove([otherUid])
    }).then((value) async {
      print('===== remove friend request =====');
      await firestore.collection('users').doc(otherUid).update({
        'friend_response': FieldValue.arrayRemove([uid])
      }).then((value) {
        _isUnrequested = true;
        print('===== remove friend response =====');
      });
    });
    notifyListeners();
  }

  Future<void> setConfirmFriend(uid, otherUid) async {
    QuerySnapshot rawData;
    await firestore.collection('users').doc(otherUid).update({
      'friend_request': FieldValue.arrayRemove([uid])
    }).then((value) async {
      print('===== remove friend request =====');
      await firestore.collection('users').doc(uid).update({
        'friend_response': FieldValue.arrayRemove([otherUid])
      }).then((value) async {
        await firestore.collection('users').doc(otherUid).update({
          'friends': FieldValue.arrayUnion([uid])
        }).then((value) async {
          await firestore.collection('users').doc(uid).update({
            'friends': FieldValue.arrayUnion([otherUid])
          }).then((value) {
            _isFriend = true;
            print('===== be friend =====');
          });
        });
      });
    });
    notifyListeners();
  }

  Future<void> blockUser(uid, otherUid) async {
    await firestore.collection('users').doc(uid).update({
      'blocked_users': FieldValue.arrayUnion([otherUid])
    }).then((value) async {
      var snap1 = await firestore.collection('users').doc(otherUid).get();

      WUser? user;
      if (snap1.exists) {
        user = WUser.fromFirestore(snap1);
        await firestore
            .collection('users')
            .doc(uid)
            .collection('blocked_users')
            .doc(user.uid)
            .set(user.toJson());

        /// set block to other user
        await firestore.collection('users').doc(otherUid).update({
          'blocked_users': FieldValue.arrayUnion([uid])
        }).then((value) async {
          var snap2 = await firestore.collection('users').doc(uid).get();
          WUser? u;
          u = WUser.fromFirestore(snap2);
          await firestore
              .collection('users')
              .doc(otherUid)
              .collection('blocked_users')
              .doc(u.uid)
              .set(u.toJson());
          notifyListeners();
        });
      } else {}
    });
    notifyListeners();
  }

  Future<void> unblockUser(uid, otherUid) async {
    await firestore.collection('users').doc(uid).update({
      'blocked_users': FieldValue.arrayRemove([otherUid])
    }).then((value) async {
      var snap1 = await firestore.collection('users').doc(otherUid).get();

      WUser? user;
      if (snap1.exists) {
        user = WUser.fromFirestore(snap1);
        await firestore
            .collection('users')
            .doc(uid)
            .collection('blocked_users')
            .doc(user.uid)
            .delete();

        /// set block to other user
        await firestore.collection('users').doc(otherUid).update({
          'blocked_users': FieldValue.arrayRemove([uid])
        }).then((value) async {
          var snap2 = await firestore.collection('users').doc(uid).get();
          WUser? u;
          u = WUser.fromFirestore(snap2);
          await firestore
              .collection('users')
              .doc(otherUid)
              .collection('blocked_users')
              .doc(u.uid)
              .delete();
          notifyListeners();
        });
      } else {}
    });
    notifyListeners();
  }

  Future<void> removeFriend(uid, otherUid) async {
    await firestore.collection('users').doc(uid).update({
      'friends': FieldValue.arrayRemove([otherUid])
    }).then((value) async {
      await firestore.collection('users').doc(otherUid).update({
        'friends': FieldValue.arrayRemove([uid])
      }).then((value) async {
        _isFriend = false;
        print('===== removed friend =====');
      });
    });
    notifyListeners();
  }

  Future<void> removeRequestFriend(uid, otherUid) async {
    QuerySnapshot rawData;
    await firestore.collection('users').doc(otherUid).update({
      'friend_request': FieldValue.arrayRemove([uid])
    }).then((value) async {
      print('===== remove friend request =====');
      await firestore.collection('users').doc(uid).update({
        'friend_response': FieldValue.arrayRemove([otherUid])
      }).then((value) async {
        _isFriend = false;
        print('===== be friend =====');
      });
    });
    notifyListeners();
  }

  setLoading(bool isloading) {
    _isLoading = isloading;
    notifyListeners();
  }

  onRandomRefresh(uid, mounted) {
    _isLoading = true;
    _snap.clear();
    users.clear();
    _lastVisible = null;
    getRandomUsers(uid, mounted);
    notifyListeners();
  }

  Future<void> addOrRemoveInterest(name, uid) async {
    try {
      var kkk = await firestore.collection('users').doc(uid).get();

      var user = WUser.fromFirestore(kkk);

      if (user.interests!.contains(name)) {
        await firestore.collection('users').doc(uid).update({
          'interests': FieldValue.arrayRemove([name])
        }).then((value) async {
          print('===== removed $name interest =====');
          _hasError = false;
        });
      } else {
        await firestore.collection('users').doc(uid).update({
          'interests': FieldValue.arrayUnion([name])
        }).then((value) {
          print('===== added $name interest =====');
          _hasError = false;
        });
      }
      notifyListeners();
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateProfile(
    String uid,
    String hometown,
    String worksat,
    String studied,
    String lives,
    Relationship? relationship,
    String interests,
    String birth,
    String genger,
    String hometownPrivacy,
    String worksatPrivacy,
    String studiedatPrivacy,
    String livesinPrivacy,
    String relationshipPrivacy,
    String birthdatePrivacy,
    String genderPrivacy,
  ) async {
    try {
      List<String> inters = [];
      if (interests != '') {
        inters.addAll(interests.split(', '));
      }

      var data = {
        'info': {
          'hometown': hometown,
          'works_at': worksat,
          'studied_at': studied,
          'lives_in': lives,
          'relationship_status': relationship?.toJson(),
          // 'interests': inters,
          'birthdate': birth,
          'gender': genger,
          'hometown_privacy': hometownPrivacy,
          'works_at_privacy': worksatPrivacy,
          'studied_at_privacy': studiedatPrivacy,
          'lives_in_privacy': livesinPrivacy,
          'relationship_status_privacy': relationshipPrivacy,
          'birthdate_privacy': birthdatePrivacy,
          'gender_privacy': genderPrivacy,
        }
      };

      await firestore.collection('users').doc(uid).update(data).then((value) {
        _hasError = false;
        notifyListeners();
      });
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateCoverPhoto(String uid, String cover) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'cover_url': cover,
      }).then((value) {});
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateAvatarPhoto(String uid, String avatar) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'image_url': avatar,
      }).then((value) {});
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future updateState(String uid, String status) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'status': status,
      }).then((value) {});
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<String> getUserStatus(String uid) async {
    String status = '';

    var snapshot = await firestore.collection('users').doc(uid).get();
    var user = WUser.fromFirestore(snapshot);
    status = user.status!;

    return status;
  }

  Future updateFcmToken(String uid, String fcmToken) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'fcm_token': fcmToken,
      }).then((value) {});
    } catch (e) {
      _hasError = true;
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future inviteGroup(Group g, String uid) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'invite_groups': FieldValue.arrayUnion([g.id])
      }).then((value) async {
        print('===== invited group to users collection =====');
        await firestore.collection('groups').doc(g.id).update({
          'invite_users': FieldValue.arrayUnion([uid])
        }).then((value) {
          print('===== invited users to groups collection =====');
          notifyListeners();
        });
      });
    } catch (e) {
      print(e);
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future unInviteGroup(Group g, String uid) async {
    try {
      await firestore.collection('users').doc(uid).update({
        'invite_groups': FieldValue.arrayRemove([g.id])
      }).then((value) async {
        print('===== uninvited group to users collection =====');
        await firestore.collection('groups').doc(g.id).update({
          'invite_users': FieldValue.arrayRemove([uid])
        }).then((value) {
          print('===== uninvited users to groups collection =====');
          notifyListeners();
        });
      });
    } catch (e) {
      print(e);
      _errorCode = e.toString();
      notifyListeners();
    }
  }

  Future<List<String>> getInviteGroups(String uid) async {
    List<String> groupIds = [];
    try {
      var snapshot = await firestore.collection('users').doc(uid).get();
      var user = WUser.fromFirestore(snapshot);
      groupIds.addAll(user.inviteGroups!);
    } catch (e) {
      print(e);
      _errorCode = e.toString();
    }
    return groupIds;
  }
}
