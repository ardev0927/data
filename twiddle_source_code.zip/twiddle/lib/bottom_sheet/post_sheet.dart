// Bottom sheet for post more
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:twiddle/models/user.dart';

import '../config/config.dart';
import '../models/post.dart';

showMoreSheet(
  BuildContext ctx,
  WUser u,
  Post p,
  bool showPinned,
  String ownUid,
  bool showReport, {
  required Function()? onPinTap,
  required Function()? onFollowTap,
  required Function()? onReportTap,
  required Function()? onHideTap,
  required Function()? onDeleteTap,
  Function()? onReportPost,
  Function()? onCopyLink,
}) {
  showModalBottomSheet(
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16))),
    elevation: 10,
    context: ctx,
    builder: (ctx) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                  },
                  icon: Icon(Icons.clear)),
            ],
          ),
          // Pin/Unpin
          showPinned == false
              ? Container()
              : InkWell(
                  onTap: onPinTap,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        p.pinned == true
                            ? SvgPicture.asset('assets/images/unpin.svg')
                            : Icon(Icons.push_pin_outlined,
                                color: Config().text90Color),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            p.pinned == true
                                ? 'unpin_post'.tr()
                                : 'pin_post'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
          // Follow/Unfollow
          // ownUid != p.uid
          //     ? InkWell(
          //         onTap: onFollowTap,
          //         child: Padding(
          //           padding: const EdgeInsets.all(16.0),
          //           child: Row(
          //             children: [
          //               Icon(Icons.person_outline, color: Config().text90Color),
          //               Padding(
          //                 padding: const EdgeInsets.only(left: 16),
          //                 child: Text(
          //                   (u.friends!.contains(p.uid) == true ||
          //                           u.friendRequests!.contains(p.uid) == true ||
          //                           u.friendResponses!.contains(p.uid) == true)
          //                       ? '${'follow'.tr()} ${p.username}'
          //                       : '${'unfollow'.tr()} ${p.username}',
          //                   style: TextStyle(
          //                       fontSize: 16,
          //                       fontWeight: FontWeight.w600,
          //                       color: Config().text90Color),
          //                 ),
          //               ),
          //             ],
          //           ),
          //         ),
          //       )
          //     : Container(),
          // Report Post
          showReport == false
              ? Container()
              : InkWell(
                  onTap: onReportPost,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.report_outlined,
                            color: Config().text90Color),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'report_post'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
          // Copy linke
          // InkWell(
          //   onTap: onCopyLink,
          //   child: Padding(
          //     padding: const EdgeInsets.all(16.0),
          //     child: Row(
          //       children: [
          //         Icon(Icons.content_copy_rounded, color: Config().text90Color),
          //         Padding(
          //           padding: const EdgeInsets.only(left: 16),
          //           child: Text(
          //             'copy_link'.tr(),
          //             style: TextStyle(
          //                 fontSize: 16,
          //                 fontWeight: FontWeight.w600,
          //                 color: Config().text90Color),
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
          // Hide Post
          InkWell(
            onTap: onHideTap,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.hide_image_outlined, color: Config().text90Color),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text(
                      'hide_post'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Delete Post
          ownUid == p.uid
              ? InkWell(
                  onTap: onDeleteTap,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline_outlined,
                            color: Config().text90Color),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'delete_post'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Container(),
        ],
      );
    },
  );
}
