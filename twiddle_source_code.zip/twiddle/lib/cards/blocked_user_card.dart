import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../config/config.dart';
import '../models/group.dart';
import '../models/user.dart';

class BlockedUserCard extends StatelessWidget {
  final WUser d;
  final Group g;
  final String heroTag;
  final Function() onUnblockPressed;

  const BlockedUserCard({
    super.key,
    required this.d,
    required this.g,
    required this.heroTag,
    required this.onUnblockPressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.avatar!),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                d.name!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text100Color),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: onUnblockPressed,
              style: ElevatedButton.styleFrom(
                  backgroundColor: Config().primary10Color),
              child: Text(
                'unblock'.tr(),
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.black),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
