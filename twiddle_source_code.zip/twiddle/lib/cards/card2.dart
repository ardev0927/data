import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:twiddle/models/post.dart';

import '../utils/cached_image.dart';

class Card2 extends StatelessWidget {
  const Card2(
      {super.key,
      required this.p,
      required this.onItemTap,
      required this.mode});

  final String p;
  final Function() onItemTap;
  final int mode;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTap,
      child: Container(
        padding: const EdgeInsets.only(left: 0, top: 0),
        height: mode == 1 ? 160 : 0,
        width: mode == 1 ? 110 : 0,
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            mode == 2
                ? Container(
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.red, width: 2),
                        borderRadius: BorderRadius.circular(8)),
                    child: CustomCacheImage(
                      imageUrl: p,
                      radius: 8.0,
                      circularShape: true,
                    ),
                  )
                : Container(
                    height: 160,
                    width: mode == 1 ? 110 : 160,
                    decoration: BoxDecoration(
                        border: Border.all(color: Colors.red, width: 2),
                        borderRadius: BorderRadius.circular(8)),
                    child: CustomCacheImage(
                      imageUrl: p,
                      radius: 8.0,
                      circularShape: true,
                    ),
                  ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.red,
                    child: SvgPicture.asset('assets/images/add.svg'),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: Text(
                      'add_story'.tr(),
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            // VideoIcon(
            //   contentType: d.contentType,
            //   iconSize: 80,
            // )
          ],
        ),
      ),
    );
  }
}
