import 'dart:ui' as ui;
import 'dart:async';
import 'package:any_link_preview/any_link_preview.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/utils/cached_image_ratio.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../models/post.dart';
import '../utils/cached_image.dart';
import '../utils/feeling_utils.dart';
import '../utils/get_thumbnail_video.dart';

class Card3 extends StatelessWidget {
  final Post d;
  final String time;

  Card3({
    super.key,
    required this.d,
    required this.time,
  });

  @override
  Widget build(BuildContext context) {
    print(d.postId);
    return Container(
      // margin: const EdgeInsets.symmetric(horizontal: 16),
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(color: Config().text4Color),
      child: Wrap(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(d.useravatar!),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              d.username!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: Config().text100Color),
                            ),
                            d.feeling!.isEmpty
                                ? Container()
                                : mapFeeling[d.feeling] == null
                                    ? Text(
                                        ' - ${d.feeling!}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                            fontSize: 13,
                                            fontWeight: FontWeight.w400,
                                            color: Config().text90Color),
                                      )
                                    : Row(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 8, right: 4),
                                            child: SvgPicture.asset(
                                                'assets/images/${d.feeling!}.svg',
                                                width: 18,
                                                height: 18),
                                          ),
                                          Text(
                                            d.feeling!.contains('feeling_')
                                                ? 'Feeling '
                                                : ' ',
                                            style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w400,
                                                color: Config().text90Color),
                                          ),
                                          Text(
                                            mapFeeling[d.feeling]!,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.w600,
                                                color: d.tagFriends!.isNotEmpty
                                                    ? Config().text70Color
                                                    : Config().text90Color),
                                          ),
                                        ],
                                      ),
                          ],
                        ),
                        Row(
                          children: [
                            SvgPicture.asset('assets/images/public.svg',
                                width: 15, height: 15),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                time,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text100Color),
                              ),
                            ),
                            d.pinned == true
                                ? const Padding(
                                    padding: EdgeInsets.only(left: 16),
                                    child:
                                        Icon(Icons.push_pin_outlined, size: 15),
                                  )
                                : Container(),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                // const Spacer(),
                // InkWell(
                //   onTap: onMoreTap,
                //   child: Container(
                //     width: 15,
                //     height: 15,
                //     child: SvgPicture.asset(
                //       'assets/images/more_horiz.svg',
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
          d.description == ''
              ? Container()
              : Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Linkify(
                    // onOpen: (link) async {
                    //   bool isLaunch = await canLaunchUrl(Uri.parse(link.url));
                    //   if (isLaunch) {
                    //     await launchUrl(Uri.parse(link.url));
                    //   }
                    // },
                    text: d.description!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
                  ),
                ),
          const SizedBox(height: 10),
          // View image/video or gif
          Stack(
            alignment: Alignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _contentType(context),
              ),
              // VideoIcon(
              //   contentType: d.contentType,
              //   iconSize: 80,
              // )
            ],
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  _contentType(context) {
    if (d.mediaType == 1 || d.mediaType == 7 || d.mediaType == 9) {
      if (d.mediaUrls!.length == 1) {
        return SizedBox(
          height: 200,
          width: MediaQuery.of(context).size.width,
          child: _imageWidget(context),
        );
      } else {
        return SizedBox(
          height: 200,
          width: MediaQuery.of(context).size.width,
          child: _imageWidget(context),
        );
      }
    } else if (d.mediaType == 8) {
      return _pollWidget(context);
    } else if (d.mediaType == 3) {
      return textWidget(context);
    } else if (d.mediaType == 10) {
      return SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 200,
        child: locationWidget(),
      );
    } else if (d.mediaType == 11) {
      return articleWidget(context);
    } else if (d.mediaType == 5) {
      return liveStreamWidget(context);
    }
  }

  liveStreamWidget(context) {
    return Container(
      height: 250,
      width: MediaQuery.of(context).size.width,
      color: Colors.black87,
      child: Stack(
        children: [
          // Hero(
          //   tag: heroTag,
          //   child: CustomCacheImage(
          //     imageUrl: d.mediaUrls![0],
          //     radius: 0.0,
          //     circularShape: false,
          //   ),
          // ),
          Align(
            alignment: Alignment.topRight,
            child: Container(
              height: 30,
              width: 180,
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.red),
              child: Center(
                child: Text(
                  'Live Stream Ended',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Config().whiteColor),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  getYoutubeUrlsInText(String text) {
    List<String> youtubeList = [];
    RegExp exp = RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
    Iterable<RegExpMatch> matches = exp.allMatches(text);
    matches.forEach((match) {
      var url = text.substring(match.start, match.end);
      if (url.contains('youtube') || url.contains('youtu.be')) {
        youtubeList.add(url);
      }
      print(url);
    });
    return youtubeList;
  }

  convertShortsUrlToId(String shortUrl) {
    var ret = shortUrl.split('/shorts/');
    if (ret.length > 1) {
      String? last = ret[1].substring(0, 11);
      return last;
    } else {
      return null;
    }
  }

  textWidget(context) {
    List<String> youtubeList = getYoutubeUrlsInText(d.description!);
    if (youtubeList.isEmpty) return Container();

    YoutubePlayerController _controller;
    String? videoId;
    if (youtubeList[0].contains('/shorts/')) {
      videoId = convertShortsUrlToId(youtubeList[0]);
    } else {
      videoId = YoutubePlayer.convertUrlToId(youtubeList[0]);
    }
    String thumbnailUrl = getThumbnail(videoId: videoId ?? "");

    return youtubeWidget(youtubeList[0], thumbnailUrl);
  }

  youtubeWidget(String url, String thumbUrl) {
    return SizedBox(
      // width: MediaQuery.of(context),
      height: 300,
      child: Stack(
        children: [
          CustomCacheImage(
            imageUrl: thumbUrl,
            radius: 0.0,
            circularShape: false,
          ),
          Center(
            child: IconButton(
              onPressed: () async {
                bool canLaunch = await canLaunchUrl(Uri.parse(url));
                if (canLaunch) {
                  launchUrl(Uri.parse(url));
                } else {
                  throw 'Could not launch $url';
                }
              },
              icon: Icon(
                Icons.play_circle_fill,
                color: Colors.white,
                size: 50,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String getYouTubeUrl(String content) {
    RegExp regExp = RegExp(
        r'((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?');
    String? matches = regExp.stringMatch(content);
    if (matches == null) {
      return ''; // Always returns here while the video URL is in the content paramter
    }
    final String youTubeUrl = matches;
    return youTubeUrl;
  }

  articleWidget(context) {
    print('===== article ${d.article} =====');
    var youtubeUrl = getYouTubeUrl(d.article!);
    // bool isYoutube = d.article!.contains('youtube');
    if (youtubeUrl.isNotEmpty) {
      YoutubePlayerController _controller;
      String? videoId;
      if (d.article!.contains('/shorts/')) {
        videoId = convertShortsUrlToId(d.article!);
      } else {
        videoId = YoutubePlayer.convertUrlToId(d.article!);
      }
      String thumbnailUrl = getThumbnail(videoId: videoId ?? "");

      // return youtubeWidget(d.article!, thumbnailUrl);
      if (videoId == null) return Container();
      _controller = YoutubePlayerController(
        initialVideoId: videoId,
        flags: const YoutubePlayerFlags(
          autoPlay: false,
          mute: false,
          forceHD: false,
          loop: true,
          controlsVisibleAtStart: false,
          enableCaption: false,
        ),
      );

      return YoutubePlayer(
        controller: _controller,
        showVideoProgressIndicator: true,
        progressIndicatorColor: Colors.red,
        progressColors: const ProgressBarColors(
          playedColor: Colors.red,
          handleColor: Colors.redAccent,
        ),
        onReady: () {},
        // onReady () {
        //     _controller.addListener(listener);
        // },
      );
    }
    return AnyLinkPreview.builder(
      link: d.article!,
      itemBuilder: (context, metadata, imageProvider) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (imageProvider != null)
            Container(
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.width * 0.5,
              ),
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          Container(
            width: double.infinity,
            color: Config().primary10Color,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (metadata.title != null)
                  Text(
                    metadata.title!,
                    maxLines: 1,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                const SizedBox(height: 5),
                if (metadata.desc != null)
                  Text(
                    metadata.desc!,
                    maxLines: 5,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                Text(
                  metadata.url ?? d.article!,
                  maxLines: 1,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  locationWidget() {
    return GoogleMap(
      initialCameraPosition: CameraPosition(
          target: LatLng(d.location!.latitude!, d.location!.longitude!),
          zoom: 16),
      mapType: MapType.normal,
      onMapCreated: (controller) {},
      minMaxZoomPreference: MinMaxZoomPreference(0, 16),
    );
  }

  _imageWidget(context) {
    if (d.mediaUrls!.length == 1) {
      return CustomCacheImageRatio(
        imageUrl: d.mediaUrls![0],
        radius: 0.0,
        circularShape: false,
      );
    } else if (d.mediaUrls!.length == 2) {
      return Row(
        children: [
          Expanded(
            child: IntrinsicHeight(
              child: CustomCacheImage(
                imageUrl: d.mediaUrls![0],
                radius: 0.0,
                circularShape: false,
              ),
            ),
          ),
          const VerticalDivider(width: 2),
          Expanded(
            child: IntrinsicHeight(
              child: CustomCacheImage(
                imageUrl: d.mediaUrls![1],
                radius: 0.0,
                circularShape: false,
              ),
            ),
          ),
        ],
      );
    } else {
      return Row(
        children: [
          Expanded(
            child: IntrinsicHeight(
              child: CustomCacheImage(
                imageUrl: d.mediaUrls![0],
                radius: 0.0,
                circularShape: false,
              ),
            ),
          ),
          const VerticalDivider(width: 2),
          Expanded(
            child: IntrinsicHeight(
              child: Column(
                children: [
                  Expanded(
                    child: CustomCacheImage(
                      imageUrl: d.mediaUrls![1],
                      radius: 0.0,
                      circularShape: false,
                    ),
                  ),
                  const Divider(height: 2),
                  Expanded(
                    child: Stack(
                      children: [
                        CustomCacheImage(
                          imageUrl: d.mediaUrls![2],
                          radius: 0.0,
                          circularShape: false,
                        ),
                        d.mediaUrls!.length > 3
                            ? Center(
                                child: Text(
                                  '+${d.mediaUrls!.length - 3} Photos',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }
  }

  _pollWidget(context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      color: Colors.white,
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            d.poll!.question!,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text90Color),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Config().text4Color,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option1!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Config().text4Color,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option2!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
