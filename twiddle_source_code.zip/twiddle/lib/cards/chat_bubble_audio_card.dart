import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/bubble_type.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_5.dart';

import '../config/config.dart';

class ChatBubbleAudioCard extends StatefulWidget {
  const ChatBubbleAudioCard({
    super.key,
    required this.avatar,
    required this.msg,
    required this.bubbleType,
    required this.time,
  });

  final String avatar;
  final String msg;
  final BubbleType bubbleType;
  final String time;

  @override
  State<ChatBubbleAudioCard> createState() => _ChatBubbleAudioCardState();
}

class _ChatBubbleAudioCardState extends State<ChatBubbleAudioCard> {
  AudioPlayer player = AudioPlayer();

  int maxduration = 100;
  int currentpos = 0;
  //int time = 0;

  bool isplaying = false;
  bool audioplayed = false;

  String time = '';

  @override
  void initState() {
    Future.delayed(Duration.zero, () async {
      await player.setSourceUrl(widget.msg);
      player.onDurationChanged.listen((Duration d) {
        //get the duration of audio
        maxduration = d.inMilliseconds;
        var sec = d.inSeconds % 60;

        time =
            '${d.inMinutes.toString().padLeft(2, '0')}:${sec.toString().padLeft(2, '0')}';
        print(
            '===== Time ${NumberFormat("###").format(d.inMinutes)}:${NumberFormat("###").format(sec)} =====');
        setState(() {});
      });

      player.onPositionChanged.listen((Duration p) {
        currentpos =
            p.inMilliseconds; //get the current position of playing audio

        setState(() {
          //refresh the UI
        });
      });

      player.onPlayerComplete.listen((event) {
        setState(() {
          currentpos = 0;
          isplaying = false;
          audioplayed = false;
        });
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: widget.bubbleType == BubbleType.sendBubble
          ? const EdgeInsets.only(right: 16)
          : const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: widget.bubbleType == BubbleType.sendBubble
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: [
          widget.bubbleType != BubbleType.sendBubble
              ? Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.grey[300],
                      backgroundImage:
                          CachedNetworkImageProvider(widget.avatar),
                    ),
                    const SizedBox(width: 8),
                    ChatBubble(
                      clipper: ChatBubbleClipper5(type: widget.bubbleType),
                      alignment: widget.bubbleType == BubbleType.sendBubble
                          ? Alignment.topRight
                          : Alignment.topLeft,
                      // margin: const EdgeInsets.only(top: 10),
                      backGroundColor:
                          widget.bubbleType == BubbleType.sendBubble
                              ? Config().primary30Color
                              : Config().text4Color,
                      child: Container(
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.7,
                        ),
                        child: messageWidget(),
                      ),
                    ),
                  ],
                )
              : ChatBubble(
                  clipper: ChatBubbleClipper5(type: widget.bubbleType),
                  alignment: widget.bubbleType == BubbleType.sendBubble
                      ? Alignment.topRight
                      : Alignment.topLeft,
                  // margin: const EdgeInsets.only(top: 10),
                  backGroundColor: widget.bubbleType == BubbleType.sendBubble
                      ? Config().primary30Color
                      : Config().text4Color,
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.6,
                    ),
                    child: messageWidget(),
                  ),
                ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: widget.time.isEmpty
                ? Container()
                : Text(
                    convertTime(widget.time),
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        color: Config().text60Color),
                  ),
          ),
        ],
      ),
    );
  }

  convertTime(timestamp) {
    if (timestamp == '') return '';
    var input = DateTime.parse(timestamp).toLocal();

    return DateFormat('HH:mm').format(input);
  }

  messageWidget() {
    return Row(
      children: [
        GestureDetector(
          onTap: () async {
            if (!isplaying && !audioplayed) {
              print(widget.msg);
              await player.play(UrlSource(widget.msg));
              setState(() {
                isplaying = true;
                audioplayed = true;
              });
            } else if (audioplayed && !isplaying) {
              await player.resume();
              //resume success
              setState(() {
                isplaying = true;
                audioplayed = true;
              });
            } else {
              await player.pause();
              //pause success
              setState(() {
                isplaying = false;
              });
            }
          },
          child: SizedBox(
            width: 30,
            height: 30,
            child: Icon(
              isplaying ? Icons.pause : Icons.play_arrow,
              color: widget.bubbleType == BubbleType.sendBubble
                  ? Colors.white
                  : Config().primary30Color,
              size: 30,
            ),
          ),
        ),
        Expanded(
          child: Slider(
            value: double.parse(currentpos.toString()),
            min: 0,
            max: double.parse(maxduration.toString()),
            thumbColor: widget.bubbleType == BubbleType.sendBubble
                ? Colors.blue
                : Colors.white,
            activeColor: widget.bubbleType == BubbleType.sendBubble
                ? Colors.white
                : Config().appColor,
            inactiveColor: Config().text20Color,
            onChanged: (value) async {
              int seekval = value.round();
              await player.seek(Duration(milliseconds: seekval));
            },
            onChangeEnd: (value) async {},
          ),
        ),
        Text(
          time,
          style: TextStyle(
              color: widget.bubbleType == BubbleType.sendBubble
                  ? Colors.white
                  : Colors.blue),
        ),
      ],
    );
  }
}
