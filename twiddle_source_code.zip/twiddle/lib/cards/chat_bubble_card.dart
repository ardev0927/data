import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/bubble_type.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_5.dart';
import 'package:twiddle/utils/enums.dart';

import '../config/config.dart';

class ChatBubbleCard extends StatelessWidget {
  ChatBubbleCard({
    super.key,
    required this.avatar,
    required this.msg,
    required this.type,
    required this.bubbleType,
    required this.time,
  });

  final String avatar;
  final String msg;
  final BubbleType bubbleType;
  final String time;
  final int type;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: bubbleType == BubbleType.sendBubble
          ? const EdgeInsets.only(right: 16)
          : const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: bubbleType == BubbleType.sendBubble
            ? CrossAxisAlignment.end
            : CrossAxisAlignment.start,
        children: [
          bubbleType != BubbleType.sendBubble
              ? Row(
                  children: [
                    CircleAvatar(
                      radius: 20,
                      backgroundColor: Colors.grey[300],
                      backgroundImage: CachedNetworkImageProvider(avatar),
                    ),
                    const SizedBox(width: 8),
                    ChatBubble(
                      padding: type == MessageType.image
                          ? const EdgeInsets.all(0)
                          : const EdgeInsets.all(8),

                      clipper: ChatBubbleClipper5(type: bubbleType),
                      alignment: bubbleType == BubbleType.sendBubble
                          ? Alignment.topRight
                          : Alignment.topLeft,
                      // margin: const EdgeInsets.only(top: 10),
                      backGroundColor: bubbleType == BubbleType.sendBubble
                          ? Config().primary30Color
                          : Config().text4Color,
                      child: Container(
                        constraints: BoxConstraints(
                          maxWidth: MediaQuery.of(context).size.width * 0.7,
                        ),
                        child: messageWidget(),
                      ),
                    ),
                  ],
                )
              : ChatBubble(
                  padding: type == MessageType.image
                      ? const EdgeInsets.all(0)
                      : const EdgeInsets.all(8),
                  clipper: ChatBubbleClipper5(type: bubbleType),
                  alignment: bubbleType == BubbleType.sendBubble
                      ? Alignment.topRight
                      : Alignment.topLeft,
                  // margin: const EdgeInsets.only(top: 10),
                  backGroundColor: bubbleType == BubbleType.sendBubble
                      ? Config().primary30Color
                      : Config().text4Color,
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth: type == MessageType.voice
                          ? MediaQuery.of(context).size.width * 0.5
                          : MediaQuery.of(context).size.width * 0.7,
                    ),
                    child: messageWidget(),
                  ),
                ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: time.isEmpty
                ? Container()
                : Text(
                    convertTime(time),
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        color: Config().text60Color),
                  ),
          ),
        ],
      ),
    );
  }

  convertTime(timestamp) {
    if (timestamp == '') return '';
    var input = DateTime.parse(timestamp).toLocal();

    return DateFormat('HH:mm').format(input);
  }

  messageWidget() {
    switch (type) {
      case MessageType.text:
        return Text(
          msg,
          style: TextStyle(
              color: bubbleType == BubbleType.sendBubble
                  ? Colors.white
                  : Config().text90Color),
        );
      case MessageType.image:
        return ClipRRect(
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(12),
              topRight: const Radius.circular(12),
              bottomLeft: bubbleType == BubbleType.sendBubble
                  ? const Radius.circular(12)
                  : const Radius.circular(0),
              bottomRight: bubbleType == BubbleType.sendBubble
                  ? const Radius.circular(0)
                  : const Radius.circular(12),
            ),
            child: CachedNetworkImage(imageUrl: msg));
      default:
        return Container();
    }
  }
}
