import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:twiddle/models/user.dart';

import '../config/config.dart';

class FriendsCard2 extends StatelessWidget {
  final WUser d;
  final String heroTag;
  final Function() onPressed;

  const FriendsCard2(
      {super.key,
      required this.d,
      required this.heroTag,
      required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: 50,
        height: 50,
        margin: const EdgeInsets.only(left: 8, right: 8),
        child: Column(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.avatar!),
            ),
            // Text(
            //   d.name!,
            //   maxLines: 1,
            //   overflow: TextOverflow.ellipsis,
            //   style: TextStyle(
            //       fontSize: 10,
            //       fontWeight: FontWeight.w400,
            //       color: Config().text80Color),
            // ),
          ],
        ),
      ),
    );
  }
}
