import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../config/config.dart';
import '../models/user.dart';

class FriendsCard4 extends StatelessWidget {
  const FriendsCard4({
    super.key,
    required this.d,
    required this.heroTag,
    required this.onTapped,
  });

  final WUser d;
  final String heroTag;
  final Function()? onTapped;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTapped,
      leading: CircleAvatar(
        radius: 24,
        backgroundColor: Colors.grey[300],
        backgroundImage: CachedNetworkImageProvider(d.avatar!),
      ),
      title: Text(
        d.name!,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Config().text100Color),
      ),
    );
  }
}
