import 'package:flutter/material.dart';

import '../models/group.dart';
import '../utils/cached_image_with_dark.dart';

class GroupCard extends StatelessWidget {
  final Group d;
  final int index;
  final Function()? onTap;
  const GroupCard(
      {Key? key, required this.d, required this.index, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('===== Group id is ${d.id} =====');
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 96,
        height: 100,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            boxShadow: <BoxShadow>[
              BoxShadow(
                  blurRadius: 10,
                  offset: Offset(0, 3),
                  color: Theme.of(context).shadowColor)
            ]),
        child: Stack(
          children: [
            Hero(
              tag: 'group$index',
              child: Container(
                child: CustomCacheImageWithDarkFilterBottom(
                    imageUrl: d.coverPhoto, radius: 5.0),
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Container(
                margin: EdgeInsets.only(left: 15, bottom: 8, right: 10),
                child: Text(
                  d.name!,
                  style: TextStyle(
                      fontSize: 12,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.6),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
