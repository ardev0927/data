import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../blocs/sign_in_bloc.dart';
import '../config/config.dart';
import '../models/group.dart';

class GroupFollowing2Card extends StatelessWidget {
  final Group d;
  final String heroTag;
  final Function() onFollowPressed;
  final Function() onItemTapped;

  GroupFollowing2Card({
    super.key,
    required this.d,
    required this.heroTag,
    required this.onFollowPressed,
    required this.onItemTapped,
  });

  int followStatus = 0;
  String btnTitle = '';

  @override
  Widget build(BuildContext context) {
    validateFollowGroup(context);

    return InkWell(
      onTap: onItemTapped,
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.coverPhoto!),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Config().text100Color),
                    ),
                    Text(
                      '${d.members!.length} members',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text100Color),
                    ),
                  ],
                ),
              ),
            ),
            ElevatedButton(
                onPressed: onFollowPressed,
                style: ElevatedButton.styleFrom(
                  backgroundColor: getBgColorFromStatus(),
                ),
                child: Text(
                  btnTitle,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: getTextColorFromStatus(),
                  ),
                ))
          ],
        ),
      ),
    );
  }

  Color getBgColorFromStatus() {
    Color? color;
    switch (followStatus) {
      case 1:
        color = Config().text4Color;
        break;
      case 2:
        color = Config().primary30Color;
        break;
      default:
    }
    return color!;
  }

  Color getTextColorFromStatus() {
    Color? color;
    switch (followStatus) {
      case 1:
        color = Config().text100Color;
        break;
      case 2:
        color = Colors.white;
        break;
      default:
    }
    return color!;
  }

  validateFollowGroup(BuildContext context) {
    final sb = context.read<SignInBloc>();

    if (d.following!.contains(sb.uid)) {
      btnTitle = 'following'.tr();
      followStatus = 1;
    } else {
      btnTitle = 'follow'.tr();
      followStatus = 2;
    }
  }
}
