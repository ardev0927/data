import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/user.dart';

import '../config/config.dart';
import '../models/group.dart';

class GroupInvitedCard extends StatelessWidget {
  final Group d;
  // final WUser u;
  final String heroTag;
  final double width;
  final Function() onItemTapped;
  final Function() onJoinPressed;
  final Function() onDeletePressed;

  GroupInvitedCard({
    super.key,
    required this.d,
    // required this.u,
    required this.heroTag,
    required this.width,
    required this.onItemTapped,
    required this.onJoinPressed,
    required this.onDeletePressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTapped,
      child: Container(
        // width: width,
        margin: const EdgeInsets.symmetric(vertical: 8),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        decoration: BoxDecoration(
          color: Config().text4Color,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(d.coverPhoto!),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          d.name!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Config().text100Color),
                        ),
                        Text(
                          'Invited you',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Config().text100Color),
                        ),
                        Row(
                          children: [
                            ElevatedButton(
                              onPressed: onJoinPressed,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Config().primary30Color,
                              ),
                              child: Text(
                                'join_group'.tr(),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Config().whiteColor,
                                ),
                              ),
                            ),
                            const SizedBox(width: 20),
                            ElevatedButton(
                              onPressed: onDeletePressed,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Config().text10Color,
                              ),
                              child: Text(
                                'delete_invite'.tr(),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Config().text100Color,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
