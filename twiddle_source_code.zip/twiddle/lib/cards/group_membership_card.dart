import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../blocs/sign_in_bloc.dart';
import '../config/config.dart';
import '../models/group.dart';

class GroupMembershipCard extends StatelessWidget {
  final Group d;
  final String heroTag;
  final Function() onLeavePressed;
  final Function() onItemTapped;

  GroupMembershipCard({
    super.key,
    required this.d,
    required this.heroTag,
    required this.onLeavePressed,
    required this.onItemTapped,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTapped,
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.coverPhoto!),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Config().text100Color),
                    ),
                    Text(
                      '${d.members!.length} members',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text100Color),
                    ),
                  ],
                ),
              ),
            ),
            ElevatedButton(
                onPressed: onLeavePressed,
                style: ElevatedButton.styleFrom(
                  primary: Config().text4Color,
                ),
                child: Text(
                  'leave'.tr(),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color,
                  ),
                ))
          ],
        ),
      ),
    );
  }
}
