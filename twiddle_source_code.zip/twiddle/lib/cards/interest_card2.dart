import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:twiddle/models/user.dart';

import '../config/config.dart';

class InterestCard2 extends StatelessWidget {
  final String avatar;
  final String name;
  final String heroTag;
  bool isJoined;
  final Function() onTap;

  InterestCard2({
    super.key,
    required this.avatar,
    required this.name,
    required this.heroTag,
    required this.onTap,
    required this.isJoined,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(avatar),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text100Color),
                  ),
                ],
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: onTap,
              child: Container(
                width: 45,
                height: 32,
                decoration: BoxDecoration(
                    color: isJoined
                        ? Config().text10Color
                        : Config().primary30Color,
                    borderRadius: BorderRadius.circular(4)),
                child: Icon(isJoined ? Icons.check : Icons.add,
                    color: isJoined ? Config().text100Color : Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // openPopupDialog(context) {
  //   showDialog(
  //       context: context,
  //       builder: (BuildContext context) {
  //         return Dialog(
  //           alignment: Alignment.center,
  //           child: Padding(
  //             padding: const EdgeInsets.all(20.0),
  //             child: Column(
  //               mainAxisSize: MainAxisSize.min,
  //               children: [
  //                 CircleAvatar(
  //                   radius: 28,
  //                   backgroundColor: Colors.grey[300],
  //                   backgroundImage: CachedNetworkImageProvider(d.avatar!),
  //                 ),
  //                 Padding(
  //                   padding: const EdgeInsets.all(16.0),
  //                   child: Text(
  //                     d.name!,
  //                     maxLines: 1,
  //                     overflow: TextOverflow.ellipsis,
  //                     style: TextStyle(
  //                         fontSize: 20,
  //                         fontWeight: FontWeight.w700,
  //                         color: Config().text90Color),
  //                   ),
  //                 ),
  //                 Divider(height: 2, color: Config().text8Color),
  //                 Padding(
  //                   padding: const EdgeInsets.symmetric(vertical: 20),
  //                   child: Text(
  //                     '${'want_block_frind'.tr()} ${d.name!}?',
  //                     textAlign: TextAlign.center,
  //                     style: TextStyle(
  //                         fontSize: 16,
  //                         fontWeight: FontWeight.w400,
  //                         color: Config().text100Color),
  //                   ),
  //                 ),
  //                 Row(
  //                   mainAxisAlignment: MainAxisAlignment.center,
  //                   children: [
  //                     ElevatedButton(
  //                       onPressed: () {
  //                         Navigator.pop(context);
  //                       },
  //                       style: ElevatedButton.styleFrom(
  //                           primary: Config().text20Color,
  //                           fixedSize: Size(100, 40)),
  //                       child: Text(
  //                         'no'.tr(),
  //                         style: TextStyle(
  //                             fontSize: 16,
  //                             fontWeight: FontWeight.w700,
  //                             color: Config().text100Color),
  //                       ),
  //                     ),
  //                     const SizedBox(width: 30),
  //                     ElevatedButton(
  //                       onPressed: onPressed,
  //                       style:
  //                           ElevatedButton.styleFrom(fixedSize: Size(100, 40)),
  //                       child: Text(
  //                         'yes'.tr(),
  //                         style: TextStyle(
  //                             fontSize: 16, fontWeight: FontWeight.w700),
  //                       ),
  //                     )
  //                   ],
  //                 ),
  //               ],
  //             ),
  //           ),
  //         );
  //       });
  // }
}
