import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:twiddle/models/interest.dart';
import 'package:twiddle/models/user.dart';

import '../config/config.dart';

class InterestCard3 extends StatelessWidget {
  final Interest d;
  final String heroTag;
  final Function() onPressed;

  const InterestCard3(
      {super.key,
      required this.d,
      required this.heroTag,
      required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: 48,
        height: 48,
        margin: const EdgeInsets.only(left: 8, right: 8),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Config().text8Color,
          image: DecorationImage(image: CachedNetworkImageProvider(d.image!)),
        ),
      ),
    );
  }
}
