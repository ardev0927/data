import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../config/config.dart';
import '../models/group.dart';
import '../models/user.dart';

class InviteCard extends StatelessWidget {
  final WUser d;
  final Group g;
  final String heroTag;
  final Function() onInvitePressed;

  const InviteCard({
    super.key,
    required this.d,
    required this.g,
    required this.heroTag,
    required this.onInvitePressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.avatar!),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                d.name!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text100Color),
              ),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: onInvitePressed,
              style: ElevatedButton.styleFrom(
                  backgroundColor: d.inviteGroups!.contains(g.id)
                      ? Config().primary10Color
                      : Config().primary30Color),
              child: Text(
                d.inviteGroups!.contains(g.id) ? 'invited'.tr() : 'invite'.tr(),
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: d.inviteGroups!.contains(g.id)
                        ? Colors.black
                        : Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
