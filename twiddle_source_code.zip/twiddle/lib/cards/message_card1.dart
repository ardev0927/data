import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/utils/enums.dart';

import '../config/config.dart';

class MessageCard1 extends StatelessWidget {
  final String avatar;
  final String name;
  final String message;
  final int type;
  final int count;
  final String heroTag;
  final Function() onItemTap;
  final Function() onLongPress;

  const MessageCard1(
      {super.key,
      required this.avatar,
      required this.name,
      required this.message,
      required this.type,
      required this.count,
      required this.heroTag,
      required this.onItemTap,
      required this.onLongPress});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTap,
      onLongPress: onLongPress,
      child: SizedBox(
        width: MediaQuery.of(context).size.width,
        // margin: const EdgeInsets.symmetric(vertical: 16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(avatar),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Config().text100Color),
                  ),
                  subtitleWidget(),
                ],
              ),
            ),
            const Spacer(),
            count > 0
                ? Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Config().primary30Color,
                    ),
                    child: Center(
                      child: Text(
                        '$count',
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: Colors.white),
                      ),
                    ),
                  )
                : Container(),
          ],
        ),
      ),
    );
  }

  subtitleWidget() {
    switch (type) {
      case MessageType.text:
        return Text(
          message,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Config().text60Color),
        );
      case MessageType.image:
        return Row(
          children: [
            Icon(Icons.image_outlined, color: Config().text60Color),
            const SizedBox(width: 8),
            Text(
              'Image',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Config().text60Color),
            )
          ],
        );
      case MessageType.voice:
        return Row(
          children: [
            Icon(Icons.mic, color: Config().text60Color),
            const SizedBox(width: 8),
            Text(
              'Voice',
              style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Config().text60Color),
            )
          ],
        );
        ;
      default:
    }
  }
}
