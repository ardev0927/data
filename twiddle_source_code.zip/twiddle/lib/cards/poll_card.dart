import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:twiddle/config/config.dart';

import '../models/post.dart';
import '../utils/cached_image.dart';

class PoolCard extends StatelessWidget {
  final Post d;
  final String time;
  final String heroTag;
  final Function() onLikePressed;
  final Function() onLikesPressed;
  final bool isLiked;
  final Function() onSharePressed;
  final Function() onSharesPressed;
  final bool isShared;
  final Function() onCommentPressed;
  final Function() onCommentsPressed;
  final Function()? onMoreTap;

  PoolCard({
    super.key,
    required this.d,
    required this.time,
    required this.heroTag,
    required this.onLikePressed,
    required this.onLikesPressed,
    required this.isLiked,
    required this.onSharePressed,
    required this.onSharesPressed,
    required this.isShared,
    required this.onCommentPressed,
    required this.onCommentsPressed,
    this.onMoreTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        decoration: BoxDecoration(
            color: Config().text4Color,
            borderRadius: BorderRadius.circular(5),
            boxShadow: <BoxShadow>[
              BoxShadow(
                  color: Theme.of(context).shadowColor,
                  blurRadius: 10,
                  offset: Offset(0, 3))
            ]),
        child: Wrap(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: CachedNetworkImageProvider(d.useravatar!),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              d.username!,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: Config().text100Color),
                            ),
                            d.feeling!.isEmpty
                                ? Container()
                                : Text(
                                    d.feeling!,
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400,
                                        color: Config().text90Color),
                                  ),
                          ],
                        ),
                        Row(
                          children: [
                            SvgPicture.asset('assets/images/public.svg'),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                time,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text100Color),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: onMoreTap,
                    child: SvgPicture.asset('assets/images/more_horiz.svg'),
                  ),
                ],
              ),
            ),
            d.description == ''
                ? Container()
                : Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Text(
                      d.description!,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    ),
                  ),
            SizedBox(
              height: 10,
            ),
            Stack(
              alignment: Alignment.center,
              children: [
                _pollWidget(context),
                // VideoIcon(
                //   contentType: d.contentType,
                //   iconSize: 80,
                // )
              ],
            ),
            Container(
              // margin: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              TextButton(
                                onPressed: onLikesPressed,
                                child: Text(
                                  '${d.likes!.length} ${'likes'.tr()}',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(
                                onPressed: onCommentsPressed,
                                child: Text(
                                  '${d.comments} ${'comments'.tr()}',
                                  // '${d.comments!.length.length} ${'comments'.tr()}',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: onSharesPressed,
                                child: Text(
                                  '${d.shares!.length} ${'shares'.tr()}',
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    color: Config().text10Color,
                    height: 2,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: onLikePressed,
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/images/like.svg',
                                    color: isLiked == false
                                        ? Config().text90Color
                                        : Config().primary30Color),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'like'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: isLiked == false
                                            ? FontWeight.w400
                                            : FontWeight.w700,
                                        color: isLiked == false
                                            ? Config().text90Color
                                            : Config().primary30Color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextButton(
                            onPressed: onCommentPressed,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset('assets/images/comment.svg'),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'comment'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Config().text90Color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextButton(
                            onPressed: onSharePressed,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                SvgPicture.asset('assets/images/send.svg',
                                    color: isShared == false
                                        ? Config().text90Color
                                        : Config().primary30Color),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'share'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: isShared == false
                                            ? FontWeight.w400
                                            : FontWeight.w700,
                                        color: isShared == false
                                            ? Config().text90Color
                                            : Config().primary30Color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      onTap: () {},
    );
  }

  _pollWidget(context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      color: Config().text4Color,
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            d.poll!.question!,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text90Color),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option1!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option2!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
