import 'dart:ui' as ui;
import 'dart:async';
import 'package:any_link_preview/any_link_preview.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:twiddle/cards/card3.dart';
import 'package:twiddle/cards/youtube_fullscreen.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/utils/cached_image_ratio.dart';
import 'package:twiddle/utils/convert_time_ago.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/loading_cards.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/widgets/app_button.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:webview_flutter/webview_flutter.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:latlong2/latlong.dart' as ll;

import '../models/post.dart';
import '../utils/cached_image.dart';
import '../utils/feeling_utils.dart';
import '../utils/get_thumbnail_video.dart';

class PostCard extends StatelessWidget {
  final Post d;
  final String time;
  final String heroTag;
  final Function() onLikePressed;
  final Function() onLikesPressed;
  final bool isLiked;
  final Function() onSharePressed;
  final Function() onSharesPressed;
  final bool isShared;
  final Function() onCommentPressed;
  final Function() onCommentsPressed;
  final Function()? onMoreTap;
  final Function()? onPhotoTap;
  final Function()? onAvatarTap;
  final Function()? onArticleTap;
  final Function()? onTypeTap;
  final Function()? onSharedTap;
  final Function()? onCWShowPressed;

  PostCard({
    super.key,
    required this.d,
    required this.time,
    required this.heroTag,
    required this.onLikePressed,
    required this.onLikesPressed,
    required this.isLiked,
    required this.onSharePressed,
    required this.onSharesPressed,
    required this.isShared,
    required this.onCommentPressed,
    required this.onCommentsPressed,
    this.onMoreTap,
    required this.onPhotoTap,
    required this.onAvatarTap,
    this.onArticleTap,
    this.onTypeTap,
    this.onSharedTap,
    this.onCWShowPressed,
  });

  String getTagString(String feeling) {
    var names = feeling.substring(5).split(',');
    return names[0];
  }

  getTitleWidget(double width) {
    /// Map
    if (d.mediaType == PostType.checkin) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: d.username,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: ' at ',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
            TextSpan(
              text: d.location!.address,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
          ],
        ),
      );
    }

    /// Tag friend
    if (d.feeling!.contains('with ') && d.tagFriends!.isNotEmpty) {
      var name = getTagString(d.feeling!);
      return InkWell(
        onTap: onTypeTap,
        child: RichText(
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          text: TextSpan(
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
            children: [
              TextSpan(
                text: d.username,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              TextSpan(
                  text: ' is with ',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Config().text100Color)),
              TextSpan(
                text: name,
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              TextSpan(
                  text: d.tagFriends!.length == 1 ? '' : ' and ',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Config().text100Color)),
              TextSpan(
                text: d.tagFriends!.length == 1
                    ? ''
                    : '${d.tagFriends!.length - 1} others',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
            ],
          ),
        ),
      );
    }

    /// Group post
    if (d.isGroupPost == true && d.mediaType != PostType.sharegroup) {
      return InkWell(
        onTap: onTypeTap,
        child: RichText(
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          text: TextSpan(
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
            children: [
              TextSpan(
                text: '${d.username}\n',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              TextSpan(
                  text: d.group!.name,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Config().text100Color)),
            ],
          ),
        ),
      );
    }

    /// Shared to Group
    if (d.isGroupPost == true && d.mediaType == PostType.sharegroup) {
      return InkWell(
        onTap: onTypeTap,
        child: RichText(
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          text: TextSpan(
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
            children: [
              TextSpan(
                text: d.username,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              TextSpan(
                  text: ' shared to ',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text100Color)),
              TextSpan(
                  text: d.group!.name,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color)),
            ],
          ),
        ),
      );
    }

    /// Album
    if (d.mediaType == PostType.album) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: d.username,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: '   ${d.feeling}',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Shared a post
    if (d.mediaType == PostType.share) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: d.username,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: '   shared a post',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Feeling
    if (d.feeling!.isNotEmpty) {
      return Row(
        children: [
          RichText(
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            text: TextSpan(
              children: [
                TextSpan(
                  text: d.username,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
              ],
            ),
          ),
          const SizedBox(width: 4),
          SizedBox(
            width: width * 0.4,
            child: getTextWidget(),
          ),
        ],
      );
    } else {
      return RichText(
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          children: [
            TextSpan(
              text: d.username,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
          ],
        ),
      );
    }
  }

  postAvatar() {
    return SizedBox(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          GestureDetector(
            onTap: onAvatarTap,
            child: CircleAvatar(
              radius: 20,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.useravatar!),
            ),
          ),
          d.group!.name == null
              ? Container()
              : Align(
                  alignment: Alignment.bottomRight,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.grey[300],
                    backgroundImage:
                        CachedNetworkImageProvider(d.group!.coverPhoto!),
                  ),
                ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    print(d.postId);
    var w = MediaQuery.of(context).size.width;
    return Container(
      decoration: BoxDecoration(
        color: Config().whiteColor,
        borderRadius: BorderRadius.circular(5),
        boxShadow: <BoxShadow>[
          BoxShadow(
              color: Config().text4Color, blurRadius: 10, offset: Offset(0, 3))
        ],
      ),
      child: Wrap(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                postAvatar(),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        getTitleWidget(w),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            SvgPicture.asset('assets/images/public.svg',
                                width: 15, height: 15),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                time,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text100Color),
                              ),
                            ),
                            d.pinned == true
                                ? const Padding(
                                    padding: EdgeInsets.only(left: 16),
                                    child:
                                        Icon(Icons.push_pin_outlined, size: 15),
                                  )
                                : Container(),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                // const Spacer(),
                InkWell(
                  onTap: onMoreTap,
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: SvgPicture.asset(
                      'assets/images/more_horiz.svg',
                    ),
                  ),
                ),
              ],
            ),
          ),
          d.description == ''
              ? Container()
              : Container(
                  width: MediaQuery.of(context).size.width,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  // color: Config().secondary20Color,
                  child: getExpandableDescription(),
                ),
          const SizedBox(height: 10),
          const Divider(thickness: 1, height: 1),
          // View image/video or gif
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                color: Config().text4Color,
                child: _contentType(context),
              ),
              // VideoIcon(
              //   contentType: d.contentType,
              //   iconSize: 80,
              // )
            ],
          ),
          // Likes, comments and shares body
          Container(
            // margin: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            TextButton(
                              onPressed: onLikesPressed,
                              child: Text(
                                '${d.likes!.length} ${'likes'.tr()}',
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text90Color),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: onCommentsPressed,
                            child: Text(
                              '${d.comments} ${'comments'.tr()}',
                              // '${d.comments!.length.length} ${'comments'.tr()}',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: Config().text90Color),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(
                            onPressed: onSharesPressed,
                            child: Text(
                              '${d.shares!.length} ${'shares'.tr()}',
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  color: Config().text90Color),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Divider(
                  color: Config().text10Color,
                  height: 2,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Expanded(
                        child: TextButton(
                          onPressed: onLikePressed,
                          child: Row(
                            children: [
                              SvgPicture.asset('assets/images/like.svg',
                                  color: isLiked == false
                                      ? Config().text90Color
                                      : Config().primary30Color),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  'like'.tr(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: isLiked == false
                                          ? FontWeight.w400
                                          : FontWeight.w700,
                                      color: isLiked == false
                                          ? Config().text90Color
                                          : Config().primary30Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: TextButton(
                          onPressed: onCommentPressed,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset('assets/images/comment.svg'),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  'comment'.tr(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: TextButton(
                          onPressed: onSharePressed,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SvgPicture.asset('assets/images/send.svg',
                                  color: isShared == false
                                      ? Config().text90Color
                                      : Config().primary30Color),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  'share'.tr(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: isShared == false
                                          ? FontWeight.w400
                                          : FontWeight.w700,
                                      color: isShared == false
                                          ? Config().text90Color
                                          : Config().primary30Color),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _contentType(context) {
    if (d.mediaType == PostType.image ||
        d.mediaType == PostType.gif ||
        d.mediaType == PostType.album) {
      // image, album, gif
      if (d.mediaUrls!.length == 1) {
        return GestureDetector(
          onTap: onPhotoTap,
          child: _imageWidget(context),
        );
      } else {
        return GestureDetector(
          onTap: onPhotoTap,
          child: SizedBox(
            height: 250,
            width: MediaQuery.of(context).size.width,
            child: _imageWidget(context),
          ),
        );
      }
    } else if (d.mediaType == PostType.poll) {
      // poll post
      return _pollWidget(context);
    } else if (d.mediaType == PostType.text) {
      // only text
      return textWidget(context);
    } else if (d.mediaType == PostType.checkin) {
      // location post
      return SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 250,
        child: Stack(
          children: [
            locationWidget(),
            SizedBox(width: MediaQuery.of(context).size.width, height: 250),
          ],
        ),
      );
    } else if (d.mediaType == PostType.article) {
      // article post
      return articleWidget(context);
    } else if (d.mediaType == PostType.livestream) {
      // live stream post
      return liveStreamWidget(context);
    } else if (d.mediaType == PostType.share ||
        d.mediaType == PostType.sharegroup) {
      // Shared post
      return sharedPostWidget(context);
      // return Container();
    } else if (d.mediaType == PostType.contentwarning) {
      return contentWarningWidget(context);
    } else {
      return const Divider(thickness: 1, height: 1);
    }
  }

  /// Content warning widget
  contentWarningWidget(context) {
    return Container(
      height: 250,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Config().gradientColor1,
            Config().gradientColor2,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Stack(
        children: [
          Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                d.contentWarning!,
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Config().whiteColor),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomRight,
            child: Container(
              height: 50,
              padding: const EdgeInsets.only(bottom: 16, right: 16),
              child: AppButton('show'.tr(), onPressed: onCWShowPressed!),
            ),
          ),
        ],
      ),
    );
  }

  sharedPostWidget(context) {
    return InkWell(
      onTap: onSharedTap,
      child: Card3(
        d: d.sharedPost!,
        time: convertToAgo(d.sharedPost!.timestamp!),
      ),
    );
  }

  liveStreamWidget(context) {
    return Container(
      height: 250,
      width: MediaQuery.of(context).size.width,
      color: Colors.black87,
      child: Stack(
        children: [
          // Hero(
          //   tag: heroTag,
          //   child: CustomCacheImage(
          //     imageUrl: d.mediaUrls![0],
          //     radius: 0.0,
          //     circularShape: false,
          //   ),
          // ),
          Align(
            alignment: Alignment.topRight,
            child: Container(
              height: 30,
              width: 180,
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.red),
              child: Center(
                child: Text(
                  'Live Stream Ended',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Config().whiteColor),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  getExpandableDescription() {
    return ExpandablePanel(
      collapsed: Linkify(
        onOpen: (link) async {
          bool isLaunch = await canLaunchUrl(Uri.parse(link.url));
          if (isLaunch) {
            await launchUrl(Uri.parse(link.url));
          }
        },
        text: d.description!,
        maxLines: 5,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
      ),

      expanded: Linkify(
        onOpen: (link) async {
          bool isLaunch = await canLaunchUrl(Uri.parse(link.url));
          if (isLaunch) {
            await launchUrl(Uri.parse(link.url));
          }
        },
        text: d.description!,
        maxLines: null,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
      ),
      // builder: (context, collapsed, expanded) {},
    );
  }

  getYoutubeUrlsInText(String text) {
    List<String> youtubeList = [];
    RegExp exp = RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
    Iterable<RegExpMatch> matches = exp.allMatches(text);
    matches.forEach((match) {
      var url = text.substring(match.start, match.end);
      if (url.contains('youtube') || url.contains('youtu.be')) {
        youtubeList.add(url);
      }
      print(url);
    });
    return youtubeList;
  }

  convertShortsUrlToId(String shortUrl) {
    var ret = shortUrl.split('/shorts/');
    if (ret.length > 1) {
      String? last = ret[1].substring(0, 11);
      return last;
    } else {
      return null;
    }
  }

  textWidget(context) {
    List<String> youtubeList = getYoutubeUrlsInText(d.description!);
    if (youtubeList.isEmpty) return Container();

    YoutubePlayerController _controller;
    String? videoId;
    if (youtubeList[0].contains('/shorts/')) {
      videoId = convertShortsUrlToId(youtubeList[0]);
    } else {
      videoId = YoutubePlayer.convertUrlToId(youtubeList[0]);
    }
    String thumbnailUrl = getThumbnail(videoId: videoId ?? "");

    return youtubeWidget(youtubeList[0], thumbnailUrl);
    // if (videoId != null) {
    //   _controller = YoutubePlayerController(
    //     initialVideoId: videoId,
    //     flags: const YoutubePlayerFlags(
    //       autoPlay: false,
    //       mute: false,
    //       forceHD: false,
    //       loop: false,
    //       controlsVisibleAtStart: false,
    //       enableCaption: false,
    //     ),
    //   );
    //   return YoutubePlayerBuilder(
    //     onEnterFullScreen: () {
    //       print('===== Full screen =====');
    //     },
    //     onExitFullScreen: () {},
    //     player: YoutubePlayer(
    //       controller: _controller,
    //       showVideoProgressIndicator: true,
    //       progressIndicatorColor: Colors.red,
    //       progressColors: const ProgressBarColors(
    //         playedColor: Colors.red,
    //         handleColor: Colors.redAccent,
    //       ),
    //       onReady: () {},
    //       // onReady () {
    //       //     _controller.addListener(listener);
    //       // },
    //       bottomActions: [
    //         CurrentPosition(),
    //         ProgressBar(
    //           isExpanded: true,
    //           colors: const ProgressBarColors(
    //             playedColor: Colors.red,
    //             handleColor: Colors.redAccent,
    //           ),
    //         ),
    //         RemainingDuration(),
    //         IconButton(
    //           onPressed: () {
    //             nextScreen(context,
    //                 YoutubeFullScreen(youtubePlayerController: _controller));
    //           },
    //           icon: Icon(
    //             Icons.fullscreen_outlined,
    //             color: Config().whiteColor,
    //           ),
    //         ),
    //       ],
    //     ),
    //     builder: (ctx, player) {
    //       return Stack(
    //         children: [
    //           player,
    //           // Align(
    //           //   alignment: Alignment.bottomRight,
    //           //   child: Padding(
    //           //     padding: const EdgeInsets.all(16),
    //           //     child: IconButton(
    //           //       onPressed: () {},
    //           //       icon: Icon(
    //           //         Icons.fullscreen_outlined,
    //           //         color: Config().whiteColor,
    //           //       ),
    //           //     ),
    //           //   ),
    //           // ),
    //         ],
    //       );
    //     },
    //   );
    // } else {
    //   return Container();
    // }
  }

  youtubeWidget(String url, String thumbUrl) {
    return SizedBox(
      // width: MediaQuery.of(context),
      height: 300,
      child: Stack(
        children: [
          CustomCacheImage(
            imageUrl: thumbUrl,
            radius: 0.0,
            circularShape: false,
          ),
          Center(
            child: IconButton(
              onPressed: () async {
                bool canLaunch = await canLaunchUrl(Uri.parse(url));
                if (canLaunch) {
                  launchUrl(Uri.parse(url));
                } else {
                  throw 'Could not launch $url';
                }
              },
              icon: Icon(
                Icons.play_circle_fill,
                color: Colors.white,
                size: 50,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String getYouTubeUrl(String content) {
    RegExp regExp = RegExp(
        r'((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?');
    String? matches = regExp.stringMatch(content);
    if (matches == null) {
      return ''; // Always returns here while the video URL is in the content paramter
    }
    final String youTubeUrl = matches;
    return youTubeUrl;
  }

  articleWidget(context) {
    print('===== article ${d.article} =====');
    var youtubeUrl = getYouTubeUrl(d.article!);
    // bool isYoutube = d.article!.contains('youtube');
    if (youtubeUrl.isNotEmpty) {
      YoutubePlayerController _controller;
      String? videoId;
      if (d.article!.contains('/shorts/')) {
        videoId = convertShortsUrlToId(d.article!);
      } else {
        videoId = YoutubePlayer.convertUrlToId(d.article!);
      }
      String thumbnailUrl = getThumbnail(videoId: videoId ?? "");

      // return youtubeWidget(d.article!, thumbnailUrl);
      if (videoId == null) return Container();
      _controller = YoutubePlayerController(
        initialVideoId: videoId,
        flags: const YoutubePlayerFlags(
          autoPlay: false,
          mute: false,
          forceHD: false,
          loop: true,
          controlsVisibleAtStart: false,
          enableCaption: true,
        ),
      );

      return YoutubePlayer(
        controller: _controller,
        showVideoProgressIndicator: true,
        progressIndicatorColor: Colors.red,
        progressColors: const ProgressBarColors(
          playedColor: Colors.red,
          handleColor: Colors.redAccent,
        ),
        onReady: () {},
        // onReady () {
        //     _controller.addListener(listener);
        // },
      );
    }
    return GestureDetector(
      onTap: onArticleTap,
      child: AnyLinkPreview.builder(
        link: d.article!,
        errorWidget: const SizedBox(
          height: 200,
          child: Center(
            child: Text("This article couldn't be found!"),
          ),
        ),
        itemBuilder: (context, metadata, imageProvider) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (imageProvider != null)
              Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.width * 0.5,
                ),
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: imageProvider,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            Container(
              width: double.infinity,
              color: Config().primary10Color,
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (metadata.title != null)
                    Text(
                      metadata.title!,
                      maxLines: 1,
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  const SizedBox(height: 5),
                  if (metadata.desc != null)
                    Text(
                      metadata.desc!,
                      maxLines: 5,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  Text(
                    metadata.url ?? d.article!,
                    maxLines: 1,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  locationWidget() {
    return FlutterMap(
      options: MapOptions(
        enableScrollWheel: false,
        absorbPanEventsOnScrollables: false,
        center: ll.LatLng(
            d.location!.latitude!,
            d.location!
                .longitude!), //LatLng(51.5, -0.09), //LatLng(45.5231, -122.6765),
        zoom: 16, //10.0,
        onTap: (tapPosition, point) {},
      ),
      children: [
        TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'),
      ],
    );
    // return GoogleMap(
    //   initialCameraPosition: CameraPosition(
    //       target: LatLng(d.location!.latitude!, d.location!.longitude!),
    //       zoom: 16),
    //   mapType: MapType.normal,
    //   rotateGesturesEnabled: false,
    //   scrollGesturesEnabled: false,
    //   zoomControlsEnabled: false,
    //   zoomGesturesEnabled: false,
    // );
  }

  _imageWidget(context) {
    if (d.mediaUrls!.length == 1) {
      return Hero(
        tag: heroTag,
        child: CustomCacheImageRatio(
          imageUrl: d.mediaUrls![0],
          radius: 0.0,
          circularShape: false,
        ),
      );
    } else if (d.mediaUrls!.length == 2) {
      return Row(
        children: [
          Expanded(
            child: IntrinsicHeight(
              child: Hero(
                tag: '$heroTag 1',
                child: CustomCacheImage(
                  imageUrl: d.mediaUrls![0],
                  radius: 0.0,
                  circularShape: false,
                ),
              ),
            ),
          ),
          const VerticalDivider(width: 2),
          Expanded(
            child: IntrinsicHeight(
              child: Hero(
                tag: '$heroTag 2',
                child: CustomCacheImage(
                  imageUrl: d.mediaUrls![1],
                  radius: 0.0,
                  circularShape: false,
                ),
              ),
            ),
          ),
        ],
      );
    } else {
      return Row(
        children: [
          Expanded(
            child: IntrinsicHeight(
              child: Hero(
                tag: '$heroTag 1',
                child: CustomCacheImage(
                  imageUrl: d.mediaUrls![0],
                  radius: 0.0,
                  circularShape: false,
                ),
              ),
            ),
          ),
          const VerticalDivider(width: 2),
          Expanded(
            child: IntrinsicHeight(
              child: Column(
                children: [
                  Expanded(
                    child: Hero(
                      tag: '$heroTag 2',
                      child: CustomCacheImage(
                        imageUrl: d.mediaUrls![1],
                        radius: 0.0,
                        circularShape: false,
                      ),
                    ),
                  ),
                  const Divider(height: 2),
                  Expanded(
                    child: Stack(
                      children: [
                        Hero(
                          tag: '$heroTag 3',
                          child: CustomCacheImage(
                            imageUrl: d.mediaUrls![2],
                            radius: 0.0,
                            circularShape: false,
                          ),
                        ),
                        d.mediaUrls!.length > 3
                            ? Center(
                                child: Text(
                                  '+${d.mediaUrls!.length - 3} Photos',
                                  style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }
  }

  _pollWidget(context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      color: Colors.white,
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            d.poll!.question!,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text90Color),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Config().text4Color,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option1!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.only(top: 20),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
                color: Config().text4Color,
                borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    d.poll!.option2!,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'votes'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                    Text(
                      '0%',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Config().text80Color),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  getShortName(String fullname) {
    var shortName = '';
    var splits = fullname.split(' ');
    if (splits.length > 1 && splits[1].length > 1) {
      shortName = '${splits[0]} ${splits[1][0]}...';
    } else {
      shortName = fullname;
    }
    return shortName;
  }

  getTextWidget() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, right: 4),
          child: SvgPicture.asset('assets/images/${d.feeling!}.svg',
              width: 15, height: 15),
        ),
        Text(
          d.feeling!.contains('feeling_') ? 'Feeling ' : ' ',
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: Config().text90Color),
        ),
        Text(
          mapFeeling[d.feeling]!,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: d.tagFriends!.isNotEmpty
                  ? Config().text70Color
                  : Config().text90Color),
        ),
      ],
    );
  }
}
