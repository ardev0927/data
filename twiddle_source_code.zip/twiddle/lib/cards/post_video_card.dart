import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import '../config/config.dart';
import '../models/post.dart';
import '../utils/enums.dart';
import '../utils/feeling_utils.dart';

class PostVideoCard extends StatefulWidget {
  const PostVideoCard({
    super.key,
    required this.d,
    required this.time,
    required this.heroTag,
    required this.onLikePressed,
    required this.onLikesPressed,
    required this.isLiked,
    required this.onSharePressed,
    required this.onSharesPressed,
    required this.isShared,
    required this.onCommentPressed,
    required this.onCommentsPressed,
    this.onMoreTap,
    required this.onPhotoTap,
    required this.onAvatarTap,
    this.onTypeTap,
  });

  final Post d;
  final String time;
  final String heroTag;
  final Function() onLikePressed;
  final Function() onLikesPressed;
  final bool isLiked;
  final Function() onSharePressed;
  final Function() onSharesPressed;
  final bool isShared;
  final Function() onCommentPressed;
  final Function() onCommentsPressed;
  final Function()? onMoreTap;
  final Function()? onPhotoTap;
  final Function()? onAvatarTap;
  final Function()? onTypeTap;

  @override
  State<PostVideoCard> createState() => _PostVideoCardState();
}

class _PostVideoCardState extends State<PostVideoCard> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  int? bufferDelay;
  late SharedPreferences sp;

  @override
  void initState() {
    super.initState();
    initializePlayer();
    initSP();
  }

  initSP() async {
    sp = await SharedPreferences.getInstance();
  }

  @override
  void dispose() {
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> initializePlayer() async {
    _videoPlayerController =
        VideoPlayerController.network(widget.d.mediaUrls![0]);
    await Future.wait([
      _videoPlayerController!.initialize(),
    ]);
    _createChewieController();
    setState(() {});
  }

  void _createChewieController() {
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController!,
      autoPlay: getAutoPlay(),
      looping: false,
      hideControlsTimer: const Duration(seconds: 3),
      showControls: true,

      // showControls: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.blueAccent,
        handleColor: Colors.blue,
        backgroundColor: Colors.grey,
        bufferedColor: Colors.white,
      ),
      placeholder: Container(
        color: Colors.black,
      ),
      autoInitialize: false,
    );
  }

  getAutoPlay() {
    return sp.getBool('video_auto_play') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        decoration: BoxDecoration(
          color: Config().whiteColor,
        ),
        child: Wrap(
          children: [
            // Header widget
            headerWidget(),
            // Description widget
            descriptionWidget(),
            SizedBox(
              height: 10,
            ),
            // View video or gif
            contentWidget(),
            // Likes, comments and shares body
            bottomWidget(),
          ],
        ),
      ),
      onTap: () {},
    );
  }

  postAvatar() {
    return SizedBox(
      width: 40,
      height: 40,
      child: Stack(
        children: [
          GestureDetector(
            onTap: widget.onAvatarTap,
            child: CircleAvatar(
              radius: 20,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(widget.d.useravatar!),
            ),
          ),
          widget.d.group!.name == null
              ? Container()
              : Align(
                  alignment: Alignment.bottomRight,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.grey[300],
                    backgroundImage:
                        CachedNetworkImageProvider(widget.d.group!.coverPhoto!),
                  ),
                ),
        ],
      ),
    );
  }

  getTitleWidget(double width) {
    /// Map
    if (widget.d.mediaType == PostType.checkin) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: widget.d.username,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: ' at ',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
            TextSpan(
              text: widget.d.location!.address,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
          ],
        ),
      );
    }

    /// Tag friend
    if (widget.d.feeling!.contains('with ') &&
        widget.d.tagFriends!.isNotEmpty) {
      var name = getTagString(widget.d.feeling!);
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: widget.d.username,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: ' is with ',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
            TextSpan(
              text: name,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: widget.d.tagFriends!.length == 1 ? '' : ' and ',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
            TextSpan(
              text: widget.d.tagFriends!.length == 1
                  ? ''
                  : '${widget.d.tagFriends!.length - 1} others',
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
          ],
        ),
      );
    }

    /// Group post
    if (widget.d.isGroupPost == true &&
        widget.d.mediaType != PostType.sharegroup) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: '${widget.d.username}\n',
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: widget.d.group!.name,
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Shared to Group
    if (widget.d.isGroupPost == true &&
        widget.d.mediaType == PostType.sharegroup) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: widget.d.username,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: ' shared to ',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
            TextSpan(
                text: widget.d.group!.name,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Album
    if (widget.d.mediaType == PostType.album) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: widget.d.username,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: '   ${widget.d.feeling}',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Shared a post
    if (widget.d.mediaType == PostType.share) {
      return RichText(
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          children: [
            TextSpan(
              text: widget.d.username,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            TextSpan(
                text: '   shared a post',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text100Color)),
          ],
        ),
      );
    }

    /// Feeling
    if (widget.d.feeling!.isNotEmpty) {
      return Row(
        children: [
          Text(
            widget.d.username!,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: width * 0.4,
            child: getTextWidget(),
          ),
        ],
      );
    } else {
      return Text(
        widget.d.username!,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: Config().text100Color),
      );
    }
  }

  String getTagString(String feeling) {
    var names = feeling.substring(5).split(',');
    return names[0];
  }

  headerWidget() {
    var w = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          postAvatar(),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  getTitleWidget(w),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      SvgPicture.asset('assets/images/public.svg',
                          width: 15, height: 15),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          widget.time,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                              color: Config().text100Color),
                        ),
                      ),
                      widget.d.pinned == true
                          ? const Padding(
                              padding: EdgeInsets.only(left: 16),
                              child: Icon(Icons.push_pin_outlined, size: 15),
                            )
                          : Container(),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // const Spacer(),
          InkWell(
            onTap: widget.onMoreTap,
            child: Container(
              width: 15,
              height: 15,
              child: SvgPicture.asset(
                'assets/images/more_horiz.svg',
              ),
            ),
          ),
        ],
      ),
    );
  }

  descriptionWidget() {
    return widget.d.description == ''
        ? Container()
        : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              widget.d.description!,
              maxLines: 8,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
            ),
          );
  }

  bottomWidget() {
    return Container(
      // margin: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      TextButton(
                        onPressed: widget.onLikesPressed,
                        child: Text(
                          '${widget.d.likes!.length} ${'likes'.tr()}',
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: widget.onCommentsPressed,
                      child: Text(
                        '${widget.d.comments} ${'comments'.tr()}',
                        // '${widget.d.comments!.length.length} ${'comments'.tr()}',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(
                      onPressed: widget.onSharesPressed,
                      child: Text(
                        '${widget.d.shares!.length} ${'shares'.tr()}',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Divider(
            color: Config().text10Color,
            height: 2,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: widget.onLikePressed,
                    child: Row(
                      children: [
                        SvgPicture.asset('assets/images/like.svg',
                            color: widget.isLiked == false
                                ? Config().text90Color
                                : Config().primary30Color),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            'like'.tr(),
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: widget.isLiked == false
                                    ? FontWeight.w400
                                    : FontWeight.w700,
                                color: widget.isLiked == false
                                    ? Config().text90Color
                                    : Config().primary30Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: TextButton(
                    onPressed: widget.onCommentPressed,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset('assets/images/comment.svg'),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            'comment'.tr(),
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w400,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: TextButton(
                    onPressed: widget.onSharePressed,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        SvgPicture.asset('assets/images/send.svg',
                            color: widget.isShared == false
                                ? Config().text90Color
                                : Config().primary30Color),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            'share'.tr(),
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: widget.isShared == false
                                    ? FontWeight.w400
                                    : FontWeight.w700,
                                color: widget.isShared == false
                                    ? Config().text90Color
                                    : Config().primary30Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  contentWidget() {
    return Center(
      child: _chewieController != null &&
              _chewieController!.videoPlayerController.value.isInitialized
          ? AspectRatio(
              aspectRatio:
                  _chewieController!.videoPlayerController.value.aspectRatio,
              child: Chewie(
                controller: _chewieController!,
              ),
            )
          : Container(
              height: 300,
              width: MediaQuery.of(context).size.width,
              color: Colors.black,
              child: const Center(
                child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: CupertinoActivityIndicator(color: Colors.white)),
              ),
            ),
    );
  }

  getShortName(String fullname) {
    var shortName = '';
    var splits = fullname.split(' ');
    if (splits.length > 1 && splits[1].length > 1) {
      shortName = '${splits[0]} ${splits[1][0]}...';
    } else {
      shortName = fullname;
    }
    return shortName;
  }

  getTextWidget() {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, right: 4),
          child: SvgPicture.asset('assets/images/${widget.d.feeling!}.svg',
              width: 15, height: 15),
        ),
        Text(
          widget.d.feeling!.contains('feeling_') ? 'Feeling ' : ' ',
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w500,
              color: Config().text90Color),
        ),
        Text(
          mapFeeling[widget.d.feeling]!,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: widget.d.tagFriends!.isNotEmpty
                  ? Config().text70Color
                  : Config().text90Color),
        ),
      ],
    );
  }
}
