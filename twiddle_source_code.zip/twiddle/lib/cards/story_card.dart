import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:twiddle/models/user_story.dart';

import '../utils/cached_image.dart';

class StoryCard extends StatelessWidget {
  const StoryCard(
      {super.key,
      required this.us,
      required this.onItemTap,
      required this.mode});

  final UserStory us;
  final Function() onItemTap;
  final int mode;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTap,
      child: Container(
        padding: const EdgeInsets.only(left: 0, top: 0),
        height: mode == 1 ? 160 : 0,
        width: mode == 1 ? 110 : 0,
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            mode == 2
                ? CustomCacheImage(
                    imageUrl: us.media!,
                    radius: 8.0,
                    circularShape: true,
                  )
                : SizedBox(
                    height: 160,
                    width: mode == 1 ? 110 : 160,
                    child: CustomCacheImage(
                      imageUrl: us.media!,
                      radius: 8.0,
                      circularShape: true,
                    ),
                  ),
            Container(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 9,
                    backgroundColor: Colors.red,
                    child: CircleAvatar(
                      radius: 8,
                      backgroundColor: Colors.grey[300],
                      backgroundImage:
                          CachedNetworkImageProvider(us.useravatar!),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      us.username!,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            // VideoIcon(
            //   contentType: d.contentType,
            //   iconSize: 80,
            // )
          ],
        ),
      ),
    );
  }
}
