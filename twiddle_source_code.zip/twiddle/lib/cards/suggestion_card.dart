import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/utils/snacbar.dart';

import '../config/config.dart';
import '../models/user.dart';

class SuggestionCard extends StatelessWidget {
  final String uid;
  final WUser d;
  final String heroTag;
  final Function() onAddFriendPressed;
  final Function() onRemovePressed;
  final Function() onItemTapped;

  const SuggestionCard({
    super.key,
    required this.uid,
    required this.d,
    required this.heroTag,
    required this.onAddFriendPressed,
    required this.onRemovePressed,
    required this.onItemTapped,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onItemTapped,
      child: Container(
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.avatar!),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text100Color),
                    ),
                    Row(
                      children: [
                        // SvgPicture.asset('assets/images/public.svg'),
                        Padding(
                          padding: EdgeInsets.only(
                              left: (d.friends!.isNotEmpty) ? 8 : 0),
                          child: Text(
                            '${d.friends!.length} mutual Friends',
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w400,
                                color: Config().text90Color),
                          ),
                        )
                      ],
                    ),
                    Row(
                      children: [
                        ElevatedButton(
                          onPressed: onAddFriendPressed,
                          style: ElevatedButton.styleFrom(
                            primary: d.friendResponses!.contains(uid) == true
                                ? Config().gradientColor2
                                : Config().appColor,
                          ),
                          child: Text(
                            d.friendResponses!.contains(uid) == true
                                ? 'requested'.tr()
                                : 'add_friends'.tr(),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const SizedBox(width: 20),
                        ElevatedButton(
                          onPressed: onRemovePressed,
                          style: ElevatedButton.styleFrom(
                              primary: Config().text20Color),
                          child: Text(
                            'remove'.tr(),
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // IconButton(onPressed: () {

            // }, icon: icon)
            // GestureDetector(
            //   onTap: () {
            //     // openPopupDialog(context);
            //   },
            //   child: Padding(
            //     padding: const EdgeInsets.only(top: 8),
            //     child: SvgPicture.asset('assets/images/more_horiz.svg'),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
