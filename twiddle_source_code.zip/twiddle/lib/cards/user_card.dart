import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../config/config.dart';
import '../models/user.dart';

class UserCard extends StatelessWidget {
  final WUser d;
  final String heroTag;
  final double width;
  final double height;
  final Function() onUserTap;

  const UserCard({
    super.key,
    required this.d,
    required this.heroTag,
    required this.width,
    required this.height,
    required this.onUserTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onUserTap,
      child: Container(
        width: width,
        height: height,
        margin: const EdgeInsets.only(top: 16, bottom: 16),
        child: Stack(
          alignment: Alignment.bottomRight,
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              backgroundImage: CachedNetworkImageProvider(d.avatar!),
            ),
            Container(
              width: 14,
              height: 14,
              padding: const EdgeInsets.all(1),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: d.status == 'Online'
                      ? Config().primary50Color
                      : Config().text60Color,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
