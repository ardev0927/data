import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

import '../config/config.dart';
import '../models/post.dart';
import '../utils/feeling_utils.dart';

class VideoCard2 extends StatefulWidget {
  const VideoCard2({
    super.key,
    required this.d,
    required this.time,
  });

  final Post d;
  final String time;

  @override
  State<VideoCard2> createState() => _VideoCard2State();
}

class _VideoCard2State extends State<VideoCard2> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  int? bufferDelay;
  late SharedPreferences sp;

  @override
  void initState() {
    super.initState();
    initializePlayer();
    initSP();
  }

  initSP() async {
    sp = await SharedPreferences.getInstance();
  }

  @override
  void dispose() {
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  Future<void> initializePlayer() async {
    _videoPlayerController =
        VideoPlayerController.network(widget.d.mediaUrls![0]);
    await Future.wait([
      _videoPlayerController!.initialize(),
    ]);
    _createChewieController();
    setState(() {});
  }

  void _createChewieController() {
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController!,
      autoPlay: getAutoPlay(),
      looping: false,
      hideControlsTimer: const Duration(seconds: 3),
      showControls: true,

      // showControls: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.blueAccent,
        handleColor: Colors.blue,
        backgroundColor: Colors.grey,
        bufferedColor: Colors.white,
      ),
      placeholder: Container(
        color: Colors.black,
      ),
      autoInitialize: false,
    );
  }

  getAutoPlay() {
    return sp.getBool('video_auto_play') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
        decoration: BoxDecoration(
          color: Config().text4Color,
          border: Border.all(),
        ),
        child: Wrap(
          children: [
            // Header widget
            headerWidget(),
            // Description widget
            descriptionWidget(),
            SizedBox(
              height: 10,
            ),
            // View video or gif
            contentWidget(),
            // Likes, comments and shares body
            // bottomWidget(),
          ],
        ),
      ),
      onTap: () {},
    );
  }

  headerWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(widget.d.useravatar!),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        widget.d.username!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      widget.d.feeling!.isEmpty
                          ? Container()
                          : mapFeeling[widget.d.feeling] == null
                              ? Text(
                                  ' - ${widget.d.feeling!}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                )
                              : Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          left: 8, right: 4),
                                      child: SvgPicture.asset(
                                          'assets/images/${widget.d.feeling!}.svg',
                                          width: 18,
                                          height: 18),
                                    ),
                                    Text(
                                      widget.d.feeling!.contains('feeling_')
                                          ? 'Feeling '
                                          : 'Activity ',
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w400,
                                          color: Config().text90Color),
                                    ),
                                    Text(
                                      mapFeeling[widget.d.feeling]!,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                          color: widget.d.tagFriends!.isNotEmpty
                                              ? Config().text70Color
                                              : Config().text90Color),
                                    ),
                                  ],
                                ),
                    ],
                  ),
                  Row(
                    children: [
                      SvgPicture.asset('assets/images/public.svg',
                          width: 15, height: 15),
                      Padding(
                        padding: const EdgeInsets.only(left: 8),
                        child: Text(
                          widget.time,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                              color: Config().text100Color),
                        ),
                      ),
                      widget.d.pinned == true
                          ? const Padding(
                              padding: EdgeInsets.only(left: 16),
                              child: Icon(Icons.push_pin_outlined, size: 15),
                            )
                          : Container(),
                    ],
                  ),
                ],
              ),
            ),
          ),
          // const Spacer(),
          // InkWell(
          //   onTap: widget.onMoreTap,
          //   child: Container(
          //     width: 15,
          //     height: 15,
          //     child: SvgPicture.asset(
          //       'assets/images/more_horiz.svg',
          //     ),
          //   ),
          // ),
        ],
      ),
    );
  }

  descriptionWidget() {
    return widget.d.description == ''
        ? Container()
        : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              widget.d.description!,
              maxLines: 8,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
            ),
          );
  }

  contentWidget() {
    return Center(
      child: _chewieController != null &&
              _chewieController!.videoPlayerController.value.isInitialized
          ? AspectRatio(
              aspectRatio:
                  _chewieController!.videoPlayerController.value.aspectRatio,
              child: Chewie(
                controller: _chewieController!,
              ),
            )
          : Container(
              height: 300,
              width: MediaQuery.of(context).size.width,
              color: Colors.black,
              child: const Center(
                child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: CupertinoActivityIndicator(color: Colors.white)),
              ),
            ),
    );
  }
}
