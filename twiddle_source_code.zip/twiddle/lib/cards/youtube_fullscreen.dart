import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../config/config.dart';

class YoutubeFullScreen extends StatefulWidget {
  YoutubeFullScreen({super.key, required this.youtubePlayerController});

  YoutubePlayerController youtubePlayerController;

  @override
  State<YoutubeFullScreen> createState() => _YoutubeFullScreenState();
}

class _YoutubeFullScreenState extends State<YoutubeFullScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]);
    if (widget.youtubePlayerController.value.isPlaying) {
      print('===== Is playing =====');
    }
  }

  @override
  void dispose() {
    super.dispose();
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayer(
      controller: widget.youtubePlayerController,
      showVideoProgressIndicator: true,
      progressIndicatorColor: Colors.red,
      progressColors: const ProgressBarColors(
        playedColor: Colors.red,
        handleColor: Colors.redAccent,
      ),
      onReady: () {},
      // onReady () {
      //     _controller.addListener(listener);
      // },
      bottomActions: [
        CurrentPosition(),
        ProgressBar(
          isExpanded: true,
          colors: const ProgressBarColors(
            playedColor: Colors.red,
            handleColor: Colors.redAccent,
          ),
        ),
        RemainingDuration(),
        IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.fullscreen_exit_outlined,
            color: Config().whiteColor,
          ),
        ),
      ],
    );
  }
}
