import 'package:flutter/material.dart';

class Config {
  final String appName = 'Twiddle';
  final String splashIcon = 'assets/images/logo_large.png';
  final String supportEmail = 'mrblab24@gmail.com';
  final String privacyPolicyUrl = 'https://www.mrb-lab.com/privacy-policy';
  final String ourWebsiteUrl = 'https://www.twiddle.com';
  final String iOSAppId = '000000';
  final String defaultUserImageUrl =
      'https://www.oxfordglobal.co.uk/nextgen-omics-series-us/wp-content/uploads/sites/16/2020/03/Jianming-Xu-e5cb47b9ddeec15f595e7000717da3fe.png';

  //app theme color
  final Color appColor = const Color(0xff0669B1);
  final Color transparent = const Color(0x00ffffff);
  final Color whiteColor = const Color(0xffffffff);
  final Color blackColor = const Color(0xff000000);
  final Color primary4Color = const Color(0xffDCE0E3);
  final Color primary30Color = const Color(0xff0669B1);
  final Color primary10Color = const Color(0xFFD0D9E1);
  final Color primarySilverColor = const Color(0xFF909A9F);
  final Color secondary20Color = const Color(0xFFF3F5F8);
  final Color secondary21Color = const Color(0xFFC4C4C4);
  final Color text60Color = const Color(0xFF6C6C6C);
  final Color text4Color = const Color(0xFFF5F5F5);
  final Color text8Color = const Color(0xFFEBEBEB);
  final Color text10Color = const Color(0xFFE6E6E6);
  final Color text20Color = const Color(0xFFCECECE);
  final Color text100Color = const Color(0xFF09090A);
  final Color text90Color = const Color(0xFF222222);
  final Color text70Color = const Color(0xFFff0000);
  final Color text80Color = const Color(0xFF353536);
  final Color bgColor = const Color(0xFFE6DCDC);
  final Color primary50Color = const Color(0xFF00FF00);
  final Color textPrimaryColor = const Color(0xFF2D2B29);
  final Color textParagraphColor = const Color(0xFF434343);
  final Color bg10Color = const Color(0xAA09090A);
  final Color gradientColor1 = const Color(0xff0C67A9);
  final Color gradientColor2 = const Color(0xff5EBBFE);

  //Intro images
  final String introImage1 = 'assets/images/news1.png';
  final String introImage2 = 'assets/images/news6.png';
  final String introImage3 = 'assets/images/news7.png';

  //animation files
  final String doneAsset = 'assets/animation_files/done.json';

  //Language Setup
  final List<String> languages = ['English', 'Spanish'];

  static String fcmToken = '';

  final String agoraAppId = '4a85e0a92efa4024931c317e0ceff0d7';
  final String agoraCertificate = '72d9c0469803432f97e90146c094eb35';
  final String agoraTestToken =
      '0064a85e0a92efa4024931c317e0ceff0d7IAA/daLvSfYDPMnx9f0SQvo35ySv957VuEKWYRWy6tQBAruiVPAAAAAAEAB0/t05SAfYYgEAAQBJB9hi';

  final String kGoogleApiKey = 'AIzaSyBHfsL3Sr2R-RS4LsprnKphFgCllVSdfKs';

  // Settings

  // Post type
  final int AlbumType = 9;
}
