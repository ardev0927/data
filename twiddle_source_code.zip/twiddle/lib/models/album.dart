import 'package:cloud_firestore/cloud_firestore.dart';

class Album {
  String? id;
  String? uid;
  String? name;
  List<String>? images;
  String? timestamp;

  Album({this.id, this.uid, this.name, this.images, this.timestamp});

  factory Album.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Album(
      id: d['id'] ?? '',
      uid: d['uid'] ?? '',
      name: d['name'] ?? '',
      images: List.from(d['images'] ?? []),
      timestamp: d['timestamp'] ?? '',
    );
  }
}
