import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:twiddle/models/unread_message.dart';

class ChatRoom {
  String? id;
  List<String>? uids;
  List<String>? avatars;
  List<String>? names;
  List<UnreadMessage>? unreads;
  String? lastMessage;
  int? lastType;
  String? timestamp;

  ChatRoom({
    this.id,
    this.uids,
    this.avatars,
    this.names,
    this.lastMessage,
    this.lastType,
    this.unreads,
    this.timestamp,
  });

  factory ChatRoom.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    var snap = List.from(d['unreads'] ?? []);
    return ChatRoom(
      id: d['id'] ?? '',
      uids: List.from(d['uids'] ?? []),
      avatars: List.from(d['avatars'] ?? []),
      names: List.from(d['names'] ?? []),
      lastMessage: d['last_message'] ?? '',
      lastType: d['last_type'] ?? 1,
      unreads: snap.isEmpty
          ? []
          : snap.map((e) => UnreadMessage.fromJson(e)).toList(),
      timestamp: d['timestamp'] ?? '',
    );
  }
}
