class Checkin {
  double? latitude;
  double? longitude;
  String? address;

  Checkin({
    this.latitude,
    this.longitude,
    this.address,
  });

  factory Checkin.fromJson(dynamic d) {
    return Checkin(
      latitude: d['latitude'] ?? 0.0,
      longitude: d['longitude'] ?? 0.0,
      address: d['address'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'latitude': latitude,
        'longitude': longitude,
        'address': address,
      };
}
