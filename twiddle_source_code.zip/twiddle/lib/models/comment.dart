import 'package:cloud_firestore/cloud_firestore.dart';

class Comment {
  String? postId;
  String? uid;
  String? username;
  String? useravatar;
  String? type;
  String? comment;
  int? likes;
  List<String>? replies;
  String? timestamp;

  Comment({
    this.postId,
    this.uid,
    this.username,
    this.useravatar,
    this.type,
    this.comment,
    this.likes,
    this.replies,
    this.timestamp,
  });

  factory Comment.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Comment(
      postId: d['post_id'] ?? '',
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      type: d['type'] ?? '',
      comment: d['comment'] ?? '',
      likes: d['likes'] ?? 0,
      replies: List.from(d['replies']),
      timestamp: d['timestamp'] ?? '',
    );
  }
}
