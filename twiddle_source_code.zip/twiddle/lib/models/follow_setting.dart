import 'package:cloud_firestore/cloud_firestore.dart';

class FollowSetting {
  String? id;
  String? uid;
  String? followMe;
  String? seePeople;
  String? seeStory;
  String? seeFriendList;
  String? timestamp;

  FollowSetting({
    this.id,
    this.uid,
    this.followMe,
    this.seePeople,
    this.seeStory,
    this.seeFriendList,
    this.timestamp,
  });

  factory FollowSetting.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return FollowSetting(
      id: d['id'] ?? '',
      uid: d['uid'] ?? '',
      followMe: d['follow_me'] ?? 'Public',
      seePeople: d['see_people'] ?? 'Public',
      seeStory: d['see_story'] ?? 'Friends',
      seeFriendList: d['see_friend_list'] ?? 'Public',
      timestamp: d['timestamp'] ?? '',
    );
  }
}
