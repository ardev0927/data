import 'package:cloud_firestore/cloud_firestore.dart';

class Gif {
  String? name;
  String? gifUrl;
  String? timestamp;

  Gif({
    this.name,
    this.gifUrl,
    this.timestamp,
  });

  factory Gif.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Gif(
      name: d['name'] ?? '',
      gifUrl: d['gif_url'] ?? '',
      timestamp: d['timestamp'],
    );
  }
}
