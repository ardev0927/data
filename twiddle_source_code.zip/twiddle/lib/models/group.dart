import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:twiddle/models/group_admin_assist.dart';
import 'package:twiddle/models/group_manage_discussion.dart';
import 'package:twiddle/models/group_rule.dart';

class Group {
  String? id;
  String? name;
  String? privacy;
  String? description;
  String? coverPhoto;
  String? ownerUid;
  String? ownerName;
  String? ownerAvatar;
  List<String>? members;
  List<String>? posts;
  List<String>? following;
  List<String>? reports;
  List<String>? alerts;
  List<String>? joinRequests;
  bool? pinned;
  String? timestamp;
  List<String>? inviteUsers;
  String? hoursOpen;
  String? hoursClose;
  String? week;
  ManageDiscussion? manageDiscussion;
  AdminAssist? adminAssist;
  List<String>? adminModerators;
  List<String>? blockedUsers;
  List<Rule>? rules;

  Group({
    this.id,
    this.name,
    this.privacy,
    this.description,
    this.coverPhoto,
    this.ownerUid,
    this.ownerAvatar,
    this.ownerName,
    this.members,
    this.posts,
    this.pinned,
    this.timestamp,
    this.following,
    this.reports,
    this.alerts,
    this.joinRequests,
    this.inviteUsers,
    this.hoursOpen,
    this.hoursClose,
    this.week,
    this.manageDiscussion,
    this.adminAssist,
    this.adminModerators,
    this.blockedUsers,
    this.rules,
  });

  factory Group.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;

    List<Rule> rules = [];
    if (d['rules'] != null) {
      var m = d['rules'] as List<dynamic>;
      rules = m.map((e) => Rule.fromJson(e)).toList();
    }

    return Group(
      id: d['id'] ?? '',
      name: d['name'] ?? '',
      privacy: d['privacy'] ?? '',
      description: d['description'] ?? '',
      coverPhoto: d['cover_photo'] ?? '',
      ownerUid: d['owner_uid'] ?? '',
      ownerAvatar: d['owner_avatar'] ?? '',
      ownerName: d['owner_name'] ?? '',
      members: List.from(d['members'] ?? []),
      posts: List.from(d['posts'] ?? []),
      following: List.from(d['following'] ?? []),
      reports: List.from(d['reports'] ?? []),
      alerts: List.from(d['alerts'] ?? []),
      joinRequests: List.from(d['join_requests'] ?? []),
      pinned: d['pinned'] ?? false,
      timestamp: d['timestamp'],
      inviteUsers: List.from(d['invite_users'] ?? []),
      hoursOpen: d['hours_open'] ?? '',
      hoursClose: d['hours_close'] ?? '',
      week: d['week'] ?? '',
      manageDiscussion: d['manage_discussion'] != null
          ? ManageDiscussion.fromJson(d['manage_discussion'])
          : null,
      adminAssist: d['admin_assist'] != null
          ? AdminAssist.fromJson(d['admin_assist'])
          : null,
      adminModerators: List.from(d['admins_moderators'] ?? []),
      blockedUsers: List.from(d['blocked_users'] ?? []),
      rules: rules,
    );
  }

  factory Group.fromJson(Map d) {
    if (d.isEmpty) return Group();

    List<Rule> rules = [];
    if (d['rules'] != null) {
      var m = d['rules'] as List<dynamic>;
      rules = m.map((e) => Rule.fromJson(e)).toList();
    }

    return Group(
      id: d['id'] ?? '',
      name: d['name'] ?? '',
      privacy: d['privacy'] ?? '',
      description: d['description'] ?? '',
      coverPhoto: d['cover_photo'] ?? '',
      ownerUid: d['owner_uid'] ?? '',
      ownerAvatar: d['owner_avatar'] ?? '',
      ownerName: d['owner_name'] ?? '',
      members: List.from(d['members'] ?? []),
      posts: List.from(d['posts'] ?? []),
      following: List.from(d['following'] ?? []),
      reports: List.from(d['reports'] ?? []),
      alerts: List.from(d['alerts'] ?? []),
      joinRequests: List.from(d['join_requests'] ?? []),
      pinned: d['pinned'] ?? false,
      timestamp: d['timestamp'],
      inviteUsers: List.from(d['invite_users'] ?? []),
      hoursOpen: d['hours_open'] ?? '',
      hoursClose: d['hours_close'] ?? '',
      week: d['week'] ?? '',
      manageDiscussion: d['manage_discussion'] != null
          ? ManageDiscussion.fromJson(d['manage_discussion'])
          : null,
      adminAssist: d['admin_assist'] != null
          ? AdminAssist.fromJson(d['admin_assist'])
          : null,
      adminModerators: List.from(d['admins_moderators'] ?? []),
      blockedUsers: List.from(d['blocked_users'] ?? []),
      rules: rules,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'privacy': privacy,
        'description': description,
        'cover_photo': coverPhoto,
        'owner_uid': ownerUid,
        'owner_avatar': ownerAvatar,
        'owner_name': ownerName,
        'members': members,
        'posts': posts,
        'following': following,
        'reports': reports,
        'alerts': alerts,
        'join_requests': joinRequests,
        'pinned': pinned,
        'timestamp': timestamp,
        'invite_users': inviteUsers,
        'hours_open': hoursOpen,
        'hours_close': hoursClose,
        'week': week,
        'manage_discussion':
            manageDiscussion == null ? null : manageDiscussion!.toJson(),
        'admin_assist': adminAssist == null ? null : adminAssist!.toJson(),
        'admins_moderators': adminModerators,
        'blocked_users': blockedUsers,
        'rules': rules!.map((e) => e.toJson()).toList(),
      };
}
