import 'package:cloud_firestore/cloud_firestore.dart';

class AdminAssist {
  String? approveMember;
  String? declineMember;

  AdminAssist({
    this.approveMember,
    this.declineMember,
  });

  factory AdminAssist.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return AdminAssist(
      approveMember: d['approve_member'] ?? 'Admin',
      declineMember: d['decline_member'] ?? 'Admin',
    );
  }

  factory AdminAssist.fromJson(Map d) {
    return AdminAssist(
      approveMember: d['approve_member'] ?? 'Admin',
      declineMember: d['decline_member'] ?? 'Admin',
    );
  }

  Map<String, dynamic> toJson() => {
        'approve_member': approveMember,
        'decline_member': declineMember,
      };
}
