import 'package:cloud_firestore/cloud_firestore.dart';

class ManageDiscussion {
  String? whoCanPost;
  String? postApproval;

  ManageDiscussion({
    this.whoCanPost,
    this.postApproval,
  });

  factory ManageDiscussion.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return ManageDiscussion(
      whoCanPost: d['who_can_post'] ?? 'Admin',
      postApproval: d['post_approval'] ?? 'Admin',
    );
  }

  factory ManageDiscussion.fromJson(Map d) {
    return ManageDiscussion(
      whoCanPost: d['who_can_post'] ?? 'Admin',
      postApproval: d['post_approval'] ?? 'Admin',
    );
  }

  Map<String, dynamic> toJson() => {
        'who_can_post': whoCanPost,
        'post_approval': postApproval,
      };
}
