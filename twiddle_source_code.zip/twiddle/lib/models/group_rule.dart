import 'package:cloud_firestore/cloud_firestore.dart';

class Rule {
  String? name;
  String? description;

  Rule({
    this.name,
    this.description,
  });

  factory Rule.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Rule(
      name: d['name'] ?? '',
      description: d['description'] ?? '',
    );
  }

  factory Rule.fromJson(Map d) {
    return Rule(
      name: d['name'] ?? '',
      description: d['description'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'description': description,
      };

  List<Rule> toList(dynamic rules) {
    var map = rules as List<Map<String, dynamic>>;
    return map.map((e) => Rule.fromJson(e)).toList();
  }
}
