import 'package:cloud_firestore/cloud_firestore.dart';

class Interest {
  String? name;
  String? image;
  List<String>? uids;
  String? timestamp;

  Interest({
    this.name,
    this.image,
    this.uids,
    this.timestamp,
  });

  factory Interest.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Interest(
      name: d['name'] ?? '',
      image: d['image'] ?? '',
      uids: List.from(d['uids']),
      timestamp: d['timestamp'],
    );
  }
}
