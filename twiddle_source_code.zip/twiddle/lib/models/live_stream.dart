class LiveStream {
  String? channelId;
  String? image;
  String? title;
  String? username;
  String? uid;
  int? viewers;

  LiveStream({
    this.channelId,
    this.image,
    this.title,
    this.username,
    this.uid,
    this.viewers,
  });

  factory LiveStream.fromJson(dynamic d) {
    return LiveStream(
      uid: d['uid'] ?? '',
      channelId: d['channel_id'] ?? '',
      title: d['title'] ?? '',
      username: d['username'] ?? '',
      image: d['image'] ?? '',
      viewers: d['viewers'] ?? 0,
    );
  }
}
