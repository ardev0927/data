import 'package:cloud_firestore/cloud_firestore.dart';

class Message {
  String? id;
  String? groupId;
  String? sendUid;
  String? sendName;
  String? sendAvatar;
  String? recvUid;
  String? recvName;
  String? recvAvatar;
  String? message;
  int? type;
  bool? read;
  String? timestamp;

  Message({
    this.id,
    this.groupId,
    this.sendUid,
    this.sendName,
    this.sendAvatar,
    this.recvUid,
    this.recvName,
    this.recvAvatar,
    this.message,
    this.type,
    this.read,
    this.timestamp,
  });

  factory Message.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Message(
      id: d['id'] ?? '',
      groupId: d['group_id'],
      sendUid: d['send_uid'] ?? '',
      sendName: d['send_name'] ?? '',
      sendAvatar: d['send_avatar'] ?? '',
      recvUid: d['recv_id'] ?? '',
      recvName: d['recv_name'] ?? '',
      recvAvatar: d['recv_avatar'] ?? '',
      message: d['message'] ?? '',
      type: d['type'] ?? 1,
      read: d['read'] ?? false,
      timestamp: d['timestamp'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'group_id': groupId,
        'send_uid': sendUid,
        'send_name': sendName,
        'send_avatar': sendAvatar,
        'recv_id': recvUid,
        'recv_name': recvName,
        'recv_avatar': recvAvatar,
        'message': message,
        'type': type,
        'read': read,
        'timestamp': timestamp,
      };
}
