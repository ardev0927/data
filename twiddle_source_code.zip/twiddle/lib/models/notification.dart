import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationModel {
  String? id;
  String? title;
  int? type;
  String? typedata;
  String? uid;
  String? useravatar;
  String? timestamp;

  NotificationModel({
    this.id,
    this.title,
    this.type,
    this.typedata,
    this.uid,
    this.useravatar,
    this.timestamp,
  });

  factory NotificationModel.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return NotificationModel(
      id: d['notificaion_id'] ?? '',
      title: d['title'] ?? '',
      type: d['type'] ?? 0,
      typedata: d['typedata'] ?? '',
      uid: d['uid'] ?? '',
      useravatar: d['useravatar'] ?? '',
      timestamp: d['timestamp'] ?? '',
    );
  }
}
