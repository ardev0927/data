import 'package:twiddle/models/relationship.dart';

class PersonInfo {
  String? hometown;
  String? hometownPrivacy;
  String? worksat;
  String? worksatPrivacy;
  String? studiedat;
  String? studiedatPrivacy;
  String? livesin;
  String? livesinPrivacy;
  Relationship? relationship;
  String? relationshipPrivacy;
  String? birthdate;
  String? birthdatePrivacy;
  String? gender;
  String? genderPrivacy;

  PersonInfo({
    this.hometown,
    this.hometownPrivacy,
    this.worksat,
    this.worksatPrivacy,
    this.studiedat,
    this.studiedatPrivacy,
    this.livesin,
    this.livesinPrivacy,
    this.relationship,
    this.relationshipPrivacy,
    this.birthdate,
    this.birthdatePrivacy,
    this.gender,
    this.genderPrivacy,
  });

  factory PersonInfo.fromJson(d) {
    var isNotNull = false;
    if (d['relationship_status'] == null) {
      isNotNull = false;
    } else {
      isNotNull = true;
    }

    return PersonInfo(
      hometown: d['hometown'],
      hometownPrivacy: d['hometown_privacy'],
      worksat: d['works_at'],
      worksatPrivacy: d['works_at_privacy'],
      studiedat: d['studied_at'],
      studiedatPrivacy: d['studied_at_privacy'],
      livesin: d['lives_in'],
      livesinPrivacy: d['lives_in_privacy'],
      relationship: isNotNull == false
          ? null
          : Relationship.fromJson(d['relationship_status']),
      relationshipPrivacy: d['relationship_status_privacy'],
      birthdate: d['birthdate'],
      birthdatePrivacy: d['birthdate_privacy'],
      gender: d['gender'],
      genderPrivacy: d['gender_privacy'],
    );
  }

  Map<String, dynamic> toJson() => {
        'hometown': hometown,
        'hometown_privacy': hometownPrivacy,
        'works_at': worksat,
        'works_at_privacy': worksatPrivacy,
        'studied_at': studiedat,
        'studied_at_privacy': studiedatPrivacy,
        'lives_in': livesin,
        'lives_in_privacy': livesinPrivacy,
        'relationship_status':
            relationship == null ? null : relationship!.toJson(),
        'relationship_status_privacy': relationshipPrivacy,
        'birthdate': birthdate,
        'birthdate_privacy': birthdatePrivacy,
        'gender': gender,
        'gender_privacy': genderPrivacy,
      };
}
