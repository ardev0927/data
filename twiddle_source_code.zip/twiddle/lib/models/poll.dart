import 'package:cloud_firestore/cloud_firestore.dart';

class Poll {
  String? question;
  String? option1;
  int? option1Votes;
  String? option2;
  int? option2Votes;
  int? votes;
  bool? isVoted;

  Poll({
    this.question,
    this.option1,
    this.option1Votes,
    this.option2,
    this.option2Votes,
    this.votes,
    this.isVoted,
  });

  factory Poll.fromJson(dynamic d) {
    return Poll(
      question: d['question'] ?? '',
      option1: d['option1'] ?? '',
      option1Votes: d['option1_votes'] ?? 0,
      option2: d['option2'] ?? '',
      option2Votes: d['option2_votes'] ?? 0,
      votes: d['votes'] ?? 0,
      isVoted: d['is_voted'] ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'question': question,
        'option1': option1,
        'option1_votes': option1Votes,
        'option2': option2,
        'option2_votes': option2Votes,
        'votes': votes,
        'is_voted': isVoted,
      };
}
