import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:twiddle/models/check_in.dart';
import 'package:twiddle/models/poll.dart';

import 'group.dart';

class Post {
  String? postId;
  String? uid;
  String? username;
  String? useravatar;
  int? mediaType; // 1: Image, 2: Video, 3: , 8: Poll, 9: Album
  List<String>? mediaUrls;
  String? description;
  Checkin? location;
  String? timestamp;
  List<String>? likes;
  List<String>? views;
  int? comments;
  List<String>? shares;
  String? privacy;
  String? feeling;
  Poll? poll;
  bool? pinned;
  bool? reported;
  bool? isGroupPost;
  Group? group;
  // List<String>? hides;
  String? article;
  List<String>? tagFriends;
  Post? sharedPost;
  List<String>? hide;
  bool? hasTag;
  String? contentWarning;

  Post({
    this.postId,
    this.uid,
    this.username,
    this.useravatar,
    this.mediaType,
    this.mediaUrls,
    this.description,
    this.location,
    this.timestamp,
    this.likes,
    this.views,
    this.comments,
    this.shares,
    this.privacy,
    this.feeling,
    this.poll,
    this.pinned,
    this.reported,
    this.isGroupPost,
    this.group,
    // this.hides,
    this.article,
    this.tagFriends,
    this.sharedPost,
    this.hide,
    this.hasTag,
    this.contentWarning,
  });

  factory Post.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    Poll? poll = Poll.fromJson(d['poll']);
    Post? post =
        d['shared_post'] != null ? Post.fromJson(d['shared_post']) : Post();
    Map group = d['group_post'];
    return Post(
      postId: d['post_id'] ?? '',
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      mediaType: d['media_type'] ?? 0,
      mediaUrls: List.from(d['media_url'] ?? []),
      description: d['description'] ?? '',
      location: Checkin.fromJson(d['location'] ?? {}),
      timestamp: d['timestamp'] ?? '',
      likes: List.from(d['likes'] ?? []),
      views: List.from(d['views'] ?? []),
      shares: List.from(d['shares'] ?? []),
      comments: d['comments'] ?? 0,
      privacy: d['privacy'],
      feeling: d['feeling_activity'] ?? '',
      poll: poll,
      pinned: d['pinned'] ?? false,
      reported: d['reported'] ?? false,
      isGroupPost: d['is_group_post'] ?? false,
      group: Group.fromJson(group),
      // hides: List.from(d['hides'] ?? []),
      article: d['article'] ?? '',
      tagFriends: List.from(d['tag_friends'] ?? []),
      sharedPost: post,
      hide: List.from(d['hide'] ?? []),
      hasTag: d['has_tag'] ?? false,
      contentWarning: d['content_warning'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'post_id': postId,
        'uid': uid,
        'username': username,
        'useravatar': useravatar,
        'media_type': mediaType,
        'media_url': mediaUrls,
        'description': description,
        'location': location!.toJson(),
        'timestamp': timestamp,
        'likes': likes,
        'views': views,
        'shares': shares,
        'comments': comments,
        'privacy': privacy,
        'feeling_activity': feeling,
        'poll': poll!.toJson(),
        'pinned': pinned,
        'reported': reported,
        'is_group_post': isGroupPost,
        'group_post': group!.toJson(),
        // 'hides': hides,
        'article': article,
        'tag_friends': tagFriends,
        'shared_post': sharedPost!.postId == null ? {} : sharedPost!.toJson(),
        'hide': hide,
        'has_tag': hasTag,
        'content_warning': contentWarning,
      };

  factory Post.fromJson(Map<String, dynamic> d) {
    if (d.isEmpty) return Post();
    Poll? poll = Poll.fromJson(d['poll']);
    Map group = d['group_post'];
    Post? post =
        d['shared_post'] != null ? Post.fromJson(d['shared_post']) : Post();
    return Post(
      postId: d['post_id'] ?? '',
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      mediaType: d['media_type'] ?? 0,
      mediaUrls: List.from(d['media_url'] ?? []),
      description: d['description'] ?? '',
      location: Checkin.fromJson(d['location'] ?? {}),
      timestamp: d['timestamp'] ?? '',
      likes: List.from(d['likes'] ?? []),
      views: List.from(d['views'] ?? []),
      shares: List.from(d['shares'] ?? []),
      comments: d['comments'] ?? 0,
      privacy: d['privacy'],
      feeling: d['feeling_activity'] ?? '',
      poll: poll,
      pinned: d['pinned'] ?? false,
      reported: d['reported'] ?? false,
      isGroupPost: d['is_group_post'] ?? false,
      group: Group.fromJson(group),
      // hides: List.from(d['hides'] ?? []),
      article: d['article'] ?? '',
      tagFriends: List.from(d['tag_friends'] ?? []),
      sharedPost: post,
      hide: List.from(d['hide'] ?? []),
      hasTag: d['has_tag'] ?? false,
      contentWarning: d['content_warning'] ?? '',
    );
  }
}
