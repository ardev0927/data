import 'package:cloud_firestore/cloud_firestore.dart';

class Relationship {
  int? type;
  String? typeName; // Signle, Married, Engaged
  String? avatar;
  String? title;
  String? description;
  String? privacy;

  Relationship({
    this.type,
    this.typeName,
    this.avatar,
    this.title,
    this.description,
    this.privacy,
  });

  factory Relationship.fromJson(dynamic d) {
    return Relationship(
      type: d['type'],
      typeName: d['type_name'],
      avatar: d['avatar'],
      title: d['title'],
      description: d['description'],
      privacy: d['privacy'],
    );
  }

  Map<String, dynamic> toJson() => {
        'type': type,
        'type_name': typeName,
        'avatar': avatar,
        'title': title,
        'description': description,
        'privacy': privacy,
      };

  factory Relationship.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Relationship.fromJson(d);
  }
}
