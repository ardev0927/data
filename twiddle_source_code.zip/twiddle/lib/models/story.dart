import 'package:cloud_firestore/cloud_firestore.dart';

class Story {
  String? id;
  String? uid;
  String? username;
  String? useravatar;
  String? storyType;
  String? media;
  String? thumbnail;
  String? caption;
  List<String>? views;
  String? timestamp;

  Story({
    this.id,
    this.uid,
    this.username,
    this.useravatar,
    this.storyType,
    this.media,
    this.thumbnail,
    this.caption,
    this.views,
    this.timestamp,
  });

  factory Story.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return Story(
      id: d['id'] ?? '',
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      storyType: d['story_type'] ?? '',
      media: d['media'] ?? '',
      thumbnail: d['thumbnail'] ?? '',
      caption: d['caption'] ?? '',
      views: List.from(d['views'] ?? []),
      timestamp: d['timestamp'] ?? '',
    );
  }

  factory Story.fromJson(Map<String, dynamic> d) {
    return Story(
      id: d['id'] ?? '',
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      storyType: d['story_type'] ?? '',
      media: d['media'] ?? '',
      thumbnail: d['thumbnail'] ?? '',
      caption: d['caption'] ?? '',
      views: List.from(d['uid'] ?? []),
      timestamp: d['timestamp'] ?? '',
    );
  }
}
