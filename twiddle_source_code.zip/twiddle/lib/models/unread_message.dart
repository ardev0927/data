import 'package:cloud_firestore/cloud_firestore.dart';

class UnreadMessage {
  String? uid;
  int? count;

  UnreadMessage({
    this.uid,
    this.count,
  });

  factory UnreadMessage.fromJson(dynamic d) {
    return UnreadMessage(
      uid: d['uid'] ?? '',
      count: d['count'] ?? 0,
    );
  }
}
