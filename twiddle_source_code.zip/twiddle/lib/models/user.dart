import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:twiddle/models/person_info.dart';

class WUser {
  String? uid;
  String? name;
  String? email;
  String? avatar;
  // String? birthdate;
  // String? gender;
  String? phone;
  List<String>? friends;
  String? timestamp;
  List<String>? friendRequests;
  List<String>? friendResponses;
  List<String>? interests;
  // String? hometown;
  // String? worksAt;
  // String? studiedAt;
  // String? livesIn;
  // String? relationshipStatus;
  String? coverUrl;
  String? status;
  String? fcmToken;
  List<String>? liveInvited;
  PersonInfo? info;
  List<String>? inviteGroups;
  List<String>? blockedUsers;

  WUser({
    this.uid,
    this.name,
    this.email,
    this.avatar,
    // this.birthdate,
    // this.gender,
    this.phone,
    this.friends,
    this.timestamp,
    this.friendRequests,
    this.friendResponses,
    this.interests,
    // this.hometown,
    // this.worksAt,
    // this.studiedAt,
    // this.livesIn,
    // this.relationshipStatus,
    this.coverUrl,
    this.status,
    this.fcmToken,
    this.liveInvited,
    this.info,
    this.inviteGroups,
    this.blockedUsers,
  });

  factory WUser.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return WUser(
      uid: d['uid'] ?? '',
      name: d['name'] ?? '',
      email: d['email'] ?? '',
      avatar: d['image_url'] ?? '',
      // birthdate: d['birthdate'] ?? '',
      // gender: d['gender'] ?? '',
      phone: d['phone'] ?? '',
      friends: List.from(d['friends'] ?? []),
      timestamp: d['timestamp'],
      friendRequests: List.from(d['friend_request'] ?? []),
      friendResponses: List.from(d['friend_response'] ?? []),
      interests: List.from(d['interests'] ?? []),
      coverUrl: d['cover_url'] ?? '',
      // hometown: d['hometown'] ?? '',
      // worksAt: d['works_at'] ?? '',
      // studiedAt: d['studied_at'] ?? '',
      // livesIn: d['lives_in'] ?? '',
      // relationshipStatus: d['relationship_status'] ?? '',
      status: d['status'] ?? 'Offline',
      fcmToken: d['fcm_token'] ?? '',
      liveInvited: List.from(d['live_invited'] ?? []),
      info: PersonInfo.fromJson(d['info']),
      inviteGroups: List.from(d['invite_groups'] ?? []),
      blockedUsers: List.from(d['blocked_users'] ?? []),
    );
  }

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'email': email,
        'image_url': avatar,
        // 'birthdate': birthdate,
        // 'gender': gender,
        'phone': phone,
        'friends': friends,
        'timestamp': timestamp,
        'friend_request': friendRequests,
        'friend_response': friendResponses,
        'interests': interests,
        'cover_url': coverUrl,
        // 'hometown': hometown,
        // 'works_at': worksAt,
        // 'studied_at': studiedAt,
        // 'lives_in': livesIn,
        // 'relationship_status': relationshipStatus,
        'status': status,
        'fcm_token': fcmToken,
        'live_invited': liveInvited,
        'info': info!.toJson(),
        'invite_groups': inviteGroups,
        'blocked_users': blockedUsers,
      };
}
