import 'package:cloud_firestore/cloud_firestore.dart';

class UserStory {
  String? uid;
  String? username;
  String? useravatar;
  String? media;
  String? timestamp;

  UserStory({
    this.uid,
    this.username,
    this.useravatar,
    this.media,
    this.timestamp,
  });

  factory UserStory.fromFirestore(DocumentSnapshot snapshot) {
    Map d = snapshot.data() as Map<dynamic, dynamic>;
    return UserStory(
      uid: d['uid'] ?? '',
      username: d['username'] ?? '',
      useravatar: d['useravatar'] ?? '',
      media: d['media'] ?? '',
      timestamp: d['timestamp'] ?? '',
    );
  }
}
