import 'package:flutter/material.dart';

class ChatBlockedAccountPage extends StatefulWidget {
  const ChatBlockedAccountPage({super.key});

  @override
  State<ChatBlockedAccountPage> createState() => _ChatBlockedAccountPageState();
}

class _ChatBlockedAccountPageState extends State<ChatBlockedAccountPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
