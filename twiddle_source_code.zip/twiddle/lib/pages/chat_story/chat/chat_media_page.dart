import 'package:flutter/material.dart';

class ChatMediaPage extends StatefulWidget {
  const ChatMediaPage({super.key});

  @override
  State<ChatMediaPage> createState() => _ChatMediaPageState();
}

class _ChatMediaPageState extends State<ChatMediaPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
