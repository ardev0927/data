import 'package:flutter/material.dart';

class ChatNotificationSoundPage extends StatefulWidget {
  const ChatNotificationSoundPage({super.key});

  @override
  State<ChatNotificationSoundPage> createState() =>
      _ChatNotificationSoundPageState();
}

class _ChatNotificationSoundPageState extends State<ChatNotificationSoundPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
