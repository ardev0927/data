import 'package:flutter/material.dart';

class ChatPrivacyPage extends StatefulWidget {
  const ChatPrivacyPage({super.key});

  @override
  State<ChatPrivacyPage> createState() => _ChatPrivacyPageState();
}

class _ChatPrivacyPageState extends State<ChatPrivacyPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
