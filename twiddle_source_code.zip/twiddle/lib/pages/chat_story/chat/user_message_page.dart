import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chat_bubble/bubble_type.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_4.dart';
import 'package:flutter_chat_bubble/clippers/chat_bubble_clipper_5.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twiddle/blocs/chat_room_bloc.dart';
import 'package:twiddle/blocs/chats_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/chat_bubble_audio_card.dart';
import 'package:twiddle/models/message.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:uuid/uuid.dart';

import '../../../cards/chat_bubble_card.dart';
import '../../../config/config.dart';
import '../../../services/app_service.dart';
import '../../../utils/crop_image.dart';
import '../../../utils/format_time.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/snacbar.dart';

class UserMessagePage extends StatefulWidget {
  const UserMessagePage({super.key, this.user, this.isSend = false, this.url});
  final WUser? user;
  final bool? isSend;
  final String? url;
  // final int? type;
  // final String? fcmToken;

  @override
  State<UserMessagePage> createState() => _UserMessagePageState();
}

class _UserMessagePageState extends State<UserMessagePage>
    with TickerProviderStateMixin {
  ScrollController? msgScrollCtrl;
  WUser? user;
  Timer? _timer;
  String? status;
  StreamSubscription<RecordState>? _recordSub;
  StreamSubscription<Amplitude>? _amplitudeSub;
  Amplitude? _amplitude;
  AnimationController? _controller;
  Animation<double>? _animation;

  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  TextEditingController msgController = TextEditingController();
  final _audioRecorder = Record();
  final String _orderBy = 'timestamp';
  String msg = '';
  String chatRoomId = '';
  bool isLoadingRoom = false;
  bool isRecordWidget = false;
  bool isExistRoom = false;
  int _recordDuration = 0;

  RecordState _recordState = RecordState.stop;

  @override
  void initState() {
    super.initState();

    if (widget.isSend == true) {
      msgController.text = widget.url!;
    }

    Future.delayed(Duration(milliseconds: 0)).then((value) {
      _getRoom();
    });

    // Record
    _recordSub = _audioRecorder.onStateChanged().listen((recordState) {
      setState(() => _recordState = recordState);
    });

    _amplitudeSub = _audioRecorder
        .onAmplitudeChanged(const Duration(milliseconds: 300))
        .listen((amp) => setState(() => _amplitude = amp));

    recordPermission();

    // Animation
    _controller = AnimationController(
      duration: const Duration(
        seconds: 1,
      ),
      vsync: this,
      value: 0.5,
    )..repeat(reverse: true);
    _animation = CurvedAnimation(
      parent: _controller!,
      curve: Curves.easeInOut,
    );
  }

  recordPermission() async {
    await _audioRecorder.hasPermission();
  }

  @override
  void dispose() {
    msgController.dispose();
    _controller!.dispose();
    if (msgScrollCtrl != null) {
      msgScrollCtrl!.removeListener(_msgScrollController);
    }

    // Record
    _timer?.cancel();
    _recordSub?.cancel();
    _amplitudeSub?.cancel();
    _audioRecorder.dispose();

    super.dispose();
  }

  void _msgScrollController() {
    final gb = context.read<ChatsBloc>();
    final sb = context.read<SignInBloc>();

    if (!gb.isLoading) {
      if (msgScrollCtrl!.position.pixels ==
          msgScrollCtrl!.position.maxScrollExtent) {
        context.read<ChatsBloc>().setLoading(true);
        context.read<ChatsBloc>().getData(chatRoomId, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appbar(),
      body: _body(),
    );
  }

  _appbar() {
    return AppBar(
      backgroundColor: Config().text4Color,
      leadingWidth: 30,
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(Icons.arrow_back),
      ),
      title: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(widget.user!.avatar!),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.user!.name!,
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                StreamBuilder<QuerySnapshot>(
                  stream: getUser(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      var doc = snapshot.data!.docs[0];
                      var user = WUser.fromFirestore(doc);
                      status = user.status;
                      return Text(
                        status!,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Config().textPrimaryColor),
                      );
                    }
                    status = 'Offline';
                    return Container();
                  },
                ),
                // Text(
                //   widget.user!.status!,
                //   style: TextStyle(
                //       fontSize: 12,
                //       fontWeight: FontWeight.w400,
                //       color: Config().textPrimaryColor),
                // ),
              ],
            ),
          ),
        ],
      ),
      // actions: [
      //   IconButton(
      //     onPressed: () {},
      //     icon: Icon(Icons.call_outlined),
      //     iconSize: 20,
      //   ),
      //   IconButton(onPressed: () {}, icon: Icon(Icons.video_call_outlined)),
      // ],
    );
  }

  _bottom() {
    final sb = context.read<SignInBloc>();
    final ub = context.read<UserBlock>();

    return Container(
      width: MediaQuery.of(context).size.width,
      height: 60,
      padding: const EdgeInsets.only(left: 16),
      color: Config().text4Color,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              controller: msgController,
              decoration: InputDecoration(
                hintText: 'type_message'.tr(),
                hintStyle: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().textParagraphColor),
              ),
              validator: (value) {
                if (value!.isEmpty) {
                  return "This field can't be empty";
                }
                return null;
              },
              onChanged: (value) {
                msg = value;
              },
            ),
          ),
          IconButton(
              onPressed: () {
                pickMediaDialog(context);
              },
              padding: const EdgeInsets.all(0),
              visualDensity: VisualDensity(horizontal: -3, vertical: -3),
              icon: Icon(Icons.add_a_photo_outlined)),
          GestureDetector(
            onTapDown: (details) {
              print('===== Tap down =====');
              setState(() {
                isRecordWidget = true;
              });
              _start();
            },
            onTapUp: (details) {
              print('===== Tap up =====');
              setState(() {
                isRecordWidget = false;
              });
              _stop();
            },
            child: const SizedBox(
              width: 40,
              height: 40,
              child: Icon(Icons.mic),
            ),
          ),
          // IconButton(
          //     onPressed: () {},
          //     visualDensity: VisualDensity(horizontal: -3, vertical: -3),
          //     icon: Icon(Icons.mic_outlined)),
          IconButton(
              onPressed: () async {
                if (msgController.text.isNotEmpty) {
                  // var status = await ub.getUserStatus(widget.user!.uid!);
                  if (widget.isSend == true) {
                    _sendMsg(status!, MessageType.image, widget.url!);
                  } else {
                    _sendMsg(status!, MessageType.text, msg);
                  }
                } else {
                  print('message is empty');
                }
              },
              visualDensity: VisualDensity(horizontal: -3, vertical: -3),
              icon: Icon(Icons.send, color: Config().primary30Color)),
        ],
      ),
    );
  }

  _showRecordingWidget() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      color: Config().bg10Color,
      child: ScaleTransition(
        scale: _animation!,
        alignment: Alignment.center,
        child: Center(
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Config().whiteColor,
            ),
            child: Icon(Icons.mic, size: 50),
          ),
        ),
      ),
    );
  }

  _body() {
    return isLoadingRoom == true
        ? const Center(
            child: SizedBox(
              width: 32.0,
              height: 32.0,
              child: CupertinoActivityIndicator(),
            ),
          )
        : Stack(
            children: [
              Column(
                children: [
                  _chatWidget(),
                  _bottom(),
                ],
              ),
              isRecordWidget == true ? _showRecordingWidget() : Container(),
            ],
          );
  }

  _chatWidget() {
    final cb = context.watch<ChatsBloc>();
    final sb = context.watch<SignInBloc>();

    return chatRoomId.isEmpty
        ? Expanded(child: Container())
        : Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: getChatMessage(chatRoomId, 20),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  var listMsgs = snapshot.data!.docs;
                  // print('===== list message: ${listMsgs.length} =====');
                  if (listMsgs.isNotEmpty) {
                    List<DocumentSnapshot> snap = [];
                    snap.addAll(snapshot.data!.docs);
                    List<Message> datas =
                        snap.map((e) => Message.fromFirestore(e)).toList();

                    // Last message
                    // var lastMsg = datas.first;
                    // if (lastMsg.sendUid != sb.uid) {
                    //   _updateRecvMessage(lastMsg);
                    // }

                    return ListView.separated(
                      reverse: true,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      separatorBuilder: (ctx, index) {
                        return const SizedBox(height: 8);
                      },
                      itemCount: datas.isNotEmpty ? datas.length : 5,
                      controller: msgScrollCtrl,
                      itemBuilder: (ctx, index) {
                        // print('===== Message: ${datas[index].message} =====');
                        if (datas[index].sendUid != sb.uid) {
                          _recvMsg(sb, cb, datas[index]);
                        }
                        if (datas[index].type == MessageType.voice) {
                          return ChatBubbleAudioCard(
                            avatar: datas[index].sendUid != sb.uid!
                                ? datas[index].sendAvatar!
                                : datas[index].recvAvatar!,
                            msg: datas[index].message!,
                            bubbleType: datas[index].sendUid == sb.uid
                                ? BubbleType.sendBubble
                                : BubbleType.receiverBubble,
                            time: datas[index].timestamp!,
                          );
                        }
                        return ChatBubbleCard(
                          avatar: datas[index].sendUid != sb.uid!
                              ? datas[index].sendAvatar!
                              : datas[index].recvAvatar!,
                          msg: datas[index].message!,
                          type: datas[index].type!,
                          bubbleType: datas[index].sendUid == sb.uid
                              ? BubbleType.sendBubble
                              : BubbleType.receiverBubble,
                          time: datas[index].timestamp!,
                        );
                      },
                    );
                  } else {
                    return Container();
                  }
                } else {
                  return Container();
                }
              },
            ),
          );
  }

  Future _createRoom() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final ChatRoomBloc crb = Provider.of<ChatRoomBloc>(context, listen: false);

    DateTime now = DateTime.now();
    DateTime utc = now.toUtc();
    var timestamp = formatISOTime(utc);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        crb
            .createChatRoom(sb.uid!, widget.user!.uid!, sb.imageUrl!,
                widget.user!.avatar!, sb.name!, widget.user!.name!, timestamp)
            .then((value) {
          if (crb.hasError == false) {
            chatRoomId = crb.chatRoom!.id!;

            msgScrollCtrl = ScrollController()
              ..addListener(_msgScrollController);
            context.read<ChatsBloc>().getData(chatRoomId, mounted, _orderBy);

            // setState(() {});
          } else {
            print('Failed to create chat room');
          }

          // setState(() {
          //   isLoadingRoom = false;
          // });
        });
      }
    });
  }

  _getRoom() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final ChatRoomBloc crb = Provider.of<ChatRoomBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          isLoadingRoom = true;
        });
        print('get room');
        await crb.getRoom(sb.uid, widget.user!.uid!).then((value) {
          if (crb.hasError == false) {
            if (crb.chatRoom == null) {
              // _createRoom();
              isExistRoom = false;
            } else {
              isExistRoom = true;
              chatRoomId = crb.chatRoom!.id!;
              print('===== Chat room id: $chatRoomId =====');

              msgScrollCtrl = ScrollController()
                ..addListener(_msgScrollController);
              context.read<ChatsBloc>().getData(chatRoomId, mounted, _orderBy);
            }
            setState(() {
              isLoadingRoom = false;
            });
          } else {
            openToast('Something went wrong');
            setState(() {
              isLoadingRoom = false;
            });
          }
        });
      }
    });
  }

  _recvMsg(SignInBloc sb, ChatsBloc cb, Message msg) {
    cb.updateMessageRead(true, chatRoomId, msg.id!).then((value) {});
  }

  _updateRecvMessage(Message msg) {
    final crb = context.watch<ChatRoomBloc>();
    crb.updateRoom(chatRoomId, 'last_message', msg.message!);
    crb.updateRoom(chatRoomId, 'timestamp', msg.timestamp!);
  }

  pickMediaDialog(BuildContext ctx) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    await pickImage(false);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.add_photo_alternate_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    await pickImage(true);
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future pickImage(bool camera) async {
    List<XFile>? images;
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      var cropPath = await croppedImage(image.path);

      var url = await uploadImageFile(File(cropPath));

      _sendMsg(status!, MessageType.image, url);
      // setState(() {
      //   // files.add(File(cropPath));
      //   // files.add(File(image!.path));
      // });
    } else {
      print('No image selected!');
    }
  }

  Future<String> uploadImageFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Chat Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _sendMsg(String status, int type, String msg) async {
    final SignInBloc sb = context.read<SignInBloc>();
    final ChatsBloc cb = Provider.of<ChatsBloc>(context, listen: false);
    final crb = context.read<ChatRoomBloc>();

    if (chatRoomId.isEmpty) {
      DateTime now = DateTime.now();
      DateTime utc = now.toUtc();
      var timestamp = formatISOTime(utc);

      await crb.createChatRoom(sb.uid!, widget.user!.uid!, sb.imageUrl!,
          widget.user!.avatar!, sb.name!, widget.user!.name!, timestamp);

      if (crb.hasError == false) {
        chatRoomId = crb.chatRoom!.id!;

        msgScrollCtrl = ScrollController()..addListener(_msgScrollController);
        context.read<ChatsBloc>().getData(chatRoomId, mounted, _orderBy);

        // setState(() {});
      } else {
        print('Failed to create chat room');
        return;
      }
    }

    DateTime now = DateTime.now();
    DateTime utc = now.toUtc();
    var timestamp = formatISOTime(utc);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        cb
            .createMessage(
                chatRoomId,
                sb.uid!,
                sb.name!,
                sb.imageUrl!,
                widget.user!.uid!,
                widget.user!.name!,
                widget.user!.avatar!,
                msg,
                type,
                timestamp)
            .then((value) async {
          if (cb.hasError == false) {
            print('===== Sent message successfully =====');
            // crb.updateRoom(chatRoomId, 'last_message', msg);
            // crb.updateRoomType(chatRoomId, 'last_type', type);
            // crb.updateRoom(chatRoomId, 'timestamp', timestamp);
            if (status == 'Offline') {
              // int count = await crb.getUnreads(chatRoomId);
              // crb.updateUnreadCount(chatRoomId, 'unreads', count);
              if (type == MessageType.text) {
                _sendFcm(msg, sb.name!);
              } else if (type == MessageType.image) {
                _sendFcm('Image', sb.name!);
              } else {
                _sendFcm('Voice', sb.name!);
              }
            }
          } else {
            openToast('Something went wrong');
          }
        });
        msgController.clear();
      }
    });
  }

  // Send fcm
  Future _sendFcm(String msg, String ownName) async {
    print("===== fcm token ${widget.user!.fcmToken} =====");
    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [widget.user!.fcmToken],
      "messageTitle": "Unread message",
      "messageBody": "'$msg' from $ownName",
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");
  }

  // Stream to get chat messages
  Stream<QuerySnapshot> getChatMessage(String groupChatId, int limit) {
    return firestore
        .collection('chats')
        .doc(groupChatId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(limit)
        .snapshots();
  }

  // Stream to get user
  Stream<QuerySnapshot> getUser() {
    return firestore
        .collection('users')
        .where('uid', isEqualTo: widget.user!.uid!)
        .snapshots();
  }

  // Record functions
  Future<void> _start() async {
    try {
      if (await _audioRecorder.hasPermission()) {
        // We don't do anything with this but printing
        final isSupported = await _audioRecorder.isEncoderSupported(
          AudioEncoder.aacLc,
        );
        if (kDebugMode) {
          print('${AudioEncoder.aacLc.name} supported: $isSupported');
        }

        // final devs = await _audioRecorder.listInputDevices();
        // final isRecording = await _audioRecorder.isRecording();

        await _audioRecorder.start();
        _recordDuration = 0;

        _startTimer();
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  Future<void> _stop() async {
    _timer?.cancel();
    _recordDuration = 0;

    final path = await _audioRecorder.stop();

    if (path != null) {
      // widget.onStop(path);
      var url = await uploadAudioFile(File(path));

      _sendMsg(status!, MessageType.voice, url);
    }
  }

  void _startTimer() {
    _timer?.cancel();

    _timer = Timer.periodic(const Duration(seconds: 1), (Timer t) {
      setState(() => _recordDuration++);
    });
  }

  Future<String> uploadAudioFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Chat Audios/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }
}
