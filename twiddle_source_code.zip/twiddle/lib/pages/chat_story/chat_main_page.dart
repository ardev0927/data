import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:twiddle/pages/chat_story/pages/chat_page.dart';
import 'package:twiddle/pages/chat_story/pages/people_page.dart';
import 'package:twiddle/pages/chat_story/pages/stories_page.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';

class ChatMainPage extends StatefulWidget {
  const ChatMainPage({super.key});

  @override
  State<ChatMainPage> createState() => _ChatMainPageState();
}

class _ChatMainPageState extends State<ChatMainPage> {
  int _currentIndex = 0;
  final PageController _pageController = PageController();
  String title = 'chats'.tr();

  @override
  void initState() {
    super.initState();
  }

  Future onWillPop() async {
    if (_currentIndex != 0) {
      setState(() => _currentIndex = 0);
      _pageController.animateToPage(0,
          duration: Duration(milliseconds: 200), curve: Curves.easeIn);
    } else {
      await SystemChannels.platform
          .invokeMethod<void>('SystemNavigator.pop', true);
    }
  }

  void changePage(int index) {
    setState(() {
      _currentIndex = index;
    });
    _pageController.animateToPage(index,
        curve: Curves.easeIn, duration: Duration(milliseconds: 250));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: (() async => await onWillPop()),
      child: Scaffold(
        bottomNavigationBar: _bottomNavigationBar(),
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(Icons.arrow_back),
          ),
          title: Text(
            title,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          actions: [
            // IconButton(onPressed: () {}, icon: Icon(Icons.search_outlined)),
            // IconButton(onPressed: () {}, icon: Icon(Icons.settings_outlined)),
          ],
        ),
        body: _body(),
      ),
    );
  }

  _body() {
    return PageView(
      controller: _pageController,
      allowImplicitScrolling: false,
      physics: NeverScrollableScrollPhysics(),
      children: [
        ChatPage(),
        PeoplePage(),
        StoriesPage(),
      ],
    );
  }

  _bottomNavigationBar() {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: Config().text4Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
        // boxShadow: [
        //   BoxShadow(color: shadowColorGlobal, blurRadius: 10, spreadRadius: 2, offset: Offset(0, 3.0)),
        // ],
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 16.0, right: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            IconButton(
              onPressed: () {
                changePage(0);
                setState(() {
                  title = 'chats'.tr();
                });
              },
              icon: Icon(
                Icons.chat_outlined,
                color: _currentIndex == 0
                    ? Config().primary30Color
                    : Config().text60Color,
              ),
            ),
            IconButton(
              onPressed: () {
                changePage(1);
                setState(() {
                  title = 'users'.tr();
                });
              },
              icon: Icon(
                Icons.group_outlined,
                color: _currentIndex == 1
                    ? Config().primary30Color
                    : Config().text60Color,
              ),
            ),
            IconButton(
              onPressed: () {
                changePage(2);
                setState(() {
                  title = 'stories'.tr();
                });
              },
              icon: Icon(
                Icons.amp_stories_outlined,
                color: _currentIndex == 2
                    ? Config().primary30Color
                    : Config().text60Color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
