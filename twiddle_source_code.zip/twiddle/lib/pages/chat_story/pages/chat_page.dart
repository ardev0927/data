import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:twiddle/blocs/chat_room_bloc.dart';
import 'package:twiddle/blocs/chats_bloc.dart';
import 'package:twiddle/blocs/friends_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/message_card1.dart';
import 'package:twiddle/cards/user_card.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/models/chat_room.dart';
import 'package:twiddle/models/message.dart';
import 'package:twiddle/models/unread_message.dart';
import 'package:twiddle/pages/chat_story/chat/user_message_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../blocs/sign_in_bloc.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  ScrollController? userCtrl, msgCtrl;
  DocumentSnapshot<Object?>? _lastVisible;
  int msgType = 1;
  final String _orderBy = 'timestamp';
  // String fcmToken = '';
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      userCtrl = ScrollController()..addListener(_userScrollListener);
      context.read<FriendsBloc>().getData(sb.uid, mounted);
      // msgCtrl = ScrollController()..addListener(_messageScrollListener);
      // context.read<ChatRoomBloc>().onInit();
      // context.read<ChatRoomBloc>().getRooms(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    userCtrl!.removeListener(_userScrollListener);
    // msgCtrl!.removeListener(_messageScrollListener);
    super.dispose();
  }

  void _userScrollListener() {
    final ub = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();

    if (!ub.isLoading) {
      if (userCtrl!.position.pixels == userCtrl!.position.maxScrollExtent) {
        context.read<FriendsBloc>().setLoading(true);
        context.read<FriendsBloc>().getData(sb.uid, mounted);
      }
    }
  }

  // void _messageScrollListener() {
  //   final gb = context.read<ChatRoomBloc>();
  //   final sb = context.read<SignInBloc>();

  //   if (!gb.isLoading) {
  //     if (msgCtrl!.position.pixels == msgCtrl!.position.maxScrollExtent) {
  //       context.read<ChatRoomBloc>().setLoading(true);
  //       context.read<ChatRoomBloc>().getRooms(sb.uid, mounted);
  //     }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<FriendsBloc>();
    // final crb = context.watch<ChatRoomBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        // crb.onRefresh(sb.uid, mounted);
        ub.onRefresh(sb.uid, mounted);
      },
      child: Column(
        children: [
          usersWidget(),
          ub.hasData == false ? Container() : messageWidget(),
        ],
      ),
    );
  }

  usersWidget() {
    final ub = context.watch<FriendsBloc>();
    return ub.hasData == false
        ? Container()
        : Container(
            padding: const EdgeInsets.only(left: 16),
            height: 80,
            child: ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(width: 16);
              },
              itemCount: ub.data.isNotEmpty ? ub.data.length + 1 : 5,
              scrollDirection: Axis.horizontal,
              controller: userCtrl,
              itemBuilder: (ctx, index) {
                if (index < ub.data.length) {
                  return UserCard(
                    d: ub.data[index],
                    heroTag: 'user$index',
                    width: 48,
                    height: 48,
                    onUserTap: () {
                      nextScreen(
                        context,
                        //     MessageDetailsPage(
                        //       user: ub.users[index],
                        //     ));
                        UserMessagePage(
                          // type: 1,
                          user: ub.data[index],
                          // fcmToken: fcmToken,
                        ),
                      );
                    },
                  );
                }
                return Opacity(
                  opacity: ub.isLoading ? 1.0 : 0.0,
                  child: ub.lastVisible == null
                      ? LoadingCard2(height: 48, width: 48)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  messageWidget() {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            _messageHeaderWidget(),
            const SizedBox(height: 8),
            _messageListWidget(),
          ],
        ),
      ),
    );
  }

  _messageHeaderWidget() {
    return SizedBox(
      height: 40,
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                if (msgType != 1) {
                  setState(() {
                    msgType = 1;
                  });
                }
              },
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: msgType == 1
                      ? Config().primary30Color
                      : Config().text4Color,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.all_inbox_outlined,
                      color: msgType == 1 ? Colors.white : Config().text60Color,
                      size: 15,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        'all_message'.tr(),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: msgType == 1
                              ? Colors.white
                              : Config().text60Color,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {
                if (msgType != 2) {
                  setState(() {
                    msgType = 2;
                  });
                }
              },
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: msgType == 2
                      ? Config().primary30Color
                      : Config().text4Color,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.mark_chat_unread_outlined,
                      color: msgType == 2 ? Colors.white : Config().text60Color,
                      size: 15,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        'unread_message'.tr(),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: msgType == 2
                              ? Colors.white
                              : Config().text60Color,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  _messageListWidget() {
    // final crb = context.watch<ChatRoomBloc>();
    final sb = context.watch<SignInBloc>();

    // return crb.hasData == false
    //     ? Expanded(
    //         child: ListView(
    //           children: [
    //             SizedBox(height: MediaQuery.of(context).size.height * 0.35),
    //             EmptyPage(
    //                 icon: Icons.chat_outlined,
    //                 message: 'no_message_found'.tr(),
    //                 message1: ''),
    //           ],
    //         ),
    //       )
    //     : Expanded(
    return Expanded(
      child: StreamBuilder<QuerySnapshot>(
        stream: getChatRooms(sb.uid!),
        builder: (context, chatRoom) {
          if (chatRoom.connectionState == ConnectionState.active) {
            var rawData = chatRoom.data;
            if (rawData!.docs.isNotEmpty) {
              // _lastVisible = rawData.docs[rawData.docs.length - 1];
            } else {
              return Expanded(
                child: ListView(
                  children: [
                    SizedBox(height: MediaQuery.of(context).size.height * 0.35),
                    EmptyPage(
                        icon: Icons.chat_outlined,
                        message: 'no_message_found'.tr(),
                        message1: ''),
                  ],
                ),
              );
            }
            var chatRooms =
                rawData.docs.map((e) => ChatRoom.fromFirestore(e)).toList();
            return ListView.separated(
              separatorBuilder: (context, index) {
                return const SizedBox(height: 4);
              },
              itemCount: chatRooms.length,
              itemBuilder: (context, index) {
                String avatar = chatRooms[index].avatars!.singleWhere(
                      (element) => element != sb.imageUrl,
                      orElse: () => chatRooms[index].avatars![0],
                    );
                String name = chatRooms[index].names!.singleWhere(
                      (element) => element != sb.name,
                      orElse: () => chatRooms[index].names![0],
                    );
                String uid = chatRooms[index].uids!.singleWhere(
                      (element) => element != sb.uid,
                      orElse: () => chatRooms[index].uids![0],
                    );

                return StreamBuilder<QuerySnapshot>(
                  stream: getLastMessage(chatRooms[index].id!),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.data!.docs.isEmpty) {
                        return Container();
                      }
                      var msg = Message.fromFirestore(snapshot.data!.docs[0]);
                      return StreamBuilder(
                        stream: getUnreadMsgCount(msg.groupId!, sb.uid!),
                        builder: (context, snapshot1) {
                          if (snapshot1.hasData) {
                            if (msgType == 2) {
                              if (snapshot1.data!.docs.isNotEmpty) {
                                return MessageCard1(
                                  avatar: avatar,
                                  name: name,
                                  message: msg.sendUid == sb.uid
                                      ? 'You: ${msg.message}'
                                      : msg.message!,
                                  type: msg.type!,
                                  count: snapshot1.data!.docs.length,
                                  heroTag: 'messagecard1$index',
                                  onItemTap: () {
                                    final ub = context.read<UserBlock>();
                                    ub.getUser(uid, mounted).then((value) {
                                      if (ub.hasError == false) {
                                        // nextScreen(
                                        //     context,
                                        //     MessageDetailsPage(
                                        //       user: ub.data,
                                        //     ));
                                        nextScreen(
                                            context,
                                            UserMessagePage(
                                              // type: 2,
                                              user: ub.data,
                                              // fcmToken: fcmToken,
                                            ));
                                      }
                                    });
                                  },
                                  onLongPress: () {
                                    deleteChatDialog(context, chatRooms[index]);
                                  },
                                );
                              } else {
                                return Container();
                              }
                            }
                            return MessageCard1(
                              avatar: avatar,
                              name: name,
                              message: msg.sendUid == sb.uid
                                  ? 'You: ${msg.message}'
                                  : msg.message!,
                              type: msg.type!,
                              count: snapshot1.data!.docs.length,
                              heroTag: 'messagecard1$index',
                              onItemTap: () {
                                final ub = context.read<UserBlock>();
                                ub.getUser(uid, mounted).then((value) {
                                  if (ub.hasError == false) {
                                    // nextScreen(
                                    //     context,
                                    //     MessageDetailsPage(
                                    //       user: ub.data,
                                    //     ));
                                    nextScreen(
                                        context,
                                        UserMessagePage(
                                          // type: 2,
                                          user: ub.data,
                                          // fcmToken: fcmToken,
                                        ));
                                  }
                                });
                              },
                              onLongPress: () {
                                deleteChatDialog(context, chatRooms[index]);
                              },
                            );
                          } else {
                            return Container();
                          }
                        },
                      );
                    } else {
                      return Container();
                    }
                  },
                );
              },
            );
          } else if (chatRoom.connectionState == ConnectionState.waiting) {
            return Opacity(
              opacity: 1.0,
              child: _lastVisible == null
                  ? LoadingCard(height: 80)
                  : const Center(
                      child: SizedBox(
                          width: 32.0,
                          height: 32.0,
                          child: CupertinoActivityIndicator()),
                    ),
            );
          }
          return Container();
        },
      ),
      // child: ListView.separated(
      //   padding: const EdgeInsets.only(top: 16),
      //   separatorBuilder: (ctx, index) {
      //     return const SizedBox(height: 16);
      //   },
      //   shrinkWrap: true,
      //   itemCount: crb.data.isNotEmpty ? crb.data.length + 1 : 5,
      //   controller: msgCtrl,
      //   itemBuilder: (ctx, index) {
      //     if (index < crb.data.length) {
      //       String avatar = crb.data[index].avatars!.singleWhere(
      //         (element) => element != sb.imageUrl,
      //         orElse: () => crb.data[index].avatars![0],
      //       );
      //       String name = crb.data[index].names!.singleWhere(
      //         (element) => element != sb.name,
      //         orElse: () => crb.data[index].names![0],
      //       );
      //       String uid = crb.data[index].uids!.singleWhere(
      //         (element) => element != sb.uid,
      //         orElse: () => crb.data[index].uids![0],
      //       );
      //       // return Container();
      //       return StreamBuilder<QuerySnapshot>(
      //         stream: getLastMessage(crb.data[index].id!),
      //         builder: (context, snapshot) {
      //           if (snapshot.hasData) {
      //             if (snapshot.data!.docs.isEmpty) {
      //               return Container();
      //             }
      //             var msg = Message.fromFirestore(snapshot.data!.docs[0]);
      //             return StreamBuilder(
      //               stream: getUnreadMsgCount(msg.groupId!, sb.uid!),
      //               builder: (context, snapshot1) {
      //                 if (snapshot1.hasData) {
      //                   if (msgType == 2) {
      //                     if (snapshot1.data!.docs.isNotEmpty) {
      //                       return MessageCard1(
      //                         avatar: avatar,
      //                         name: name,
      //                         message: msg.sendUid == sb.uid
      //                             ? 'You: ${msg.message}'
      //                             : msg.message!,
      //                         type: msg.type!,
      //                         count: snapshot1.data!.docs.length,
      //                         heroTag: 'messagecard1$index',
      //                         onItemTap: () {
      //                           final ub = context.read<UserBlock>();
      //                           ub.getUser(uid, mounted).then((value) {
      //                             if (ub.hasError == false) {
      //                               // nextScreen(
      //                               //     context,
      //                               //     MessageDetailsPage(
      //                               //       user: ub.data,
      //                               //     ));
      //                               nextScreen(
      //                                   context,
      //                                   UserMessagePage(
      //                                     // type: 2,
      //                                     user: ub.data,
      //                                     // fcmToken: fcmToken,
      //                                   ));
      //                             }
      //                           });
      //                         },
      //                         onLongPress: () {
      //                           deleteChatDialog(
      //                               context, crb.data[index]);
      //                         },
      //                       );
      //                     } else {
      //                       return Container();
      //                     }
      //                   }
      //                   return MessageCard1(
      //                     avatar: avatar,
      //                     name: name,
      //                     message: msg.sendUid == sb.uid
      //                         ? 'You: ${msg.message}'
      //                         : msg.message!,
      //                     type: msg.type!,
      //                     count: snapshot1.data!.docs.length,
      //                     heroTag: 'messagecard1$index',
      //                     onItemTap: () {
      //                       final ub = context.read<UserBlock>();
      //                       ub.getUser(uid, mounted).then((value) {
      //                         if (ub.hasError == false) {
      //                           // nextScreen(
      //                           //     context,
      //                           //     MessageDetailsPage(
      //                           //       user: ub.data,
      //                           //     ));
      //                           nextScreen(
      //                               context,
      //                               UserMessagePage(
      //                                 // type: 2,
      //                                 user: ub.data,
      //                                 // fcmToken: fcmToken,
      //                               ));
      //                         }
      //                       });
      //                     },
      //                     onLongPress: () {
      //                       deleteChatDialog(context, crb.data[index]);
      //                     },
      //                   );
      //                 } else {
      //                   return Container();
      //                 }
      //               },
      //             );
      //           } else {
      //             return Container();
      //           }
      //         },
      //       );
      //     }
      //     return Opacity(
      //       opacity: crb.isLoading ? 1.0 : 0.0,
      //       child: crb.lastVisible == null
      //           ? LoadingCard(height: 80)
      //           : const Center(
      //               child: SizedBox(
      //                   width: 32.0,
      //                   height: 32.0,
      //                   child: CupertinoActivityIndicator()),
      //             ),
      //     );
      //   },
      // ),
    );
  }

  getUnreadCount(ChatRoom chatRoom, uid) {
    int count = 0;
    // UnreadMessage? unread = chatRoom.unreads!.firstWhere(
    //   (element) => element.uid == uid,
    //   orElse: () => null,
    // );
    chatRoom.unreads!.forEach((element) {
      if (element.uid == uid) {
        count = element.count!;
      }
    });
    // count = unread.count!;
    return count;
  }

  Stream<QuerySnapshot> getUnreadMsgCount(String groupId, String uid) {
    // int count = 0;
    return firestore
        .collection('chats')
        .doc(groupId)
        .collection('messages')
        .where('recv_uid', isEqualTo: uid)
        .where('read', isEqualTo: false)
        .snapshots();
  }

  // Stream to get chat messages
  Stream<DocumentSnapshot> getUserChat(String uid1) {
    return firestore.collection('chats').doc(uid1).snapshots();
  }

  // Stream to get last messages
  Stream<QuerySnapshot> getLastMessage(String groupId) {
    return firestore
        .collection('chats')
        .doc(groupId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .limit(5)
        .snapshots();
  }

  // Stream to get chat room
  Stream<QuerySnapshot> getChatRooms(String uid) {
    if (_lastVisible == null) {
      return firestore
          .collection('chats')
          .where('uids', arrayContains: uid)
          .orderBy('timestamp', descending: true)
          .limit(20)
          .snapshots();
    } else {
      return firestore
          .collection('chats')
          .where('uids', arrayContains: uid)
          .orderBy('timestamp', descending: true)
          .startAfter([_lastVisible!['timestamp']])
          .limit(20)
          .snapshots();
    }
  }

  void deleteChatDialog(context, ChatRoom chatRoom) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('delete_chat').tr(),
            actions: [
              TextButton(
                child: const Text('no').tr(),
                onPressed: () => Navigator.pop(context),
              ),
              TextButton(
                child: const Text('yes').tr(),
                onPressed: () async {
                  Navigator.pop(context);
                  deleteChat(chatRoom);
                },
              )
            ],
          );
        });
  }

  deleteChat(ChatRoom chatRoom) async {
    final instance = FirebaseFirestore.instance;
    final batch = instance.batch();
    var collection =
        instance.collection('chats').doc(chatRoom.id).collection('messages');
    var snapshots = await collection.get();
    for (var doc in snapshots.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
  }
}
