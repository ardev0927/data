import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twiddle/blocs/friends_bloc.dart';

import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/user_card.dart';
import '../../../cards/user_card2.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../chat/message_details_page.dart';
import '../chat/user_message_page.dart';

class PeoplePage extends StatefulWidget {
  const PeoplePage({super.key});

  @override
  State<PeoplePage> createState() => _PeoplePageState();
}

class _PeoplePageState extends State<PeoplePage> {
  ScrollController? userCtrl;
  int msgType = 1;
  // String fcmToken = '';
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      userCtrl = ScrollController()..addListener(_userScrollListener);
      // context.read<UserBlock>().onInit();
      context.read<FriendsBloc>().getData(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    userCtrl!.removeListener(_userScrollListener);
    super.dispose();
  }

  void _userScrollListener() {
    final ub = context.read<FriendsBloc>();
    final sb = context.read<SignInBloc>();

    if (!ub.isLoading) {
      if (userCtrl!.position.pixels == userCtrl!.position.maxScrollExtent) {
        context.read<FriendsBloc>().setLoading(true);
        context.read<FriendsBloc>().getData(sb.uid, mounted);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<FriendsBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        ub.onRefresh(sb.uid, mounted);
      },
      child: ub.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.person_outline,
                    message: 'no users found'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              padding: const EdgeInsets.only(top: 16),
              separatorBuilder: (ctx, index) {
                return const SizedBox(height: 16);
              },
              itemCount: ub.data.isNotEmpty ? ub.data.length + 1 : 5,
              controller: userCtrl,
              itemBuilder: (ctx, index) {
                if (index < ub.data.length) {
                  return UserCard2(
                    d: ub.data[index],
                    heroTag: 'user$index',
                    onItemTap: () {
                      nextScreen(
                        context,
                        // MessageDetailsPage(
                        //   user: ub.users[index],
                        // ));
                        UserMessagePage(
                          // type: 1,
                          user: ub.data[index],
                          // fcmToken: fcmToken,
                        ),
                      );
                    },
                  );
                }
                return Opacity(
                  opacity: ub.isLoading ? 1.0 : 0.0,
                  child: ub.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: CupertinoActivityIndicator(),
                          ),
                        ),
                );
              },
            ),
    );
  }
}
