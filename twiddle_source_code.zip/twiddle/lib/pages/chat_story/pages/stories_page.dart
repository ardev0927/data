import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:video_compress/video_compress.dart';

import '../../../blocs/stories_bloc.dart';
import '../../../cards/card2.dart';
import '../../../cards/story_card.dart';
import '../../../config/config.dart';
import '../../../services/app_service.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../stories/add_story_page.dart';
import '../../stories/stories_view_page.dart';

class StoriesPage extends StatefulWidget {
  const StoriesPage({super.key});

  @override
  State<StoriesPage> createState() => _StoriesPageState();
}

class _StoriesPageState extends State<StoriesPage> {
  ScrollController? storyController;
  String _orderBy = 'timestamp';
  bool _isLoading = false;

  Uint8List? videoThumbBytes;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      storyController = ScrollController()..addListener(_storyScrollListener);
      context.read<StoriesBloc>().onInit();
      context.read<StoriesBloc>().getData(sb.uid!, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    super.dispose();
    storyController!.removeListener(_storyScrollListener);
  }

  void _storyScrollListener() {
    final db = context.read<StoriesBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (storyController!.position.pixels ==
          storyController!.position.maxScrollExtent) {
        context.read<StoriesBloc>().setLoading(true);
        context.read<StoriesBloc>().getData(sb.uid!, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ssb = context.watch<StoriesBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        ssb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: ssb.hasData == false
          ? GridView.builder(
              controller: storyController,
              padding: const EdgeInsets.only(
                  left: 10, right: 10, top: 15, bottom: 15),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 1),
              itemCount: 1,
              itemBuilder: (_, int index) {
                return Card2(
                  p: sb.imageUrl!,
                  onItemTap: () {
                    showAddStorySheet(context);
                  },
                  mode: 2,
                );
              },
            )
          //    : Container(
          //   padding: const EdgeInsets.only(left: 16, top: 8, bottom: 16),
          //   width: MediaQuery.of(context).size.width,
          //   height: 160,
          //   color: Config().whiteColor,
          //   child: Card2(
          //     p: sb.imageUrl!,
          //     onItemTap: () {
          //       showAddStorySheet(context);
          //     },
          //   ),
          // )
          : GridView.builder(
              controller: storyController,
              padding: const EdgeInsets.only(
                  left: 10, right: 10, top: 15, bottom: 15),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 1),
              itemCount: ssb.data.isNotEmpty ? ssb.data.length + 2 : 10,
              itemBuilder: (_, int index) {
                print('===== ${ssb.data.length} =====');
                if (index < ssb.data.length + 1) {
                  if (index == 0) {
                    return Card2(
                      p: sb.imageUrl!,
                      onItemTap: () {
                        showAddStorySheet(context);
                      },
                      mode: 2,
                    );
                  }
                  var userstory = ssb.data[index - 1];
                  if (twoDaysAgo(userstory.timestamp!)) {
                    // Delete stories on firestore
                    _deleteStories(ssb, userstory.uid);
                    return Container();
                  }
                  return StoryCard(
                    us: ssb.data[index - 1],
                    onItemTap: () {
                      nextScreen(
                          context,
                          StoriesViewpage(
                            uid: ssb.data[index - 1].uid,
                            username: ssb.data[index - 1].username,
                            useravatar: ssb.data[index - 1].useravatar,
                            timestamp: ssb.data[index - 1].timestamp,
                          ));
                    },
                    mode: 2,
                  );
                }
                return Opacity(
                  opacity: ssb.isLoading ? 1.0 : 0.0,
                  child: ssb.lastVisible == null
                      ? LoadingCard(height: null)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }

  showAddStorySheet(BuildContext ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Image
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 1);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.image_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // video
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 2);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.live_tv_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'video'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  pickMediaDialog(BuildContext ctx, int type) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(type == 1
                            ? Icons.add_photo_alternate_outlined
                            : Icons.video_camera_front_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<File?> pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      return File(image.path);
    } else {
      print('No image selected!');
      return null;
    }
  }

  Future<File?> pickVideo(bool camera) async {
    XFile? video;
    if (camera) {
      video = await ImagePicker().pickVideo(source: ImageSource.camera);
    } else {
      video = await ImagePicker().pickVideo(source: ImageSource.gallery);
    }

    var size = await video!.readAsBytes();
    if (size.lengthInBytes > 50 * 1024 * 1024) {
      openToast('The video size should be less than 50MB');
      return null;
    }

    if (video != null) {
      // Generate thumbnail
      var thumbBytes = await VideoCompress.getByteThumbnail(video.path,
          quality: 50, position: -1);

      videoThumbBytes = thumbBytes;

      // Compress video
      setState(() {
        _isLoading = true;
      });
      MediaInfo? mi;
      try {
        await VideoCompress.setLogLevel(0);

        mi = await VideoCompress.compressVideo(video.path,
            quality: VideoQuality.LowQuality,
            includeAudio: true,
            deleteOrigin: true);

        setState(() {
          _isLoading = false;
        });
        return File(mi!.path!);
      } catch (e) {
        VideoCompress.cancelCompression();
        setState(() {
          _isLoading = false;
        });
      }
      // return File(video.path);
    } else {
      print('No image selected!');
      return null;
    }
  }

  _deleteStories(StoriesBloc sb, uid) async {
    final ssb = context.watch<StoriesBloc>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        sb.deleteUserStory(uid).then((value) {
          if (sb.hasError == false) {
            ssb.onRefresh(uid, mounted, _orderBy);
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
