import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/forget_password/complete_password_page.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';
import '../../widgets/elevated_button_widget.dart';

class ChangePasswordPage extends StatefulWidget {
  const ChangePasswordPage({super.key});

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _pwControl = TextEditingController();
  final _pwConfirmControl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Enter Your Name
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'forget_password'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 40),
          // Email Or Phone number
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'new_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwConfirmControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                // emailPhone = value;
              });
            },
          ),
          const SizedBox(height: 16),
          // Password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'confirm_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwConfirmControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                // emailPhone = value;
              });
            },
          ),
          const SizedBox(height: 100),
          // Sign In button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              nextScreen(context, CompletePasswordPage());
            },
          ),
        ],
      ),
    );
  }
}
