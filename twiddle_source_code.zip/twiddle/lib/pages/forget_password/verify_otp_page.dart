import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:twiddle/pages/forget_password/change_password_page.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';
import '../../widgets/elevated_button_widget.dart';

class VerifyOtpPage extends StatefulWidget {
  const VerifyOtpPage({super.key});

  @override
  State<VerifyOtpPage> createState() => _VerifyOtpPageState();
}

class _VerifyOtpPageState extends State<VerifyOtpPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final controller = TextEditingController();
  final focusNode = FocusNode();
  bool showError = false;

  @override
  void dispose() {
    controller.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              _verifyBody(),
            ],
          ),
        ),
      ),
    );
  }

  _verifyBody() {
    const borderColor = Color.fromRGBO(114, 178, 238, 1);
    const errorColor = Color.fromRGBO(255, 234, 238, 1);
    final defaultPinTheme = PinTheme(
      width: 40,
      height: 40,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      textStyle: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w400,
      ),
      decoration: BoxDecoration(
        color: Config().secondary21Color,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Colors.transparent),
      ),
    );
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Verify OTP
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'verify_otp'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 55),
          SizedBox(
            height: 50,
            child: Pinput(
              length: 4,
              controller: controller,
              focusNode: focusNode,
              defaultPinTheme: defaultPinTheme,
              onCompleted: (pin) {
                setState(() => showError = pin != '5555');
              },
              focusedPinTheme: defaultPinTheme.copyWith(
                height: 50,
                width: 50,
                decoration: defaultPinTheme.decoration!.copyWith(
                  border: Border.all(color: borderColor),
                ),
              ),
              errorPinTheme: defaultPinTheme.copyWith(
                decoration: BoxDecoration(
                  color: errorColor,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),
          const SizedBox(height: 23),
          // Time remaining
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('time_remaining'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
              Text(': 4m 42s',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
            ],
          ),
          const SizedBox(height: 150),
          // Resend
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('didnt_receive_code'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
              const SizedBox(width: 5),
              Text('resend_sms'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.black)),
            ],
          ),
          const SizedBox(height: 80),
          // Continue button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              nextScreen(context, ChangePasswordPage());
            },
          ),
        ],
      ),
    );
  }
}
