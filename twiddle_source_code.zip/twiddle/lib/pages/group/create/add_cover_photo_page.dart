import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/group/create/add_description_page.dart';
import 'package:twiddle/utils/datetime.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:uuid/uuid.dart';

import '../../../blocs/group_bloc.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../../utils/upload_files.dart';
import '../../../widgets/app_mini_button.dart';
import '../../../widgets/app_picker_item.dart';

class AddCoverPhotoPage extends StatefulWidget {
  final Function(File? cover)? onPressed;
  const AddCoverPhotoPage({
    super.key,
    required this.onPressed,
  });

  @override
  State<AddCoverPhotoPage> createState() => _AddCoverPhotoPageState();
}

class _AddCoverPhotoPageState extends State<AddCoverPhotoPage> {
  File? coverFile;
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    return _body();
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'add_cover_photo'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'invite_member_description'.tr(),
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
          Container(
            alignment: Alignment.center,
            margin: const EdgeInsets.symmetric(vertical: 16),
            height: 200,
            width: MediaQuery.of(context).size.width,
            decoration: coverFile != null
                ? BoxDecoration(
                    color: Config().text4Color,
                    image: DecorationImage(
                        image: Image.file(coverFile!).image, fit: BoxFit.cover),
                  )
                : BoxDecoration(
                    color: Config().text4Color,
                  ),
            child: Center(
              child: GestureDetector(
                onTap: () {
                  //
                  _showPhotoSheet(context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.image),
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        'upload_cover_photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: coverFile == null ? null : widget.onPressed!(coverFile),
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            child: Text(
              'next'.tr(),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  // Bottom sheet for cover
  _showPhotoSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickImage(false);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/images/add_photo_alternate.svg',
                      color: Config().text90Color,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickImage(true);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/camera.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      coverFile = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  // _handleSetCoverPhoto(Group g) async {
  //   var gp = Provider.of<GroupBloc>(context, listen: false);
  //   await AppService().checkInternet().then((hasInternet) async {
  //     if (hasInternet == false) {
  //       openSnacbar(context, 'no internet'.tr());
  //     } else {
  //       // Upload cover photo to firebase storage
  //       if (coverFile != null) {
  //         setState(() {
  //           _saving = true;
  //         });
  //         String coverPath = await uploadGroupCoverFile(context, coverFile!, g);

  //         gp.updateGroup(g.id!, 'cover_photo', coverPath).then((value) async {
  //           setState(() {
  //             _saving = false;
  //           });
  //           if (gp.hasError == false) {
  //             var ret = await Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                     builder: (context) =>
  //                         AddDescriptionPage(group: gp.group)));
  //             if (ret != null && ret == true) {
  //               // _result = ret;
  //               Navigator.pop(context, ret);
  //             }
  //           } else {
  //             openToast('Something went wrong');
  //           }
  //         });
  //       }
  //     }
  //   });
  // }
}
