import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/group/group_post_page.dart';
import 'package:twiddle/pages/post/create_post_page.dart';
import 'package:twiddle/utils/datetime.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../blocs/group_bloc.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../../widgets/app_mini_button.dart';
import '../../../widgets/app_picker_item.dart';

class AddDescriptionPage extends StatefulWidget {
  final Function(String? description, String? week, String? time)? onPressed;

  AddDescriptionPage({super.key, required this.onPressed});

  @override
  State<AddDescriptionPage> createState() => _AddDescriptionPageState();
}

class _AddDescriptionPageState extends State<AddDescriptionPage> {
  final _descCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String description = '';
  bool _saving = false;
  bool _result = false;

  String? selectedTime;
  String _week = '';
  final List<String> _weeks = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  @override
  void dispose() {
    _descCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _body();
  }

  _body() {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'add_description'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'invite_member_description'.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: TextFormField(
                controller: _descCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.all(16),
                  hintText: 'describe_your_group'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                keyboardType: TextInputType.multiline,
                maxLines: 8,
                validator: (String? value) {
                  if (value!.length == 0) return "This field can't be empty";
                  return null;
                },
                onChanged: (value) {
                  setState(() {
                    description = value;
                  });
                },
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'hours_of_opperations'.tr(),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text90Color,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                AppMiniButton(
                  _weeks[0][0],
                  fontWeight:
                      _week == _weeks[0] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Monday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[1][0],
                  fontWeight:
                      _week == _weeks[1] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Tuesday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[2][0],
                  fontWeight:
                      _week == _weeks[2] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Wednesday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[3][0],
                  fontWeight:
                      _week == _weeks[3] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Thursday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[4][0],
                  fontWeight:
                      _week == _weeks[4] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Friday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[5][0],
                  fontWeight:
                      _week == _weeks[5] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Saturday';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[6][0],
                  fontWeight:
                      _week == _weeks[6] ? FontWeight.bold : FontWeight.w400,
                  onPressed: () {
                    setState(() {
                      _week = 'Sunday';
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'select_time'.tr(),
              leading: const Icon(Icons.schedule_outlined),
              value: selectedTime,
              onPressed: _onShowTimePicker,
            ),
            const Spacer(),
            ElevatedButton(
              onPressed:
                  description.isEmpty || _week.isEmpty || selectedTime == null
                      ? null
                      : widget.onPressed!(description, _week, selectedTime),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: Text(
                'create_group'.tr(),
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }

  ///Show Picker Time
  void _onShowTimePicker() async {
    final now = TimeOfDay.now();
    final picked = await showTimePicker(
      context: context,
      initialTime: now,
    );
    if (picked != null) {
      setState(() {
        selectedTime = picked.viewTime;
      });
    }
  }

  _handleUpdateDescription(Group g) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      FocusScope.of(context).requestFocus(new FocusNode());

      await AppService().checkInternet().then((hasInternet) {
        if (hasInternet == false) {
          openSnacbar(context, 'no internet'.tr());
        } else {
          setState(() {
            _saving = true;
          });

          gp.updateGroup(g.id!, 'description', description).then((value) async {
            setState(() {
              _saving = false;
            });
            if (gp.hasError == false) {
              // var ret = await Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => GroupPostPage(group: gp.group)));
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CreatePostPage(type: PostType.empty, g: gp.group)));
              if (ret != null && ret == true) {
                _result = ret;
                Navigator.pop(context, _result);
              }
            } else {
              openToast('Something went wrong');
            }
          });
        }
      });
    }
  }
}
