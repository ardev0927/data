import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../../config/config.dart';
import '../../../utils/toast.dart';
import '../../../widgets/app_picker_item.dart';

class AddGroupNamePage extends StatefulWidget {
  final Function(String? name, String? privacy)? onPressed;
  const AddGroupNamePage({super.key, required this.onPressed});

  @override
  State<AddGroupNamePage> createState() => _AddGroupNamePageState();
}

class _AddGroupNamePageState extends State<AddGroupNamePage> {
  final _formKey = GlobalKey<FormState>();
  final _groupCtrl = TextEditingController();
  String group = '';
  String? privacy;
  bool _creating = false;

  @override
  Widget build(BuildContext context) {
    return _body();
  }

  _body() {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            textFieldWidget(controller: _groupCtrl),
            AppPickerItem(
              title: 'choose_privacy'.tr(),
              value: privacy,
              onPressed: _showChoosePrivacySheet,
            ),
            // textItem(
            //   name: privacy,
            //   onTap: () {
            //     // _showGenderDialog(context);
            //     _showChoosePrivacySheet(context);
            //   },
            // ),
            const Spacer(),
            // Create group button
            ElevatedButton(
              onPressed:
                  privacy == null ? null : widget.onPressed!(group, privacy),
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: _creating
                  ? CircularProgressIndicator()
                  : Text(
                      'create_group'.tr(),
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  textItem({
    required String? name,
    required Function()? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.only(top: 5, bottom: 16),
        decoration: BoxDecoration(
            color: Config().text4Color, borderRadius: BorderRadius.circular(8)),
        child: Row(
          children: [
            Text(
              name!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color),
            ),
            const Spacer(),
            Icon(Icons.keyboard_arrow_down)
          ],
        ),
      ),
    );
  }

  Padding textFieldWidget({required TextEditingController? controller}) {
    return Padding(
      padding: const EdgeInsets.only(top: 5, bottom: 16),
      child: TextFormField(
        decoration: InputDecoration(
          // enabledBorder: ,
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: Config().text4Color)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: Config().text4Color)),
          fillColor: Config().text4Color,
          filled: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12),
          hintText: 'nate_your_group'.tr(),
          hintStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Config().text90Color),
        ),
        controller: controller,
        validator: (String? value) {
          if (value!.length == 0) return "This field can't be empty";
          return null;
        },
        onChanged: (value) {
          setState(() {
            group = value;
          });
        },
      ),
    );
  }

  // Bottom sheet for group privacy
  _showChoosePrivacySheet() {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: context,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                setState(() {
                  privacy = 'public'.tr();
                });
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.public_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // private
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                privacy = 'private'.tr();
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.lock_outline),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'private'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // _handleCreateGroup() async {
  //   var sb = context.read<SignInBloc>();
  //   var gp = Provider.of<GroupBloc>(context, listen: false);
  //   if (_formKey.currentState!.validate()) {
  //     _formKey.currentState!.save();
  //     FocusScope.of(context).requestFocus(new FocusNode());

  //     setState(() {
  //       _creating = true;
  //     });

  //     await AppService().checkInternet().then((hasInternet) {
  //       if (hasInternet == false) {
  //         openSnacbar(context, 'no internet'.tr());
  //       } else {
  //         String timestamp = DateTime.now().toIso8601String();
  //         gp
  //             .createGroup(sb, group, '', privacy, '', timestamp)
  //             .then((value) async {
  //           setState(() {
  //             _creating = false;
  //           });
  //           if (gp.hasError == false) {
  //             var ret = await Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                     builder: (context) =>
  //                         InviteMembersPage(group: gp.group)));
  //             if (ret != null && ret == true) {
  //               Navigator.pop(context, gp.group);
  //             }
  //           } else {
  //             openToast('Something went wrong');
  //           }
  //         });
  //       }
  //     });
  //   }
  // }
}
