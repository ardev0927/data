import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/pages/group/create/add_cover_photo_page.dart';
import 'package:twiddle/pages/group/create/add_description_page.dart';
import 'package:twiddle/pages/group/create/add_group_name.dart';
import 'package:twiddle/pages/group/create/invite_members_page.dart';
import 'package:twiddle/utils/datetime.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';

import '../../../config/config.dart';
import '../../../services/app_service.dart';
import '../../../utils/other.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/upload_files.dart';
import '../../../utils/validate.dart';
import '../../../widgets/app_mini_button.dart';
import '../../../widgets/app_picker_item.dart';
import '../../../widgets/app_text_input.dart';

class CreateGroupPage extends StatefulWidget {
  const CreateGroupPage({super.key});

  @override
  State<CreateGroupPage> createState() => _CreateGroupPageState();
}

class _CreateGroupPageState extends State<CreateGroupPage> {
  final _formKey = GlobalKey<FormState>();
  bool _creating = false;
  bool _result = false;
  int pageIndex = 0;

  File? groupCoverPhoto;
  String? groupName,
      groupPrivacy,
      groupDescription,
      groupOpenTime,
      groupCloseTime;

  /// Group name
  final _textGroupNameCtrl = TextEditingController();
  final _focusGroupName = FocusNode();
  String? _validGroupName;
  String? _validGroupPrivacy;

  // Group Describe
  final _textGroupDescribeCtrl = TextEditingController();
  final _focusGroupDescribe = FocusNode();
  String? _validGroupDescribe,
      _validGroupWeek,
      _valideGroupOpenTime,
      _valideGroupCloseTime;

  final List<String> _weeks = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  String _monday = '';
  String _tuesday = '';
  String _wednesday = '';
  String _thursday = '';
  String _friday = '';
  String _saturday = '';
  String _sunday = '';

  String groupWeek = '';

  /// Get title
  getTitle() {
    if (pageIndex == 0) {
      return 'create_group'.tr();
    } else if (pageIndex == 1) {
      return 'cover_photo'.tr();
    } else {
      return 'description'.tr();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            if (pageIndex == 2 || pageIndex == 1) {
              setState(() {
                pageIndex -= 1;
              });
            } else {
              Navigator.pop(context, null);
            }
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          getTitle(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    if (pageIndex == 0) {
      return _addGroupNameBody();
    } else if (pageIndex == 1) {
      return _groupCoverPhotoBody();
    } else {
      return _descriptionBody();
    }
  }

  /// Group name and private widget
  _addGroupNameBody() {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            AppTextInput(
              hintText: 'nate_your_group'.tr(),
              errorText: _validGroupName,
              focusNode: _focusGroupName,
              textInputAction: TextInputAction.done,
              // trailing: Cont,
              onSubmitted: (text) {},
              onChanged: (text) {
                setState(() {
                  _validGroupName = UtilValidator.validate(
                    _textGroupNameCtrl.text,
                  );
                });
              },
              controller: _textGroupNameCtrl,
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'choose_privacy'.tr(),
              value: groupPrivacy,
              onPressed: _showChoosePrivacySheet,
            ),
            const Spacer(),
            // Create group button
            ElevatedButton(
              onPressed: () {
                UtilOther.hiddenKeyboard(context);
                setState(() {
                  _validGroupName = UtilValidator.validate(
                    _textGroupNameCtrl.text,
                  );
                  _validGroupPrivacy = UtilValidator.validate(groupPrivacy!);
                });

                if (_validGroupName == null && _validGroupPrivacy == null) {
                  setState(() {
                    groupName = _textGroupNameCtrl.text;
                    pageIndex = 1;
                  });
                }
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: Text(
                'next'.tr(),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Group cover photo body
  _groupCoverPhotoBody() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'add_cover_photo'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'invite_member_description'.tr(),
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
          Container(
            alignment: Alignment.center,
            margin: const EdgeInsets.symmetric(vertical: 16),
            height: 200,
            width: MediaQuery.of(context).size.width,
            decoration: groupCoverPhoto != null
                ? BoxDecoration(
                    color: Config().text4Color,
                    image: DecorationImage(
                        image: Image.file(groupCoverPhoto!).image,
                        fit: BoxFit.cover),
                  )
                : BoxDecoration(
                    color: Config().text4Color,
                  ),
            child: Center(
              child: GestureDetector(
                onTap: () {
                  //
                  _showPhotoSheet(context);
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.image),
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        'upload_cover_photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              if (groupCoverPhoto == null) {
                openToast('Please upload a image');
              } else {
                setState(() {
                  pageIndex = 2;
                });
              }
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            child: Text(
              'next'.tr(),
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  /// Description & week & time body
  _descriptionBody() {
    return Form(
      key: _formKey,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'add_description'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'invite_member_description'.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
            ),
            AppTextInput(
              hintText: 'describe_your_group'.tr(),
              errorText: _validGroupDescribe,
              focusNode: _focusGroupDescribe,
              maxLines: 5,
              textInputAction: TextInputAction.done,
              // trailing: Cont,
              onSubmitted: (text) {},
              onChanged: (text) {
                setState(() {
                  _validGroupDescribe = UtilValidator.validate(
                    _textGroupDescribeCtrl.text,
                  );
                });
              },
              controller: _textGroupDescribeCtrl,
            ),
            const SizedBox(height: 16),
            Text(
              'hours_of_opperations'.tr(),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text90Color,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                AppMiniButton(
                  _weeks[0][0],
                  backgroundColor: groupWeek == 'Monday' && _monday == 'Monday'
                      ? Config().appColor
                      : Config().primary4Color,
                  fontWeight: _monday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Monday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: groupWeek == 'Monday' && _monday == 'Monday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Monday' ? '' : 'Monday';
                      } else {
                        groupWeek = _monday.isNotEmpty ? '' : 'Monday';
                      }
                      _monday = _monday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _wednesday =
                          _thursday = _friday = _saturday = _sunday = '';
                    });
                  },
                ),
                AppMiniButton(_weeks[1][0],
                    backgroundColor:
                        groupWeek == 'Tuesday' && _tuesday == 'Tuesday'
                            ? Config().appColor
                            : Config().primary4Color,
                    fontWeight: _tuesday.isNotEmpty
                        ? groupWeek.isEmpty
                            ? FontWeight.bold
                            : groupWeek == 'Tuesday'
                                ? FontWeight.bold
                                : FontWeight.w400
                        : FontWeight.w400,
                    textColor: groupWeek == 'Tuesday' && _tuesday == 'Tuesday'
                        ? Config().whiteColor
                        : Config().text100Color, onPressed: () {
                  setState(() {
                    if (groupWeek.isNotEmpty) {
                      groupWeek = groupWeek == 'Tuesday' ? '' : 'Tuesday';
                    } else {
                      groupWeek = _tuesday.isNotEmpty ? '' : 'Tuesday';
                    }
                    _tuesday = _tuesday.isNotEmpty ? '' : groupWeek;
                    _monday = _wednesday =
                        _thursday = _friday = _saturday = _sunday = '';
                  });
                }),
                AppMiniButton(
                  _weeks[2][0],
                  backgroundColor:
                      groupWeek == 'Wednesday' && _wednesday == 'Wednesday'
                          ? Config().appColor
                          : Config().primary4Color,
                  fontWeight: _wednesday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Wednesday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor:
                      groupWeek == 'Wednesday' && _wednesday == 'Wednesday'
                          ? Config().whiteColor
                          : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Wednesday' ? '' : 'Wednesday';
                      } else {
                        groupWeek = _wednesday.isNotEmpty ? '' : 'Wednesday';
                      }
                      _wednesday = _wednesday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _monday =
                          _thursday = _friday = _saturday = _sunday = '';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[3][0],
                  backgroundColor:
                      groupWeek == 'Thursday' && _thursday == 'Thursday'
                          ? Config().appColor
                          : Config().primary4Color,
                  fontWeight: _thursday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Thursday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: groupWeek == 'Thursday' && _thursday == 'Thursday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Thursday' ? '' : 'Thursday';
                      } else {
                        groupWeek = _thursday.isNotEmpty ? '' : 'Thursday';
                      }
                      _thursday = _thursday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _wednesday =
                          _monday = _friday = _saturday = _sunday = '';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[4][0],
                  backgroundColor: groupWeek == 'Friday' && _friday == 'Friday'
                      ? Config().appColor
                      : Config().primary4Color,
                  fontWeight: _friday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Friday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: groupWeek == 'Friday' && _friday == 'Friday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Friday' ? '' : 'Friday';
                      } else {
                        groupWeek = _friday.isNotEmpty ? '' : 'Friday';
                      }
                      _friday = _friday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _wednesday =
                          _thursday = _monday = _saturday = _sunday = '';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[5][0],
                  backgroundColor: Config().primary4Color,
                  fontWeight: _saturday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Saturday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: groupWeek == 'Saturday' && _saturday == 'Saturday'
                      ? Config().appColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Saturday' ? '' : 'Saturday';
                      } else {
                        groupWeek = _saturday.isNotEmpty ? '' : 'Saturday';
                      }
                      _saturday = _saturday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _wednesday =
                          _thursday = _friday = _monday = _sunday = '';
                    });
                  },
                ),
                AppMiniButton(
                  _weeks[6][0],
                  backgroundColor: Config().primary4Color,
                  fontWeight: _sunday.isNotEmpty
                      ? groupWeek.isEmpty
                          ? FontWeight.bold
                          : groupWeek == 'Sunday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: groupWeek == 'Sunday' && _sunday == 'Sunday'
                      ? Config().appColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (groupWeek.isNotEmpty) {
                        groupWeek = groupWeek == 'Sunday' ? '' : 'Sunday';
                      } else {
                        groupWeek = _sunday.isNotEmpty ? '' : 'Sunday';
                      }
                      _sunday = _sunday.isNotEmpty ? '' : groupWeek;
                      _tuesday = _wednesday =
                          _thursday = _friday = _saturday = _monday = '';
                    });
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'open_time'.tr(),
              leading: const Icon(Icons.schedule_outlined),
              value: groupOpenTime,
              onPressed: () async {
                var time = await _onShowTimePicker();
                setState(() {
                  groupOpenTime = time;
                });
              },
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'close_time'.tr(),
              leading: const Icon(Icons.schedule_outlined),
              value: groupCloseTime,
              onPressed: () async {
                var time = await _onShowTimePicker();
                setState(() {
                  groupCloseTime = time;
                });
              },
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                UtilOther.hiddenKeyboard(context);
                setState(() {
                  _validGroupDescribe = UtilValidator.validate(
                    _textGroupDescribeCtrl.text,
                  );
                  _validGroupWeek = UtilValidator.validate(groupWeek);
                  _valideGroupOpenTime = UtilValidator.validate(groupOpenTime!);
                  _valideGroupCloseTime =
                      UtilValidator.validate(groupCloseTime!);
                });

                if (_validGroupDescribe == null &&
                    _validGroupWeek == null &&
                    _valideGroupOpenTime == null &&
                    _valideGroupCloseTime == null) {
                  groupDescription = _textGroupDescribeCtrl.text;
                  _handleCreateGroup();
                }
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: _creating
                  ? CircularProgressIndicator()
                  : Text(
                      'create_group'.tr(),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // Bottom sheet for group privacy
  _showChoosePrivacySheet() {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: context,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                setState(() {
                  groupPrivacy = 'public'.tr();
                });
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.public_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // private
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                setState(() {
                  groupPrivacy = 'private'.tr();
                });
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.lock_outline),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'private'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Bottom sheet for cover
  _showPhotoSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickImage(false);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/images/add_photo_alternate.svg',
                      color: Config().text90Color,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickImage(true);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/camera.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  /// Pick cover image
  Future pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      groupCoverPhoto = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  ///Show Picker Time
  Future<String?>? _onShowTimePicker() async {
    String? time;
    final now = TimeOfDay.now();
    final picked = await showTimePicker(
      context: context,
      initialTime: now,
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        MaterialLocalizations localization = MaterialLocalizations.of(context);
        time = localization.formatTimeOfDay(picked);
        // groupTime = picked.format(context);
      });
    }
    return time;
  }

  _handleCreateGroup() async {
    var sb = context.read<SignInBloc>();
    var gp = Provider.of<GroupBloc>(context, listen: false);
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      FocusScope.of(context).requestFocus(new FocusNode());

      await AppService().checkInternet().then((hasInternet) {
        if (hasInternet == false) {
          openSnacbar(context, 'no internet'.tr());
        } else {
          setState(() {
            _creating = true;
          });

          //
          String timestamp = DateTime.now().toIso8601String();
          gp
              .createGroup(sb, groupName!, groupDescription!, groupPrivacy!,
                  groupWeek, groupOpenTime!, groupCloseTime!, '', timestamp)
              .then((value) async {
            // setState(() {
            //   _creating = false;
            // });
            if (gp.hasError == false) {
              // Upload cover photo
              String coverPath = await uploadGroupCoverFile(
                  context, groupCoverPhoto!, gp.group!);

              await gp
                  .updateGroup(gp.group!.id!, 'cover_photo', coverPath)
                  .then((value) async {
                // nextScreen(context, page);
                gp.group!.coverPhoto = coverPath;

                var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            InviteMembersPage(group: gp.group)));
                if (ret != null && ret == true) {
                  Navigator.pop(context, gp.group);
                }
              });
            } else {
              setState(() {
                _creating = false;
              });
              openToast('Something went wrong');
            }
          });
        }
      });
    }
  }
}
