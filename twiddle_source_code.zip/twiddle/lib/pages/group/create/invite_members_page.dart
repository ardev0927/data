import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/invite_card.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/pages/group/create/add_cover_photo_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../config/config.dart';
import '../../../utils/empty.dart';
import '../../../utils/enums.dart';
import '../../../utils/loading_cards.dart';
import '../../post/create_post_page.dart';

class InviteMembersPage extends StatefulWidget {
  InviteMembersPage({super.key, required this.group});
  Group? group;

  @override
  State<InviteMembersPage> createState() => _InviteMembersPageState();
}

class _InviteMembersPageState extends State<InviteMembersPage> {
  final _searchCtrl = TextEditingController();
  ScrollController? controller;
  bool _result = false;

  @override
  void initState() {
    super.initState();
    final sb = context.read<SignInBloc>();

    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = ScrollController()..addListener(_scrollListener);
      context.read<UserBlock>().onInit();
      context.read<UserBlock>().getRandomUsers(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<UserBlock>().setLoading(true);
        context.read<UserBlock>().getRandomUsers(sb.uid, mounted);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'invite_members'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              nextScreenReplace(
                context,
                CreatePostPage(
                  type: PostType.empty,
                  g: widget.group,
                  isCreatedGroup: true,
                ),
              );
              // var ret = await Navigator.pushReplacement(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => CreatePostPage(
              //       type: PostType.empty,
              //       g: widget.group,
              //       isCreatedGroup: true,
              //     ),
              //   ),
              // );
              // if (ret != null && ret == true) {
              //   _result = ret;
              //   Navigator.pop(context, _result);
              // }
              // nextScreen(context, AddCoverPhotoPage());
            },
            child: Text(
              'next'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    final ub = context.watch<UserBlock>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        ub.onRandomRefresh(sb.uid, mounted);
      },
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'your_group_has_been_created'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Text(
                'invite_member_description'.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
            ),
            // Users list
            Expanded(
              child: ub.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        EmptyPage(
                            icon: Icons.person_outline,
                            message: 'no users found'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      // padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                      controller: controller,
                      // physics: AlwaysScrollableScrollPhysics(),
                      // physics: ClampingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: ub.users.length != 0 ? ub.users.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 15,
                      ),

                      //shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < ub.users.length) {
                          return InviteCard(
                              d: ub.users[index],
                              g: widget.group!,
                              heroTag: 'invite$index',
                              onInvitePressed: () {});
                        }
                        return Opacity(
                          opacity: ub.isLoading ? 1.0 : 0.0,
                          child: ub.lastVisible == null
                              ? LoadingCard(height: 60)
                              : Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
