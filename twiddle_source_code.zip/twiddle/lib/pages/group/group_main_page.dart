import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/group/create/create_group_page.dart';
import 'package:twiddle/pages/group/setting/group_setting_page.dart';
import 'package:twiddle/pages/group/tabs/discover_tab.dart';
import 'package:twiddle/pages/group/tabs/for_you_tab.dart';
import 'package:twiddle/pages/group/tabs/manage_tab.dart';
import 'package:twiddle/pages/group/tabs/your_groups_tab.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';

class GroupMainPage extends StatefulWidget {
  const GroupMainPage({super.key, required this.index});
  final int? index;

  @override
  State<GroupMainPage> createState() => _GroupMainPageState();
}

class _GroupMainPageState extends State<GroupMainPage>
    with TickerProviderStateMixin {
  TabController? _tabController;

  final List<Tab> _tabs = [
    // Tab(
    //   text: 'your_posts'.tr(),
    // ),
    Tab(
      text: 'your_groups'.tr(),
    ),
    Tab(
      text: 'discover'.tr(),
    ),
    Tab(
      text: 'manage'.tr(),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: _tabs.length,
      vsync: this,
      initialIndex: widget.index!,
    );
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Config().text4Color,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          IconButton(
              onPressed: () {
                nextScreen(context, CreateGroupPage());
              },
              icon: Icon(Icons.add)),
          IconButton(onPressed: () {}, icon: Icon(Icons.search_outlined)),
          IconButton(
              onPressed: () {
                nextScreen(context, GroupSettingPage());
              },
              icon: Icon(Icons.settings_outlined)),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return DefaultTabController(
      length: _tabs.length,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
            child: TabBar(
              controller: _tabController,
              labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              labelColor: Config().text90Color,
              unselectedLabelStyle:
                  TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              unselectedLabelColor: Config().text90Color,
              indicatorColor: Config().primary30Color,
              indicatorWeight: 4,
              labelPadding: const EdgeInsets.all(4),
              tabs: _tabs,
            ),
          ),
          Flexible(
            child: TabBarView(
              controller: _tabController,
              children: const [
                // ForYouTab(),
                YourGroupsTab(),
                DiscoverTab(),
                ManageTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
