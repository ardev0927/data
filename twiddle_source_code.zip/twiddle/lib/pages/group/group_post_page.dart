import 'dart:io';
import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:uuid/uuid.dart';
import 'package:video_compress/video_compress.dart';

import '../../blocs/album_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../cards/card3.dart';
import '../../cards/video_card2.dart';
import '../../config/config.dart';
import '../../models/album.dart';
import '../../models/group.dart';
import '../../models/post.dart';
import '../../models/user.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image_with_dark.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/crop_image.dart';
import '../../utils/feeling_utils.dart';
import '../../utils/format_time.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../post/add_location_page.dart';
import '../post/article_link_page.dart';
import '../post/create_poll_page.dart';
import '../post/feeling_activity_page.dart';
import '../post/live/live_main_page.dart';
import '../post/select_album_page.dart';
import '../post/select_gif_page.dart';
import '../post/tag_friends_page.dart';

class GroupPostPage extends StatefulWidget {
  GroupPostPage({super.key, required this.group, this.p});
  Group? group;
  Post? p;

  @override
  State<GroupPostPage> createState() => _GroupPostPageState();
}

class _GroupPostPageState extends State<GroupPostPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _descControl = TextEditingController();

  String _desc = '';
  String _privacy = 'public';
  String _album = 'Album';
  Album? album;
  String _feeling = '';
  List<File> files = [];
  List<String> gifUrls = [];
  File? videoFile;
  bool _isUserFeed = false;
  bool _isGroup = true;
  bool _isLoading = false;
  int postType = 1;
  Map<String, dynamic> location = {};
  String articleUrl = '';
  String _tagFriendNicknames = '';
  List<String> _tagFriends = [];

  Uint8List? videoThumbBytes;
  bool isSharedPost = false;
  String sharedId = '';

  @override
  void initState() {
    if (widget.p != null) {
      isSharedPost = true;
      sharedId = widget.p!.postId!;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'post'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (_descControl.text.isNotEmpty &&
                  files.isEmpty &&
                  videoFile == null &&
                  gifUrls.isEmpty &&
                  location.isEmpty &&
                  articleUrl.isEmpty) {
                postType = 3; // Only text post
                _post();
              } else if (_descControl.text.isEmpty &&
                  files.isEmpty &&
                  gifUrls.isEmpty &&
                  location.isEmpty &&
                  articleUrl.isEmpty) {
                openToast('Please add text, photo/video or gif to post');
              } else {
                _post();
              }
            },
            child: Text(
              'post'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    var appbarHeight =
        MediaQuery.of(context).padding.top + AppBar().preferredSize.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height - appbarHeight,
          child: Stack(
            children: [
              Column(
                children: [
                  // Header
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: Colors.grey[300],
                          backgroundImage:
                              CachedNetworkImageProvider(sb.imageUrl!),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    sb.name!,
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: Config().text100Color),
                                  ),
                                  _feeling.isEmpty
                                      ? Container()
                                      : Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8, right: 4),
                                              child: SvgPicture.asset(
                                                  'assets/images/$_feeling.svg',
                                                  width: 18,
                                                  height: 18),
                                            ),
                                            Text(
                                              _feeling.contains('feeling_')
                                                  ? 'Feeling '
                                                  : ' ',
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                            Text(
                                              mapFeeling[_feeling]!,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w600,
                                                  color: Config().text90Color),
                                            ),
                                          ],
                                        ),
                                ],
                              ),
                              // Privacy (Public, Friends, Friends of friends, Only me)
                              Row(
                                children: [
                                  // Privacy (Public, Friends, Friends of friends, Only me)
                                  GestureDetector(
                                    onTap: () {
                                      _showPrivacySheet(context);
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 8),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 4, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Config().text4Color,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/images/public.svg'),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 4),
                                            child: Text(
                                              _privacy.tr(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                          ),
                                          SvgPicture.asset(
                                              'assets/images/arrow_drop_down.svg'),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  // Album
                                  GestureDetector(
                                    onTap: () async {
                                      // Get Album
                                      if (isSharedPost == false) return;

                                      var ret = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  SelectAlbumPage(
                                                      uid: sb.uid)));
                                      if (ret != null) {
                                        album = ret as Album?;
                                        postType = Config().AlbumType;
                                        setState(() {
                                          _album = album!.name!;
                                        });
                                      }
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 8),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 4, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Config().text4Color,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(Icons.add, size: 15),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 4),
                                            child: Text(
                                              _album,
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                          ),
                                          Icon(Icons.arrow_drop_down_outlined,
                                              size: 20),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Content
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      color: Config().text4Color,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextFormField(
                            controller: _descControl,
                            keyboardType: TextInputType.multiline,
                            maxLines: isSharedPost ? 2 : 7,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'write_post'.tr(),
                              hintStyle: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: Config().text90Color),
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "This field can't be empty";
                              }
                              return null;
                            },
                            onChanged: (value) {
                              _desc = value;
                            },
                          ),
                          _tagFriends.isNotEmpty
                              ? tagFriendsContent()
                              : Container(),
                          isSharedPost
                              ? widget.p!.mediaType == 2
                                  ? VideoCard2(
                                      d: widget.p!, time: widget.p!.timestamp!)
                                  : Card3(
                                      d: widget.p!,
                                      time: convertToAgo(widget.p!.timestamp!))
                              : getTypeWidget(postType),
                        ],
                      ),
                    ),
                  ),
                  // Footer
                  isSharedPost
                      ? Container()
                      : Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          color: Colors.white,
                          child: Column(
                            children: [
                              // User feed and Group
                              Row(
                                children: [
                                  _userFeed(
                                    title: 'user_feed'.tr(),
                                    isUser: _isUserFeed,
                                    onTap: () {
                                      // if (_isUserFeed) return;
                                      // setState(() {
                                      //   _isUserFeed = true;
                                      //   _isGroup = false;
                                      // });
                                    },
                                  ),
                                  const SizedBox(width: 16),
                                  _userFeed(
                                    title: 'group'.tr(),
                                    isUser: _isGroup,
                                    onTap: () {
                                      if (_isGroup) return;
                                      setState(() {
                                        _isUserFeed = false;
                                        _isGroup = true;
                                      });
                                    },
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              const Divider(height: 1),
                              // Photo/Video
                              _postItem(
                                svgName: 'assets/images/add_to_photos.svg',
                                itemName: 'photo_video',
                                onTap: () {
                                  _showPhotoVideoSheet(context);
                                },
                              ),
                              const Divider(height: 1),
                              // Tag prople
                              _postItem(
                                svgName: 'assets/images/sell.svg',
                                itemName: 'tab_prople',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TagFriendsPage()));
                                  if (ret != null) {
                                    // postType = 6; // Tag Friends

                                    List<WUser> users = [];
                                    _tagFriendNicknames = 'with ';
                                    users.addAll(ret);
                                    users.forEach((element) {
                                      String nickname =
                                          element.name!.split(' ').join('');
                                      _tagFriendNicknames += '@$nickname ';
                                      _tagFriends.add(element.uid!);
                                    });
                                    setState(() {});
                                  }
                                  // nextScreen(context, TagFriendsPage());
                                },
                              ),
                              const Divider(height: 1),
                              // Live
                              _postItem(
                                svgName: 'assets/images/live_tv.svg',
                                itemName: 'live',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => LiveMainPage(
                                          isBroadcater: true,
                                          channelId: 'test123',
                                          owner: true,
                                        ),
                                      ));
                                  if (ret != null) {
                                    Navigator.pop(context);
                                  }
                                },
                              ),
                              const Divider(height: 1),
                              // Check in
                              _postItem(
                                svgName: 'assets/images/add_location_alt.svg',
                                itemName: 'check_in',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              AddLocationPage()));
                                  if (ret != null) {
                                    postType = 10;
                                    location['latitude'] = ret['latitude'];
                                    location['longitude'] = ret['longitude'];
                                    location['address'] = ret['address'];
                                    setState(() {});
                                  }
                                  // nextScreen(context, AddLocationPage());
                                },
                              ),
                              const Divider(height: 1),
                              // // Gif
                              // _postItem(
                              //   svgName: 'assets/images/gif_box.svg',
                              //   itemName: 'gif',
                              //   onTap: () async {
                              //     var ret = await Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (context) =>
                              //                 const SelectGifPage()));
                              //     if (ret != null) {
                              //       postType = 7;
                              //       gifUrls.clear();
                              //       gifUrls.add(ret.gifUrl);
                              //       setState(() {});
                              //     }
                              //     // nextScreen(context, SelectGifPage());
                              //   },
                              // ),
                              // const Divider(height: 1),
                              // Feeling/Activity
                              _postItem(
                                svgName: 'assets/images/add_reaction.svg',
                                itemName: 'feeling_activity',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const FeelingActivityPage()));
                                  if (ret != null) {
                                    _feeling = ret;
                                    setState(() {});
                                  }
                                  // nextScreen(context, FeelingActivityPage());
                                },
                              ),
                              const Divider(height: 1),
                              // Article
                              _postItem(
                                svgName: 'assets/images/article.svg',
                                itemName: 'article',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ArticleLinkPage()));
                                  if (ret != null) {
                                    postType = 11;
                                    setState(() {
                                      articleUrl = ret;
                                    });
                                  }
                                  // nextScreen(context, ArticleLinkPage());
                                },
                              ),
                              const Divider(height: 1),
                              // Poll
                              _postItem(
                                svgName: 'assets/images/bar_chart.svg',
                                itemName: 'poll',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CreatePollPage()));
                                  if (ret != null) {
                                    Navigator.pop(context, ret);
                                  }
                                  // nextScreen(context, CreatePollPage());
                                },
                              ),
                            ],
                          ),
                        ),
                ],
              ),
              _isLoading
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  getTypeWidget(int postType) {
    switch (postType) {
      case 10:
        return locationContent();
      case 11:
        return articleContent();
      case 6:
        return tagFriendsContent();
      default:
        return mediaWidget();
    }
  }

  tagFriendsContent() {
    return Text(
      _tagFriendNicknames,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text70Color),
    );
  }

  locationContent() {
    return Text(
      location['address'],
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text90Color),
    );
  }

  articleContent() {
    return Text(
      articleUrl,
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text90Color),
    );
  }

  mediaWidget() {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, idx) {
          return Container(
            width: 100,
            height: 100,
            alignment: Alignment.bottomLeft,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomLeft,
                  child: Container(
                    width: 90,
                    height: 90,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: postType == 7
                          ? CustomCacheImageWithDarkFilterBottom(
                              imageUrl: gifUrls[idx], radius: 5.0)
                          : postType == 2
                              ? Image.memory(videoThumbBytes!, fit: BoxFit.fill)
                              : Image.file(
                                  files[idx],
                                  fit: BoxFit.fill,
                                ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      files.removeAt(idx);
                      setState(() {});
                    },
                    child: Container(
                      alignment: Alignment.center,
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.red,
                      ),
                      child: Center(
                        child: Icon(
                          Icons.close,
                          size: 15,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
        itemCount: postType == 7
            ? gifUrls.length
            : postType == 2
                ? 1
                : files.length,
      ),
    );
  }

  InkWell _postItem({String? svgName, String? itemName, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            SvgPicture.asset(svgName!),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }

  InkWell _userFeed({String? title, bool? isUser, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isUser == true ? Config().primary30Color : Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          title!,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isUser == true ? Colors.white : Config().text90Color),
        ),
      ),
    );
  }

  // Bottom sheet for post privacy
  _showPrivacySheet(ctx) {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () {
                if (_privacy != 'public') {
                  _privacy = 'public';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/public.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // friends
            InkWell(
              onTap: () {
                if (_privacy != 'friends') {
                  _privacy = 'friends';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/person_remove.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // only me
            InkWell(
              onTap: () {
                if (_privacy != 'only_me') {
                  _privacy = 'only_me';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/private_connectivity.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Bottom sheet for post photo/video
  _showPhotoVideoSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (postType != Config().AlbumType) {
                  postType = 1;
                }
                pickMediaDialog(ctx, postType);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.add_photo_alternate_rounded),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            // InkWell(
            //   onTap: () async {
            //     Navigator.pop(context);
            //     await pickImage(true);
            //   },
            //   child: Padding(
            //     padding: const EdgeInsets.all(16.0),
            //     child: Row(
            //       children: [
            //         SvgPicture.asset('assets/images/camera.svg'),
            //         Padding(
            //           padding: const EdgeInsets.only(left: 16),
            //           child: Text(
            //             'camera'.tr(),
            //             style: TextStyle(
            //                 fontSize: 16,
            //                 fontWeight: FontWeight.w600,
            //                 color: Config().text90Color),
            //           ),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),
            // video
            InkWell(
              onTap: () {
                Navigator.pop(context);
                if (videoFile == null) {
                  postType = 2;
                  pickMediaDialog(ctx, 2);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.live_tv_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'video'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  pickMediaDialog(BuildContext ctx, int type) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1 || type == 9) {
                      await pickImage(false);
                    } else {
                      await pickVideo(false);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(type == 1 || type == 9
                            ? Icons.add_photo_alternate_outlined
                            : Icons.video_camera_front_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1 || type == 9) {
                      await pickImage(true);
                    } else {
                      await pickVideo(true);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  //////////////////////////////////////////////////////////////////////////////

  Future pickImage(bool camera) async {
    List<XFile>? images;
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
      // if (image != null) {
      //   var cropPath = await croppedImage(image.path);
      //   setState(() {
      //     files.add(File(cropPath));
      //     // files.add(File(image!.path));
      //   });
      // } else {
      //   print('No image selected!');
      // }
    } else {
      // images = await ImagePicker().pickMultiImage();
      // if (images != null) {
      //   images.forEach((element) {
      //     files.add(File(element.path));
      //   });
      //   setState(() {});
      // } else {
      //   print('===== No images selected! =====');
      // }
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    var size = await image!.readAsBytes();
    if (size.lengthInBytes > 10 * 1024 * 1024) {
      openToast('The image size should be less than 10MB');
      return;
    }
    if (image != null) {
      var cropPath = await croppedImage(image.path);
      setState(() {
        files.add(File(cropPath));
        // files.add(File(image!.path));
      });
    } else {
      print('No image selected!');
    }
  }

  Future pickVideo(bool camera) async {
    XFile? video;
    if (camera) {
      video = await ImagePicker().pickVideo(source: ImageSource.camera);
    } else {
      video = await ImagePicker().pickVideo(source: ImageSource.gallery);
    }
    var size = await video!.readAsBytes();
    if (size.lengthInBytes > 50 * 1024 * 1024) {
      openToast('The video size should be less than 50MB');
      return;
    }
    if (video != null) {
      // Generate thumbnail
      var thumbBytes = await VideoCompress.getByteThumbnail(video.path,
          quality: 50, position: -1);

      videoThumbBytes = thumbBytes;

      // Compress video
      setState(() {
        _isLoading = true;
      });
      MediaInfo? mi;
      try {
        await VideoCompress.setLogLevel(0);

        mi = await VideoCompress.compressVideo(video.path,
            quality: VideoQuality.LowQuality,
            includeAudio: true,
            deleteOrigin: true);

        setState(() {
          _isLoading = false;
          videoFile = File(mi!.path!);
        });
      } catch (e) {
        VideoCompress.cancelCompression();
        setState(() {
          _isLoading = false;
        });
      }
    } else {
      print('===== No video selected! =====');
    }
  }

  Future<List<String>> uploadFiles(List<File> images) async {
    var imageUrls = await Future.wait(images.map((e) => uploadFile(e)));
    print('===== upload done =====');
    return imageUrls;
  }

  Future<String> uploadFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _post() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final AlbumBloc ab = context.read<AlbumBloc>();
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    final GroupBloc gb = Provider.of<GroupBloc>(context, listen: false);

    setState(() {
      _isLoading = true;
    });

    List<String> images = [];
    String video = '';
    switch (postType) {
      case 1: // Image
        var temp = await uploadImageFiles(files);
        images.addAll(temp);
        break;
      case 2: // Video
        video = await uploadVideoFile(videoFile!);
        // images.addAll(temp);
        break;
      case 3: // Text
        break;
      case 7: // Gif
        images.addAll(gifUrls);
        break;
      case 9:
        var temp = await uploadImageFiles(files);
        images.addAll(temp);
        _feeling = '${album!.name} Album';
        break;
      default:
    }

    // Get tag friend
    if (_tagFriendNicknames != '') {
      _feeling = _tagFriendNicknames;
    }

    // Create time now
    DateTime now = DateTime.now();
    DateTime utc = now.toUtc();
    var timestamp = formatISOTime(utc);

    Map<String, Object?> poll = {};
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        //
        if (isSharedPost) {
          postType = 12; // Shared Post
          var p = widget.p;
          var feeling = 'Shared a post';
          pb
              .createPost(
                  sb,
                  postType,
                  [],
                  _desc,
                  _privacy,
                  timestamp,
                  feeling,
                  poll,
                  location,
                  '',
                  widget.group!.toJson(),
                  true,
                  [],
                  p!.toJson())
              .then((value) async {
            setState(() {
              _isLoading = false;
            });
            if (pb.hasError == false) {
              if (postType == Config().AlbumType) {
                ab.updateImages(sb.uid!, album!.id, images);
              }
              openToast('You created a post');

              // update group
              await gb.updateGroupList(
                  widget.group!.id!, 'posts', pb.post!.postId!, true);

              Navigator.pop(context, pb.post);
            }
          });
        } else {
          pb.createPost(
              sb,
              postType,
              postType == 1 || postType == 9 ? images : [video],
              _desc,
              _privacy,
              timestamp,
              _feeling,
              poll,
              location,
              articleUrl,
              widget.group!.toJson(),
              true,
              _tagFriends, {}).then((value) async {
            setState(() {
              _isLoading = false;
            });
            if (pb.hasError == false) {
              if (postType == Config().AlbumType) {
                ab.updateImages(sb.uid!, album!.id, images);
              }
              openToast('You created a post');

              // update group
              await gb.updateGroupList(
                  widget.group!.id!, 'posts', pb.post!.postId!, true);

              Navigator.pop(context, pb.post);
            }
          });
        }
      }
    });
  }

  Future<int> getTotalPostsCount() async {
    const String fieldName = 'count';
    final DocumentReference ref =
        FirebaseFirestore.instance.collection('item_count').doc('posts_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount + 1});
    });
  }

  // Upload image files
  Future<List<String>> uploadImageFiles(List<File> images) async {
    var imageUrls = await Future.wait(images.map((e) => uploadImageFile(e)));
    print('===== upload done =====');
    return imageUrls;
  }

  Future<String> uploadImageFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  // Upload videos
  Future<String> uploadVideoFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Videos/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
        print('===== upload done video =====');
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }
}
