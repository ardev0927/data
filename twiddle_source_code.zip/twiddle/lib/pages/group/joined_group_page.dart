import 'package:flutter/material.dart';

class JoinedGroupPage extends StatefulWidget {
  const JoinedGroupPage({super.key});

  @override
  State<JoinedGroupPage> createState() => _JoinedGroupPageState();
}

class _JoinedGroupPageState extends State<JoinedGroupPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
