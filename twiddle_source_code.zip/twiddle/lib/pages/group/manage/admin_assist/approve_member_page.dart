import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/group_admin_assist.dart';

import '../../../../config/config.dart';

class ApproveMemberPage extends StatefulWidget {
  ApproveMemberPage({super.key, required this.group});

  Group? group;

  @override
  State<ApproveMemberPage> createState() => _ApproveMemberPageState();
}

class _ApproveMemberPageState extends State<ApproveMemberPage> {
  String? approve;
  Group? group;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    if (group!.adminAssist == null) {
      approve = 'Admin';
    } else {
      if (group!.adminAssist!.approveMember == null) {
        approve = 'Admin';
      } else {
        approve = group!.adminAssist!.approveMember;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'admin_assist'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: () {
                _save();
              },
              child: Text(
                'save'.tr(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color,
                ),
              ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            'approve_member'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          RadioListTile(
            title: Text(
              'anyone'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Anyone',
            groupValue: approve,
            onChanged: (value) {
              setState(() {
                approve = value;
              });
            },
          ),
          RadioListTile(
            title: Text(
              'admin'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Admin',
            groupValue: approve,
            onChanged: (value) {
              setState(() {
                approve = value;
              });
            },
          ),
        ],
      ),
    );
  }

  _save() {
    if (approve != null) {
      Map<String, dynamic>? data;
      if (group!.adminAssist != null) {
        group!.adminAssist!.approveMember = approve;
        data = {
          'admin_assist': group!.adminAssist!.toJson(),
        };
      } else {
        var aa = AdminAssist(approveMember: approve);
        group!.adminAssist = aa;
        data = {
          'admin_assist': aa.toJson(),
        };
      }
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, group!.adminAssist));
    }
  }
}
