import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';

import '../../../../config/config.dart';
import '../../../../models/group_admin_assist.dart';

class DeclineMemberPage extends StatefulWidget {
  DeclineMemberPage({super.key, required this.group});

  Group? group;

  @override
  State<DeclineMemberPage> createState() => _DeclineMemberPageState();
}

class _DeclineMemberPageState extends State<DeclineMemberPage> {
  String? decline;
  Group? group;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    if (group!.adminAssist == null) {
      decline = 'Admin';
    } else {
      if (group!.adminAssist!.declineMember == null) {
        decline = 'Admin';
      } else {
        decline = group!.adminAssist!.declineMember;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'admin_assist'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: () {
                _save();
              },
              child: Text(
                'save'.tr(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color,
                ),
              ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            'decline_member'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          RadioListTile(
            title: Text(
              'anyone'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Anyone',
            groupValue: decline,
            onChanged: (value) {
              setState(() {
                decline = value;
              });
            },
          ),
          RadioListTile(
            title: Text(
              'admin'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Admin',
            groupValue: decline,
            onChanged: (value) {
              setState(() {
                decline = value;
              });
            },
          ),
        ],
      ),
    );
  }

  _save() {
    if (decline != null) {
      Map<String, dynamic>? data;
      if (group!.adminAssist != null) {
        group!.adminAssist!.declineMember = decline;
        data = {
          'admin_assist': group!.adminAssist!.toJson(),
        };
      } else {
        var aa = AdminAssist(declineMember: decline);
        group!.adminAssist = aa;
        data = {
          'admin_assist': aa.toJson(),
        };
      }
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, group!.adminAssist));
    }
  }
}
