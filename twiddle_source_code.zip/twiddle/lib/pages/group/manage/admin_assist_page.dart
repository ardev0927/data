import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/group_admin_assist.dart';
import 'package:twiddle/pages/group/manage/admin_assist/approve_member_page.dart';
import 'package:twiddle/pages/group/manage/admin_assist/decline_member_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../config/config.dart';

class AdminAssistPage extends StatefulWidget {
  AdminAssistPage({super.key, required this.group});

  Group? group;

  @override
  State<AdminAssistPage> createState() => _AdminAssistPageState();
}

class _AdminAssistPageState extends State<AdminAssistPage> {
  Group? group;

  @override
  void initState() {
    super.initState();

    group = widget.group;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'admin_assist'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Setting
          Text(
            'manage_people'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          manageItem(
            itemName: 'approve_member',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ApproveMemberPage(group: group)));
              if (ret is AdminAssist) {
                group!.adminAssist = ret;
              }
              // nextScreen(context, ApproveMemberPage(group: group));
            },
          ),
          const Divider(),
          manageItem(
            itemName: 'decline_member',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DeclineMemberPage(group: group)));
              if (ret is AdminAssist) {
                group!.adminAssist = ret;
              }
              // nextScreen(context, DeclineMemberPage(group: group));
            },
          ),
          const Divider(),
        ],
      ),
    );
  }

  InkWell manageItem(
      {IconData? iconData, String? itemName, int? count, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Text(
              itemName!.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color),
            ),
            const Spacer(),
            count == null
                ? Container()
                : Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      count.toString(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
            Icon(Icons.arrow_forward_ios, size: 16)
          ],
        ),
      ),
    );
  }
}
