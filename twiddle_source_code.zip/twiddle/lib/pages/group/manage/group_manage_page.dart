import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/group/manage/admin_assist_page.dart';
import 'package:twiddle/pages/group/manage/group_people_page.dart';
import 'package:twiddle/pages/group/manage/group_review_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/manage_setting_page.dart';
import 'package:twiddle/pages/group/manage/rule/group_rule_page.dart';
import 'package:twiddle/pages/group/manage/rule/group_rules_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../config/config.dart';
import '../../../models/group.dart';

class GroupManagePage extends StatefulWidget {
  GroupManagePage({super.key, required this.group});

  Group? group;

  @override
  State<GroupManagePage> createState() => _GroupManagePageState();
}

class _GroupManagePageState extends State<GroupManagePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          // IconButton(onPressed: () {}, icon: Icon(Icons.settings_outlined))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        // crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // To review
          Text(
            'to_review'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          // const Divider(),
          // manageItem(
          //   iconData: Icons.report_outlined,
          //   itemName: 'reported',
          //   count: widget.group!.reports!.length,
          //   onTap: () {
          //     nextScreen(
          //         context, GroupReviewPage(group: widget.group, index: 0));
          //   },
          // ),
          // const Divider(),
          // manageItem(
          //   iconData: Icons.post_add_outlined,
          //   itemName: 'peding_posts',
          //   count: widget.group!.posts!.length,
          //   onTap: () {
          //     nextScreen(
          //         context, GroupReviewPage(group: widget.group, index: 1));
          //   },
          // ),
          const Divider(),
          manageItem(
            iconData: Icons.groups_outlined,
            itemName: 'member_requests',
            count: widget.group!.joinRequests!.length,
            onTap: () {
              nextScreen(
                  context, GroupReviewPage(group: widget.group, index: 2));
            },
          ),
          // const Divider(),
          // manageItem(
          //   iconData: Icons.notifications_active_outlined,
          //   itemName: 'moderation_alerts',
          //   count: widget.group!.alerts!.length,
          //   onTap: () {
          //     nextScreen(
          //         context, GroupReviewPage(group: widget.group, index: 3));
          //   },
          // ),
          // const Divider(),
          const SizedBox(height: 16),
          // Tool shortcuts
          Text(
            'tool_shortcuts'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          manageItem(
            iconData: Icons.admin_panel_settings_outlined,
            itemName: 'admin_assist',
            // count: widget.group!.reports!.length,
            onTap: () {
              nextScreen(context, AdminAssistPage(group: widget.group));
            },
          ),
          const Divider(),
          manageItem(
            iconData: Icons.person_outline,
            itemName: 'people',
            // count: widget.group!.posts!.length,
            onTap: () {
              nextScreen(context, GroupPeoplePage(group: widget.group));
            },
          ),
          // const Divider(),
          // manageItem(
          //   iconData: Icons.history_outlined,
          //   itemName: 'activity_log',
          //   // count: widget.group!.members!.length,
          //   onTap: () {},
          // ),
          const Divider(),
          manageItem(
            iconData: Icons.checklist_outlined,
            itemName: 'group_rules',
            // count: widget.group!.alerts!.length,
            onTap: () {
              if (widget.group!.rules!.isEmpty) {
                nextScreen(context, GroupRulePage(group: widget.group));
              } else {
                nextScreen(context, GroupRulesPage(group: widget.group));
              }
            },
          ),
          const Divider(),
          const SizedBox(height: 16),
          // Setting
          Text(
            'setting'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          manageItem(
            iconData: Icons.settings_outlined,
            itemName: 'group_setting',
            onTap: () {
              nextScreen(context, ManageSettingPage(group: widget.group));
            },
          ),
          const Divider(),
          // manageItem(
          //   iconData: Icons.featured_play_list_outlined,
          //   itemName: 'add_features',
          //   onTap: () {},
          // ),
          // const Divider(),
        ],
      ),
    );
  }

  InkWell manageItem(
      {IconData? iconData, String? itemName, int? count, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(iconData),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            count == null
                ? Container()
                : Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      count.toString(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
            Icon(Icons.arrow_forward_ios, size: 16)
          ],
        ),
      ),
    );
  }
}
