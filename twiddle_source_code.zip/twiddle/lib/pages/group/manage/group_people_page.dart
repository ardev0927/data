import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/user_card2.dart';
import 'package:twiddle/cards/user_card3.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/group/manage/members/group_blocked_userd_page.dart';
import 'package:twiddle/pages/group/manage/members/group_invited_users_page.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../config/config.dart';

class GroupPeoplePage extends StatefulWidget {
  GroupPeoplePage({super.key, required this.group});

  Group? group;

  @override
  State<GroupPeoplePage> createState() => _GroupPeoplePageState();
}

class _GroupPeoplePageState extends State<GroupPeoplePage> {
  final _searchCtrl = TextEditingController();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  Group? group;

  @override
  void initState() {
    super.initState();

    group = widget.group;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'members'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        shrinkWrap: true,
        children: [
          Row(
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(primary: Config().text10Color),
                child: Text(
                  'invited_users'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                onPressed: () async {
                  nextScreen(context, GroupInvitedUsersPage(group: group));
                  // var ret = await Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             GroupInvitedUsersPage(group: group)));
                  // if (ret is List<String>) {
                  //   group!.inviteUsers = ret;
                  // }
                },
              ),
              const SizedBox(width: 32),
              ElevatedButton(
                style: ElevatedButton.styleFrom(primary: Config().text10Color),
                child: Text(
                  'block'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                onPressed: () {
                  nextScreen(context, GroupBlockedUsersPage(group: group));
                },
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                prefixIcon:
                    Icon(Icons.search_outlined, color: Config().text90Color),
                hintText: 'search'.tr(),
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
            ),
          ),
          Text(
            'admin_and_moderators'.tr(),
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const SizedBox(height: 8),
          ListView.separated(
            shrinkWrap: true,
            itemCount: group!.adminModerators!.length,
            separatorBuilder: (BuildContext context, int index) {
              return const SizedBox(height: 8);
            },
            itemBuilder: (context, index) {
              return StreamBuilder<QuerySnapshot>(
                stream: getUser(group!.adminModerators![index]),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    var d = snapshot.data!.docs[0];
                    var user = WUser.fromFirestore(d);
                    return UserCard3(
                      d: user,
                      heroTag: 'admins$index',
                      onItemTap: () {
                        if (sb.uid == user.uid) {
                          nextScreen(context, ProfileMainPage(uid: user.uid));
                        } else {
                          nextScreen(context, UserProfilePage(uid: user.uid));
                        }
                      },
                    );
                  }
                  return Container();
                },
              );
            },
          ),
          const SizedBox(height: 16),
          Text(
            'all_members'.tr(),
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const SizedBox(height: 8),
          ListView.separated(
            shrinkWrap: true,
            itemCount: group!.members!.length,
            separatorBuilder: (BuildContext context, int index) {
              return const SizedBox(height: 8);
            },
            itemBuilder: (context, index) {
              return StreamBuilder<QuerySnapshot>(
                stream: getUser(group!.members![index]),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    var d = snapshot.data!.docs[0];
                    var user = WUser.fromFirestore(d);
                    return UserCard3(
                      d: user,
                      heroTag: 'members$index',
                      onItemTap: () {
                        nextScreen(context, UserProfilePage(uid: user.uid));
                      },
                    );
                  }
                  return Container();
                },
              );
            },
          ),
        ],
      ),
    );
  }

  // Stream to get user
  Stream<QuerySnapshot> getUser(String uid) {
    return firestore
        .collection('users')
        .where('uid', isEqualTo: uid)
        .orderBy('timestamp', descending: true)
        .limit(1)
        .snapshots();
  }
}
