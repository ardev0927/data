import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/group/manage/tab/members_tab.dart';
import 'package:twiddle/pages/group/manage/tab/moderation_tab.dart';
import 'package:twiddle/pages/group/manage/tab/post_tab.dart';
import 'package:twiddle/pages/group/manage/tab/reported_tab.dart';

import '../../../config/config.dart';
import '../../../models/group.dart';

class GroupReviewPage extends StatefulWidget {
  const GroupReviewPage({super.key, required this.group, required this.index});

  final Group? group;
  final int? index;

  @override
  State<GroupReviewPage> createState() => _GroupReviewPageState();
}

class _GroupReviewPageState extends State<GroupReviewPage>
    with TickerProviderStateMixin {
  TabController? _tabController;

  final List<Tab> _tabs = [
    Tab(
      text: 'reported'.tr(),
    ),
    Tab(
      text: 'post'.tr(),
    ),
    Tab(
      text: 'requests'.tr(),
    ),
    Tab(
      text: 'Moderation'.tr(),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: _tabs.length,
      vsync: this,
      initialIndex: widget.index!,
    );
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          // IconButton(onPressed: () {}, icon: Icon(Icons.settings_outlined))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return DefaultTabController(
      length: _tabs.length,
      // initialIndex: widget.index!,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
            child: TabBar(
              controller: _tabController,
              labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              labelColor: Config().text90Color,
              unselectedLabelStyle:
                  TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              unselectedLabelColor: Config().text90Color,
              indicatorColor: Config().primary30Color,
              indicatorWeight: 4,
              labelPadding: const EdgeInsets.all(4),
              tabs: _tabs,
            ),
          ),
          Flexible(
            child: TabBarView(
              controller: _tabController,
              children: [
                ReportedTab(group: widget.group),
                PostTab(group: widget.group),
                MembersTab(group: widget.group),
                ModerationTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
