import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../../../config/config.dart';

class ApproveRequestPage extends StatefulWidget {
  const ApproveRequestPage({super.key});

  @override
  State<ApproveRequestPage> createState() => _ApproveRequestPageState();
}

class _ApproveRequestPageState extends State<ApproveRequestPage> {
  var approve;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group_setting'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            'who_can_approve_member_request'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          RadioListTile(
            title: Text(
              'anyone'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Anyone',
            groupValue: approve,
            onChanged: (value) {
              setState(() {
                approve = value;
              });
            },
          ),
          RadioListTile(
            title: Text(
              'admin'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Admin',
            groupValue: approve,
            onChanged: (value) {
              setState(() {
                approve = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
