import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:twiddle/models/group.dart';
import 'package:uuid/uuid.dart';

import '../../../../config/config.dart';
import '../../../../utils/cached_image.dart';
import '../../../../utils/upload_files.dart';

class CoverPhotoPage extends StatefulWidget {
  CoverPhotoPage({super.key, required this.group});

  Group? group;

  @override
  State<CoverPhotoPage> createState() => _CoverPhotoPageState();
}

class _CoverPhotoPageState extends State<CoverPhotoPage> {
  Group? group;
  File? coverFile;

  double imageWidth = 150;
  double imageHeight = 150;
  bool isLoading = false;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'cover_photo'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: isLoading
                  ? null
                  : () {
                      _save();
                    },
              child: isLoading
                  ? const CircularProgressIndicator()
                  : Text(
                      'save'.tr(),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color,
                      ),
                    ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: imageWidth,
            height: imageHeight,
            decoration: const BoxDecoration(shape: BoxShape.circle),
            child: Stack(
              children: [
                coverFile == null
                    ? CustomCacheImage(
                        imageUrl: group!.coverPhoto,
                        radius: imageWidth / 2,
                        circularShape: true)
                    : Container(
                        width: imageWidth,
                        height: imageHeight,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                            image: Image.file(
                              coverFile!,
                            ).image,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: GestureDetector(
                    onTap: () {
                      _showPhotoSheet(context, true);
                    },
                    child: Container(
                      width: 32,
                      height: 32,
                      margin: const EdgeInsets.only(bottom: 5, right: 5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Config().text8Color,
                      ),
                      child: Center(
                        child: SvgPicture.asset(
                            'assets/images/android_camera.svg',
                            width: 20,
                            height: 20),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Bottom sheet for cover photo
  _showPhotoSheet(ctx, isAvatar) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickCoverImage(false);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/images/add_photo_alternate.svg',
                      color: Config().text90Color,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickCoverImage(true);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/camera.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future pickCoverImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      coverFile = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  _save() async {
    if (coverFile != null) {
      setState(() {
        isLoading = true;
      });
      var coverPath = await uploadGroupCoverFile(context, coverFile!, group!);
      var data = {
        'cover_photo': coverPath,
      };
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, coverPath));
    }
  }
}
