import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/group_manage_discussion.dart';
import 'package:twiddle/pages/group/manage/group_setting/approve_request_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/cover_photo_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/name_description_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/post_approval_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/privacy_page.dart';
import 'package:twiddle/pages/group/manage/group_setting/who_post_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../../config/config.dart';

class ManageSettingPage extends StatefulWidget {
  ManageSettingPage({super.key, required this.group});

  Group? group;

  @override
  State<ManageSettingPage> createState() => _ManageSettingPageState();
}

class _ManageSettingPageState extends State<ManageSettingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group_setting'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Setting
          Text(
            'basic_group_info'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          manageItem(
            itemName: 'name_and_description',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          NameDescriptionPage(group: widget.group)));
              // nextScreen(context, NameDescriptionPage(group: widget.group));
              if (ret is Map<String, dynamic>) {
                widget.group!.name = ret['name'];
                widget.group!.description = ret['description'];
              }
            },
          ),
          const Divider(),
          manageItem(
            itemName: 'cover_photo',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CoverPhotoPage(group: widget.group)));
              // nextScreen(context, CoverPhotoPage(group: widget.group));
              if (ret is String) {
                widget.group!.coverPhoto = ret;
              }
            },
          ),
          const Divider(),
          manageItem(
            itemName: 'privacy',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          GroupPrivacyPage(group: widget.group)));
              // nextScreen(context, GroupPrivacyPage(group: widget.group));
              if (ret is String) {
                widget.group!.privacy = ret;
              }
            },
          ),
          // const Divider(),
          // const SizedBox(height: 16),
          // // membership
          // Text(
          //   'membership'.tr(),
          //   style: TextStyle(
          //       fontSize: 20,
          //       fontWeight: FontWeight.w700,
          //       color: Config().text100Color),
          // ),
          // const Divider(),
          // manageItem(
          //   itemName: 'who_can_approve_member_request',
          //   onTap: () {
          //     nextScreen(context, ApproveRequestPage());
          //   },
          // ),
          const Divider(),
          const SizedBox(height: 16),
          // Setting
          Text(
            'manage_discussion'.tr(),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          manageItem(
            itemName: 'who_can_post',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => WhoPostPage(group: widget.group)));
              // nextScreen(context, WhoPostPage(group: widget.group));
              if (ret is ManageDiscussion) {
                widget.group!.manageDiscussion = ret;
              }
            },
          ),
          const Divider(),
          manageItem(
            itemName: 'post_approval',
            onTap: () async {
              var ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          PostApprovalPage(group: widget.group)));
              // nextScreen(context, PostApprovalPage(group: widget.group));
              if (ret is ManageDiscussion) {
                widget.group!.manageDiscussion = ret;
              }
            },
          ),
        ],
      ),
    );
  }

  InkWell manageItem(
      {IconData? iconData, String? itemName, int? count, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Text(
              itemName!.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color),
            ),
            const Spacer(),
            count == null
                ? Container()
                : Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(
                      count.toString(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
            Icon(Icons.arrow_forward_ios, size: 16)
          ],
        ),
      ),
    );
  }
}
