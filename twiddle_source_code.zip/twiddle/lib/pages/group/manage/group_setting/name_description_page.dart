import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';

import '../../../../config/config.dart';
import '../../../../utils/other.dart';
import '../../../../utils/validate.dart';
import '../../../../widgets/app_text_input.dart';

class NameDescriptionPage extends StatefulWidget {
  NameDescriptionPage({super.key, required this.group});

  Group? group;

  @override
  State<NameDescriptionPage> createState() => _NameDescriptionPageState();
}

class _NameDescriptionPageState extends State<NameDescriptionPage> {
  String? _validName;
  String? _validDescribe;

  final aboutCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final _focusName = FocusNode();
  final _focusDescribe = FocusNode();

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    if (widget.group != null) {
      aboutCtrl.text = widget.group!.description!;
      nameCtrl.text = widget.group!.name!;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'name_and_description'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: () {
                _save();
              },
              child: Text(
                'save'.tr(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color,
                ),
              ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return SingleChildScrollView(
      physics: AlwaysScrollableScrollPhysics(),
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppTextInput(
              hintText: 'group_name'.tr(),
              errorText: _validName,
              focusNode: _focusName,
              textInputAction: TextInputAction.next,
              // trailing: Cont,
              onSubmitted: (text) {
                UtilOther.fieldFocusChange(
                  context,
                  _focusName,
                  _focusDescribe,
                );
              },
              onChanged: (text) {
                setState(() {
                  _validName = UtilValidator.validate(
                    nameCtrl.text,
                  );
                });
              },
              controller: nameCtrl,
            ),
            const SizedBox(height: 16),
            AppTextInput(
              hintText: 'describe_group'.tr(),
              errorText: _validDescribe,
              focusNode: _focusDescribe,
              maxLines: 5,
              textInputAction: TextInputAction.done,
              // trailing: Cont,
              onSubmitted: (text) {},
              onChanged: (text) {
                setState(() {
                  _validDescribe = UtilValidator.validate(
                    aboutCtrl.text,
                  );
                });
              },
              controller: aboutCtrl,
            ),
          ],
        ),
      ),
    );
  }

  _save() {
    if (nameCtrl.text.isNotEmpty && aboutCtrl.text.isNotEmpty) {
      var data = {
        'name': nameCtrl.text,
        'description': aboutCtrl.text,
      };
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, data));
    }
  }
}
