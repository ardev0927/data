import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';

import '../../../../config/config.dart';
import '../../../../models/group_manage_discussion.dart';

class PostApprovalPage extends StatefulWidget {
  PostApprovalPage({super.key, required this.group});

  Group? group;

  @override
  State<PostApprovalPage> createState() => _PostApprovalPageState();
}

class _PostApprovalPageState extends State<PostApprovalPage> {
  String? approval;
  Group? group;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    if (group!.manageDiscussion == null) {
      approval = 'Anyone';
    } else {
      if (group!.manageDiscussion!.postApproval == null) {
        approval = 'Anyone';
      } else {
        approval = group!.manageDiscussion!.postApproval;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'manage_discussion'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: () {
                _save();
              },
              child: Text(
                'save'.tr(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color,
                ),
              ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            '${'post_approval'.tr()}?',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          RadioListTile(
            title: Text(
              'anyone'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Anyone',
            groupValue: approval,
            onChanged: (value) {
              setState(() {
                approval = value;
              });
            },
          ),
          RadioListTile(
            title: Text(
              'admin'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Admin',
            groupValue: approval,
            onChanged: (value) {
              setState(() {
                approval = value;
              });
            },
          ),
        ],
      ),
    );
  }

  _save() {
    if (approval != null) {
      Map<String, dynamic>? data;
      if (group!.manageDiscussion != null) {
        group!.manageDiscussion!.postApproval = approval;
        data = {
          'manage_discussion': group!.manageDiscussion!.toJson(),
        };
      } else {
        var md = ManageDiscussion(postApproval: approval);
        group!.manageDiscussion = md;
        data = {
          'manage_discussion': md.toJson(),
        };
      }
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, group!.manageDiscussion));
    }
  }
}
