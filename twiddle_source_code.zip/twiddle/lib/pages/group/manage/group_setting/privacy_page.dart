import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/widgets/group_privacy_bottom_sheet.dart';

import '../../../../config/config.dart';
import '../../../../widgets/app_picker_item.dart';

class GroupPrivacyPage extends StatefulWidget {
  GroupPrivacyPage({super.key, required this.group});

  Group? group;

  @override
  State<GroupPrivacyPage> createState() => _GroupPrivacyPageState();
}

class _GroupPrivacyPageState extends State<GroupPrivacyPage> {
  bool isLoading = false;

  Group? group;
  String? privacy;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    privacy = group!.privacy;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'privacy'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: isLoading
                  ? null
                  : () {
                      _save();
                    },
              child: isLoading
                  ? const CircularProgressIndicator()
                  : Text(
                      'save'.tr(),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color,
                      ),
                    ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          AppPickerItem(
            title: 'choose_privacy'.tr(),
            value: privacy,
            onPressed: () => showChooseGroupPrivacySheet(
              context,
              onPrivateTap: () {
                Navigator.pop(context);
                setState(() {
                  privacy = 'private'.tr();
                });
              },
              onPublicTap: () {
                Navigator.pop(context);
                setState(() {
                  privacy = 'public'.tr();
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  _save() {
    if (privacy != null) {
      var data = {
        'privacy': privacy,
      };
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, privacy));
    }
  }
}
