import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/group_manage_discussion.dart';

import '../../../../config/config.dart';

class WhoPostPage extends StatefulWidget {
  WhoPostPage({super.key, required this.group});

  Group? group;

  @override
  State<WhoPostPage> createState() => _WhoPostPageState();
}

class _WhoPostPageState extends State<WhoPostPage> {
  String? post;
  Group? group;

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    if (group!.manageDiscussion == null) {
      post = 'Admin';
    } else {
      if (group!.manageDiscussion!.whoCanPost == null) {
        post = 'Admin';
      } else {
        post = group!.manageDiscussion!.whoCanPost;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'manage_discussion'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
              onPressed: () {
                _save();
              },
              child: Text(
                'save'.tr(),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color,
                ),
              ))
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            '${'who_can_post'.tr()}?',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          RadioListTile(
            title: Text(
              'anyone'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Anyone',
            groupValue: post,
            onChanged: (value) {
              setState(() {
                post = value;
              });
            },
          ),
          RadioListTile(
            title: Text(
              'admin'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            value: 'Admin',
            groupValue: post,
            onChanged: (value) {
              setState(() {
                post = value;
              });
            },
          ),
        ],
      ),
    );
  }

  _save() {
    if (post != null) {
      Map<String, dynamic>? data;
      if (group!.manageDiscussion != null) {
        group!.manageDiscussion!.whoCanPost = post;
        data = {
          'manage_discussion': group!.manageDiscussion!.toJson(),
        };
      } else {
        var md = ManageDiscussion(whoCanPost: post);
        group!.manageDiscussion = md;
        data = {
          'manage_discussion': md.toJson(),
        };
      }
      firebaseFirestore
          .collection('groups')
          .doc(widget.group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, group!.manageDiscussion));
    }
  }
}
