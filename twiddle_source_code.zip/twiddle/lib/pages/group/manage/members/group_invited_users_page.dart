import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/cards/invited_user_card.dart';

import '../../../../config/config.dart';
import '../../../../models/group.dart';
import '../../../../models/user.dart';
import '../../../../utils/empty.dart';

class GroupInvitedUsersPage extends StatefulWidget {
  GroupInvitedUsersPage({super.key, required this.group});

  Group? group;

  @override
  State<GroupInvitedUsersPage> createState() => _GroupInvitedUsersPageState();
}

class _GroupInvitedUsersPageState extends State<GroupInvitedUsersPage> {
  Group? group;

  FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'invited_users'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: group!.inviteUsers!.isEmpty
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.groups_outlined,
                    message: 'no_invited_users'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              shrinkWrap: true,
              itemCount: group!.inviteUsers!.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(height: 8);
              },
              itemBuilder: (context, index) {
                return StreamBuilder<QuerySnapshot>(
                  stream: getUser(group!.inviteUsers![index]),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      var d = snapshot.data!.docs[0];
                      var user = WUser.fromFirestore(d);
                      return InvitedUserCard(
                        d: user,
                        g: group!,
                        heroTag: 'group_invite$index',
                        onUndoPressed: () {
                          undo(user.uid!);
                        },
                      );
                    }
                    return Container();
                  },
                );
              },
            ),
    );
  }

  // Stream to get user
  Stream<QuerySnapshot> getUser(String uid) {
    return firestore
        .collection('users')
        .where('uid', isEqualTo: uid)
        .orderBy('timestamp', descending: true)
        .limit(1)
        .snapshots();
  }

  undo(String uid) {
    firestore.collection('groups').doc(group!.id).update({
      'invite_users': FieldValue.arrayRemove([uid])
    }).then((value) {
      setState(() {
        group!.inviteUsers!.remove(uid);
      });
    });
  }
}
