import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/group_rule.dart';
import 'package:twiddle/utils/toast.dart';

import '../../../../config/config.dart';

class CreateRulePage extends StatefulWidget {
  CreateRulePage({super.key, required this.group});

  Group? group;

  @override
  State<CreateRulePage> createState() => _CreateRulePageState();
}

class _CreateRulePageState extends State<CreateRulePage> {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String ruleName = '';
  String ruleDesc = '';
  bool _saving = false;
  int pageIndex = 0;
  List<Rule> rules = [];

  Group? group;

  @override
  void initState() {
    super.initState();

    group = widget.group;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'create_rule'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Form(
      key: _formKey,
      child: pageIndex == 0 ? _firstBody() : _secondBody(),
    );
  }

  _firstBody() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: TextFormField(
              controller: _nameCtrl,
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.all(16),
                hintText: 'name_of_rule'.tr(),
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
              validator: (String? value) {
                if (value!.isEmpty) return "This field can't be empty";
                return null;
              },
              onChanged: (value) {
                setState(() {
                  ruleName = value;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: TextFormField(
              controller: _descCtrl,
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.all(16),
                hintText: 'describe_your_rule'.tr(),
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              validator: (String? value) {
                if (value!.length == 0) return "This field can't be empty";
                return null;
              },
              onChanged: (value) {
                setState(() {
                  ruleDesc = value;
                });
              },
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              if (ruleName.isEmpty || ruleDesc.isEmpty) {
                openToast('Please enter rule name and description');
              } else {
                var rule = Rule(name: ruleName, description: ruleDesc);
                rules.add(rule);

                _nameCtrl.clear();
                _descCtrl.clear();

                setState(() {
                  pageIndex += 1;
                });
              }
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            child: _saving == true
                ? CircularProgressIndicator()
                : Text(
                    'continue'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
          ),
        ],
      ),
    );
  }

  _secondBody() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: rules.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(height: 8);
              },
              itemBuilder: (context, index) {
                var rule = rules[index];
                return Container(
                  padding: const EdgeInsets.all(16),
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(color: Config().text4Color),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        rule.name!,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        rule.description!,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextButton(
              onPressed: () {
                setState(() {
                  pageIndex = 0;
                });
              },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: Text(
                'create_another_rule'.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text90Color),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton(
              onPressed: _saving
                  ? null
                  : () {
                      publish();
                    },
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              child: _saving == true
                  ? CircularProgressIndicator()
                  : Text(
                      'publish'.tr(),
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  publish() {
    setState(() {
      _saving = true;
    });
    var map = rules.map((e) => e.toJson()).toList();
    var data = {
      // 'rules': Map.fromIterable(rules) as Map<String, dynamic>,
      'rules': map,
    };
    firestore.collection('groups').doc(group!.id).update(data).then((value) {
      openToast('Successfully published group rule');
      group!.rules = rules;
      Navigator.pop(context);
    });
  }
}
