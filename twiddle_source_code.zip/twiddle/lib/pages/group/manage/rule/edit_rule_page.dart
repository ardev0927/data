import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group_rule.dart';

import '../../../../config/config.dart';
import '../../../../utils/toast.dart';

class EditRulePage extends StatefulWidget {
  EditRulePage({super.key, required this.rule});

  Rule? rule;

  @override
  State<EditRulePage> createState() => _EditRulePageState();
}

class _EditRulePageState extends State<EditRulePage> {
  Rule? rule;

  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String ruleName = '';
  String ruleDesc = '';
  bool _saving = false;

  @override
  void initState() {
    super.initState();

    rule = widget.rule;
    _nameCtrl.text = rule!.name!;
    _descCtrl.text = rule!.description!;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'edit_rule'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: TextFormField(
              controller: _nameCtrl,
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.all(16),
                hintText: 'name_of_rule'.tr(),
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
              validator: (String? value) {
                if (value!.isEmpty) return "This field can't be empty";
                return null;
              },
              onChanged: (value) {
                setState(() {
                  ruleName = value;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: TextFormField(
              controller: _descCtrl,
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.all(16),
                hintText: 'describe_your_rule'.tr(),
                hintStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
              keyboardType: TextInputType.multiline,
              maxLines: 8,
              validator: (String? value) {
                if (value!.length == 0) return "This field can't be empty";
                return null;
              },
              onChanged: (value) {
                setState(() {
                  ruleDesc = value;
                });
              },
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              if (_nameCtrl.text.isEmpty || _descCtrl.text.isEmpty) {
                openToast('Please enter rule name and description');
              } else {
                _save();
              }
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            child: _saving == true
                ? CircularProgressIndicator()
                : Text(
                    'save'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
          ),
        ],
      ),
    );
  }

  _save() {
    rule!.name = _nameCtrl.text;
    rule!.description = _descCtrl.text;
    Navigator.pop(context, true);
  }
}
