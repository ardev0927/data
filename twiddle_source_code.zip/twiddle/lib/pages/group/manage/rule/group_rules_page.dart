import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/pages/group/manage/rule/edit_rule_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../../config/config.dart';
import '../../../../models/group_rule.dart';

class GroupRulesPage extends StatefulWidget {
  GroupRulesPage({super.key, required this.group});

  Group? group;

  @override
  State<GroupRulesPage> createState() => _GroupRulesPageState();
}

class _GroupRulesPageState extends State<GroupRulesPage> {
  Group? group;
  List<Rule>? rules;

  FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    group = widget.group;
    rules = group!.rules;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'group_rules'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: ListView.separated(
        shrinkWrap: true,
        itemCount: rules!.length,
        separatorBuilder: (BuildContext context, int index) {
          return const SizedBox(height: 8);
        },
        itemBuilder: (context, index) {
          var rule = rules![index];
          return Container(
            padding: const EdgeInsets.all(16),
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(color: Config().text4Color),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      rule.name!,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    ),
                    Text(
                      rule.description!,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: IconButton(
                    onPressed: () async {
                      var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => EditRulePage(rule: rule)));
                      // nextScreen(context, EditRulePage(rule: rule));
                      if (ret is bool && ret == true) {
                        setState(() {});
                        saveRules();
                      }
                    },
                    icon: Icon(Icons.edit),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  saveRules() {
    var map = rules!.map((e) => e.toJson()).toList();
    var data = {
      'rules': map,
    };
    firestore.collection('groups').doc(group!.id).update(data).then((value) {
      group!.rules = rules;
      // Navigator.pop(context);
    });
  }
}
