import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_request_members_bloc.dart';
import 'package:twiddle/cards/group_following_card.dart';
import 'package:twiddle/models/group.dart';

import '../../../../blocs/group_bloc.dart';
import '../../../../blocs/sign_in_bloc.dart';
import '../../../../blocs/user_bloc.dart';
import '../../../../services/app_service.dart';
import '../../../../utils/empty.dart';
import '../../../../utils/loading_cards.dart';
import '../../../../utils/snacbar.dart';
import '../../../../utils/toast.dart';

class MembersTab extends StatefulWidget {
  const MembersTab({super.key, required this.group});
  final Group? group;

  @override
  State<MembersTab> createState() => _MembersTabState();
}

class _MembersTabState extends State<MembersTab> {
  ScrollController? followingCtrl;
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();
      followingCtrl = ScrollController()..addListener(_scrollListener);
      context.read<GroupRequestMembersBloc>().onInit();
      context
          .read<GroupRequestMembersBloc>()
          .getData(widget.group!.joinRequests!, mounted, _orderBy);

      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    followingCtrl!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final gfb = context.read<GroupRequestMembersBloc>();

    if (!gfb.isLoading) {
      if (followingCtrl!.position.pixels ==
          followingCtrl!.position.maxScrollExtent) {
        context.read<GroupRequestMembersBloc>().setLoading(true);
        context
            .read<GroupRequestMembersBloc>()
            .getData(widget.group!.joinRequests!, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();
    final gfb = context.watch<GroupRequestMembersBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        gfb.onRefresh(widget.group!.posts, mounted, _orderBy);
      },
      child: gfb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.groups_outlined,
                    message: 'no_member_requests'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(height: 16);
              },
              itemCount: gfb.data.isNotEmpty ? gfb.data.length + 1 : 5,
              controller: followingCtrl,
              itemBuilder: (ctx, index) {
                if (index < gfb.data.length) {
                  return GroupFollowingCard(
                    uid: sb.uid!,
                    d: gfb.data[index],
                    heroTag: 'groupfollowing$index',
                    onApprovePressed: () {
                      onApprove(gfb, index);
                    },
                    onDeclinePressed: () {
                      onDecline(gfb, index);
                    },
                  );
                }
                return Opacity(
                  opacity: gfb.isLoading ? 1.0 : 0.0,
                  child: gfb.lastVisible == null
                      ? LoadingCard(height: 200)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }

  onApprove(GroupRequestMembersBloc gfb, int index) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);
    var user = gfb.data[index];

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        await gp
            .updateGroupList(widget.group!.id!, 'members', user.uid!, true)
            .then((value) {
          if (gp.hasError == false) {
            openToast('You have approved this user successfully.');
            setState(() {
              gfb.data.remove(gfb.data[index]);
            });

            gp
                .updateGroupList(
                    widget.group!.id!, 'join_requests', user.uid!, false)
                .then((value) async {
              if (gp.hasError == false) {
              } else {
                openToast('Something went wrong');
              }
            });
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  onDecline(GroupRequestMembersBloc gfb, int index) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);
    var user = gfb.data[index];

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(
                widget.group!.id!, 'join_requests', user.uid!, false)
            .then((value) async {
          if (gp.hasError == false) {
            setState(() {
              gfb.data.remove(gfb.data[index]);
            });

            openToast('You have declined this user.');
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}
