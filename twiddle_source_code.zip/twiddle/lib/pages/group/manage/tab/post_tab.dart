import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
// import 'package:twiddle/blocs/group_posts_bloc.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/models/group.dart';

import '../../../../blocs/my_group_post_bloc.dart';
import '../../../../blocs/posts_bloc.dart';
import '../../../../blocs/sign_in_bloc.dart';
import '../../../../blocs/user_bloc.dart';
import '../../../../bottom_sheet/post_sheet.dart';
import '../../../../cards/group_post_card.dart';
import '../../../../cards/video_card.dart';
import '../../../../models/post.dart';
import '../../../../services/app_service.dart';
import '../../../../utils/convert_time_ago.dart';
import '../../../../utils/empty.dart';
import '../../../../utils/loading_cards.dart';
import '../../../../utils/next_screen.dart';
import '../../../../utils/snacbar.dart';
import '../../../../utils/toast.dart';
import '../../../post/view_comments_page.dart';
import '../../../post/view_likes_page.dart';
import '../../../post/view_shares_page.dart';
import '../../../profile/profile_main_page.dart';
import '../../../profile/show_photo_page.dart';
import '../../../profile/user_profile_page.dart';

class PostTab extends StatefulWidget {
  const PostTab({super.key, required this.group});
  final Group? group;

  @override
  State<PostTab> createState() => _PostTabState();
}

class _PostTabState extends State<PostTab> {
  ScrollController? postCtrl;
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();
      postCtrl = ScrollController()..addListener(_scrollListener);
      context.read<MyGroupPostsBloc>().onInit();
      context
          .read<MyGroupPostsBloc>()
          .getData(widget.group!.id!, mounted, _orderBy);

      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    postCtrl!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final gpb = context.read<MyGroupPostsBloc>();
    final sb = context.read<SignInBloc>();

    if (!gpb.isLoading) {
      if (postCtrl!.position.pixels == postCtrl!.position.maxScrollExtent) {
        context.read<MyGroupPostsBloc>().setLoading(true);
        context
            .read<MyGroupPostsBloc>()
            .getData(widget.group!.id!, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();
    final gpb = context.watch<MyGroupPostsBloc>();
    final ub = context.watch<UserBlock>();
    final pb = context.watch<PostsBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        gpb.onRefresh(widget.group!.id!, mounted, _orderBy);
      },
      child: gpb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.post_add_outlined,
                    message: 'No pending post to review'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(height: 16);
              },
              itemCount: gpb.data.isNotEmpty ? gpb.data.length + 1 : 5,
              controller: postCtrl,
              itemBuilder: (ctx, index) {
                if (index < gpb.data.length) {
                  // return GroupPostCard(
                  if (gpb.data[index].mediaType == 2) {
                    // VIDEO
                    // return VideoCard(
                    return PostVideoCard(
                      d: gpb.data[index],
                      time: convertToAgo(gpb.data[index].timestamp!),
                      heroTag: 'post${index - 1}',
                      onLikePressed: () {
                        if (sb.uid == gpb.data[index].uid) {
                          openToast('You can not like own post');
                          return;
                        }
                        pb.setLike(sb.uid, gpb.data[index]).then((value) {
                          if (pb.isLiked == true) {
                            gpb.data[index].likes!.add(sb.uid!);
                            openToast('Liked Post');
                          } else {
                            gpb.data[index].likes!.remove(sb.uid!);
                            openToast('Unliked Post');
                          }
                          setState(() {});
                        });
                      },
                      onLikesPressed: () {
                        nextScreen(context,
                            ViewLikesPage(uids: gpb.data[index].likes));
                      },
                      isLiked: gpb.data[index].likes!.contains(sb.uid),
                      onSharePressed: () {
                        if (sb.uid == gpb.data[index].uid) {
                          openToast('You can not share own post');
                          return;
                        }
                      },
                      onSharesPressed: () {
                        nextScreen(context,
                            ViewSharesPage(uids: gpb.data[index].shares));
                      },
                      isShared: gpb.data[index].shares!.contains(sb.uid),
                      onCommentPressed: () async {
                        if (sb.uid == gpb.data[index].uid) {
                          openToast('You can not comment own post');
                          return;
                        }
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: gpb.data[index])));
                        if (ret != null) {
                          gpb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onCommentsPressed: () async {
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: gpb.data[index])));
                        if (ret != null) {
                          gpb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onMoreTap: () {
                        // More Tap
                        showMoreSheet(
                            context,
                            ub.data!,
                            gpb.data[index],
                            sb.uid == gpb.data[index].uid ? true : false,
                            sb.uid!,
                            sb.uid == gpb.data[index].uid ? false : true,
                            onPinTap: () {
                              Navigator.pop(context);
                              _pinUnpinPost(gpb.data[index]);
                            },
                            onFollowTap: () {},
                            onReportTap: () {},
                            onHideTap: () {
                              Navigator.pop(context);
                              _hidePost(gpb.data[index], sb.uid);
                            },
                            onDeleteTap: () {
                              Navigator.pop(context);
                              _deletePost(gpb.data[index]);
                            });
                        // _showMoreSheet(context, gpb.data[index], sb.uid!);
                      },
                      onPhotoTap: () {
                        nextScreen(
                            context,
                            ShowPhotoPage(
                                p: gpb.data[index], changedArray: false));
                      },
                      onAvatarTap: () {
                        if (sb.uid != gpb.data[index].uid) {
                          nextScreen(context,
                              UserProfilePage(uid: gpb.data[index].uid));
                        } else {
                          nextScreen(context,
                              ProfileMainPage(uid: gpb.data[index].uid));
                        }
                      },
                    );
                  }
                  // return Card1(
                  return PostCard(
                    // g: gb.group!,
                    d: gpb.data[index],
                    time: convertToAgo(gpb.data[index].timestamp!),
                    heroTag: 'grouppost${index - 1}',
                    onLikePressed: () {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not like own post');
                        return;
                      }
                      pb.setLike(sb.uid, gpb.data[index]).then((value) {
                        if (pb.isLiked == true) {
                          gpb.data[index].likes!.add(sb.uid!);
                          openToast('Liked Post');
                        } else {
                          gpb.data[index].likes!.remove(sb.uid!);
                          openToast('Unliked Post');
                        }
                        setState(() {});
                      });
                    },
                    onLikesPressed: () {
                      nextScreen(
                          context, ViewLikesPage(uids: gpb.data[index].likes));
                    },
                    isLiked: gpb.data[index].likes!.contains(sb.uid),
                    onSharePressed: () {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not share own post');
                        return;
                      }
                    },
                    onSharesPressed: () {
                      nextScreen(context,
                          ViewSharesPage(uids: gpb.data[index].shares));
                    },
                    isShared: gpb.data[index].shares!.contains(sb.uid),
                    onCommentPressed: () async {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not comment own post');
                        return;
                      }
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: gpb.data[index])));
                      if (ret != null) {
                        gpb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onCommentsPressed: () async {
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: gpb.data[index])));
                      if (ret != null) {
                        gpb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onMoreTap: () {
                      // More Tap
                      showMoreSheet(
                          ctx,
                          ub.data!,
                          gpb.data[index],
                          sb.uid == gpb.data[index].uid ? true : false,
                          sb.uid!,
                          sb.uid == gpb.data[index].uid ? false : true,
                          onPinTap: () {
                            Navigator.pop(context);
                            _pinUnpinPost(gpb.data[index]);
                          },
                          onFollowTap: () {},
                          onReportTap: () {},
                          onHideTap: () {},
                          onDeleteTap: () {
                            Navigator.pop(context);
                            _deletePost(gpb.data[index]);
                          });
                      // _showMoreSheet(context, gpb.data[index], sb.uid!);
                    },
                    onPhotoTap: () {
                      nextScreen(
                          context,
                          ShowPhotoPage(
                              p: gpb.data[index], changedArray: false));
                    },
                    onAvatarTap: () {
                      if (sb.uid != gpb.data[index].uid) {
                        nextScreen(
                            context, UserProfilePage(uid: gpb.data[index].uid));
                      } else {
                        nextScreen(
                            context, ProfileMainPage(uid: gpb.data[index].uid));
                      }
                    },
                  );
                }
                return Opacity(
                  opacity: gpb.isLoading ? 1.0 : 0.0,
                  child: gpb.lastVisible == null
                      ? LoadingCard(height: 200)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
