import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_report_bloc.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/models/group.dart';

import '../../../../blocs/posts_bloc.dart';
import '../../../../blocs/sign_in_bloc.dart';
import '../../../../blocs/user_bloc.dart';
import '../../../../bottom_sheet/post_sheet.dart';
import '../../../../cards/group_post_card.dart';
import '../../../../cards/video_card.dart';
import '../../../../models/post.dart';
import '../../../../services/app_service.dart';
import '../../../../utils/convert_time_ago.dart';
import '../../../../utils/empty.dart';
import '../../../../utils/loading_cards.dart';
import '../../../../utils/next_screen.dart';
import '../../../../utils/snacbar.dart';
import '../../../../utils/toast.dart';
import '../../../post/view_comments_page.dart';
import '../../../post/view_likes_page.dart';
import '../../../post/view_shares_page.dart';
import '../../../profile/profile_main_page.dart';
import '../../../profile/show_photo_page.dart';
import '../../../profile/user_profile_page.dart';

class ReportedTab extends StatefulWidget {
  const ReportedTab({super.key, required this.group});
  final Group? group;

  @override
  State<ReportedTab> createState() => _ReportedTabState();
}

class _ReportedTabState extends State<ReportedTab> {
  ScrollController? repotedCtrl;
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();
      repotedCtrl = ScrollController()..addListener(_scrollListener);
      context.read<GroupReportBloc>().onInit();
      context
          .read<GroupReportBloc>()
          .getData(widget.group!.reports!, mounted, _orderBy);

      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    repotedCtrl!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final grb = context.read<GroupReportBloc>();
    final sb = context.read<SignInBloc>();

    if (!grb.isLoading) {
      if (repotedCtrl!.position.pixels ==
          repotedCtrl!.position.maxScrollExtent) {
        context.read<GroupReportBloc>().setLoading(true);
        context
            .read<GroupReportBloc>()
            .getData(widget.group!.reports!, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();
    final grb = context.watch<GroupReportBloc>();
    final ub = context.watch<UserBlock>();
    final pb = context.watch<PostsBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        grb.onRefresh(widget.group!.reports, mounted, _orderBy);
      },
      child: grb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.report_outlined,
                    message: 'No member reported content'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(height: 16);
              },
              itemCount: grb.data.isNotEmpty ? grb.data.length + 1 : 5,
              controller: repotedCtrl,
              itemBuilder: (ctx, index) {
                if (index < grb.data.length) {
                  // return GroupPostCard(
                  if (grb.data[index].mediaType == 2) {
                    // VIDEO
                    // return VideoCard(
                    return PostVideoCard(
                      d: grb.data[index],
                      time: convertToAgo(grb.data[index].timestamp!),
                      heroTag: 'post${index - 1}',
                      onLikePressed: () {
                        if (sb.uid == grb.data[index].uid) {
                          openToast('You can not like own post');
                          return;
                        }
                        pb.setLike(sb.uid, grb.data[index]).then((value) {
                          if (pb.isLiked == true) {
                            grb.data[index].likes!.add(sb.uid!);
                            openToast('Liked Post');
                          } else {
                            grb.data[index].likes!.remove(sb.uid!);
                            openToast('Unliked Post');
                          }
                          setState(() {});
                        });
                      },
                      onLikesPressed: () {
                        nextScreen(context,
                            ViewLikesPage(uids: grb.data[index].likes));
                      },
                      isLiked: grb.data[index].likes!.contains(sb.uid),
                      onSharePressed: () {
                        if (sb.uid == grb.data[index].uid) {
                          openToast('You can not share own post');
                          return;
                        }
                      },
                      onSharesPressed: () {
                        nextScreen(context,
                            ViewSharesPage(uids: grb.data[index].shares));
                      },
                      isShared: grb.data[index].shares!.contains(sb.uid),
                      onCommentPressed: () async {
                        if (sb.uid == grb.data[index].uid) {
                          openToast('You can not comment own post');
                          return;
                        }
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: grb.data[index])));
                        if (ret != null) {
                          grb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onCommentsPressed: () async {
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: grb.data[index])));
                        if (ret != null) {
                          grb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onMoreTap: () {
                        // More Tap
                        showMoreSheet(
                            context,
                            ub.data!,
                            grb.data[index],
                            sb.uid == grb.data[index].uid ? true : false,
                            sb.uid!,
                            sb.uid == grb.data[index].uid ? false : true,
                            onPinTap: () {
                              Navigator.pop(context);
                              _pinUnpinPost(grb.data[index]);
                            },
                            onFollowTap: () {},
                            onReportTap: () {},
                            onHideTap: () {
                              Navigator.pop(context);
                              _hidePost(grb.data[index], sb.uid);
                            },
                            onDeleteTap: () {
                              Navigator.pop(context);
                              _deletePost(grb.data[index]);
                            });
                        // _showMoreSheet(context, grb.data[index], sb.uid!);
                      },
                      onPhotoTap: () {
                        nextScreen(
                            context,
                            ShowPhotoPage(
                                p: grb.data[index], changedArray: false));
                      },
                      onAvatarTap: () {
                        if (sb.uid != grb.data[index].uid) {
                          nextScreen(context,
                              UserProfilePage(uid: grb.data[index].uid));
                        } else {
                          nextScreen(context,
                              ProfileMainPage(uid: grb.data[index].uid));
                        }
                      },
                    );
                  }
                  // return Card1(
                  return PostCard(
                    // g: gb.group!,
                    d: grb.data[index],
                    time: convertToAgo(grb.data[index].timestamp!),
                    heroTag: 'grouppost${index - 1}',
                    onLikePressed: () {
                      if (sb.uid == grb.data[index].uid) {
                        openToast('You can not like own post');
                        return;
                      }
                      pb.setLike(sb.uid, grb.data[index]).then((value) {
                        if (pb.isLiked == true) {
                          grb.data[index].likes!.add(sb.uid!);
                          openToast('Liked Post');
                        } else {
                          grb.data[index].likes!.remove(sb.uid!);
                          openToast('Unliked Post');
                        }
                        setState(() {});
                      });
                    },
                    onLikesPressed: () {
                      nextScreen(
                          context, ViewLikesPage(uids: grb.data[index].likes));
                    },
                    isLiked: grb.data[index].likes!.contains(sb.uid),
                    onSharePressed: () {
                      if (sb.uid == grb.data[index].uid) {
                        openToast('You can not share own post');
                        return;
                      }
                    },
                    onSharesPressed: () {
                      nextScreen(context,
                          ViewSharesPage(uids: grb.data[index].shares));
                    },
                    isShared: grb.data[index].shares!.contains(sb.uid),
                    onCommentPressed: () async {
                      if (sb.uid == grb.data[index].uid) {
                        openToast('You can not comment own post');
                        return;
                      }
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: grb.data[index])));
                      if (ret != null) {
                        grb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onCommentsPressed: () async {
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: grb.data[index])));
                      if (ret != null) {
                        grb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onMoreTap: () {
                      // More Tap
                      showMoreSheet(
                          ctx,
                          ub.data!,
                          grb.data[index],
                          sb.uid == grb.data[index].uid ? true : false,
                          sb.uid!,
                          sb.uid == grb.data[index].uid ? false : true,
                          onPinTap: () {
                            Navigator.pop(context);
                            _pinUnpinPost(grb.data[index]);
                          },
                          onFollowTap: () {},
                          onReportTap: () {},
                          onHideTap: () {},
                          onDeleteTap: () {
                            Navigator.pop(context);
                            _deletePost(grb.data[index]);
                          });
                      // _showMoreSheet(context, gpb.data[index], sb.uid!);
                    },
                    onPhotoTap: () {
                      nextScreen(
                          context,
                          ShowPhotoPage(
                              p: grb.data[index], changedArray: false));
                    },
                    onAvatarTap: () {
                      if (sb.uid != grb.data[index].uid) {
                        nextScreen(
                            context, UserProfilePage(uid: grb.data[index].uid));
                      } else {
                        nextScreen(
                            context, ProfileMainPage(uid: grb.data[index].uid));
                      }
                    },
                  );
                }
                return Opacity(
                  opacity: grb.isLoading ? 1.0 : 0.0,
                  child: grb.lastVisible == null
                      ? LoadingCard(height: 200)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
