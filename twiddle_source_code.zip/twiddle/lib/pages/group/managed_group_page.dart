import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/one_group_post_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/bottom_sheet/post_sheet.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/pages/group/profile/group_invite_page.dart';
import 'package:twiddle/pages/group/profile/group_members_page.dart';
import 'package:twiddle/pages/group/profile/group_search_post_page.dart';
import 'package:twiddle/pages/group/profile/edit_profile_page.dart';
import 'package:twiddle/pages/post/create_post_page.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/upload_files.dart';

import '../../blocs/group_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../cards/group_post_card.dart';
import '../../cards/video_card.dart';
import '../../config/config.dart';
import '../../models/group.dart';
import '../../models/post.dart';
import '../../models/user.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/crop_image.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../post/view_comments_page.dart';
import '../post/view_likes_page.dart';
import '../post/view_shares_page.dart';
import '../profile/show_photo_page.dart';
import '../profile/user_profile_page.dart';

class ManagedGroupPage extends StatefulWidget {
  const ManagedGroupPage({super.key, required this.group});
  final Group? group;

  @override
  State<ManagedGroupPage> createState() => _ManagedGroupPageState();
}

class _ManagedGroupPageState extends State<ManagedGroupPage> {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  ScrollController? postController;
  String _orderBy = 'timestamp';
  Group? group;
  bool isloading = false;
  bool isUpdated = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      //
      getGroup(widget.group!.id!);

      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
    group = widget.group;
    setState(() {});
  }

  @override
  void dispose() {
    postController!.removeListener(_postScrollListener);
    super.dispose();
  }

  void _postScrollListener() {
    final gb = context.read<OneGroupPostBloc>();

    if (!gb.isLoading) {
      if (postController!.position.pixels ==
          postController!.position.maxScrollExtent) {
        context.read<OneGroupPostBloc>().setLoading(true);
        context
            .read<OneGroupPostBloc>()
            .getData(widget.group!.id!, mounted, _orderBy);
      }
    }
  }

  getGroup(String gid) async {
    setState(() {
      isloading = true;
    });
    final gb = context.read<GroupBloc>();
    gb.getGroup(gid).then((value) {
      if (gb.hasError == false) {
        group = gb.group;
        postController = ScrollController()..addListener(_postScrollListener);
        context.read<OneGroupPostBloc>().onInit();
        context.read<OneGroupPostBloc>().getData(gid, mounted, _orderBy);
      } else {}
      setState(() {
        isloading = false;
      });
    });
  }

  refreshPage() {
    final ogpb = context.read<OneGroupPostBloc>();

    ogpb.onRefresh(widget.group!.id!, mounted, _orderBy);

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();
    final ogpb = context.watch<OneGroupPostBloc>();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: RefreshIndicator(
        onRefresh: () async {
          ogpb.onRefresh(widget.group!.id!, mounted, _orderBy);
        },
        child: CustomScrollView(
          slivers: [
            _customAppBar(context),
            SliverToBoxAdapter(
              child: Container(
                width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.only(top: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        group!.name!,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 16),
                      child: Row(
                        children: [
                          group!.privacy == 'Public'
                              ? Icon(Icons.public_outlined)
                              : Icon(Icons.lock_outline),
                          Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Text(
                              group!.privacy!,
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text90Color),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 16),
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Config().primary30Color,
                            ),
                          ),
                          Text(
                            '${group!.members!.length.toString()} member',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: 30,
                      padding: const EdgeInsets.only(left: 16, right: 16),
                      child: Row(
                        // mainAxisSize: MainAxisSize.min,
                        children: [
                          showMemberAvatar(),
                          Text(
                            '  + ',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                          InkWell(
                            onTap: () {
                              nextScreen(
                                  context, GroupInvitePage(group: group));
                            },
                            child: Text(
                              'invite'.tr(),
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text90Color),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(left: 16, right: 16, top: 16),
                      child: Text(
                        'about'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 8, horizontal: 16),
                      child: Text(
                        group!.description!,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      child: Text(
                        'post'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                    ),
                    GestureDetector(
                      onTap: () async {
                        // var ret = await Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) =>
                        //             GroupPostPage(group: widget.group)));
                        var ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => CreatePostPage(
                                    type: PostType.empty, g: widget.group)));
                        if (ret != null) {
                          // ogpb.getData(widget.group!.posts!, mounted, _orderBy);
                          // setState(() {});
                          refreshPage();
                        }
                      },
                      child: Container(
                        height: 70,
                        color: Config().text4Color,
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.grey[300],
                              backgroundImage:
                                  CachedNetworkImageProvider(sb.imageUrl!),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: Text(
                                'write_something'.tr(),
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text90Color),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    // _postWidget(),
                  ],
                ),
              ),
            ),
            _postWidget(),
          ],
        ),
      ),
    );
  }

  _postWidget() {
    final ogpb = context.watch<OneGroupPostBloc>();
    final sb = context.watch<SignInBloc>();
    final ub = context.watch<UserBlock>();

    return isloading == true
        ? SliverFillRemaining(
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.08,
              child: CupertinoActivityIndicator(color: Config().appColor),
            ),
          )
        : ogpb.hasData == false
            ? SliverFillRemaining(
                child: Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.08,
                    ),
                    EmptyPage(
                        icon: Icons.post_add_outlined,
                        message: 'no_post_found'.tr(),
                        message1: ''),
                  ],
                ),
              )
            : SliverPadding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    childCount: ogpb.data.isEmpty ? 5 : ogpb.data.length + 1,
                    (context, index) {
                      if (index < ogpb.data.length) {
                        // return GroupPostCard(
                        if (ogpb.data[index].mediaType == 2) {
                          // VIDEO
                          // return VideoCard(
                          return PostVideoCard(
                            d: ogpb.data[index],
                            time: convertToAgo(ogpb.data[index].timestamp!),
                            heroTag: 'post${index - 1}',
                            onLikePressed: () {
                              if (sb.uid == ogpb.data[index].uid) {
                                openToast('You can not like own post');
                                return;
                              }
                              ogpb
                                  .setLike(sb.uid, ogpb.data[index])
                                  .then((value) {
                                if (ogpb.isLiked == true) {
                                  ogpb.data[index].likes!.add(sb.uid!);
                                  openToast('Liked Post');
                                } else {
                                  ogpb.data[index].likes!.remove(sb.uid!);
                                  openToast('Unliked Post');
                                }
                                setState(() {});
                              });
                            },
                            onLikesPressed: () {
                              nextScreen(context,
                                  ViewLikesPage(uids: ogpb.data[index].likes));
                            },
                            isLiked: ogpb.data[index].likes!.contains(sb.uid),
                            onSharePressed: () {
                              if (sb.uid == ogpb.data[index].uid) {
                                openToast('You can not share own post');
                                return;
                              }
                            },
                            onSharesPressed: () {
                              nextScreen(
                                  context,
                                  ViewSharesPage(
                                      uids: ogpb.data[index].shares));
                            },
                            isShared: ogpb.data[index].shares!.contains(sb.uid),
                            onCommentPressed: () async {
                              if (sb.uid == ogpb.data[index].uid) {
                                openToast('You can not comment own post');
                                return;
                              }
                              int ret = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ViewCommentsPage(
                                          p: ogpb.data[index])));
                              if (ret != null) {
                                ogpb.data[index].comments = ret;
                                setState(() {});
                              }
                            },
                            onCommentsPressed: () async {
                              int ret = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ViewCommentsPage(
                                          p: ogpb.data[index])));
                              if (ret != null) {
                                ogpb.data[index].comments = ret;
                                setState(() {});
                              }
                            },
                            onMoreTap: () {
                              // More Tap
                              showMoreSheet(
                                context,
                                ub.data!,
                                ogpb.data[index],
                                sb.uid == ogpb.data[index].uid ? true : false,
                                sb.uid!,
                                sb.uid == ogpb.data[index].uid ? false : true,
                                onPinTap: () {
                                  Navigator.pop(context);
                                  _pinUnpinPost(ogpb.data[index]);
                                },
                                onFollowTap: () {},
                                onReportTap: () {},
                                onHideTap: () {
                                  Navigator.pop(context);
                                  _hidePost(ogpb.data[index], sb.uid);
                                },
                                onDeleteTap: () {
                                  Navigator.pop(context);
                                  _deletePost(ogpb.data[index]);
                                },
                                onReportPost: () {
                                  Navigator.pop(context);
                                  _reportPost(ogpb.data[index]);
                                },
                              );
                              // _showMoreSheet(context, ogpb.data[index], sb.uid!);
                            },
                            onPhotoTap: () {
                              nextScreen(
                                  context,
                                  ShowPhotoPage(
                                      p: ogpb.data[index],
                                      changedArray: false));
                            },
                            onAvatarTap: () {
                              if (sb.uid != ogpb.data[index].uid) {
                                nextScreen(context,
                                    UserProfilePage(uid: ogpb.data[index].uid));
                              } else {
                                nextScreen(context,
                                    ProfileMainPage(uid: ogpb.data[index].uid));
                              }
                            },
                          );
                        }
                        return GroupPostCard(
                          g: widget.group!,
                          d: ogpb.data[index],
                          time: convertToAgo(ogpb.data[index].timestamp!),
                          heroTag: 'grouppost${index - 1}',
                          onLikePressed: () {
                            if (sb.uid == ogpb.data[index].uid) {
                              openToast('You can not like own post');
                              return;
                            }
                            ogpb
                                .setLike(sb.uid, ogpb.data[index])
                                .then((value) {
                              if (ogpb.isLiked == true) {
                                ogpb.data[index].likes!.add(sb.uid!);
                                openToast('Liked Post');
                              } else {
                                ogpb.data[index].likes!.remove(sb.uid!);
                                openToast('Unliked Post');
                              }
                              setState(() {});
                            });
                          },
                          onLikesPressed: () {
                            nextScreen(context,
                                ViewLikesPage(uids: ogpb.data[index].likes));
                          },
                          isLiked: ogpb.data[index].likes!.contains(sb.uid),
                          onSharePressed: () {
                            if (sb.uid == ogpb.data[index].uid) {
                              openToast('You can not share own post');
                              return;
                            }
                            // ogpb.setShare(sb.uid, ogpb.data[index]).then((value) {
                            //   if (ogpb.isShared == true) {
                            //     ogpb.data[index].shares!.add(sb.uid!);
                            //     openToast('Shared Post');
                            //   } else {
                            //     ogpb.data[index].shares!.remove(sb.uid!);
                            //     openToast('Unshared Post');
                            //   }
                            //   setState(() {});
                            // });
                          },
                          onSharesPressed: () {
                            nextScreen(context,
                                ViewSharesPage(uids: ogpb.data[index].shares));
                          },
                          isShared: ogpb.data[index].shares!.contains(sb.uid),
                          onCommentPressed: () async {
                            if (sb.uid == ogpb.data[index].uid) {
                              openToast('You can not comment own post');
                              return;
                            }
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: ogpb.data[index])));
                            if (ret != null) {
                              ogpb.data[index].comments = ret;
                              setState(() {});
                            }
                          },
                          onCommentsPressed: () async {
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: ogpb.data[index])));
                            if (ret != null) {
                              ogpb.data[index].comments = ret;
                              setState(() {});
                            }
                          },
                          onMoreTap: () {
                            // More Tap
                            showMoreSheet(
                              context,
                              ub.data!,
                              ogpb.data[index],
                              sb.uid == ogpb.data[index].uid ? true : false,
                              sb.uid!,
                              sb.uid == ogpb.data[index].uid ? false : true,
                              onPinTap: () {
                                Navigator.pop(context);
                                _pinUnpinPost(ogpb.data[index]);
                              },
                              onFollowTap: () {},
                              onReportTap: () {},
                              onHideTap: () {},
                              onDeleteTap: () {
                                Navigator.pop(context);
                                _deletePost(ogpb.data[index]);
                              },
                              onReportPost: () {
                                Navigator.pop(context);
                                _reportPost(ogpb.data[index]);
                              },
                            );
                            // _showMoreSheet(context, ogpb.data[index], sb.uid!);
                          },
                          onPhotoTap: () {
                            nextScreen(
                                context,
                                ShowPhotoPage(
                                    p: ogpb.data[index], changedArray: false));
                          },
                          onAvatarTap: () {
                            if (sb.uid != ogpb.data[index].uid) {
                              nextScreen(context,
                                  UserProfilePage(uid: ogpb.data[index].uid));
                            } else {
                              nextScreen(context,
                                  ProfileMainPage(uid: ogpb.data[index].uid));
                            }
                          },
                        );
                      }
                      return Opacity(
                        opacity: ogpb.isLoading ? 1.0 : 0.0,
                        child: ogpb.lastVisible == null
                            ? LoadingCard(height: 200)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
              );
  }

  _customAppBar(BuildContext context) {
    final ogpb = context.watch<OneGroupPostBloc>();
    final sb = context.read<SignInBloc>();

    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: CustomCacheImage(imageUrl: group!.coverPhoto, radius: 0.0),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          if (isUpdated) {
            Navigator.pop(context, group);
          } else {
            Navigator.pop(context);
          }
        },
      ),
      title: Text(
        'profile'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      actions: <Widget>[
        // IconButton(
        //   icon: const Icon(Icons.search, size: 22, color: Colors.white),
        //   onPressed: () {
        //     // showSearch(
        //     //     context: context, delegate: GroupSearchPostDelegate(ogpb.data));
        //     nextScreen(
        //       context,
        //       GroupSearchPostPage(
        //         groupId: group!.id,
        //       ),
        //     );
        //   },
        // ),
        sb.uid == widget.group!.ownerUid
            ? IconButton(
                icon: Icon(Icons.push_pin_outlined,
                    size: 22,
                    color: group!.pinned!
                        ? Config().primary30Color
                        : Colors.white),
                onPressed: () {
                  _pinGroup();
                },
              )
            : Container(),
        sb.uid == widget.group!.ownerUid
            ? IconButton(
                icon:
                    const Icon(Icons.more_horiz, size: 22, color: Colors.white),
                onPressed: () {
                  pickSettingDialog(context);
                },
              )
            : Container(),
        const SizedBox(
          width: 5,
        )
      ],
    );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deleteGroupPost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
            refreshPage();
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  pickSettingDialog(BuildContext ctx) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    var file = await pickImage();
                    if (file != null) {
                      var url =
                          await uploadGroupCoverFile(context, file, group!);
                      saveCoverPhoto(url);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.photo_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'edit_cover'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    nextScreen(
                        context, GroupMembersPage(memberIds: group!.members!));
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.groups_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'members'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    var ret = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                EditProfilePage(group: group)));
                    if (ret != null) {
                      print('======== Updated group profile =============');
                      setState(() {
                        isUpdated = true;
                        group!.name = ret['name'];
                        group!.description = ret['description'];
                        group!.hoursOpen = ret['hours_open'];
                      });
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.person_outline),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'edit_profile'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<File?> pickImage() async {
    var image = await ImagePicker().pickImage(source: ImageSource.gallery);

    if (image != null) {
      var size = await image.readAsBytes();
      if (size.lengthInBytes > 10 * 1024 * 1024) {
        openToast('The image size should be less than 10MB');
        return null;
      }
      var cropPath = await croppedImage(image.path);

      return File(cropPath);
    } else {
      print('No image selected!');
      return null;
    }
  }

  saveCoverPhoto(String url) {
    var data = {'cover_photo': url};

    FirebaseFirestore.instance
        .collection('groups')
        .doc(group!.id)
        .update(data)
        .then((value) {
      setState(() {
        group!.coverPhoto = url;
      });
    });
  }

  showMemberAvatar() {
    return ListView.builder(
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemCount: group!.members!.length > 3 ? 3 : group!.members!.length,
      itemBuilder: (context, index) {
        return StreamBuilder<QuerySnapshot>(
          stream: getUser(group!.members![index]),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              var doc = snapshot.data!.docs[0];
              var user = WUser.fromFirestore(doc);
              return CircleAvatar(
                radius: 10,
                backgroundColor: Colors.grey[300],
                backgroundImage: CachedNetworkImageProvider(user.avatar!),
              );
            } else {
              return Container();
            }
          },
        );
      },
    );
  }

  Stream<QuerySnapshot> getUser(String? id) {
    return firebaseFirestore
        .collection('users')
        .where('uid', isEqualTo: id)
        .snapshots();
  }

  _pinGroup() async {
    final gb = context.read<GroupBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        gb.pinUnpinGroup(group!).then((value) {
          setState(() {
            group!.pinned = gb.isPinned;
          });
        });
        //
      }
    });
  }

  _reportPost(Post p) async {
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        var isReported = await pb.isReportedPost(p);
        if (isReported == false) {
          pb.reportPost(p).then((value) {
            if (pb.hasError == false) {
              openToast(
                  'Post is reported successfully, Admin will check post soon');
            } else {
              openSnacbar(context, 'Something went wrong');
            }
            setState(() {});
          });
        } else {
          openToast('This post already reported');
        }
      }
    });
  }
}
