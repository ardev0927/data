import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/models/group.dart';

import '../../blocs/group_bloc.dart';
import '../../blocs/one_group_post_bloc.dart';
import '../../cards/group_post_card.dart';
import '../../cards/post_video_card.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../post/view_comments_page.dart';
import '../post/view_likes_page.dart';
import '../post/view_shares_page.dart';
import '../profile/profile_main_page.dart';
import '../profile/show_photo_page.dart';
import '../profile/user_profile_page.dart';

class NotJoinedGroupPage extends StatefulWidget {
  const NotJoinedGroupPage({super.key, required this.group});
  final Group? group;

  @override
  State<NotJoinedGroupPage> createState() => _NotJoinedGroupPageState();
}

class _NotJoinedGroupPageState extends State<NotJoinedGroupPage> {
  Group? group;
  int joinStatus = 0;
  String btnTitle = '';

  ScrollController? postController;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    group = widget.group;
    validateJoinGroup();

    Future.delayed(const Duration(seconds: 0)).then((value) {
      if (group!.privacy == 'Public') {
        context.read<OneGroupPostBloc>().onInit();
        context.read<OneGroupPostBloc>().getData(group!.id!, mounted, _orderBy);
        postController = ScrollController()..addListener(_postScrollListener);
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    if (postController != null) {
      postController!.removeListener(_postScrollListener);
    }
    super.dispose();
  }

  void _postScrollListener() {
    final gb = context.read<OneGroupPostBloc>();

    if (!gb.isLoading) {
      if (postController!.position.pixels ==
          postController!.position.maxScrollExtent) {
        context.read<OneGroupPostBloc>().setLoading(true);
        context.read<OneGroupPostBloc>().getData(group!.id!, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: CustomScrollView(
        slivers: [
          _customAppBar(context),
          SliverToBoxAdapter(
            child: Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    group!.name!,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Config().text100Color),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Row(
                      children: [
                        group!.privacy == 'Public'
                            ? Icon(Icons.public_outlined)
                            : Icon(Icons.lock_outline),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Text(
                            group!.privacy!,
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 16),
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Config().primary30Color,
                          ),
                        ),
                        Text(
                          '${group!.members!.length.toString()} member',
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: ElevatedButton(
                      onPressed: () {
                        joinPressed();
                      },
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size.fromHeight(50),
                        primary: getBgColorFromStatus(),
                      ),
                      child: Text(
                        btnTitle,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: getTextColorFromStatus(),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'about'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      group!.description!,
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(
                      'Group rules from the admin'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'No selling, or marketing',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Text(
                      'group_activity'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      '${group!.posts!.length} new posts',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      '${group!.members!.length} total members',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Text(
                      'Created ${convertToAgo(group!.timestamp!)}',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (group!.privacy == 'Public') _postWidget(),
        ],
      ),
    );
  }

  _customAppBar(context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: CustomCacheImage(imageUrl: group!.coverPhoto, radius: 0.0),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context, group);
        },
      ),
      title: Text(
        'profile'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
    );
  }

  _postWidget() {
    final ogpb = context.watch<OneGroupPostBloc>();
    final sb = context.watch<SignInBloc>();

    return ogpb.hasData == false
        ? SliverFillRemaining(
            child: Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.08,
                ),
                EmptyPage(
                    icon: Icons.post_add_outlined,
                    message: 'no_post_found'.tr(),
                    message1: ''),
              ],
            ),
          )
        : SliverPadding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                childCount: ogpb.data.isEmpty ? 5 : ogpb.data.length + 1,
                (context, index) {
                  if (index < ogpb.data.length) {
                    // return GroupPostCard(
                    if (ogpb.data[index].mediaType == 2) {
                      // VIDEO
                      // return VideoCard(
                      return PostVideoCard(
                        d: ogpb.data[index],
                        time: convertToAgo(ogpb.data[index].timestamp!),
                        heroTag: 'post${index - 1}',
                        onLikePressed: () {
                          if (sb.uid == ogpb.data[index].uid) {
                            openToast('You can not like own post');
                            return;
                          }
                          ogpb.setLike(sb.uid, ogpb.data[index]).then((value) {
                            if (ogpb.isLiked == true) {
                              ogpb.data[index].likes!.add(sb.uid!);
                              openToast('Liked Post');
                            } else {
                              ogpb.data[index].likes!.remove(sb.uid!);
                              openToast('Unliked Post');
                            }
                            setState(() {});
                          });
                        },
                        onLikesPressed: () {
                          nextScreen(context,
                              ViewLikesPage(uids: ogpb.data[index].likes));
                        },
                        isLiked: ogpb.data[index].likes!.contains(sb.uid),
                        onSharePressed: () {},
                        onSharesPressed: () {
                          nextScreen(context,
                              ViewSharesPage(uids: ogpb.data[index].shares));
                        },
                        isShared: ogpb.data[index].shares!.contains(sb.uid),
                        onCommentPressed: () async {
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: ogpb.data[index])));
                          if (ret != null) {
                            ogpb.data[index].comments = ret;
                            setState(() {});
                          }
                        },
                        onCommentsPressed: () async {
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: ogpb.data[index])));
                          if (ret != null) {
                            ogpb.data[index].comments = ret;
                            setState(() {});
                          }
                        },
                        onMoreTap: () {},
                        onPhotoTap: () {
                          nextScreen(
                              context,
                              ShowPhotoPage(
                                  p: ogpb.data[index], changedArray: false));
                        },
                        onAvatarTap: () {
                          if (sb.uid != ogpb.data[index].uid) {
                            nextScreen(context,
                                UserProfilePage(uid: ogpb.data[index].uid));
                          } else {
                            nextScreen(context,
                                ProfileMainPage(uid: ogpb.data[index].uid));
                          }
                        },
                      );
                    }
                    return GroupPostCard(
                      g: widget.group!,
                      d: ogpb.data[index],
                      time: convertToAgo(ogpb.data[index].timestamp!),
                      heroTag: 'grouppost${index - 1}',
                      onLikePressed: () {
                        if (sb.uid == ogpb.data[index].uid) {
                          openToast('You can not like own post');
                          return;
                        }
                        ogpb.setLike(sb.uid, ogpb.data[index]).then((value) {
                          if (ogpb.isLiked == true) {
                            ogpb.data[index].likes!.add(sb.uid!);
                            openToast('Liked Post');
                          } else {
                            ogpb.data[index].likes!.remove(sb.uid!);
                            openToast('Unliked Post');
                          }
                          setState(() {});
                        });
                      },
                      onLikesPressed: () {
                        nextScreen(context,
                            ViewLikesPage(uids: ogpb.data[index].likes));
                      },
                      isLiked: ogpb.data[index].likes!.contains(sb.uid),
                      onSharePressed: () {},
                      onSharesPressed: () {
                        nextScreen(context,
                            ViewSharesPage(uids: ogpb.data[index].shares));
                      },
                      isShared: ogpb.data[index].shares!.contains(sb.uid),
                      onCommentPressed: () async {
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: ogpb.data[index])));
                        if (ret != null) {
                          ogpb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onCommentsPressed: () async {
                        int ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ViewCommentsPage(p: ogpb.data[index])));
                        if (ret != null) {
                          ogpb.data[index].comments = ret;
                          setState(() {});
                        }
                      },
                      onMoreTap: () {},
                      onPhotoTap: () {
                        nextScreen(
                            context,
                            ShowPhotoPage(
                                p: ogpb.data[index], changedArray: false));
                      },
                      onAvatarTap: () {
                        if (sb.uid != ogpb.data[index].uid) {
                          nextScreen(context,
                              UserProfilePage(uid: ogpb.data[index].uid));
                        } else {
                          nextScreen(context,
                              ProfileMainPage(uid: ogpb.data[index].uid));
                        }
                      },
                    );
                  }
                  return Opacity(
                    opacity: ogpb.isLoading ? 1.0 : 0.0,
                    child: ogpb.lastVisible == null
                        ? LoadingCard(height: 200)
                        : const Center(
                            child: SizedBox(
                                width: 32.0,
                                height: 32.0,
                                child: CupertinoActivityIndicator()),
                          ),
                  );
                },
              ),
            ),
          );
  }

  Color getBgColorFromStatus() {
    Color? color;
    switch (joinStatus) {
      case 1:
        color = Config().text4Color;
        break;
      case 2:
        color = Config().primary10Color;
        break;
      case 3:
        color = Config().primary30Color;
        break;
      default:
    }
    return color!;
  }

  Color getTextColorFromStatus() {
    Color? color;
    switch (joinStatus) {
      case 1:
      case 2:
        color = Config().text100Color;
        break;
      case 3:
        color = Colors.white;
        break;
      default:
    }
    return color!;
  }

  validateJoinGroup() {
    final sb = context.read<SignInBloc>();

    if (group!.members!.contains(sb.uid)) {
      btnTitle = 'joined'.tr();
      joinStatus = 1;
    } else {
      if (group!.joinRequests!.contains(sb.uid)) {
        btnTitle = 'join_requested'.tr();
        joinStatus = 2;
      } else {
        btnTitle = 'join_group'.tr();
        joinStatus = 3;
      }
    }
    setState(() {});
  }

  String convertToAgo(String timestamp) {
    var input = DateTime.parse(timestamp);
    Duration diff = DateTime.now().difference(input);

    if (diff.inDays >= 1) {
      return '${diff.inDays} days ago';
    } else if (diff.inHours >= 1) {
      return '${diff.inHours} hours ago';
    } else if (diff.inMinutes >= 1) {
      return '${diff.inMinutes} minutes ago';
    } else if (diff.inSeconds >= 1) {
      return '${diff.inSeconds} seconds ago';
    } else {
      return 'Just now';
    }
  }

  joinPressed() {
    switch (joinStatus) {
      case 1:
        leaveGroup();
        break;
      case 2:
        unrequestGroup();
        break;
      case 3:
        requestGroup();
        break;
      default:
    }
  }

  leaveGroup() async {
    var sb = context.read<SignInBloc>();
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'members', sb.uid!, false)
            .then((value) async {
          if (gp.hasError == false) {
            openToast('You leaved group');

            getGroup(gp, group!.id!);
            setState(() {
              joinStatus = 3;
              btnTitle = 'join_group'.tr();
            });
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  unrequestGroup() async {
    var sb = context.read<SignInBloc>();
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'join_requests', sb.uid!, false)
            .then((value) async {
          if (gp.hasError == false) {
            openToast('You unrequested group');

            getGroup(gp, group!.id!);
            setState(() {
              joinStatus = 3;
              btnTitle = 'join_group'.tr();
            });
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  requestGroup() async {
    var sb = context.read<SignInBloc>();
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'join_requests', sb.uid!, true)
            .then((value) async {
          if (gp.hasError == false) {
            openToast('You requested to join group successfully');

            getGroup(gp, group!.id!);
            setState(() {
              joinStatus = 2;
              btnTitle = 'join_requested'.tr();
            });
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  getGroup(GroupBloc gb, String gid) async {
    gb.getGroup(gid).then((value) {
      if (gb.hasError == false) {
        setState(() {
          group = gb.group;
        });
      } else {}
    });
  }
}
