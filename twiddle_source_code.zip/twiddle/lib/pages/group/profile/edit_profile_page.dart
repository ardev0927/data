import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/utils/datetime.dart';

import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../utils/other.dart';
import '../../../utils/validate.dart';
import '../../../widgets/app_mini_button.dart';
import '../../../widgets/app_picker_item.dart';
import '../../../widgets/app_text_input.dart';

class EditProfilePage extends StatefulWidget {
  EditProfilePage({super.key, required this.group});
  Group? group;

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final aboutCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final _focusName = FocusNode();
  final _focusDescribe = FocusNode();

  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

  String _week = '';
  final List<String> _weeks = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  String _monday = '';
  String _tuesday = '';
  String _wednesday = '';
  String _thursday = '';
  String _friday = '';
  String _saturday = '';
  String _sunday = '';

  Group? group;
  String? _validName;
  String? _validDescribe;
  String? openTime, closeTime;

  @override
  void initState() {
    super.initState();

    group = widget.group;

    aboutCtrl.text = group!.description ?? '';
    nameCtrl.text = group!.name ?? '';
    openTime = group!.hoursOpen ?? '';
    closeTime = group!.hoursClose ?? '';
    _week = group!.week ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: _body(),
    );
  }

  _appBar() {
    return AppBar(
      title: Text(
        'edit_profile'.tr(),
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Config().text90Color,
        ),
      ),
      actions: [
        TextButton(
            onPressed: () {
              _save();
            },
            child: Text(
              'save'.tr(),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Config().text90Color,
              ),
            ))
      ],
    );
  }

  _body() {
    return SingleChildScrollView(
      physics: AlwaysScrollableScrollPhysics(),
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AppTextInput(
              hintText: 'group_name'.tr(),
              errorText: _validName,
              focusNode: _focusName,
              textInputAction: TextInputAction.next,
              // trailing: Cont,
              onSubmitted: (text) {
                UtilOther.fieldFocusChange(
                  context,
                  _focusName,
                  _focusDescribe,
                );
              },
              onChanged: (text) {
                setState(() {
                  _validName = UtilValidator.validate(
                    nameCtrl.text,
                  );
                });
              },
              controller: nameCtrl,
            ),
            const SizedBox(height: 16),
            AppTextInput(
              hintText: 'describe_group'.tr(),
              errorText: _validDescribe,
              focusNode: _focusDescribe,
              maxLines: 5,
              textInputAction: TextInputAction.done,
              // trailing: Cont,
              onSubmitted: (text) {},
              onChanged: (text) {
                setState(() {
                  _validDescribe = UtilValidator.validate(
                    aboutCtrl.text,
                  );
                });
              },
              controller: aboutCtrl,
            ),
            const SizedBox(height: 16),
            Text(
              'hours_of_opperations'.tr(),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text90Color,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                AppMiniButton(
                  _weeks[0][0],
                  backgroundColor: _week == 'Monday' && _monday == 'Monday'
                      ? Config().appColor
                      : Config().primary4Color,
                  fontWeight: _monday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Monday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Monday' && _monday == 'Monday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Monday' ? '' : 'Monday';
                      } else {
                        _week = _monday.isNotEmpty ? '' : 'Monday';
                      }
                      _monday = _monday.isNotEmpty ? '' : _week;
                      _tuesday = _wednesday =
                          _thursday = _friday = _saturday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[1][0],
                  backgroundColor: _week == 'Tuesday' && _tuesday == 'Tuesday'
                      ? Config().appColor
                      : Config().primary4Color,
                  fontWeight: _tuesday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Tuesday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Tuesday' && _tuesday == 'Tuesday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Tuesday' ? '' : 'Tuesday';
                      } else {
                        _week = _tuesday.isNotEmpty ? '' : 'Tuesday';
                      }
                      _tuesday = _tuesday.isNotEmpty ? '' : _week;
                      _monday = _wednesday =
                          _thursday = _friday = _saturday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[2][0],
                  backgroundColor:
                      _week == 'Wednesday' && _wednesday == 'Wednesday'
                          ? Config().appColor
                          : Config().primary4Color,
                  fontWeight: _wednesday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Wednesday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Wednesday' && _wednesday == 'Wednesday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Wednesday' ? '' : 'Wednesday';
                      } else {
                        _week = _wednesday.isNotEmpty ? '' : 'Wednesday';
                      }
                      _wednesday = _wednesday.isNotEmpty ? '' : _week;
                      _tuesday = _monday =
                          _thursday = _friday = _saturday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[3][0],
                  backgroundColor:
                      _week == 'Thursday' && _thursday == 'Thursday'
                          ? Config().appColor
                          : Config().primary4Color,
                  fontWeight: _thursday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Thursday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Thursday' && _thursday == 'Thursday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Thursday' ? '' : 'Thursday';
                      } else {
                        _week = _thursday.isNotEmpty ? '' : 'Thursday';
                      }
                      _thursday = _thursday.isNotEmpty ? '' : _week;
                      _tuesday = _wednesday =
                          _monday = _friday = _saturday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[4][0],
                  backgroundColor: _week == 'Friday' && _friday == 'Friday'
                      ? Config().appColor
                      : Config().primary4Color,
                  fontWeight: _friday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Friday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Friday' && _friday == 'Friday'
                      ? Config().whiteColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Friday' ? '' : 'Friday';
                      } else {
                        _week = _friday.isNotEmpty ? '' : 'Friday';
                      }
                      _friday = _friday.isNotEmpty ? '' : _week;
                      _tuesday = _wednesday =
                          _thursday = _monday = _saturday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[5][0],
                  backgroundColor: Config().primary4Color,
                  fontWeight: _saturday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Saturday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Saturday' && _saturday == 'Saturday'
                      ? Config().appColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Saturday' ? '' : 'Saturday';
                      } else {
                        _week = _saturday.isNotEmpty ? '' : 'Saturday';
                      }
                      _saturday = _saturday.isNotEmpty ? '' : _week;
                      _tuesday = _wednesday =
                          _thursday = _friday = _monday = _sunday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
                AppMiniButton(
                  _weeks[6][0],
                  backgroundColor: Config().primary4Color,
                  fontWeight: _sunday.isNotEmpty
                      ? _week.isEmpty
                          ? FontWeight.bold
                          : _week == 'Sunday'
                              ? FontWeight.bold
                              : FontWeight.w400
                      : FontWeight.w400,
                  textColor: _week == 'Sunday' && _sunday == 'Sunday'
                      ? Config().appColor
                      : Config().text100Color,
                  onPressed: () {
                    setState(() {
                      if (_week.isNotEmpty) {
                        _week = _week == 'Sunday' ? '' : 'Sunday';
                      } else {
                        _week = _sunday.isNotEmpty ? '' : 'Sunday';
                      }
                      _sunday = _sunday.isNotEmpty ? '' : _week;
                      _tuesday = _wednesday =
                          _thursday = _friday = _saturday = _monday = '';
                    });
                    print('===== Week: $_week =====');
                    printWeeks();
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'open_time'.tr(),
              leading: const Icon(Icons.schedule_outlined),
              value: openTime,
              onPressed: () async {
                var time = await _onShowTimePicker();
                setState(() {
                  openTime = time;
                });
              },
            ),
            const SizedBox(height: 16),
            AppPickerItem(
              title: 'close_time'.tr(),
              leading: const Icon(Icons.schedule_outlined),
              value: closeTime,
              onPressed: () async {
                var time = await _onShowTimePicker();
                setState(() {
                  closeTime = time;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  printWeeks() {
    print('===== Monday: $_monday =====');
    print('===== Tuesday: $_tuesday =====');
    print('===== Wednesday: $_wednesday =====');
    print('===== Thursday: $_thursday =====');
    print('===== Friday: $_friday =====');
    print('===== Saturday: $_saturday =====');
    print('===== Sunday: $_sunday =====');
  }

  ///Show Picker Time
  Future<String?>? _onShowTimePicker() async {
    String? time;
    final now = TimeOfDay.now();
    final picked = await showTimePicker(
      context: context,
      initialTime: now,
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        MaterialLocalizations localization = MaterialLocalizations.of(context);
        time = localization.formatTimeOfDay(picked);
        // groupTime = picked.format(context);
      });
    }
    return time;
  }

  _save() {
    if (nameCtrl.text.isNotEmpty &&
        aboutCtrl.text.isNotEmpty &&
        _week.isNotEmpty &&
        openTime != null &&
        openTime!.isNotEmpty &&
        closeTime != null &&
        closeTime!.isNotEmpty) {
      var data = {
        'name': nameCtrl.text,
        'description': aboutCtrl.text,
        'week': _week,
        'hours_open': openTime,
        'hours_close': closeTime,
      };
      firebaseFirestore
          .collection('groups')
          .doc(group!.id)
          .update(data)
          .then((value) => Navigator.pop(context, data));
    }
  }
}
