import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';

import '../../../blocs/notification_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../blocs/user_bloc.dart';
import '../../../blocs/your_group_bloc.dart';
import '../../../cards/invite_card.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../models/user.dart';
import '../../../services/app_service.dart';
import '../../../utils/empty.dart';
import '../../../utils/enums.dart';
import '../../../utils/format_time.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/snacbar.dart';

class GroupInvitePage extends StatefulWidget {
  GroupInvitePage({super.key, required this.group});

  Group? group;

  @override
  State<GroupInvitePage> createState() => _GroupInvitePageState();
}

class _GroupInvitePageState extends State<GroupInvitePage> {
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    final sb = context.read<SignInBloc>();

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      controller = ScrollController()..addListener(_scrollListener);
      context.read<UserBlock>().onInit();
      context.read<UserBlock>().getRandomUsers(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<UserBlock>().setLoading(true);
        context.read<UserBlock>().getRandomUsers(sb.uid, mounted);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'invites'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return RefreshIndicator(
        onRefresh: () async {},
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                _invitesWidget(),
              ],
            ),
          ),
        ));
  }

  _invitesWidget() {
    final ub = context.watch<UserBlock>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            'invite_friends_your_groups'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
        ),
        ub.hasData == false
            ? ListView(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.35,
                  ),
                  EmptyPage(
                      icon: Icons.person_outline,
                      message: 'users_not_found'.tr(),
                      message1: ''),
                ],
              )
            : ListView.separated(
                controller: controller,
                shrinkWrap: true,
                itemCount: ub.users.isNotEmpty ? ub.users.length + 1 : 5,
                separatorBuilder: (BuildContext context, int index) =>
                    const SizedBox(height: 4),

                //shrinkWrap: true,
                itemBuilder: (_, int index) {
                  if (index < ub.users.length) {
                    if (widget.group!.members!.contains(ub.users[index].uid)) {
                      return Container();
                    }
                    return InviteCard(
                      d: ub.users[index],
                      g: widget.group!,
                      heroTag: 'invite$index',
                      onInvitePressed: () {
                        if (ub.users[index].inviteGroups!
                            .contains(widget.group!.id)) {
                          unInviteGroupToUser(ub, index, widget.group!);
                        } else {
                          inviteGroupToUser(ub, index, widget.group!);
                        }
                      },
                    );
                  }
                  return Opacity(
                    opacity: ub.isLoading ? 1.0 : 0.0,
                    child: ub.lastVisible == null
                        ? LoadingCard(height: 60)
                        : const Center(
                            child: SizedBox(
                                width: 32.0,
                                height: 32.0,
                                child: CupertinoActivityIndicator()),
                          ),
                  );
                },
              )
      ],
    );
  }

  // inviteUser(Group g, WUser u) async {
  //   final gb = context.read<GroupBloc>();

  //   await AppService().checkInternet().then((hasInternet) async {
  //     if (hasInternet == false) {
  //       openSnacbar(context, 'check your internet connection!'.tr());
  //     } else {
  //       gb.inviteUser(g, u).then((value) => inviteGroupToUser(g, u));
  //       //
  //     }
  //   });
  // }

  inviteGroupToUser(UserBlock ub, int index, Group g) async {
    final ub = context.read<UserBlock>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ub.inviteGroup(g, ub.users[index].uid!).then((value) {
          setState(() {
            ub.users[index].inviteGroups!.add(g.id!);
          });
          _sendFcmInviteGroup(ub.users[index].uid!, g,
              ub.users[index].fcmToken!, FcmType.invitegroup, true);
        });
        //
      }
    });
  }

  unInviteGroupToUser(UserBlock ub, int index, Group g) async {
    final ub = context.read<UserBlock>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ub.unInviteGroup(g, ub.users[index].uid!).then((value) {
          setState(() {
            ub.users[index].inviteGroups!.remove(g.id!);
          });
          _sendFcmInviteGroup(ub.users[index].uid!, g,
              ub.users[index].fcmToken!, FcmType.uninvitegroup, false);
        });
        //
      }
    });
  }

  _sendFcmInviteGroup(
      String uid, Group g, String fcmToken, int fcmType, bool isInvite) async {
    print("===== fcm token $fcmToken =====");
    String title = "Invite group";
    String body = isInvite
        ? "You received invitation from ${g.name} group."
        : "You cancelled invitation from ${g.name} group.";

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(uid, body, fcmType, g.id, g.coverPhoto);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
