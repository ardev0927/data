import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/cards/friends_card2.dart';
import 'package:twiddle/cards/friends_card3.dart';
import 'package:twiddle/cards/member_card.dart';

import '../../../config/config.dart';
import '../../../models/user.dart';
import '../../../utils/empty.dart';
import '../../../utils/next_screen.dart';
import '../../profile/user_profile_page.dart';

class GroupMembersPage extends StatefulWidget {
  GroupMembersPage({super.key, required this.memberIds});

  List<String>? memberIds;

  @override
  State<GroupMembersPage> createState() => _GroupMembersPageState();
}

class _GroupMembersPageState extends State<GroupMembersPage> {
  FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  List<String> memberIds = [];

  @override
  void initState() {
    super.initState();

    memberIds.addAll(widget.memberIds!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: _body(),
    );
  }

  _appBar() {
    return AppBar(
      title: Text(
        'members'.tr(),
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Config().text90Color,
        ),
      ),
    );
  }

  _body() {
    print(memberIds);
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: ListView.builder(
        physics: AlwaysScrollableScrollPhysics(),
        shrinkWrap: true,
        // padding: const EdgeInsets.all(16),
        itemCount: memberIds.length,
        itemBuilder: (context, index) {
          return StreamBuilder<QuerySnapshot>(
            stream: getUser(memberIds[index]),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                var doc = snapshot.data!.docs[0];
                var user = WUser.fromFirestore(doc);
                return MemberCard(
                  d: user,
                  heroTag: 'group_member$index',
                  onItemTapped: () {
                    // Open profile page
                    nextScreen(context, UserProfilePage(uid: user.uid));
                  },
                );
              } else {
                return Container();
                // return ListView(
                //   children: [
                //     SizedBox(
                //       height: MediaQuery.of(context).size.height * 0.20,
                //     ),
                //     EmptyPage(
                //         icon: Icons.person_off_outlined,
                //         message: 'no_member'.tr(),
                //         message1: ''),
                //   ],
                // );
              }
            },
          );
        },
      ),
    );
  }

  Stream<QuerySnapshot> getUser(String? id) {
    return firebaseFirestore
        .collection('users')
        .where('uid', isEqualTo: id)
        .snapshots();
  }
}
