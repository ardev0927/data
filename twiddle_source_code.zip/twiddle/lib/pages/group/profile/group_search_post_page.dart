import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/cards/video_card.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../blocs/sign_in_bloc.dart';
import '../../../models/post.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/next_screen.dart';
import '../../profile/profile_main_page.dart';
import '../../profile/show_photo_page.dart';
import '../../profile/user_profile_page.dart';

class GroupSearchPostPage extends StatefulWidget {
  GroupSearchPostPage({super.key, required this.groupId});

  String? groupId;

  @override
  State<GroupSearchPostPage> createState() => _GroupSearchPostPageState();
}

class _GroupSearchPostPageState extends State<GroupSearchPostPage> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  bool isLoading = false;
  List<Post> posts = [];

  @override
  void initState() {
    super.initState();

    isLoading = true;
    getPosts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: _body(),
    );
  }

  _appBar() {
    return AppBar(
      title: Text(
        'search_post'.tr(),
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: Config().text90Color,
        ),
      ),
      actions: [
        IconButton(
            onPressed: () {
              showSearch(
                  context: context, delegate: GroupSearchPostDelegate(posts));
            },
            icon: Icon(Icons.search_outlined)),
      ],
    );
  }

  _body() {
    return isLoading
        ? Center(child: CupertinoActivityIndicator(color: Colors.grey))
        : Container();
  }

  getPosts() async {
    await firestore
        .collection('groups')
        .doc(widget.groupId)
        .collection('posts')
        .orderBy('timestamp', descending: true)
        .get()
        .then((value) {
      if (value.docs.isNotEmpty) {
        posts.addAll(value.docs.map((e) => Post.fromFirestore(e)).toList());
      }
      setState(() {
        isLoading = false;
      });
    }).onError((error, stackTrace) {
      setState(() {
        isLoading = false;
      });
    });
  }
}

class GroupSearchPostDelegate extends SearchDelegate {
  final List<Post> posts;
  GroupSearchPostDelegate(this.posts);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          query = '';
          posts.clear();
        },
        icon: Icon(Icons.clear),
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, null);
      },
      icon: Icon(Icons.arrow_back),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    List<Post> matchQuery = [];
    final sb = context.read<SignInBloc>();

    for (var post in posts) {
      if (post.description!.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(post);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        if (result.mediaType == PostType.video) {
          // return VideoCard(
          return PostVideoCard(
            d: result,
            time: convertToAgo(result.timestamp!),
            heroTag: 'search_video_post$index',
            onLikePressed: () {},
            onLikesPressed: () {},
            isLiked: result.likes!.contains(sb.uid),
            onSharePressed: () {},
            onSharesPressed: () {},
            isShared: result.shares!.contains(sb.uid),
            onCommentPressed: () {},
            onCommentsPressed: () {},
            onPhotoTap: () {},
            onAvatarTap: () {
              if (sb.uid != result.uid) {
                nextScreen(context, UserProfilePage(uid: result.uid));
              } else {
                nextScreen(context, ProfileMainPage(uid: result.uid));
              }
            },
          );
        }
        // return Card1(
        return PostCard(
          d: result,
          time: convertToAgo(result.timestamp!),
          heroTag: 'search_post$index',
          onLikePressed: () {},
          onLikesPressed: () {},
          isLiked: result.likes!.contains(sb.uid),
          onSharePressed: () {},
          onSharesPressed: () {},
          isShared: result.shares!.contains(sb.uid),
          onCommentPressed: () {},
          onCommentsPressed: () {},
          onPhotoTap: () => nextScreen(
              context, ShowPhotoPage(p: result, changedArray: false)),
          onAvatarTap: () {
            if (sb.uid != result.uid) {
              nextScreen(context, UserProfilePage(uid: result.uid));
            } else {
              nextScreen(context, ProfileMainPage(uid: result.uid));
            }
          },
          onArticleTap: () {
            if (posts[index - 1].mediaType == 11) {
              launchUrl(Uri.parse(posts[index - 1].article!));
            }
          },
        );
      },
    );
    // List<String> matchQuery = [];
    // for (var fruit in searchTerms) {
    //   if (fruit.toLowerCase().contains(query.toLowerCase())) {
    //     matchQuery.add(fruit);
    //   }
    // }
    // return ListView.builder(
    //   itemCount: matchQuery.length,
    //   itemBuilder: (context, index) {
    //     var result = matchQuery[index];
    //     return ListTile(
    //       title: Text(result),
    //     );
    //   },
    // );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Container();
    // List<Post> matchQuery = [];
    // for (var post in posts) {
    //   if (post.description!.toLowerCase().contains(query.toLowerCase())) {
    //     matchQuery.add(post);
    //   }
    // }
    // return ListView.builder(
    //   itemCount: matchQuery.length,
    //   itemBuilder: (context, index) {
    //     var result = matchQuery[index];
    //     return ListTile(
    //       title: Text(result.description!),
    //     );
    //   },
    // );
  }
}
