import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_follow_bloc.dart';
import 'package:twiddle/cards/group_following2_card.dart';

import '../../../blocs/sign_in_bloc.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../joined_group_page.dart';
import '../managed_group_page.dart';
import '../not_joined_group_page.dart';

class GroupFollowingPage extends StatefulWidget {
  const GroupFollowingPage({super.key});

  @override
  State<GroupFollowingPage> createState() => _GroupFollowingPageState();
}

class _GroupFollowingPageState extends State<GroupFollowingPage> {
  final _searchCtrl = TextEditingController();
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      controller = ScrollController()..addListener(_scrollListener);
      context.read<GroupFollowBloc>().getGroups(mounted, sb.uid!, _orderBy);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final gpb = context.read<GroupFollowBloc>();
    final sb = context.read<SignInBloc>();

    if (!gpb.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<GroupFollowBloc>().setLoading(true);
        context.read<GroupFollowBloc>().getGroups(mounted, sb.uid!, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'following'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final gb = context.watch<GroupFollowBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {},
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
            ),
            Expanded(
              child: gb.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        EmptyPage(
                            icon: Icons.group_outlined,
                            message: 'no group found'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      controller: controller,
                      shrinkWrap: true,
                      itemCount: gb.data.isNotEmpty ? gb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          const SizedBox(
                        height: 4,
                      ),

                      //shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < gb.data.length) {
                          return GroupFollowing2Card(
                            d: gb.data[index],
                            heroTag: 'group_follow$index',
                            onItemTapped: () async {
                              if (gb.data[index].members!.contains(sb.uid)) {
                                nextScreen(context,
                                    ManagedGroupPage(group: gb.data[index]));
                              } else {
                                var ret = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            NotJoinedGroupPage(
                                                group: gb.data[index])));
                                if (ret != null) {
                                  setState(() {
                                    gb.data[index] = ret;
                                  });
                                }
                              }
                            },
                            onFollowPressed: () async {
                              following(sb, gb, index);
                            },
                          );
                        }
                        return Opacity(
                          opacity: gb.isLoading ? 1.0 : 0.0,
                          child: gb.lastVisible == null
                              ? const LoadingCard(height: 60)
                              : const Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  following(SignInBloc sb, GroupFollowBloc gb, int index) {
    if (gb.data[index].following!.contains(sb.uid)) {
      followGroup(gb.data[index], sb, gb, index, false);
    } else {
      followGroup(gb.data[index], sb, gb, index, true);
    }
  }

  followGroup(Group? group, SignInBloc sb, GroupFollowBloc gb, int index,
      bool following) async {
    var gp = Provider.of<GroupFollowBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        if (following) {
          gp
              .updateGroupList(group!.id!, 'following', sb.uid!, true)
              .then((value) async {
            if (gp.hasError == false) {
              gp.getGroup(group.id!).then((value) {
                if (gp.hasError == false) {
                  setState(() {
                    gb.data[index] = gp.group!;
                  });
                } else {}
              });
            } else {
              openToast('Something went wrong');
            }
          });
        } else {
          gp
              .updateGroupList(group!.id!, 'following', sb.uid!, false)
              .then((value) async {
            if (gp.hasError == false) {
              gp.getGroup(group.id!).then((value) {
                if (gp.hasError == false) {
                  setState(() {
                    gb.data[index] = gp.group!;
                  });
                } else {}
              });
            } else {
              openToast('Something went wrong');
            }
          });
        }
      }
    });
  }
}
