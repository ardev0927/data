import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:twiddle/cards/group_invited_card.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/group/not_joined_group_page.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';

import '../../../blocs/notification_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../blocs/user_bloc.dart';
import '../../../blocs/your_group_bloc.dart';
import '../../../cards/invite_card.dart';
import '../../../config/config.dart';
import '../../../services/app_service.dart';
import '../../../utils/empty.dart';
import '../../../utils/enums.dart';
import '../../../utils/format_time.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/snacbar.dart';

class GroupInvitesPage extends StatefulWidget {
  const GroupInvitesPage({super.key});

  @override
  State<GroupInvitesPage> createState() => _GroupInvitesPageState();
}

class _GroupInvitesPageState extends State<GroupInvitesPage> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  List<Group> myGroups = [];
  List<String> invitedGroupIds = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      isLoading = true;
      getGroupIds();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'invited'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return RefreshIndicator(
      onRefresh: () async {},
      child: Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, top: 8, bottom: 8),
        child: _invitedGroupsWidget(),
      ),
    );
  }

  _invitedGroupsWidget() {
    return isLoading
        ? const Center(
            child: SizedBox(
            width: 32,
            height: 32,
            child: CupertinoActivityIndicator(),
          ))
        : invitedGroupIds.isEmpty
            ? ListView(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.20,
                  ),
                  EmptyPage(
                      icon: Icons.group_add_outlined,
                      message:
                          'you_have_not_received_invitation_any_group'.tr(),
                      message1: ''),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.symmetric(vertical: 8),
                itemCount: invitedGroupIds.length,
                itemBuilder: (context, index) {
                  return StreamBuilder<QuerySnapshot>(
                    stream: getGroup(invitedGroupIds[index]),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        var doc = snapshot.data!.docs[0];
                        var group = Group.fromFirestore(doc);
                        return GroupInvitedCard(
                          d: group,
                          // u: u,
                          heroTag: 'group_invite$index',
                          width: MediaQuery.of(context).size.width,
                          onItemTapped: () {
                            nextScreen(
                                context, NotJoinedGroupPage(group: group));
                          },
                          onJoinPressed: () {
                            joinGroup(group);
                          },
                          onDeletePressed: () {
                            unInviteGroupToUser(group);
                          },
                        );
                      }
                      return Container();
                    },
                  );
                },
              );
  }

  Stream<QuerySnapshot> getGroup(String gid) {
    return firestore
        .collection('groups')
        .where('id', isEqualTo: gid)
        .snapshots();
  }

  getGroupIds() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final UserBlock ub = context.read<UserBlock>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        invitedGroupIds = await ub.getInviteGroups(sb.uid!);

        //
      }
      setState(() {
        isLoading = false;
      });
    });
  }

  unInviteGroupToUser(Group g) async {
    final ub = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ub.unInviteGroup(g, sb.uid!).then((value) {
          setState(() {
            invitedGroupIds.remove(g.id);
          });
        });
        //
      }
    });
  }

  joinGroup(Group g) async {
    final gb = context.read<GroupBloc>();
    final sb = context.read<SignInBloc>();
    final ub = context.read<UserBlock>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        gb.joinGroup(g, sb.uid!).then((value) {
          setState(() {
            invitedGroupIds.remove(g.id);
          });
          openToast('You have joined ${g.name} group');

          ub.getUser(g.ownerUid, mounted).then(
            (value) {
              _sendFcmJoinGroup(
                  sb.uid!, sb.name!, g, ub.data!.fcmToken!, FcmType.joingroup);
            },
          );
        });
        //
      }
    });
  }

  _sendFcmJoinGroup(
      String uid, String name, Group g, String fcmToken, int fcmType) async {
    print("===== fcm token $fcmToken =====");
    String title = "Joined group";
    String body = "$name has joined ${g.name} group.";

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(uid, body, fcmType, g.id, g.coverPhoto);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
