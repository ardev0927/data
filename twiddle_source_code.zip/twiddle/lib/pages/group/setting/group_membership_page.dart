import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/cards/group_membership_card.dart';
import 'package:twiddle/pages/group/managed_group_page.dart';

import '../../../blocs/group_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../joined_group_page.dart';

class GroupMembershipPage extends StatefulWidget {
  const GroupMembershipPage({super.key});

  @override
  State<GroupMembershipPage> createState() => _GroupMembershipPageState();
}

class _GroupMembershipPageState extends State<GroupMembershipPage> {
  final _searchCtrl = TextEditingController();
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = ScrollController()..addListener(_scrollListener);
      context.read<GroupBloc>().getData(mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final gpb = context.read<GroupBloc>();

    if (!gpb.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<GroupBloc>().setLoading(true);
        context.read<GroupBloc>().getData(mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'membership'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final gb = context.watch<GroupBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {},
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
            ),
            Expanded(
              child: gb.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        EmptyPage(
                            icon: Icons.group_outlined,
                            message: 'no group found'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      controller: controller,
                      shrinkWrap: true,
                      itemCount: gb.data.isNotEmpty ? gb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 15,
                      ),

                      //shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < gb.data.length) {
                          if (gb.data[index].ownerUid == sb.uid) {
                            return Container();
                          }
                          if (!gb.data[index].members!.contains(sb.uid)) {
                            return Container();
                          }
                          return GroupMembershipCard(
                            d: gb.data[index],
                            heroTag: 'group_follow$index',
                            onItemTapped: () async {
                              if (gb.data[index].members!.contains(sb.uid)) {
                                nextScreen(context,
                                    ManagedGroupPage(group: gb.data[index]));
                              }
                            },
                            onLeavePressed: () async {
                              leaveDialog(context, sb, gb, index);
                            },
                          );
                        }
                        return Opacity(
                          opacity: gb.isLoading ? 1.0 : 0.0,
                          child: gb.lastVisible == null
                              ? LoadingCard(height: 60)
                              : Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  leaveDialog(BuildContext ctx, SignInBloc sb, GroupBloc gb, int index) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
                ),
                Text(
                  sb.name!,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                const Divider(),
                Text(
                  'are_you_sure_want_leave_group'.tr(),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Config().text10Color),
                      child: Text(
                        'no'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text90Color),
                      ),
                    ),
                    const SizedBox(width: 32),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        leaveGroup(gb.data[index], sb, gb, index);
                      },
                      child: Text(
                        'yes'.tr(),
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  leaveGroup(Group? group, SignInBloc sb, GroupBloc gb, int index) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'members', sb.uid!, false)
            .then((value) async {
          if (gp.hasError == false) {
            setState(() {
              gb.data.remove(group);
            });
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}
