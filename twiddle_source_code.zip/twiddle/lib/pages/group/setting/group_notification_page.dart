import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:twiddle/cards/group_notification_card.dart';

import '../../../config/config.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';

class GroupNotificationPage extends StatefulWidget {
  const GroupNotificationPage({super.key});

  @override
  State<GroupNotificationPage> createState() => _GroupNotificationPageState();
}

class _GroupNotificationPageState extends State<GroupNotificationPage> {
  final _searchCtrl = TextEditingController();
  ScrollController? controller;
  String _orderBy = 'timestamp';
  String setting = 'all_post'.tr();

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = new ScrollController()..addListener(_scrollListener);
      // context.read<GroupBloc>().onInit();
      context.read<GroupBloc>().getData(mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);

    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<GroupBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<GroupBloc>().setLoading(true);
        context.read<GroupBloc>().getData(mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'group_notification'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final gb = context.watch<GroupBloc>();

    return RefreshIndicator(
      onRefresh: () async {},
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
            ),
            Expanded(
              child: gb.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        EmptyPage(
                            icon: Icons.group_outlined,
                            message: 'no group found'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      controller: controller,
                      shrinkWrap: true,
                      itemCount: gb.data.isNotEmpty ? gb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 15,
                      ),

                      //shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < gb.data.length) {
                          return GroupNotificationCard(
                            d: gb.data[index],
                            setting: setting,
                            heroTag: 'group_following$index',
                            onSettingTap: () async {
                              var ret = await _showBottomSheet(context);
                              setState(() {
                                // setting = ret;
                              });
                            },
                          );
                        }
                        return Opacity(
                          opacity: gb.isLoading ? 1.0 : 0.0,
                          child: gb.lastVisible == null
                              ? LoadingCard(height: 60)
                              : Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // Bottom sheet for setting
  _showBottomSheet(ctx) async {
    var ret = await showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context, '');
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // all post
            ListTile(
              onTap: () {
                Navigator.pop(context, 'all_post'.tr());
              },
              title: Text(
                'all_post'.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            // Highlights
            ListTile(
              onTap: () {
                Navigator.pop(context, 'highlights'.tr());
              },
              title: Text(
                'highlights'.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            // Friends post
            ListTile(
              onTap: () {
                Navigator.pop(context, "friend_post".tr());
              },
              title: Text(
                "friend_post".tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            // Off
            ListTile(
              onTap: () {
                Navigator.pop(context, 'off'.tr());
              },
              title: Text(
                "off".tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
          ],
        );
      },
    );
    print('====== Group Noti : $ret ======');
    return ret;
  }
}
