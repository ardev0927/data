import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/group/setting/group_following_page.dart';
import 'package:twiddle/pages/group/setting/group_invites_page.dart';
import 'package:twiddle/pages/group/setting/group_membership_page.dart';
import 'package:twiddle/pages/group/setting/group_notification_page.dart';
import 'package:twiddle/pages/group/setting/pinned_groups_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../blocs/user_bloc.dart';
import '../../../models/user.dart';
import '../../../utils/cached_image.dart';

class GroupSettingPage extends StatefulWidget {
  const GroupSettingPage({super.key});

  @override
  State<GroupSettingPage> createState() => _GroupSettingPageState();
}

class _GroupSettingPageState extends State<GroupSettingPage> {
  @override
  void initState() {
    final ub = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();
    ub.getUser(sb.uid, mounted).then((value) {});

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<UserBlock>();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ub.isLoading == true
          ? Container(
              child: Center(child: CircularProgressIndicator()),
            )
          : CustomScrollView(
              slivers: [
                _customAppBar(ub.data!, context),
                SliverToBoxAdapter(
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Divider(),
                        _postItem(
                          iconData: Icons.notifications_active_outlined,
                          itemName: 'notification',
                          onTap: () {
                            nextScreen(context, GroupNotificationPage());
                          },
                        ),
                        // const Divider(),
                        // _postItem(
                        //   iconData: Icons.push_pin_outlined,
                        //   itemName: 'pinned_groups',
                        //   onTap: () {
                        //     nextScreen(context, PinnedGroupsPage());
                        //   },
                        // ),
                        const Divider(),
                        _postItem(
                          iconData: Icons.person_add_outlined,
                          itemName: 'following',
                          onTap: () {
                            nextScreen(context, GroupFollowingPage());
                          },
                        ),
                        // const Divider(),
                        // _postItem(
                        //   iconData: Icons.groups_outlined,
                        //   itemName: 'membership',
                        //   onTap: () {
                        //     nextScreen(context, GroupMembershipPage());
                        //   },
                        // ),
                        const Divider(),
                        _postItem(
                          iconData: Icons.notifications_active_outlined,
                          itemName: 'invites',
                          onTap: () {
                            nextScreen(context, GroupInvitesPage());
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  _customAppBar(WUser user, context) {
    var width = MediaQuery.of(context).size.width;
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: user.coverUrl != ''
            ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
            : Image.asset(
                'assets/images/profile_cover.png',
                fit: BoxFit.cover,
              ),
      ),
      leading: IconButton(
        icon: const Icon(Icons.keyboard_backspace, size: 22),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        'group'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Config().text100Color),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: width,
                height: 50,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 100,
                    height: 100,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: CustomCacheImage(
                          imageUrl: user.avatar,
                          radius: 45.0,
                          circularShape: true),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  InkWell _postItem({IconData? iconData, String? itemName, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(iconData),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }
}
