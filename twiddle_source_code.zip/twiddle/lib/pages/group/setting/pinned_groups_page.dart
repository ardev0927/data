import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_pinned_bloc.dart';

import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/group_pinned_card.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../joined_group_page.dart';
import '../managed_group_page.dart';
import '../not_joined_group_page.dart';

class PinnedGroupsPage extends StatefulWidget {
  const PinnedGroupsPage({super.key});

  @override
  State<PinnedGroupsPage> createState() => _PinnedGroupsPageState();
}

class _PinnedGroupsPageState extends State<PinnedGroupsPage> {
  final _searchCtrl = TextEditingController();
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = new ScrollController()..addListener(_scrollListener);
      // context.read<GroupBloc>().onInit();
      context.read<GroupPinnedBloc>().getData(mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);

    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<GroupPinnedBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<GroupPinnedBloc>().setLoading(true);
        context.read<GroupPinnedBloc>().getData(mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'pinned_groups'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final gpb = context.watch<GroupPinnedBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        gpb.onRefresh(mounted, _orderBy);
      },
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
            ),
            Expanded(
              child: gpb.hasData == false
                  ? Container()
                  : Container(
                      width: MediaQuery.of(context).size.width,
                      child: ListView.builder(
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount:
                            gpb.data.isNotEmpty ? gpb.data.length + 2 : 5,
                        controller: controller,
                        itemBuilder: (ctx, index) {
                          print('pinned group count is ${gpb.data.length}');
                          if (index < gpb.data.length + 1) {
                            if (index == 0) {
                              return Text(
                                'pinned'.tr(),
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: Config().text100Color),
                              );
                            }
                            return GroupPinnedCard(
                              d: gpb.data[index - 1],
                              heroTag: 'grouppinned${index - 1}',
                              onTap: () async {
                                if (gpb.data[index - 1].ownerUid == sb.uid) {
                                  nextScreen(
                                      context,
                                      ManagedGroupPage(
                                          group: gpb.data[index - 1]));
                                } else {
                                  if (gpb.data[index - 1].members!
                                      .contains(sb.uid)) {
                                    nextScreen(context, JoinedGroupPage());
                                  } else {
                                    var ret = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                NotJoinedGroupPage(
                                                    group:
                                                        gpb.data[index - 1])));
                                    if (ret != null) {
                                      gpb.data[index - 1] = ret;
                                    }
                                  }
                                }
                                // _validateGroup(
                                //     gpb, gpb.data[index - 1], sb.uid);
                              },
                            );
                          }
                          return Opacity(
                            opacity: gpb.isLoading ? 1.0 : 0.0,
                            child: gpb.lastVisible == null
                                ? LoadingCard(height: 80)
                                : const Center(
                                    child: SizedBox(
                                        width: 32.0,
                                        height: 32.0,
                                        child: CupertinoActivityIndicator()),
                                  ),
                          );
                        },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
