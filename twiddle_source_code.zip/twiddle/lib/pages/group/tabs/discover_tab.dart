import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/suggest_group_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/suggestion_card.dart';
import 'package:twiddle/utils/enums.dart';

import '../../../blocs/group_bloc.dart';
import '../../../blocs/notification_bloc.dart';
import '../../../blocs/other_group_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/suggest_group_card.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/empty.dart';
import '../../../utils/format_time.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../joined_group_page.dart';
import '../managed_group_page.dart';
import '../not_joined_group_page.dart';

class DiscoverTab extends StatefulWidget {
  const DiscoverTab({super.key});

  @override
  State<DiscoverTab> createState() => _DiscoverTabState();
}

class _DiscoverTabState extends State<DiscoverTab> {
  ScrollController? suggestCtrl;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();
      suggestCtrl = ScrollController()..addListener(_otherScrollListener);
      context.read<SuggestedGroupBloc>().getData(sb.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    suggestCtrl!.removeListener(_otherScrollListener);
    super.dispose();
  }

  void _otherScrollListener() {
    final gpb = context.read<SuggestedGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!gpb.isLoading) {
      if (suggestCtrl!.position.pixels ==
          suggestCtrl!.position.maxScrollExtent) {
        context.read<SuggestedGroupBloc>().setLoading(true);
        context.read<SuggestedGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mgb = context.watch<SuggestedGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return mgb.hasData == false
        ? ListView(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.35,
              ),
              EmptyPage(
                  icon: Icons.group_outlined,
                  message: 'no suggested group found'.tr(),
                  message1: ''),
            ],
          )
        : Container(
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.all(16),
            child: ListView.separated(
              separatorBuilder: (context, index) {
                return SizedBox(height: 4);
              },
              itemCount: mgb.data.isNotEmpty ? mgb.data.length + 2 : 5,
              controller: suggestCtrl,
              itemBuilder: (ctx, index) {
                print('suggest group count is ${mgb.data.length}');
                if (index < mgb.data.length + 1) {
                  if (index == 0) {
                    return Text(
                      'suggested_for_you'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    );
                  }
                  if (mgb.data[index - 1].members!.contains(sb.uid)) {
                    return Container();
                  }
                  return SuggestedGroupCard(
                    d: mgb.data[index - 1],
                    heroTag: 'suggested${index - 1}',
                    onItemTapped: () async {
                      if (mgb.data[index - 1].ownerUid == sb.uid) {
                        nextScreen(context,
                            ManagedGroupPage(group: mgb.data[index - 1]));
                      } else {
                        if (mgb.data[index - 1].members!.contains(sb.uid)) {
                          nextScreen(context, JoinedGroupPage());
                        } else {
                          var ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotJoinedGroupPage(
                                      group: mgb.data[index - 1])));
                          if (ret != null) {
                            setState(() {
                              mgb.data[index - 1] = ret;
                            });
                          }
                        }
                      }
                    },
                    onJoinPressed: () async {
                      joinFunction(sb, mgb, index - 1);
                    },
                  );
                }
                return Opacity(
                  opacity: mgb.isLoading ? 1.0 : 0.0,
                  child: mgb.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  joinFunction(SignInBloc sb, SuggestedGroupBloc mgb, int index) {
    if (mgb.data[index].members!.contains(sb.uid)) {
    } else {
      if (mgb.data[index].joinRequests!.contains(sb.uid)) {
        unrequestGroup(mgb.data[index], sb, mgb, index);
      } else {
        requestGroup(mgb.data[index], sb, mgb, index);
      }
    }
  }

  unrequestGroup(
      Group? group, SignInBloc sb, SuggestedGroupBloc mgb, int index) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'join_requests', sb.uid!, false)
            .then((value) async {
          if (gp.hasError == false) {
            openToast('You unrequested group');

            gp.getGroup(group.id!).then((value) {
              if (gp.hasError == false) {
                setState(() {
                  mgb.data[index] = gp.group!;
                });
              } else {}
            });

            final user = context.read<UserBlock>();
            user.getUser(group.ownerUid, true).then(
              (value) {
                _fcmRequestGroup(
                  user.data!.uid!,
                  group,
                  user.data!.fcmToken!,
                  FcmType.unrequestgroup,
                  false,
                );
              },
            );
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  requestGroup(
      Group? group, SignInBloc sb, SuggestedGroupBloc mgb, int index) async {
    var gp = Provider.of<GroupBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        gp
            .updateGroupList(group!.id!, 'join_requests', sb.uid!, true)
            .then((value) async {
          if (gp.hasError == false) {
            openToast('You requested to join group successfully');

            gp.getGroup(group.id!).then((value) {
              if (gp.hasError == false) {
                setState(() {
                  mgb.data[index] = gp.group!;
                });
              } else {}
            });

            final user = context.read<UserBlock>();
            user.getUser(group.ownerUid, true).then(
              (value) {
                _fcmRequestGroup(
                  user.data!.uid!,
                  group,
                  user.data!.fcmToken!,
                  FcmType.requestgroup,
                  true,
                );
              },
            );
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }

  _fcmRequestGroup(
      String uid, Group g, String fcmToken, int fcmType, bool request) async {
    print("===== fcm token $fcmToken =====");
    String title =
        request ? "Request to join group" : "Unrequest to join group";
    String body = request
        ? "You received request to join your ${g.name} group."
        : "You received unrequest to join your ${g.name} group.";

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(uid, body, fcmType, g.id, g.coverPhoto, request);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar, request) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Successfully requested to join group');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
