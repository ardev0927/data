import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_bloc.dart';
import 'package:twiddle/blocs/group_posts_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/your_group_bloc.dart';
import 'package:twiddle/bottom_sheet/post_sheet.dart';
import 'package:twiddle/cards/group_card.dart';
import 'package:twiddle/cards/group_post_card.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/pages/group/joined_group_page.dart';
import 'package:twiddle/pages/group/managed_group_page.dart';
import 'package:twiddle/pages/group/not_joined_group_page.dart';
import 'package:twiddle/utils/empty_mini.dart';

import '../../../blocs/all_group_post_bloc.dart';
import '../../../blocs/posts_bloc.dart';
import '../../../blocs/user_bloc.dart';
import '../../../config/config.dart';
import '../../../models/post.dart';
import '../../../services/app_service.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../post/view_comments_page.dart';
import '../../post/view_likes_page.dart';
import '../../post/view_shares_page.dart';
import '../../profile/profile_main_page.dart';
import '../../profile/show_photo_page.dart';
import '../../profile/user_profile_page.dart';

class ForYouTab extends StatefulWidget {
  const ForYouTab({super.key});

  @override
  State<ForYouTab> createState() => _ForYouTabState();
}

class _ForYouTabState extends State<ForYouTab> {
  ScrollController? groupController, postController;
  String _orderBy = 'timestamp';
  List<Group> _groups = [];
  List<String> _postIds = [];
  bool _isLoadingGroup = true;
  bool _isLoadingPost = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      getGroups();

      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    if (groupController != null) {
      groupController!.removeListener(_groupScrollListener);
    }
    if (postController != null) {
      postController!.removeListener(_postScrollListener);
    }
    super.dispose();
  }

  void _groupScrollListener() {
    final gb = context.read<YourGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!gb.isLoading) {
      if (groupController!.position.pixels ==
          groupController!.position.maxScrollExtent) {
        context.read<YourGroupBloc>().setLoading(true);
        context.read<YourGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  // void _postScrollListener() {
  //   final gb = context.read<AllGroupPostBloc>();
  //   final sb = context.read<SignInBloc>();

  //   if (!gb.isLoading) {
  //     if (postController!.position.pixels ==
  //         postController!.position.maxScrollExtent) {
  //       context.read<AllGroupPostBloc>().setLoading(true);
  //       context.read<AllGroupPostBloc>().getData(sb.uid, mounted, _orderBy);
  //     }
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    // final gpb = context.watch<AllGroupPostBloc>();
    final gb = context.watch<YourGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        gb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: _isLoadingGroup
          ? Center(child: CupertinoActivityIndicator(color: Config().appColor))
          : Column(
              children: [
                _groupWidget(context, sb, gb),
                _groupPostWidget(context, sb, gb),
                // _groupPostWidget(context, gpb, gb, sb),
              ],
            ),
    );
  }

  _groupWidget(ctx, SignInBloc sb, YourGroupBloc gb) {
    return Container(
      padding: const EdgeInsets.only(left: 16, top: 8, bottom: 8),
      height: 120,
      child: ListView.separated(
        separatorBuilder: (ctx, index) {
          return const SizedBox(width: 16);
        },
        itemCount: _groups.length,
        scrollDirection: Axis.horizontal,
        // controller: groupController,
        itemBuilder: (ctx, index) {
          return GroupCard(
            d: _groups[index],
            index: index,
            onTap: () async {
              if (_groups[index].ownerUid == sb.uid) {
                var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            ManagedGroupPage(group: _groups[index])));
                if (ret != null) {
                  setState(() {
                    _groups[index].name = ret.name;
                    _groups[index].description = ret.description;
                    _groups[index].coverPhoto = ret.coverPhoto;
                  });
                }
                // nextScreen(context, ManagedGroupPage(group: _groups[index]));
              } else {
                if (_groups[index].members!.contains(sb.uid)) {
                  nextScreen(context, ManagedGroupPage(group: _groups[index]));
                } else {
                  var ret = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              NotJoinedGroupPage(group: _groups[index])));
                  if (ret != null) {
                    _groups[index] = ret;
                  }
                }
              }
              // _validateGroup(gb, gb.data[index], sb.uid);
            },
          );
        },
      ),
    );
  }

  _groupPostWidget(ctx, SignInBloc sb, YourGroupBloc ygb) {
    final ub = context.watch<UserBlock>();
    final gpb = context.watch<GroupPostsBloc>();
    final pb = context.read<PostsBloc>();

    return ygb.hasData == false
        ? Expanded(
            child: ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.2,
                ),
                EmptyPage(
                    icon: Icons.group_outlined,
                    message: 'group_not_found'.tr(),
                    message1: 'please_create_group'.tr()),
              ],
            ),
          )
        : Expanded(
            child: ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(height: 16);
              },
              itemCount: gpb.data.isNotEmpty ? gpb.data.length + 1 : 5,
              controller: postController,
              itemBuilder: (ctx, index) {
                if (index < gpb.data.length) {
                  var group = _groups.singleWhere(
                    (element) =>
                        element.posts!.contains(gpb.data[index].postId),
                    orElse: () => Group(),
                  );
                  print(group.name);
                  if (group.coverPhoto == null) {
                    return Container();
                  }
                  return GroupPostCard(
                    g: group,
                    d: gpb.data[index],
                    time: convertToAgo(gpb.data[index].timestamp!),
                    heroTag: 'grouppost${index - 1}',
                    onLikePressed: () {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not like own post');
                        return;
                      }
                      pb.setLike(sb.uid, gpb.data[index]).then((value) {
                        if (pb.isLiked == true) {
                          gpb.data[index].likes!.add(sb.uid!);
                          openToast('Liked Post');
                        } else {
                          gpb.data[index].likes!.remove(sb.uid!);
                          openToast('Unliked Post');
                        }
                        setState(() {});
                      });
                    },
                    onLikesPressed: () {
                      nextScreen(
                          context, ViewLikesPage(uids: gpb.data[index].likes));
                    },
                    isLiked: gpb.data[index].likes!.contains(sb.uid),
                    onSharePressed: () {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not share own post');
                        return;
                      }
                      // gpb.setShare(sb.uid, gpb.data[index]).then((value) {
                      //   if (gpb.isShared == true) {
                      //     gpb.data[index].shares!.add(sb.uid!);
                      //     openToast('Shared Post');
                      //   } else {
                      //     gpb.data[index].shares!.remove(sb.uid!);
                      //     openToast('Unshared Post');
                      //   }
                      //   setState(() {});
                      // });
                    },
                    onSharesPressed: () {
                      nextScreen(context,
                          ViewSharesPage(uids: gpb.data[index].shares));
                    },
                    isShared: gpb.data[index].shares!.contains(sb.uid),
                    onCommentPressed: () async {
                      if (sb.uid == gpb.data[index].uid) {
                        openToast('You can not comment own post');
                        return;
                      }
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: gpb.data[index])));
                      if (ret != null) {
                        gpb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onCommentsPressed: () async {
                      int ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  ViewCommentsPage(p: gpb.data[index])));
                      if (ret != null) {
                        gpb.data[index].comments = ret;
                        setState(() {});
                      }
                    },
                    onMoreTap: () {
                      // More Tap
                      showMoreSheet(
                          ctx,
                          ub.data!,
                          gpb.data[index],
                          sb.uid == gpb.data[index].uid ? true : false,
                          sb.uid!,
                          sb.uid == gpb.data[index].uid ? false : true,
                          onPinTap: () {
                            Navigator.pop(context);
                            _pinUnpinPost(gpb.data[index]);
                          },
                          onFollowTap: () {},
                          onReportTap: () {},
                          onHideTap: () {},
                          onDeleteTap: () {
                            Navigator.pop(context);
                            _deletePost(gpb.data[index]);
                          });
                      // _showMoreSheet(context, gpb.data[index], sb.uid!);
                    },
                    onPhotoTap: () {
                      nextScreen(
                          context,
                          ShowPhotoPage(
                              p: gpb.data[index], changedArray: false));
                    },
                    onAvatarTap: () {
                      if (sb.uid != gpb.data[index].uid) {
                        nextScreen(
                            context, UserProfilePage(uid: gpb.data[index].uid));
                      } else {
                        nextScreen(
                            context, ProfileMainPage(uid: gpb.data[index].uid));
                      }
                    },
                  );
                }
                return Opacity(
                  opacity: gpb.isLoading ? 1.0 : 0.0,
                  child: gpb.lastVisible == null
                      ? LoadingCard(height: 200)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  getGroups() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final YourGroupBloc ygb = context.read<YourGroupBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        setState(() {
          _isLoadingGroup = false;
        });
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ygb.getData(sb.uid, mounted, _orderBy).then((value) {
          if (ygb.hasData == true) {
            _groups.clear();
            _groups.addAll(ygb.data);
            _groups.forEach((element) {
              _postIds.addAll(element.posts!);
            });
            //
            getGroupPosts(sb.uid!);
          } else {}
          setState(() {
            _isLoadingGroup = false;
          });
        });
        //
      }
    });
  }

  getGroupPosts(String uid) async {
    postController = ScrollController()..addListener(_postScrollListener);
    context.read<GroupPostsBloc>().onInit();
    context.read<GroupPostsBloc>().getData(uid, mounted, _orderBy);
  }

  void _postScrollListener() {
    final sb = context.read<SignInBloc>();
    final gb = context.read<GroupPostsBloc>();

    if (!gb.isLoading) {
      if (postController!.position.pixels ==
          postController!.position.maxScrollExtent) {
        context.read<GroupPostsBloc>().setLoading(true);
        context.read<GroupPostsBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }
}
