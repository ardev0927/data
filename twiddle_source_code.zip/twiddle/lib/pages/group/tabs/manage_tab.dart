import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/group/manage/group_manage_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../blocs/my_group_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/group_card.dart';
import '../../../models/group.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../manage/group_review_page.dart';

class ManageTab extends StatefulWidget {
  const ManageTab({super.key});

  @override
  State<ManageTab> createState() => _ManageTabState();
}

class _ManageTabState extends State<ManageTab> {
  Group? _selectedGroup;
  ScrollController? managedCtrl;
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();
      managedCtrl = ScrollController()..addListener(_scrollListener);
      context.read<MyGroupBloc>().onInit();
      context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    managedCtrl!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final gpb = context.read<MyGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!gpb.isLoading) {
      if (managedCtrl!.position.pixels ==
          managedCtrl!.position.maxScrollExtent) {
        context.read<MyGroupBloc>().setLoading(true);
        context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();
    final mgb = context.watch<MyGroupBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        mgb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: Column(
        children: [
          _groupWidget(context, mgb, sb),
          _contentWidget(context, mgb),
        ],
      ),
    );
  }

  _groupWidget(ctx, MyGroupBloc mgb, SignInBloc sb) {
    if (mgb.hasData == true) {
      if (_selectedGroup == null) {
        setState(() {
          _selectedGroup = mgb.data[0];
        });
      }
    }
    return mgb.hasData == false
        ? Expanded(
            child: ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.group_outlined,
                    message: 'group_not_found'.tr(),
                    message1: 'please_create_group'.tr()),
              ],
            ),
          )
        : Container(
            padding: const EdgeInsets.only(left: 16, top: 8, bottom: 8),
            height: 120,
            child: ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(width: 16);
              },
              itemCount: mgb.data.isNotEmpty ? mgb.data.length + 1 : 5,
              scrollDirection: Axis.horizontal,
              controller: managedCtrl,
              itemBuilder: (ctx, index) {
                if (index < mgb.data.length) {
                  return GroupCard(
                    d: mgb.data[index],
                    index: index,
                    onTap: () {
                      setState(() {
                        _selectedGroup = mgb.data[index];
                      });
                    },
                  );
                }
                return Opacity(
                  opacity: mgb.isLoading ? 1.0 : 0.0,
                  child: mgb.lastVisible == null
                      ? LoadingCard2(height: 100, width: 95)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  _contentWidget(BuildContext ctx, MyGroupBloc mgb) {
    return mgb.hasData == false
        ? Container()
        : _selectedGroup == null
            ? Container()
            : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      'groups_you_manage'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          color: Config().text90Color,
                          fontWeight: FontWeight.w700),
                    ),
                    InkWell(
                      onTap: () {
                        nextScreen(
                            context, GroupManagePage(group: _selectedGroup));
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: 24,
                              backgroundColor: Colors.grey[300],
                              backgroundImage: CachedNetworkImageProvider(
                                  _selectedGroup!.coverPhoto!),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _selectedGroup!.name!,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: Config().text90Color),
                                  ),
                                  Text(
                                    '${_selectedGroup!.members!.length} members',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: Config().text90Color),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Divider(),
                    // manageItem(
                    //   iconData: Icons.report_outlined,
                    //   itemName: 'reported',
                    //   count: _selectedGroup!.reports!.length,
                    //   onTap: () {
                    //     nextScreen(context,
                    //         GroupReviewPage(group: _selectedGroup, index: 0));
                    //   },
                    // ),
                    // const Divider(),
                    // manageItem(
                    //   iconData: Icons.post_add_outlined,
                    //   itemName: 'peding_posts',
                    //   count: _selectedGroup!.posts!.length,
                    //   onTap: () {
                    //     nextScreen(context,
                    //         GroupReviewPage(group: _selectedGroup, index: 1));
                    //   },
                    // ),
                    // const Divider(),
                    manageItem(
                      iconData: Icons.groups_outlined,
                      itemName: 'member_requests',
                      count: _selectedGroup!.joinRequests!.length,
                      onTap: () {
                        nextScreen(context,
                            GroupReviewPage(group: _selectedGroup, index: 2));
                      },
                    ),
                    // const Divider(),
                    // manageItem(
                    //   iconData: Icons.notifications_active_outlined,
                    //   itemName: 'moderation_alerts',
                    //   count: _selectedGroup!.alerts!.length,
                    //   onTap: () {
                    //     nextScreen(context,
                    //         GroupReviewPage(group: _selectedGroup, index: 3));
                    //   },
                    // ),
                  ],
                ),
              );
  }

  InkWell manageItem(
      {IconData? iconData, String? itemName, int? count, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(iconData),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Text(
                count.toString(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 16)
          ],
        ),
      ),
    );
  }
}
