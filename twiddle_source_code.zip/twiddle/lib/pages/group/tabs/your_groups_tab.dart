import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/group_pinned_bloc.dart';
import 'package:twiddle/blocs/my_group_bloc.dart';
import 'package:twiddle/blocs/my_joined_group_bloc.dart';
import 'package:twiddle/blocs/other_group_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/group_pinned_card.dart';
import 'package:twiddle/cards/manage_group_card.dart';

import '../../../blocs/user_bloc.dart';
import '../../../config/config.dart';
import '../../../models/group.dart';
import '../../../services/app_service.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../joined_group_page.dart';
import '../managed_group_page.dart';
import '../not_joined_group_page.dart';

class YourGroupsTab extends StatefulWidget {
  const YourGroupsTab({super.key});

  @override
  State<YourGroupsTab> createState() => _YourGroupsTabState();
}

class _YourGroupsTabState extends State<YourGroupsTab> {
  ScrollController? pinnedCtrl, myCtrl, otherCtrl;
  String _orderBy = 'timestamp';

  List<String> invitedGroupIds = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      // isLoading = true;
      // getGroupIds();

      var sb = context.read<SignInBloc>();
      pinnedCtrl = ScrollController()..addListener(_pinnedScrollListener);
      context.read<GroupPinnedBloc>().onInit();
      context.read<GroupPinnedBloc>().getData(mounted, _orderBy);

      myCtrl = ScrollController()..addListener(_myScrollListener);
      context.read<MyGroupBloc>().onInit();
      context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);

      otherCtrl = ScrollController()..addListener(_otherScrollListener);
      context.read<MyJoinedGroupBloc>().onInit();
      context.read<MyJoinedGroupBloc>().getData(sb.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    pinnedCtrl!.removeListener(_pinnedScrollListener);
    myCtrl!.removeListener(_myScrollListener);
    otherCtrl!.removeListener(_otherScrollListener);
    super.dispose();
  }

  void _pinnedScrollListener() {
    final gpb = context.read<GroupPinnedBloc>();

    if (!gpb.isLoading) {
      if (pinnedCtrl!.position.pixels == pinnedCtrl!.position.maxScrollExtent) {
        context.read<GroupPinnedBloc>().setLoading(true);
        context.read<GroupPinnedBloc>().getData(mounted, _orderBy);
      }
    }
  }

  void _myScrollListener() {
    final mgb = context.read<MyGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!mgb.isLoading) {
      if (myCtrl!.position.pixels == myCtrl!.position.maxScrollExtent) {
        context.read<MyGroupBloc>().setLoading(true);
        context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  void _otherScrollListener() {
    final ogb = context.read<MyJoinedGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!ogb.isLoading) {
      if (otherCtrl!.position.pixels == otherCtrl!.position.maxScrollExtent) {
        context.read<MyJoinedGroupBloc>().setLoading(true);
        context.read<MyJoinedGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final gpb = context.watch<GroupPinnedBloc>();
    final mgb = context.watch<MyGroupBloc>();
    final ogb = context.watch<MyJoinedGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
        onRefresh: () async {
          gpb.onRefresh(mounted, _orderBy);
          mgb.onRefresh(sb.uid, mounted, _orderBy);
          ogb.onRefresh(sb.uid, mounted, _orderBy);
        },
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                _pinnedWidget(),
                _manageGroupWidget(),
                _otherGroupWidget(),
              ],
            ),
          ),
        ));
  }

  _pinnedWidget() {
    final gpb = context.watch<GroupPinnedBloc>();
    final sb = context.watch<SignInBloc>();

    return gpb.hasData == false
        ? Container()
        : Container(
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: gpb.data.isNotEmpty ? gpb.data.length + 2 : 5,
              controller: pinnedCtrl,
              itemBuilder: (ctx, index) {
                print('pinned group count is ${gpb.data.length}');
                if (index < gpb.data.length + 1) {
                  if (index == 0) {
                    return Text(
                      'pinned'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    );
                  }
                  if (gpb.data[index - 1].ownerUid != sb.uid) {
                    return Container();
                  }
                  return GroupPinnedCard(
                    d: gpb.data[index - 1],
                    heroTag: 'grouppinned${index - 1}',
                    onTap: () async {
                      if (gpb.data[index - 1].ownerUid == sb.uid) {
                        nextScreen(context,
                            ManagedGroupPage(group: gpb.data[index - 1]));
                      } else {
                        if (gpb.data[index - 1].members!.contains(sb.uid)) {
                          nextScreen(context,
                              ManagedGroupPage(group: gpb.data[index - 1]));
                        } else {
                          var ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotJoinedGroupPage(
                                      group: gpb.data[index - 1])));
                          if (ret != null) {
                            gpb.data[index - 1] = ret;
                          }
                        }
                      }
                      // _validateGroup(gpb, gpb.data[index - 1], sb.uid);
                    },
                  );
                }
                return Opacity(
                  opacity: gpb.isLoading ? 1.0 : 0.0,
                  child: gpb.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  _manageGroupWidget() {
    final mgb = context.watch<MyGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return mgb.hasData == false
        ? Container()
        : Container(
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: mgb.data.isNotEmpty ? mgb.data.length + 2 : 5,
              controller: myCtrl,
              itemBuilder: (ctx, index) {
                print('manage group count is ${mgb.data.length}');
                if (index < mgb.data.length + 1) {
                  if (index == 0) {
                    return Text(
                      'groups_you_manage'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    );
                  }
                  if (mgb.data[index - 1].ownerUid != sb.uid) {
                    return Container();
                  }
                  return ManageGroupCard(
                    d: mgb.data[index - 1],
                    heroTag: 'manage${index - 1}',
                    onTap: () async {
                      if (mgb.data[index - 1].ownerUid == sb.uid) {
                        nextScreen(context,
                            ManagedGroupPage(group: mgb.data[index - 1]));
                      } else {
                        if (mgb.data[index - 1].members!.contains(sb.uid)) {
                          nextScreen(context,
                              ManagedGroupPage(group: mgb.data[index - 1]));
                        } else {
                          var ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotJoinedGroupPage(
                                      group: mgb.data[index - 1])));
                          if (ret != null) {}
                        }
                      }
                      // _validateGroup(mgb, mgb.data[index - 1], sb.uid);
                    },
                  );
                }
                return Opacity(
                  opacity: mgb.isLoading ? 1.0 : 0.0,
                  child: mgb.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  _otherGroupWidget() {
    final ogb = context.watch<MyJoinedGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return ogb.hasData == false
        ? Container()
        : Container(
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: ogb.data.isNotEmpty ? ogb.data.length + 2 : 5,
              controller: otherCtrl,
              itemBuilder: (ctx, index) {
                print('other group count is ${ogb.data.length}');
                if (index < ogb.data.length + 1) {
                  if (index == 0) {
                    return Text(
                      'joined'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text100Color),
                    );
                  }
                  return ManageGroupCard(
                    d: ogb.data[index - 1],
                    heroTag: 'ohter${index - 1}',
                    onTap: () async {
                      if (ogb.data[index - 1].ownerUid == sb.uid) {
                        nextScreen(context,
                            ManagedGroupPage(group: ogb.data[index - 1]));
                      } else {
                        if (ogb.data[index - 1].members!.contains(sb.uid)) {
                          nextScreen(context,
                              ManagedGroupPage(group: ogb.data[index - 1]));
                        } else {
                          var ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotJoinedGroupPage(
                                      group: ogb.data[index - 1])));
                          if (ret != null) {
                            ogb.data[index - 1] = ret;
                          }
                        }
                      }
                      // _validateGroup(ogb, ogb.data[index - 1], sb.uid);
                    },
                  );
                }
                return Opacity(
                  opacity: ogb.isLoading ? 1.0 : 0.0,
                  child: ogb.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  getGroupIds() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final UserBlock ub = context.read<UserBlock>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        invitedGroupIds = await ub.getInviteGroups(sb.uid!);

        //
      }
      setState(() {
        isLoading = false;
      });
    });
  }
}
