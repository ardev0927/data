import 'package:flutter/cupertino.dart';
import 'package:flutter/src/widgets/framework.dart';

class ViewOtherGroupPage extends StatefulWidget {
  const ViewOtherGroupPage({super.key});

  @override
  State<ViewOtherGroupPage> createState() => _ViewOtherGroupPageState();
}

class _ViewOtherGroupPageState extends State<ViewOtherGroupPage> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
