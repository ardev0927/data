import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/interest_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/interest_card2.dart';
import 'package:twiddle/models/interest.dart';
import 'package:twiddle/utils/toast.dart';

import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../../utils/snacbar.dart';

class InterestViewPage extends StatefulWidget {
  const InterestViewPage({super.key, required this.interest});
  final Interest interest;

  @override
  State<InterestViewPage> createState() => _InterestViewPageState();
}

class _InterestViewPageState extends State<InterestViewPage> {
  List<String> uids = [];
  bool isJoined = false;

  @override
  void initState() {
    super.initState();

    final sb = context.read<SignInBloc>();
    uids.addAll(widget.interest.uids!);
    if (uids.contains(sb.uid)) {
      isJoined = true;
      uids.remove(sb.uid);
    }
    context.read<UserBlock>().getUsers(uids, mounted);
  }

  Future<bool> _onWillPop() async {
    Navigator.pop(context, isJoined);
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context, isJoined);
            },
            icon: Icon(Icons.arrow_back),
          ),
          title: Text(
            'interests'.tr(),
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
        ),
        body: _body(),
      ),
    );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    final ub = context.watch<UserBlock>();

    var height = MediaQuery.of(context).size.height;
    var appbarHeight =
        MediaQuery.of(context).padding.top + AppBar().preferredSize.height;

    return Container(
      width: MediaQuery.of(context).size.width,
      height: height - appbarHeight,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Config().text8Color,
              image: DecorationImage(
                  image: CachedNetworkImageProvider(widget.interest.image!)),
            ),
          ),
          Text(
            'Interested in  ${widget.interest.name!}',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '${widget.interest.uids!.length}',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              Text(
                ' other users'.tr(),
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
            ],
          ),
          InterestCard2(
              avatar: sb.imageUrl!,
              name: sb.name!,
              heroTag: 'owninterest',
              onTap: () {
                _join(widget.interest.name!.toLowerCase(), sb.uid);
              },
              isJoined: isJoined),
          Expanded(
            child: ub.hasData == false
                ? Container()
                : ListView.separated(
                    // key: PageStorageKey(widget.category),
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: ub.users.length != 0 ? ub.users.length + 1 : 5,
                    separatorBuilder: (BuildContext context, int index) =>
                        SizedBox(
                      height: 3,
                    ),
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < ub.users.length) {
                        return InterestCard2(
                            avatar: ub.users[index].avatar!,
                            name: ub.users[index].name!,
                            heroTag: 'inte${ub.users[index]}',
                            onTap: () {},
                            isJoined: true);
                      }
                      return Opacity(
                        opacity: ub.isLoading ? 1.0 : 0.0,
                        child: ub.lastVisible == null
                            ? LoadingCard(height: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  _join(docId, uid) async {
    final ib = context.read<InterestBloc>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await ib.joinOrLeft(docId, uid).then((_) {
          if (ib.hasError == true) {
            openSnacbar(context, 'something is wrong. please try again.'.tr());
            // _googleController.reset();

          } else {
            setState(() {
              isJoined = ib.isJoined!;
            });
            if (ib.isJoined == true) {
              openToast('You interested in ${widget.interest.name}'.tr());
            } else {
              openToast('You not interested in ${widget.interest.name}'.tr());
            }
            _addRemoveInterestToUser(uid);
          }
        });
      }
    });
  }

  _addRemoveInterestToUser(uid) async {
    final ib = context.read<UserBlock>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await ib.addOrRemoveInterest(widget.interest.name, uid).then((_) {
          if (ib.hasError == true) {
            openSnacbar(context, 'something is wrong. please try again.'.tr());
            // _googleController.reset();

          } else {}
        });
      }
    });
  }
}
