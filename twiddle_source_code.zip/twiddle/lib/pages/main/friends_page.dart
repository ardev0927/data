import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/friends_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/models/user.dart';

import '../../blocs/tab_index_bloc.dart';
import '../../config/config.dart';
import '../../tabs/friends_tab.dart';
import '../../tabs/interests_tab.dart';
import '../../tabs/request_tab.dart';
import '../../tabs/suggestion_tab.dart';
import '../../widgets/tab_medium.dart';

class FriendsPage extends StatefulWidget {
  const FriendsPage({super.key, required this.user});

  final WUser? user;

  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage>
    with TickerProviderStateMixin {
  var scaffoldKey = GlobalKey<ScaffoldState>();
  TabController? _tabController;

  final List<Tab> _tabs = [
    Tab(
      text: 'friends'.tr(),
    ),
    Tab(
      text: 'suggestion'.tr(),
    ),
    // Tab(
    //   text: 'interests'.tr(),
    // ),
    Tab(
      text: 'request'.tr(),
    ),
  ];

  @override
  void initState() {
    super.initState();
    final sb = context.read<SignInBloc>();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController!.addListener(() {
      context.read<TabIndexBloc>().setTabIndex(_tabController!.index);
    });
    Future.delayed(Duration(milliseconds: 0)).then((value) async {});
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Config().whiteColor,
      child: DefaultTabController(
        length: _tabs.length,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 16),
              child: Text(
                'friends'.tr(),
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
            ),
            SizedBox(
              height: 50,
              child: TabBar(
                controller: _tabController,
                labelStyle:
                    TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                labelColor: Config().text90Color,
                unselectedLabelStyle:
                    TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                unselectedLabelColor: Config().text90Color,
                indicatorColor: Config().primary30Color,
                indicatorWeight: 4,
                labelPadding: const EdgeInsets.all(4),
                tabs: _tabs,
              ),
            ),
            Flexible(
              // child: TabMedium(
              //   sc: innerScrollController,
              //   tc: _tabController,
              //   // uids: sb.friends,
              // ),
              child: TabBarView(
                children: [
                  FriendsTab(),
                  SuggestionTab(),
                  // InterestsTab(),
                  RequestTab(),
                ],
                controller: _tabController,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
