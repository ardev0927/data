import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/notification_bloc.dart';
import 'package:twiddle/blocs/post_friends_bloc.dart';
// import 'package:twiddle/blocs/posts_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/stories_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/bottom_sheet/post_sheet.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/card2.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/cards/story_card.dart';
import 'package:twiddle/cards/video_card.dart';
import 'package:twiddle/pages/post/create_post_page.dart';
import 'package:twiddle/pages/post/one_post_view.dart';
import 'package:twiddle/pages/post/show_cw_post_page.dart';
import 'package:twiddle/pages/post/view_comments_page.dart';
import 'package:twiddle/pages/post/view_likes_page.dart';
import 'package:twiddle/pages/post/view_shares_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:twiddle/pages/stories/add_story_page.dart';
import 'package:twiddle/pages/stories/stories_view_page.dart';
import 'package:twiddle/pages/tag_friends/tag_friends_page.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_compress/video_compress.dart';
// import 'package:webview_flutter/webview_flutter.dart';

import '../../blocs/album_bloc.dart';
import '../../blocs/group_bloc.dart';
import '../../blocs/group_manage_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../cards/post_card.dart';
import '../../config/config.dart';
import '../../models/group.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/empty.dart';
import '../../utils/format_time.dart';
import '../../utils/loading_cards.dart';
import '../../utils/snacbar.dart';
import '../group/managed_group_page.dart';
import '../group/not_joined_group_page.dart';
import '../profile/profile_main_page.dart';

class HomePage extends StatefulWidget {
  static final globalKey = GlobalKey<_HomePageState>();
  HomePage({this.created}) : super(key: globalKey);
  Post? created;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  ScrollController? controller, storyController;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  String _orderBy = 'timestamp';
  Uint8List? videoThumbBytes;
  bool _isLoading = false;

  List<Group> _groups = [];

  Group? group;
  Post? retPost;

  @override
  void initState() {
    super.initState();
    // if (Platform.isAndroid) WebView.platform = AndroidWebView();
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      controller = ScrollController()..addListener(_scrollListener);
      context.read<PostFriendsBloc>().onInit();
      context.read<PostFriendsBloc>().getData(sb.uid, mounted, _orderBy);
      context.read<UserBlock>().onInit();
      context.read<UserBlock>().getUser(sb.uid, mounted);

      storyController = ScrollController()..addListener(_storyScrollListener);
      context.read<StoriesBloc>().onInit();
      context.read<StoriesBloc>().getData(sb.uid!, mounted, _orderBy);

      loadingManagedGroups();
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    storyController!.removeListener(_storyScrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<PostFriendsBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        print('===== post scroll listener =====');
        context.read<PostFriendsBloc>().setLoading(true);
        context.read<PostFriendsBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  void _storyScrollListener() {
    final db = context.read<StoriesBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (storyController!.position.pixels ==
          storyController!.position.maxScrollExtent) {
        context.read<StoriesBloc>().setLoading(true);
        context.read<StoriesBloc>().getData(sb.uid!, mounted, _orderBy);
      }
    }
  }

  refreshPage() {
    final pb = context.read<PostFriendsBloc>();
    final sb = context.read<SignInBloc>();
    final ssb = context.read<StoriesBloc>();

    pb.onRefresh(sb.uid, mounted, _orderBy);
    ssb.onRefresh(sb.uid, mounted, _orderBy);

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    List<Post> posts = [];

    var height = MediaQuery.of(context).size.height;

    var pb = context.watch<PostFriendsBloc>();
    final sb = context.watch<SignInBloc>();
    final ub = context.watch<UserBlock>();
    final ssb = context.watch<StoriesBloc>();

    var tmp = pb.data.where((p) => p.hide!.contains(sb.uid) == false).toList();
    posts.addAll(tmp);

    return RefreshIndicator(
      onRefresh: () async {
        pb.onRefresh(sb.uid, mounted, _orderBy);
        ssb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: Stack(
        children: [
          pb.hasData == false
              ? SizedBox(
                  height: height,
                  child: ListView(
                    children: [
                      _storyWidget(context, ssb, sb),
                      SizedBox(
                        height: height * 0.2,
                      ),
                      EmptyPage(
                          icon: Icons.post_add_outlined,
                          message: 'no_post_found'.tr(),
                          message1: ''),
                    ],
                  ),
                )
              : ListView.separated(
                  // padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                  controller: controller,
                  // physics: NeverScrollableScrollPhysics(),
                  // physics: ScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: posts.isNotEmpty ? posts.length + 2 : 5,
                  separatorBuilder: (BuildContext context, int index) =>
                      Container(
                    height: 8,
                    color: Config().text4Color,
                  ),

                  //shrinkWrap: true,
                  itemBuilder: (_, int index) {
                    if (index < posts.length + 1) {
                      if (index == 0) {
                        return _storyWidget(context, ssb, sb);
                      }
                      // if (posts[index - 1].hide!.contains(sb.uid)) {
                      //   print('===== Post hide =====');
                      //   return SizedBox(width: 0, height: 0);
                      // }
                      if (posts[index - 1].mediaType == 2) {
                        // VIDEO
                        // return VideoCard(
                        return PostVideoCard(
                          d: posts[index - 1],
                          time: convertToAgo(posts[index - 1].timestamp!),
                          heroTag: 'post${index}',
                          onLikePressed: () {
                            if (sb.uid == posts[index - 1].uid) {
                              openToast('You can not like own post');
                              return;
                            }
                            pb.setLike(sb.uid, posts[index - 1]).then((value) {
                              if (pb.isLiked == true) {
                                // Update post for like
                                posts[index - 1].likes!.add(sb.uid!);
                                openToast('Liked Post');

                                // Notification
                                _sendFcmPost(
                                    ub,
                                    sb.uid!,
                                    sb.name!,
                                    sb.imageUrl!,
                                    posts[index - 1],
                                    ub.data!.fcmToken!,
                                    FcmType.react);
                              } else {
                                posts[index - 1].likes!.remove(sb.uid!);
                                openToast('Unliked Post');
                              }
                              setState(() {});
                            });
                          },
                          onLikesPressed: () {
                            nextScreen(context,
                                ViewLikesPage(uids: posts[index - 1].likes));
                          },
                          isLiked: posts[index - 1].likes!.contains(sb.uid),
                          onSharePressed: () {
                            // if (sb.uid == posts[index - 1].uid) {
                            //   openToast('You can not share own post');
                            //   return;
                            // }
                            showShareSheet(context, posts[index - 1]);
                          },
                          onSharesPressed: () {
                            nextScreen(context,
                                ViewSharesPage(uids: posts[index - 1].shares));
                          },
                          isShared: posts[index - 1].shares!.contains(sb.uid),
                          onCommentPressed: () async {
                            // if (sb.uid == posts[index - 1].uid) {
                            //   openToast('You can not comment own post');
                            //   return;
                            // }
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: posts[index - 1])));
                            if (ret != null) {
                              posts[index - 1].comments = ret;
                              setState(() {});
                            }
                          },
                          onCommentsPressed: () async {
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: posts[index - 1])));
                            if (ret != null) {
                              posts[index - 1].comments = ret;
                              setState(() {});
                            }
                          },
                          onMoreTap: () {
                            // More Tap
                            showMoreSheet(
                              context,
                              ub.data!,
                              posts[index - 1],
                              sb.uid == posts[index - 1].uid ? true : false,
                              sb.uid!,
                              sb.uid == posts[index - 1].uid ? false : true,
                              onPinTap: () {
                                Navigator.pop(context);
                                _pinUnpinPost(posts[index - 1]);
                              },
                              onFollowTap: () {},
                              onReportTap: () {},
                              onHideTap: () {
                                Navigator.pop(context);
                                _hidePost(posts[index - 1], sb.uid);
                              },
                              onDeleteTap: () async {
                                Navigator.pop(context);
                                _deletePost(pb, posts[index - 1]);
                              },
                              onReportPost: () {
                                Navigator.pop(context);
                                _reportPost(posts[index - 1]);
                              },
                              onCopyLink: () {
                                Navigator.pop(context);
                                _copyLink(posts[index - 1]);
                              },
                            );
                            // _showMoreSheet(context, posts[index-1], sb.uid!);
                          },
                          onPhotoTap: () {
                            nextScreen(
                                context,
                                ShowPhotoPage(
                                    p: posts[index - 1], changedArray: false));
                          },
                          onAvatarTap: () {
                            if (sb.uid != posts[index - 1].uid) {
                              nextScreen(context,
                                  UserProfilePage(uid: posts[index - 1].uid));
                            } else {
                              nextScreen(context,
                                  ProfileMainPage(uid: posts[index - 1].uid));
                            }
                          },
                          onTypeTap: () async {
                            var d = posts[index - 1];
                            if (d.feeling!.contains('with ') &&
                                d.tagFriends!.isNotEmpty) {
                              nextScreen(
                                context,
                                TagFriendsPage(tags: d.tagFriends),
                              );
                            } else {
                              var g = d.group;
                              if (g!.name != null) {
                                if (g.ownerUid == sb.uid) {
                                  nextScreen(
                                      context, ManagedGroupPage(group: g));
                                } else {
                                  var gb = context.read<GroupBloc>();
                                  await gb.getGroup(g.id!).then((value) async {
                                    if (gb.group!.members!.contains(sb.uid)) {
                                      nextScreen(context,
                                          ManagedGroupPage(group: gb.group));
                                    } else {
                                      var ret = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  NotJoinedGroupPage(
                                                      group: g)));
                                      if (ret != null) {
                                        d.group = ret;
                                      }
                                    }
                                  });
                                }
                              }
                            }
                          },
                          // onSharedTap: () {
                          //   nextScreen(
                          //     context,
                          //     OnePostView(
                          //         postId: posts[index - 1].sharedPost!.postId),
                          //   );
                          // },
                        );
                      }
                      // return Card1(
                      return PostCard(
                        d: posts[index - 1],
                        time: convertToAgo(posts[index - 1].timestamp!),
                        heroTag: 'post${index}',
                        onLikePressed: () {
                          if (sb.uid == posts[index - 1].uid) {
                            openToast('You can not like own post');
                            return;
                          }
                          pb.setLike(sb.uid, posts[index - 1]).then((value) {
                            if (pb.isLiked == true) {
                              posts[index - 1].likes!.add(sb.uid!);
                              openToast('Liked Post');

                              // Notification
                              _sendFcmPost(
                                  ub,
                                  sb.uid!,
                                  sb.name!,
                                  sb.imageUrl!,
                                  posts[index - 1],
                                  ub.data!.fcmToken!,
                                  FcmType.react);
                            } else {
                              posts[index - 1].likes!.remove(sb.uid!);
                              openToast('Unliked Post');
                            }
                            setState(() {});
                          });
                        },
                        onLikesPressed: () {
                          nextScreen(context,
                              ViewLikesPage(uids: posts[index - 1].likes));
                        },
                        isLiked: posts[index - 1].likes!.contains(sb.uid),
                        onSharePressed: () {
                          // if (sb.uid == posts[index - 1].uid) {
                          //   openToast('You can not share own post');
                          //   return;
                          // }
                          showShareSheet(context, posts[index - 1]);
                        },
                        onSharesPressed: () {
                          nextScreen(context,
                              ViewSharesPage(uids: posts[index - 1].shares));
                        },
                        isShared: posts[index - 1].shares!.contains(sb.uid),
                        onCommentPressed: () async {
                          // if (sb.uid == posts[index - 1].uid) {
                          //   openToast('You can not comment own post');
                          //   return;
                          // }
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: posts[index - 1])));
                          if (ret != null) {
                            posts[index - 1].comments = ret;
                            setState(() {});
                          }
                        },
                        onCommentsPressed: () async {
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: posts[index - 1])));
                          if (ret != null) {
                            posts[index - 1].comments = ret;
                            setState(() {});
                          }
                        },
                        onMoreTap: () {
                          // More Tap
                          showMoreSheet(
                            context,
                            ub.data!,
                            posts[index - 1],
                            sb.uid == posts[index - 1].uid ? true : false,
                            sb.uid!,
                            sb.uid == posts[index - 1].uid ? false : true,
                            onPinTap: () {
                              Navigator.pop(context);
                              _pinUnpinPost(posts[index - 1]);
                            },
                            onFollowTap: () {},
                            onReportTap: () {},
                            onHideTap: () {
                              Navigator.pop(context);
                              _hidePost(posts[index - 1], sb.uid);
                            },
                            onDeleteTap: () async {
                              Navigator.pop(context);
                              _deletePost(pb, posts[index - 1]);
                            },
                            onReportPost: () {
                              Navigator.pop(context);
                              _reportPost(posts[index - 1]);
                            },
                            onCopyLink: () {
                              Navigator.pop(context);
                              _copyLink(posts[index - 1]);
                            },
                          );
                          // _showMoreSheet(context, posts[index-1], sb.uid!);
                        },
                        onPhotoTap: () {
                          nextScreen(
                              context,
                              ShowPhotoPage(
                                  p: posts[index - 1], changedArray: false));
                        },
                        onAvatarTap: () {
                          if (sb.uid != posts[index - 1].uid) {
                            nextScreen(context,
                                UserProfilePage(uid: posts[index - 1].uid));
                          } else {
                            nextScreen(context,
                                ProfileMainPage(uid: posts[index - 1].uid));
                          }
                        },
                        onArticleTap: () {
                          if (posts[index - 1].mediaType == 11) {
                            launchUrl(Uri.parse(posts[index - 1].article!));
                          }
                        },
                        onTypeTap: () async {
                          var d = posts[index - 1];
                          if (d.feeling!.contains('with ') &&
                              d.tagFriends!.isNotEmpty) {
                            nextScreen(
                              context,
                              TagFriendsPage(tags: posts[index - 1].tagFriends),
                            );
                          } else {
                            print('===== Type tap =====');
                            var g = d.group;
                            if (g!.name != null) {
                              if (g.ownerUid == sb.uid) {
                                nextScreen(context, ManagedGroupPage(group: g));
                              } else {
                                var gb = context.read<GroupBloc>();
                                await gb.getGroup(g.id!).then((value) async {
                                  if (gb.group!.members!.contains(sb.uid)) {
                                    nextScreen(context,
                                        ManagedGroupPage(group: gb.group));
                                  } else {
                                    var ret = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                NotJoinedGroupPage(group: g)));
                                    if (ret != null) {
                                      d.group = ret;
                                    }
                                  }
                                });
                              }
                            }
                          }
                        },
                        onSharedTap: () {
                          nextScreen(
                            context,
                            OnePostView(
                                postId: posts[index - 1].sharedPost!.postId),
                          );
                        },
                        onCWShowPressed: () {
                          nextScreen(
                              context,
                              ShowContentWarningPostPage(
                                  post: posts[index - 1]));
                        },
                      );
                    }
                    return Opacity(
                      opacity: pb.isLoading ? 1.0 : 0.0,
                      child: pb.lastVisible == null
                          ? LoadingCard(height: 250)
                          : Center(
                              child: SizedBox(
                                  width: 32.0,
                                  height: 32.0,
                                  child: new CupertinoActivityIndicator()),
                            ),
                    );
                  },
                ),
          _isLoading
              ? Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  _storyWidget(ctx, StoriesBloc gb, SignInBloc sb) {
    return gb.hasData == false
        ? Container(
            padding: const EdgeInsets.only(left: 16, top: 8, bottom: 16),
            width: MediaQuery.of(context).size.width,
            height: 160,
            color: Config().whiteColor,
            child: Card2(
              p: sb.imageUrl!,
              onItemTap: () {
                showAddStorySheet(context);
              },
              mode: 1,
            ),
          )
        : Container(
            padding: const EdgeInsets.only(left: 16, top: 8, bottom: 16),
            height: 160,
            width: MediaQuery.of(context).size.width,
            color: Config().whiteColor,
            child: ListView.separated(
              separatorBuilder: (ctx, index) {
                return const SizedBox(width: 16);
              },
              itemCount: gb.data.isNotEmpty ? gb.data.length + 2 : 5,
              scrollDirection: Axis.horizontal,
              controller: storyController,
              itemBuilder: (ctx, index) {
                if (index < gb.data.length + 1) {
                  if (index == 0) {
                    return Card2(
                        p: sb.imageUrl!,
                        onItemTap: () {
                          showAddStorySheet(context);
                        },
                        mode: 1);
                  }
                  var userstory = gb.data[index - 1];
                  if (twoDaysAgo(userstory.timestamp!)) {
                    // Delete stories on firestore
                    _deleteStories(gb, userstory.uid);
                    return Container();
                  }
                  return StoryCard(
                    us: gb.data[index - 1],
                    onItemTap: () {
                      nextScreen(
                          context,
                          StoriesViewpage(
                            uid: gb.data[index - 1].uid,
                            username: gb.data[index - 1].username,
                            useravatar: gb.data[index - 1].useravatar,
                            timestamp: gb.data[index - 1].timestamp,
                          ));
                    },
                    mode: 1,
                  );
                }
                return Opacity(
                  opacity: gb.isLoading ? 1.0 : 0.0,
                  child: gb.lastVisible == null
                      ? LoadingCard2(height: 130, width: 100)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  showShareSheet(BuildContext ctx, Post? p) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Share to feed
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (p!.mediaType != PostType.share) {
                  var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CreatePostPage(type: PostType.share, p: p),
                    ),
                  );
                  if (ret != null) {
                    refreshPage();
                  }
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.feed_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_feed'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Share to group
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                selectGroupDialog(p!);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.groups_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_group'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  showAddStorySheet(BuildContext ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                  },
                  icon: Icon(Icons.clear),
                ),
              ],
            ),
            // Image
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 1);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.image_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // video
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 2);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.live_tv_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'video'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // text
            InkWell(
              onTap: () async {
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    const Icon(Icons.text_snippet_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'text'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  pickMediaDialog(BuildContext ctx, int type) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(type == 1
                            ? Icons.add_photo_alternate_outlined
                            : Icons.video_camera_front_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<File?> pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      return File(image.path);
    } else {
      print('No image selected!');
      return null;
    }
  }

  Future<File?> pickVideo(bool camera) async {
    XFile? video;
    if (camera) {
      video = await ImagePicker().pickVideo(source: ImageSource.camera);
    } else {
      video = await ImagePicker().pickVideo(source: ImageSource.gallery);
    }

    var size = await video!.readAsBytes();
    if (size.lengthInBytes > 50 * 1024 * 1024) {
      openToast('The video size should be less than 50MB');
      return null;
    }

    if (video != null) {
      // Generate thumbnail
      var thumbBytes = await VideoCompress.getByteThumbnail(video.path,
          quality: 50, position: -1);

      videoThumbBytes = thumbBytes;

      // Compress video
      setState(() {
        _isLoading = true;
      });
      MediaInfo? mi;
      try {
        await VideoCompress.setLogLevel(0);

        mi = await VideoCompress.compressVideo(video.path,
            quality: VideoQuality.LowQuality,
            includeAudio: true,
            deleteOrigin: true);

        setState(() {
          _isLoading = false;
        });
        return File(mi!.path!);
      } catch (e) {
        VideoCompress.cancelCompression();
        setState(() {
          _isLoading = false;
        });
        return null;
      }
      // return File(video.path);
    } else {
      print('No image selected!');
      return null;
    }
  }

  Future _deletePost(PostFriendsBloc pfb, Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        var isDeleted = await pfb.deletePost(pb, p);
        if (isDeleted) {
          setState(() {});
          openToast('Post is deleted');
        } else {
          openSnacbar(context, 'Something went wrong');
        }
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== hide post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    final pfb = context.read<PostFriendsBloc>();
    final sb = context.read<SignInBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            // pb.onRefresh(sb.uid, mounted, _orderBy);
            pfb.onRefresh(sb.uid, mounted, _orderBy);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          // setState(() {});
        });
      }
    });
  }

  _reportPost(Post p) async {
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        var isReported = await pb.isReportedPost(p);
        if (isReported == false) {
          pb.reportPost(p).then((value) {
            if (pb.hasError == false) {
              openToast(
                  'Post is reported successfully, Admin will check post soon');
            } else {
              openSnacbar(context, 'Something went wrong');
            }
            setState(() {});
          });
        } else {
          openToast('This post already reported');
        }
      }
    });
  }

  _copyLink(Post p) async {
    var postUrl = '${Config().ourWebsiteUrl}/posts/${p.postId}';
    Clipboard.setData(ClipboardData(text: postUrl)).then((value) {
      openToast('Copied $postUrl');
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== pinned/unpinnned post id: ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _sendFcmPost(UserBlock ub, String uid, String name, String avatar, Post p,
      String fcmToken, int fcmType) async {
    final user = await ub.getWUser(p.uid);
    print("===== fcm token ${user!.fcmToken} =====");
    String body = '';
    String title = '';
    if (fcmType == FcmType.react) {
      title = "Reaction post";
      body = "$name reacted to ${p.username} Post.";
    } else if (fcmType == FcmType.tag) {
      title = "Post tag";
      body = "You received tag post from ${p.username}.";
    }

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [user.fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(user.uid, body, fcmType, p.postId, avatar);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _deleteStories(StoriesBloc sb, uid) async {
    final ssb = context.watch<StoriesBloc>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        sb.deleteUserStory(uid).then((value) {
          if (sb.hasError == false) {
            ssb.onRefresh(uid, mounted, _orderBy);
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  // Loading managed groups
  loadingManagedGroups() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final GroupManageBloc gmb =
        Provider.of<GroupManageBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        gmb.getData(sb.uid!, mounted, 'timestamp').then((value) async {
          if (gmb.hasData == true) {
            _groups.clear();
            _groups.addAll(gmb.data);
          } else {
            print('Failed loading groups');
          }
        });
      }
    });
  }

  selectGroupDialog(Post p) {
    showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
          contentPadding: const EdgeInsets.all(16),
          title: Text(
            'select_group'.tr(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          children: [
            SizedBox(
              height: 300,
              width: MediaQuery.of(context).size.width,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: _groups.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: () async {
                      group = _groups[index];
                      // setState(() {
                      //   isGroupPost = true;
                      // });
                      Navigator.pop(context);
                      if (p.mediaType != PostType.share ||
                          p.mediaType != PostType.sharegroup) {
                        var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CreatePostPage(
                              type: PostType.sharegroup,
                              p: p,
                              g: group,
                            ),
                          ),
                        );
                        if (ret != null) {
                          refreshPage();
                          // setState(() {});
                        }
                      }
                    },
                    title: Text(_groups[index].name!),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
