import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/notification_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/notification_card.dart';
import 'package:twiddle/models/notification.dart';
import 'package:twiddle/pages/group/group_main_page.dart';
import 'package:twiddle/pages/group/joined_group_page.dart';
import 'package:twiddle/pages/group/managed_group_page.dart';
import 'package:twiddle/pages/post/live/live_main_page.dart';
import 'package:twiddle/pages/post/one_post_view.dart';
import 'package:twiddle/utils/enums.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../group/setting/group_invites_page.dart';

class NotificationPage extends StatefulWidget {
  const NotificationPage({super.key});

  @override
  State<NotificationPage> createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  ScrollController? controller;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      controller = ScrollController()..addListener(_scrollListener);
      context.read<NotificationBloc>().onInit();
      context.read<NotificationBloc>().getData(sb.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<NotificationBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<NotificationBloc>().setLoading(true);
        context.read<NotificationBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    var nb = context.watch<NotificationBloc>();
    final sb = context.watch<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        nb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        color: Config().whiteColor,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'notification'.tr(),
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: Config().text100Color),
            ),
            const SizedBox(height: 16),
            nb.hasData == false
                ? Expanded(
                    child: ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.25,
                        ),
                        EmptyPage(
                            icon: Icons.notifications_outlined,
                            message: 'no_notification_found'.tr(),
                            message1: ''),
                      ],
                    ),
                  )
                : Expanded(
                    child: ListView.separated(
                      controller: controller,
                      shrinkWrap: true,
                      itemCount: nb.data.isNotEmpty ? nb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 15,
                      ),

                      //shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < nb.data.length) {
                          return NotificationCard(
                            d: nb.data[index],
                            timeago: convertToAgo(nb.data[index].timestamp!),
                            heroTag: 'notification$index',
                            onTap: () async {
                              gotoPage(nb, nb.data[index], index);
                            },
                          );
                        }
                        return Opacity(
                          opacity: nb.isLoading ? 1.0 : 0.0,
                          child: nb.lastVisible == null
                              ? const LoadingCard(height: 100)
                              : const Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  _deleteNotification(NotificationBloc nb, int index) {
    nb.deleteNotification(nb.data[index]).then((value) {
      if (nb.hasError == false) {
        nb.data.removeAt(index);
      } else {
        print('===== Failed delete notification');
      }
    });
  }

  gotoPage(NotificationBloc nb, NotificationModel nm, int index) {
    if (nm.type == FcmType.react || nm.type == FcmType.tag) {
      nextScreen(context, OnePostView(postId: nm.typedata));
      _deleteNotification(nb, index);
    } else if (nm.type == 3) {
      nextScreen(
        context,
        LiveMainPage(
          channelId: 'test123',
          isBroadcater: true,
          owner: false,
        ),
      );
      _deleteNotification(nb, index);
    } else if (nm.type == FcmType.requestgroup ||
        nm.type == FcmType.unrequestgroup) {
      nextScreen(context, GroupMainPage(index: 3));
      _deleteNotification(nb, index);
    } else if (nm.type == FcmType.invitegroup) {
      nextScreen(context, GroupInvitesPage());
      _deleteNotification(nb, index);
    } else if (nm.type == FcmType.joingroup) {
    } else if (nm.type == FcmType.requestfriend) {
      _deleteNotification(nb, index);
    }
    _deleteNotification(nb, index);
  }
}
