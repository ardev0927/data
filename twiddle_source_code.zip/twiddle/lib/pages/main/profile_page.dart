import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/group/group_main_page.dart';
import 'package:twiddle/pages/profile/pinned_post_page.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/settings/help_support_page.dart';
import 'package:twiddle/pages/settings/setting_privacy_page.dart';
import 'package:twiddle/pages/sign_in_up/account_page.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../blocs/theme_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../utils/next_screen.dart';
import '../sign_in_up/sign_in_up_page.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    final sb = context.watch<SignInBloc>();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      color: Config().whiteColor,
      child: ListView(
        children: [
          Text(
            'profile'.tr(),
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: GestureDetector(
              onTap: () {
                nextScreen(
                    context,
                    ProfileMainPage(
                      uid: sb.uid,
                    ));
              },
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sb.name!,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Config().text100Color),
                        ),
                        Text(
                          'go_profile'.tr(),
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                              color: Config().text90Color),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          ProfileCard(
            icon: 'assets/images/group1.svg',
            title: 'group'.tr(),
            onTap: () {
              nextScreen(context, GroupMainPage(index: 0));
            },
          ),
          ProfileCard(
            icon: 'assets/images/pinned.svg',
            title: 'pinned_post'.tr(),
            onTap: () {
              nextScreen(context, PinnedPostPage());
            },
          ),
          ProfileCard(
            icon: 'assets/images/settings.svg',
            title: 'settings_privacy'.tr(),
            onTap: () async {
              await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => SettingPrivacyPage()));
              setState(() {});
              // nextScreen(context, SettingPrivacyPage());
            },
          ),
          ProfileCard(
            icon: 'assets/images/help.svg',
            title: 'help_support'.tr(),
            onTap: () {
              nextScreen(context, HelpSupportPage());
            },
          ),
          ProfileCard(
            icon: 'assets/images/logout.svg',
            title: 'log_out'.tr(),
            onTap: () {
              openLogoutDialog(context);
            },
          ),
        ],
      ),
    );
  }

  void openLogoutDialog(context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('logout_title').tr(),
            actions: [
              TextButton(
                child: Text('no').tr(),
                onPressed: () => Navigator.pop(context),
              ),
              TextButton(
                child: Text('yes').tr(),
                onPressed: () async {
                  Navigator.pop(context);
                  await context
                      .read<SignInBloc>()
                      .userSignout()
                      .then((value) =>
                          context.read<SignInBloc>().afterUserSignOut())
                      .then((value) {
                    if (context.read<ThemeBloc>().darkTheme == true) {
                      context.read<ThemeBloc>().toggleTheme();
                    }

                    ///
                    setUserState('Offline');

                    ///
                    // nextScreenCloseOthers(context, SignInUpPage());
                    nextScreenCloseOthers(context, AccountPage());
                  });
                },
              )
            ],
          );
        });
  }

  setUserState(String status) {
    var ub = context.read<UserBlock>();
    var sb = context.read<SignInBloc>();

    ub.updateState(sb.uid!, status);
  }
}

class ProfileCard extends StatelessWidget {
  final String icon;
  final String title;
  final Function() onTap;
  const ProfileCard({
    Key? key,
    required this.icon,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: GestureDetector(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Config().text4Color,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Center(
                child: SvgPicture.asset(icon),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                title,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text90Color),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
