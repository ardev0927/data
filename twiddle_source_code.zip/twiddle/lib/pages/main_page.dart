import 'package:badges/badges.dart' as badges;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twiddle/blocs/notification_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/models/post.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/chat_story/chat_main_page.dart';
import 'package:twiddle/pages/post/create_post_page.dart';
import 'package:twiddle/pages/sign_in_up/sign_in_up_page.dart';
import 'package:twiddle/utils/enums.dart';

import '../blocs/sign_in_bloc.dart';
import '../blocs/theme_bloc.dart';
import '../config/config.dart';
import '../services/messaging_service.dart';
import '../utils/next_screen.dart';
import '../widgets/bubble_bottom_bar.dart';
import 'main/friends_page.dart';
import 'main/home_page.dart';
import 'main/notification_page.dart';
import 'main/profile_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> with WidgetsBindingObserver {
  int _currentIndex = 0;
  Post? post;
  // var _isSelected = 1;
  final PageController _pageController = PageController();
  WUser? user;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  // // Agora client
  // AgoraClient agoraClient = AgoraClient(
  //     agoraConnectionData:
  //         AgoraConnectionData(appId: Config().agoraAppId, channelName: 'test'),
  //     enabledPermission: [Permission.camera, Permission.microphone]);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    Future.delayed(const Duration(milliseconds: 0)).then((value) async {
      context
          .read<NotificationBloc>()
          .initFirebasePushNotification(context)
          .then((value) {
        loadUser();
      });
    });

    // Agora
    // agoraClient.initialize();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }

  Future<String> getFcmToken() async {
    var sp = await SharedPreferences.getInstance();
    return sp.getString('fcm_token') ?? '';
  }

  loadUser() {
    var ub = context.read<UserBlock>();
    var sb = context.read<SignInBloc>();
    ub.getOwner(sb.uid).then((value) async {
      if (ub.hasError == false) {
        // Set user online status
        user = ub.data;
        setUserState('Online');
        // set fcm token
        var token = await getFcmToken();
        ub.updateFcmToken(sb.uid!, token);
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      print('===== online =====');
      setUserState('Online');
    } else {
      print('===== offline =====');
      setUserState('Offline');
    }
  }

  setUserState(String status) {
    var ub = context.read<UserBlock>();
    var sb = context.read<SignInBloc>();

    ub.updateState(sb.uid!, status);
  }

  Future _onWillPop() async {
    if (_currentIndex != 0) {
      setState(() => _currentIndex = 0);
      _pageController.animateToPage(0,
          duration: Duration(milliseconds: 200), curve: Curves.easeIn);
    } else {
      await SystemChannels.platform
          .invokeMethod<void>('SystemNavigator.pop', true);
    }
  }

  void changePage(int index) {
    setState(() {
      _currentIndex = index;
    });
    _pageController.animateToPage(index,
        curve: Curves.easeIn, duration: Duration(milliseconds: 250));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: (() async => await _onWillPop()),
      child: Scaffold(
        backgroundColor: Config().text4Color,
        bottomNavigationBar: _buildBottomMenu(),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Config().primary30Color,
          onPressed: () async {
            //
            var result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        CreatePostPage(type: PostType.empty)));
            if (result != null) {
              HomePage.globalKey.currentState!.refreshPage();
            }
          },
          child: const Icon(
            Icons.add,
            color: Colors.white,
            size: 30,
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        appBar: PreferredSize(
          child: _appbar(),
          preferredSize: Size.fromHeight(60),
        ),
        body: PageView(
          controller: _pageController,
          allowImplicitScrolling: false,
          physics: NeverScrollableScrollPhysics(),
          children: [
            HomePage(created: post),
            FriendsPage(user: user),
            NotificationPage(),
            ProfilePage(),
          ],
        ),
      ),
    );
  }

  _appbar() {
    return AppBar(
      automaticallyImplyLeading: false,
      flexibleSpace: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 16),
            child: Image.asset(
              'assets/images/logo_mini.png',
              fit: BoxFit.contain,
              width: 120,
              height: 70,
            ),
          ),
        ],
      ),
      leadingWidth: 100,
      actions: [
        // GestureDetector(
        //   onTap: () {},
        //   child: Padding(
        //     padding: const EdgeInsets.symmetric(horizontal: 8),
        //     child: SvgPicture.asset('assets/images/search.svg',
        //         width: 20, height: 20),
        //   ),
        // ),
        GestureDetector(
          onTap: () {
            nextScreen(context, ChatMainPage());
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SvgPicture.asset('assets/images/chat.svg',
                width: 20, height: 20),
          ),
        ),
      ],
    );
  }

  ///Build bottom menu
  Widget _buildBottomMenu() {
    var sb = context.watch<SignInBloc>();

    return BottomAppBar(
      shape: const AutomaticNotchedShape(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25),
            topRight: Radius.circular(25),
          ),
        ),
      ),
      child: SizedBox(
        height: 56,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(child: tabItem(0, Icons.home_outlined)),
            Expanded(child: tabItem(1, Icons.group_outlined)),
            const SizedBox(width: 56),
            StreamBuilder<DocumentSnapshot>(
              stream: getNotificationCount(sb.uid!),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  int count = snapshot.data!['count'] ?? 0;
                  return count == 0
                      ? Expanded(
                          child: tabItem(2, Icons.notifications_outlined))
                      : Expanded(
                          child: Container(
                            alignment: Alignment.center,
                            child: badges.Badge(
                              badgeStyle: badges.BadgeStyle(
                                  badgeColor: Config().appColor),
                              // badgeColor: Config().appColor,
                              badgeContent: Text(
                                count.toString(),
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.white),
                              ),
                              child: GestureDetector(
                                onTap: () {
                                  changePage(2);
                                },
                                child: Icon(
                                  Icons.notifications_outlined,
                                  size: 30,
                                  color: _currentIndex == 2
                                      ? Config().primary30Color
                                      : Config().text60Color,
                                ),
                              ),
                            ),
                          ),
                        );
                }
                return Container();
              },
            ),
            Expanded(child: tabItem(3, Icons.manage_accounts_outlined)),
          ],
        ),
      ),
    );
  }

  _bottomNavigationBar() {
    var sb = context.watch<SignInBloc>();

    return Stack(
      alignment: Alignment.topCenter,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 20),
          height: 60,
          decoration: BoxDecoration(
            color: Config().whiteColor,
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16), topRight: Radius.circular(16)),
            // boxShadow: [
            //   BoxShadow(color: shadowColorGlobal, blurRadius: 10, spreadRadius: 2, offset: Offset(0, 3.0)),
            // ],
          ),
          child: Padding(
            padding: EdgeInsets.only(left: 16.0, right: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                // tabItem(0, 'assets/images/home.svg'),
                // tabItem(1, 'assets/images/group.svg'),
                Expanded(child: tabItem(0, Icons.home_outlined)),
                Expanded(child: tabItem(1, Icons.group_outlined)),
                Expanded(child: Container()),
                StreamBuilder<DocumentSnapshot>(
                  stream: getNotificationCount(sb.uid!),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      int count = snapshot.data!['count'] ?? 0;
                      return count == 0
                          ? Expanded(
                              child: tabItem(2, Icons.notifications_outlined))
                          : Expanded(
                              child: Container(
                                alignment: Alignment.center,
                                child: badges.Badge(
                                  badgeStyle: badges.BadgeStyle(
                                      badgeColor: Config().appColor),
                                  // badgeColor: Config().appColor,
                                  badgeContent: Text(
                                    count.toString(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white),
                                  ),
                                  child: GestureDetector(
                                    onTap: () {
                                      changePage(2);
                                    },
                                    child: Icon(
                                      Icons.notifications_outlined,
                                      size: 30,
                                      color: _currentIndex == 2
                                          ? Config().primary30Color
                                          : Config().text60Color,
                                    ),
                                  ),
                                ),
                              ),
                            );
                    }
                    return Container();
                  },
                ),
                // tabItem(2, 'assets/images/notifications.svg'),
                // tabItem(3, 'assets/images/manage_accounts.svg'),
                Expanded(child: tabItem(3, Icons.manage_accounts_outlined)),
              ],
            ),
          ),
        ),
        Container(
          child: FloatingActionButton(
            backgroundColor: Config().primary30Color,
            onPressed: () async {
              //
              var result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CreatePostPage(type: PostType.empty)));
              if (result != null) {
                // post = result;
                // setState(() {});
                HomePage.globalKey.currentState!.refreshPage();
              }
              // nextScreen(context, CreatePostPage());
            },
            child: Icon(
              Icons.add,
              color: Colors.white,
              size: 30,
            ),
          ),
        )
      ],
    );
  }

  Widget tabItem(var pos, var icon) {
    return GestureDetector(
      onTap: () {
        changePage(pos);
      },
      child: Icon(
        icon,
        size: 30,
        color: _currentIndex == pos
            ? Config().primary30Color
            : Config().text60Color,
      ),
    );
  }

  Stream<DocumentSnapshot> getNotificationCount(String uid) {
    return firestore
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count')
        .snapshots();
    // .orderBy('timestamp', descending: true)
    // .limit(limit)
    // .snapshots();
  }
}
