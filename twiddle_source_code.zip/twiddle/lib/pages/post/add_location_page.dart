import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_api_headers/google_api_headers.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_maps_webservice/places.dart';
import 'package:twiddle/utils/snacbar.dart';
import 'package:location/location.dart' as loc;

import '../../config/config.dart';

class AddLocationPage extends StatefulWidget {
  const AddLocationPage({super.key});

  @override
  State<AddLocationPage> createState() => _AddLocationPageState();
}

final homeScaffoldKey = GlobalKey<ScaffoldState>();

class _AddLocationPageState extends State<AddLocationPage> {
  final LatLng _initialcameraposition = LatLng(35.13, -79.43);
  GoogleMapController? _controller;
  PlacesDetailsResponse? _placesDetailsResponse;
  final loc.Location _location = loc.Location();

  String search = '';
  String? _currentAddress;
  Position? _currentPosition;

  Map<String, dynamic> data = {};
  Set<Marker> markersList = {};
  bool isFirstLoad = true;

  @override
  void initState() {
    super.initState();

    search = 'search'.tr();
  }

  @override
  void dispose() {
    super.dispose();
    _controller!.dispose();
  }

  _onMapCreated(GoogleMapController _cntlr) async {
    _controller = _cntlr;
    if (isFirstLoad) {
      var ret = await _location.getLocation();
      _controller!.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(
              target: LatLng(ret.latitude!, ret.longitude!), zoom: 15),
        ),
      );
      // _location.onLocationChanged.listen((l) {
      //   print('===== First load =====');
      //   _controller!.animateCamera(
      //     CameraUpdate.newCameraPosition(
      //       CameraPosition(target: LatLng(l.latitude!, l.longitude!), zoom: 15),
      //     ),
      //   );
      // });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(),
    );
  }

  _body() {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;

    return Container(
      width: width,
      height: height,
      child: Stack(
        children: [
          GoogleMap(
            initialCameraPosition:
                CameraPosition(target: _initialcameraposition),
            mapType: MapType.normal,
            onMapCreated: _onMapCreated,
            myLocationEnabled: false,
            markers: markersList,
            minMaxZoomPreference: MinMaxZoomPreference(0, 15),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 40),
            child: IconButton(
                onPressed: () {
                  Navigator.pop(context, null);
                },
                icon: Icon(Icons.arrow_back)),
          ),
          GestureDetector(
            onTap: () {
              _handlePressButton();
            },
            child: Container(
              height: 50,
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(top: 40, left: 50, right: 16),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: Row(
                children: [
                  Icon(Icons.search_outlined),
                  Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Text(
                      search,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: ElevatedButton(
              onPressed: () {
                if (_placesDetailsResponse != null) {
                  _getLocation();
                }
                // _getCurrentPosition();
              },
              child: Text(
                'Get Location',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
              ),
            ),
            // child: Padding(
            //   padding: const EdgeInsets.only(bottom: 50),
            //   child: FloatingActionButton(
            //     onPressed: () {
            //       _getCurrentPosition();
            //     },
            //     child: Icon(Icons.add, size: 40),
            //   ),
            // ),
          ),
        ],
      ),
    );
  }

  Future<void> _handlePressButton() async {
    // show input autocomplete with selected mode
    // then get the Prediction selected
    Prediction? p = await PlacesAutocomplete.show(
      context: context,
      apiKey: Config().kGoogleApiKey,
      onError: onError,
      mode: Mode.overlay,
      language: 'en',
      strictbounds: false,
      types: [""],
      decoration: InputDecoration(
        hintText: 'Search',
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(
            color: Colors.white,
          ),
        ),
      ),
      components: [
        Component(Component.country, "us"),
        Component(Component.country, "ua"),
        Component(Component.country, "pe"),
        Component(Component.country, "af"),
        Component(Component.country, "au"),
      ],
    );

    if (p != null) {
      displayPrediction(p, homeScaffoldKey.currentState);
    }
  }

  void onError(PlacesAutocompleteResponse response) {
    openSnacbar(context, response.errorMessage);
  }

  Future<void> displayPrediction(
      Prediction p, ScaffoldState? currentState) async {
    GoogleMapsPlaces places = GoogleMapsPlaces(
        apiKey: Config().kGoogleApiKey,
        apiHeaders: await const GoogleApiHeaders().getHeaders());

    PlacesDetailsResponse detail = await places.getDetailsByPlaceId(p.placeId!);

    _placesDetailsResponse = detail;

    final lat = detail.result.geometry!.location.lat;
    final lng = detail.result.geometry!.location.lng;

    markersList.clear();
    markersList.add(Marker(
        markerId: const MarkerId("0"),
        position: LatLng(lat, lng),
        infoWindow: InfoWindow(title: detail.result.name)));

    setState(() {
      isFirstLoad = false;
    });

    _controller!
        .animateCamera(CameraUpdate.newLatLngZoom(LatLng(lat, lng), 14.0));
    // if (p != null) {
    //   // get detail (lat/lng)
    //   GoogleMapsPlaces _places = GoogleMapsPlaces(
    //     apiKey: Config().kGoogleApiKey,
    //     apiHeaders: await GoogleApiHeaders().getHeaders(),
    //   );
    //   PlacesDetailsResponse detail =
    //       await _places.getDetailsByPlaceId(p.placeId!);
    //   final lat = detail.result.geometry!.location.lat;
    //   final lng = detail.result.geometry!.location.lng;

    //   // _searchCtrl.text = detail.result.formattedAddress!;

    //   setState(() {
    //     search = detail.result.formattedAddress!;
    //   });

    //   // scaffold.showSnackBar(
    //   //   SnackBar(content: Text("${p.description} - $lat/$lng")),
    //   // );
    // }
  }

  _getLocation() {
    double latitude = _placesDetailsResponse!.result.geometry!.location.lat;
    double longitude = _placesDetailsResponse!.result.geometry!.location.lng;
    String address = _placesDetailsResponse!.result.formattedAddress!;
    data['latitude'] = latitude;
    data['longitude'] = longitude;
    data['address'] = address;

    print('===== latitude is ${data['latitude']} =====');
    print('===== longitude is ${data['longitude']} =====');
    print('===== address is $address =====');

    Navigator.pop(context, data);

    // _placesDetailsResponse
  }

  Future<void> _getCurrentPosition() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
        .then((Position position) {
      setState(() => _currentPosition = position);
      _getAddressFromLatLng(_currentPosition!);
    }).catchError((e) {
      debugPrint(e);
    });
  }

  Future<void> _getAddressFromLatLng(Position position) async {
    await placemarkFromCoordinates(
            _currentPosition!.latitude, _currentPosition!.longitude)
        .then((List<Placemark> placemarks) {
      Placemark place = placemarks[0];

      _currentAddress =
          '${place.street}, ${place.subLocality}, ${place.subAdministrativeArea}, ${place.postalCode}';

      data['latitude'] = position.latitude;
      data['longitude'] = position.longitude;
      data['address'] = _currentAddress;

      print('===== latitude is ${data['latitude']} =====');
      print('===== longitude is ${data['longitude']} =====');
      print('===== address is $_currentAddress =====');

      Navigator.pop(context, data);
    }).catchError((e) {
      debugPrint(e);
    });
  }
}
