import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../config/config.dart';

class ArticleLinkPage extends StatefulWidget {
  const ArticleLinkPage({super.key});

  @override
  State<ArticleLinkPage> createState() => _ArticleLinkPageState();
}

class _ArticleLinkPageState extends State<ArticleLinkPage> {
  final _linkCtrl = TextEditingController();
  String url = '';

  @override
  void dispose() {
    _linkCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'article'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (url.isNotEmpty) {
                Navigator.pop(context, url);
              }
            },
            child: Text(
              'next'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextFormField(
            controller: _linkCtrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              prefixIcon: Icon(Icons.link, color: Config().text90Color),
              hintText: 'add_link_article'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
            keyboardType: TextInputType.url,
            validator: (String? value) {
              if (value!.isEmpty) {
                return "This field can't be empty";
              }
              return null;
            },
            onChanged: (value) {
              setState(() {
                url = value;
              });
            },
          ),
        ],
      ),
    );
  }
}
