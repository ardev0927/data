import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../config/config.dart';

class ContentWarningPage extends StatefulWidget {
  const ContentWarningPage({super.key});

  @override
  State<ContentWarningPage> createState() => _ContentWarningPageState();
}

class _ContentWarningPageState extends State<ContentWarningPage> {
  bool _isNudity = false;
  bool _isViolence = false;
  bool _isSensitive = false;
  String contentWarning = 'Content Warning: ';
  String? cw;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'content_warning'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context, cw);
            },
            child: Text(
              'done'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 250,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Config().gradientColor1,
                      Config().gradientColor2,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      cw ?? contentWarning,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          color: Config().whiteColor),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'put_content_warning_title'.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Config().text90Color),
              ),
              const SizedBox(height: 8),
              Text(
                'put_content_warning_content'.tr(),
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Config().text90Color),
              ),
              const SizedBox(height: 16),
              const Divider(thickness: 1, height: 1),
              CheckboxListTile(
                value: _isNudity,
                onChanged: (value) {
                  setState(() {
                    _isNudity = value!;
                    cw =
                        '$contentWarning ${_isNudity == false ? '' : 'Nudity,'} ${_isViolence == false ? '' : 'Violence,'} ${_isSensitive == false ? '' : 'Sensitive content'}';
                  });
                },
                title: Text(
                  'nudity'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Config().text90Color),
                ),
                controlAffinity: ListTileControlAffinity.trailing,
              ),
              const Divider(thickness: 1, height: 1),
              CheckboxListTile(
                value: _isViolence,
                onChanged: (value) {
                  setState(() {
                    _isViolence = value!;
                    cw =
                        '$contentWarning ${_isNudity == false ? '' : 'Nudity,'} ${_isViolence == false ? '' : 'Violence,'} ${_isSensitive == false ? '' : 'Sensitive content'}';
                  });
                },
                title: Text(
                  'violence'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Config().text90Color),
                ),
                controlAffinity: ListTileControlAffinity.trailing,
              ),
              const Divider(thickness: 1, height: 1),
              CheckboxListTile(
                value: _isSensitive,
                onChanged: (value) {
                  setState(() {
                    _isSensitive = value!;
                    cw =
                        '$contentWarning ${_isNudity == false ? '' : 'Nudity,'} ${_isViolence == false ? '' : 'Violence,'} ${_isSensitive == false ? '' : 'Sensitive content'}';
                  });
                },
                title: Text(
                  'sensitive'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Config().text90Color),
                ),
                controlAffinity: ListTileControlAffinity.trailing,
                visualDensity: VisualDensity(vertical: 0),
              ),
              const Divider(thickness: 1, height: 1),
            ],
          ),
        ),
      ),
    );
  }
}
