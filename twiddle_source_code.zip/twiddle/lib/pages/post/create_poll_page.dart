import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/pages/post/post_poll_page.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';

import '../../config/config.dart';

class CreatePollPage extends StatefulWidget {
  CreatePollPage({super.key, this.group});
  Group? group;

  @override
  State<CreatePollPage> createState() => _CreatePollPageState();
}

class _CreatePollPageState extends State<CreatePollPage> {
  final _askCtrl = TextEditingController();
  final _option1Ctrl = TextEditingController();
  final _option2Ctrl = TextEditingController();

  @override
  void dispose() {
    _askCtrl.dispose();
    _option1Ctrl.dispose();
    _option2Ctrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, null);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'create_new_poll'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              if (_validate()) {
                var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => PostPollPage(
                            question: _askCtrl.text,
                            option1: _option1Ctrl.text,
                            option2: _option2Ctrl.text)));
                if (ret != null) {
                  Navigator.pop(context, ret);
                }
                // nextScreen(
                //     context,
                //     PostPollPage(
                //         question: _askCtrl.text,
                //         option1: _option1Ctrl.text,
                //         option2: _option2Ctrl.text));
              }
            },
            child: Text(
              'next'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextFormField(
            controller: _askCtrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'ask_question'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _option1Ctrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'add_option1'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _option2Ctrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'add_option2'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
    );
  }

  _validate() {
    if (_askCtrl.text.isEmpty) {
      openToast('Please enter a question');
      return false;
    }
    if (_option1Ctrl.text.isEmpty) {
      openToast('Please enter a option 1');
      return false;
    }
    if (_option2Ctrl.text.isEmpty) {
      openToast('Please enter a option 2');
      return false;
    }
    return true;
  }
}
