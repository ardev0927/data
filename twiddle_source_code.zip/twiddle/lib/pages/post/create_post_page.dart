import 'dart:io';
import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/album_bloc.dart';
import 'package:twiddle/blocs/group_manage_bloc.dart';
import 'package:twiddle/blocs/posts_bloc.dart';
import 'package:twiddle/cards/card3.dart';
import 'package:twiddle/cards/video_card2.dart';
import 'package:twiddle/models/album.dart';
import 'package:twiddle/models/group.dart';
import 'package:twiddle/models/post.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/group/managed_group_page.dart';
import 'package:twiddle/pages/post/add_location_page.dart';
import 'package:twiddle/pages/post/article_link_page.dart';
import 'package:twiddle/pages/post/content_warning_page.dart';
import 'package:twiddle/pages/post/create_poll_page.dart';
import 'package:twiddle/pages/post/feeling_activity_page.dart';
import 'package:twiddle/pages/post/live/live_channel_video.dart';
import 'package:twiddle/pages/post/live/live_main_page.dart';
import 'package:twiddle/pages/post/live/temp_live.dart';
import 'package:twiddle/pages/post/location/location_view_page.dart';
import 'package:twiddle/pages/post/select_album_page.dart';
import 'package:twiddle/pages/post/select_gif_page.dart';
import 'package:twiddle/pages/post/tag_friends_page.dart';
import 'package:twiddle/pages/profile/photo_tabs/albums_tab.dart';
import 'package:twiddle/pages/profile/photo_tabs/photo_tab.dart';
import 'package:twiddle/utils/convert_time_ago.dart';
import 'package:twiddle/utils/feeling_utils.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:uuid/uuid.dart';
import 'package:video_compress/video_compress.dart';

import '../../blocs/group_bloc.dart';
import '../../blocs/notification_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image_with_dark.dart';
import '../../utils/crop_image.dart';
import '../../utils/enums.dart';
import '../../utils/format_time.dart';
import '../../utils/snacbar.dart';

class CreatePostPage extends StatefulWidget {
  CreatePostPage(
      {super.key,
      required this.type,
      this.p,
      this.g,
      this.isCreatedGroup = false});

  final Post? p;
  final Group? g;
  final int? type;
  bool isCreatedGroup;

  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _descControl = TextEditingController();
  final List<String> _tagFriends = [];
  final List<Group> _groups = [];
  List<WUser> tagUsers = [];
  List<File> files = [];
  List<String> gifUrls = [];
  Map<String, dynamic> location = {};
  String _desc = '';
  String _privacy = 'public';
  String _album = 'Album';
  String _feeling = '';
  String articleUrl = '';
  String _tagFriendNicknames = '';
  int postType = 1;
  bool _isLoading = false;
  bool isSharedPost = false;
  bool isGroupPost = false;

  late List<CameraDescription> _cameras;

  File? videoFile;
  Album? album;
  Uint8List? videoThumbBytes;
  Group? group;
  String? contentWarning;

  @override
  void initState() {
    if (widget.type == PostType.share || widget.type == PostType.sharegroup) {
      isSharedPost = true;
    }
    if (widget.g != null) {
      group = widget.g;
      if (widget.type == PostType.empty) {
        isGroupPost = true;
      }
    }
    super.initState();

    loadingManagedGroups();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          isGroupPost == false ? getAppbarTitle() : group!.name,
          // : '${'group_post'.tr()}(${group!.name})',
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (_descControl.text.isNotEmpty &&
                  files.isEmpty &&
                  videoFile == null &&
                  gifUrls.isEmpty &&
                  location.isEmpty &&
                  articleUrl.isEmpty) {
                postType = 3; // Only text post
                _post();
              } else if (_descControl.text.isEmpty &&
                  files.isEmpty &&
                  gifUrls.isEmpty &&
                  location.isEmpty &&
                  articleUrl.isEmpty) {
                openToast('Please add text, photo/video or gif to post');
              } else {
                _post();
              }
            },
            child: Text(
              'post'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: body(),
    );
  }

  getAppbarTitle() {
    String title = 'post'.tr();
    if (widget.type == PostType.share) {
      title = 'share_to_feed'.tr();
    } else if (widget.type == PostType.sharegroup) {
      title = 'share_to_group'.tr();
    }
    return title;
  }

  body() {
    final sb = context.read<SignInBloc>();
    var appbarHeight =
        MediaQuery.of(context).padding.top + AppBar().preferredSize.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height - appbarHeight,
          child: Stack(
            children: [
              Column(
                children: [
                  // Header
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 20,
                          backgroundColor: Colors.grey[300],
                          backgroundImage:
                              CachedNetworkImageProvider(sb.imageUrl!),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    sb.name!,
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w700,
                                        color: Config().text100Color),
                                  ),
                                  _feeling.isEmpty
                                      ? Container()
                                      : Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 8, right: 4),
                                              child: SvgPicture.asset(
                                                  'assets/images/$_feeling.svg',
                                                  width: 18,
                                                  height: 18),
                                            ),
                                            Text(
                                              _feeling.contains('feeling_')
                                                  ? 'Feeling '
                                                  : ' ',
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                            Text(
                                              mapFeeling[_feeling]!,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.w600,
                                                  color: Config().text90Color),
                                            ),
                                          ],
                                        ),
                                ],
                              ),
                              Row(
                                children: [
                                  // Privacy (Public, Friends, Friends of friends, Only me)
                                  GestureDetector(
                                    onTap: () {
                                      _showPrivacySheet(context);
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 8),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 4, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Config().text4Color,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/images/public.svg'),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 4),
                                            child: Text(
                                              _privacy.tr(),
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                          ),
                                          SvgPicture.asset(
                                              'assets/images/arrow_drop_down.svg'),
                                        ],
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  // Album
                                  GestureDetector(
                                    onTap: () async {
                                      // Get Album
                                      if (isSharedPost == true) return;

                                      var ret = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  SelectAlbumPage(
                                                      uid: sb.uid)));
                                      if (ret != null) {
                                        album = ret as Album?;
                                        postType = Config().AlbumType;
                                        setState(() {
                                          _album = album!.name!;
                                        });
                                      }
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 8),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 4, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: Config().text4Color,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Row(
                                        children: [
                                          Icon(Icons.add, size: 15),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 4),
                                            child: Text(
                                              _album,
                                              style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w400,
                                                  color: Config().text90Color),
                                            ),
                                          ),
                                          Icon(Icons.arrow_drop_down_outlined,
                                              size: 20),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Content
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      color: Config().text4Color,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _descControl,
                              keyboardType: TextInputType.multiline,
                              // maxLines: isSharedPost ? 2 : 7,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'write_post'.tr(),
                                hintStyle: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w400,
                                    color: Config().text90Color),
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return "This field can't be empty";
                                }
                                return null;
                              },
                              onChanged: (value) {
                                _desc = value;
                              },
                            ),
                          ),
                          _tagFriends.isNotEmpty
                              ? tagFriendsContent()
                              : Container(),
                          widget.type == PostType.sharegroup
                              ? Text(
                                  '${widget.g!.name!} group',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Config().text90Color),
                                )
                              : Container(),
                          isSharedPost
                              ? widget.p!.mediaType == PostType.video
                                  ? VideoCard2(
                                      d: widget.p!, time: widget.p!.timestamp!)
                                  : Card3(
                                      d: widget.p!,
                                      time: convertToAgo(widget.p!.timestamp!))
                              : getTypeWidget(postType),
                          // postType == 10
                          //     ? locationContent()
                          //     : postType == 11
                          //         ? articleContent()
                          //         : mediaWidget(),
                        ],
                      ),
                    ),
                  ),
                  // Footer
                  isSharedPost
                      ? Container()
                      : Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          color: Colors.white,
                          child: Column(
                            children: [
                              // User feed and Group
                              Row(
                                children: [
                                  // _userFeed(
                                  //   title: 'user_feed'.tr(),
                                  //   isUser: true,
                                  //   onTap: () {
                                  //     setState(() {
                                  //       isGroupPost = false;
                                  //     });
                                  //   },
                                  // ),
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        isGroupPost = false;
                                      });
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: isGroupPost == false
                                            ? Config().primary30Color
                                            : Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        'user_feed'.tr(),
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: isGroupPost == false
                                                ? Colors.white
                                                : Config().text90Color),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  // _userFeed(
                                  //   title: 'group'.tr(),
                                  //   isUser: false,
                                  //   onTap: () {
                                  //     selectGroupDialog();
                                  //     // setState(() {
                                  //     //   isGroupPost = true;
                                  //     // });
                                  //   },
                                  // ),
                                  InkWell(
                                    onTap: () {
                                      selectGroupDialog();
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 5),
                                      decoration: BoxDecoration(
                                        color: isGroupPost == true
                                            ? Config().primary30Color
                                            : Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        'group'.tr(),
                                        style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: isGroupPost == true
                                                ? Colors.white
                                                : Config().text90Color),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              const Divider(height: 1),
                              // Photo/Video
                              _postItem(
                                svgName: 'assets/images/add_to_photos.svg',
                                itemName: 'photo_video',
                                onTap: () {
                                  _showPhotoVideoSheet(context);
                                },
                              ),
                              const Divider(height: 1),
                              // Tag prople
                              _postItem(
                                svgName: 'assets/images/sell.svg',
                                itemName: 'tab_prople',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TagFriendsPage()));
                                  if (ret != null) {
                                    // postType = 6; // Tag Friends

                                    tagUsers.clear();
                                    _tagFriendNicknames = 'with ';
                                    tagUsers.addAll(ret);
                                    tagUsers.forEach((element) {
                                      _tagFriendNicknames += '${element.name},';
                                      _tagFriends.add(element.uid!);
                                    });
                                    setState(() {});
                                  }
                                  // nextScreen(context, TagFriendsPage());
                                },
                              ),
                              // const Divider(height: 1),
                              // // Live
                              // _postItem(
                              //   svgName: 'assets/images/live_tv.svg',
                              //   itemName: 'live',
                              //   onTap: () async {
                              //     var ret = await Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //           builder: (context) => LiveMainPage(
                              //             isBroadcater: true,
                              //             channelId: 'test123',
                              //             owner: true,
                              //           ),
                              //         ));
                              //     if (ret != null) {
                              //       Navigator.pop(context);
                              //     }
                              //   },
                              // ),
                              const Divider(height: 1),
                              // Check in
                              _postItem(
                                svgName: 'assets/images/add_location_alt.svg',
                                itemName: 'check_in',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              AddLocationPage()));
                                  if (ret != null) {
                                    postType = 10;
                                    location['latitude'] = ret['latitude'];
                                    location['longitude'] = ret['longitude'];
                                    location['address'] = ret['address'];
                                    setState(() {});
                                  }
                                  // nextScreen(context, AddLocationPage());
                                },
                              ),
                              const Divider(height: 1),
                              // // Gif
                              // _postItem(
                              //   svgName: 'assets/images/gif_box.svg',
                              //   itemName: 'gif',
                              //   onTap: () async {
                              //     var ret = await Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (context) =>
                              //                 const SelectGifPage()));
                              //     if (ret != null) {
                              //       postType = 7;
                              //       gifUrls.clear();
                              //       gifUrls.add(ret.gifUrl);
                              //       setState(() {});
                              //     }
                              //     // nextScreen(context, SelectGifPage());
                              //   },
                              // ),
                              // const Divider(height: 1),
                              // Feeling/Activity
                              _postItem(
                                svgName: 'assets/images/add_reaction.svg',
                                itemName: 'feeling_activity',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              const FeelingActivityPage()));
                                  if (ret != null) {
                                    _feeling = ret;
                                    setState(() {});
                                  }
                                  // nextScreen(context, FeelingActivityPage());
                                },
                              ),
                              const Divider(height: 1),
                              // Article
                              _postItem(
                                svgName: 'assets/images/article.svg',
                                itemName: 'article',
                                onTap: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              ArticleLinkPage()));
                                  if (ret != null) {
                                    postType = 11;
                                    setState(() {
                                      articleUrl = ret;
                                    });
                                  }
                                  // nextScreen(context, ArticleLinkPage());
                                },
                              ),
                              const Divider(height: 1),
                              // Poll
                              // _postItem(
                              //   svgName: 'assets/images/bar_chart.svg',
                              //   itemName: 'poll',
                              //   onTap: () async {
                              //     var ret = await Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (context) =>
                              //                 CreatePollPage()));
                              //     if (ret != null) {
                              //       Navigator.pop(context, ret);
                              //     }
                              //     // nextScreen(context, CreatePollPage());
                              //   },
                              // ),
                            ],
                          ),
                        ),
                ],
              ),
              _isLoading
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : Container(),
            ],
          ),
        ),
      ),
    );
  }

  getTypeWidget(int postType) {
    switch (postType) {
      case PostType.checkin:
        return locationContent();
      case PostType.article:
        return articleContent();
      case PostType.tagfriend:
        return tagFriendsContent();
      default:
        return mediaWidget();
    }
  }

  tagFriendsContent() {
    return Text(
      _tagFriendNicknames,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text70Color),
    );
  }

  locationContent() {
    return Text(
      location['address'],
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text90Color),
    );
  }

  articleContent() {
    return Text(
      articleUrl,
      style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Config().text90Color),
    );
  }

  mediaWidget() {
    return SizedBox(
      height: 120,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, idx) {
            return Container(
              width: 120,
              height: 120,
              alignment: Alignment.bottomLeft,
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: SizedBox(
                      width: 110,
                      height: 110,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(5),
                        child: postType == 7
                            ? CustomCacheImageWithDarkFilterBottom(
                                imageUrl: gifUrls[idx], radius: 5.0)
                            : postType == 2
                                ? Image.memory(videoThumbBytes!,
                                    fit: BoxFit.fill)
                                : Image.file(
                                    files[idx],
                                    fit: BoxFit.fill,
                                  ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: InkWell(
                      onTap: () async {
                        var ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ContentWarningPage()));
                        if (ret != null && ret is String) {
                          // postType = PostType.contentwarning;
                          contentWarning = ret;
                        }
                        // nextScreen(context, ContentWarningPage());
                      },
                      child: Container(
                        width: 30,
                        height: 30,
                        margin: const EdgeInsets.only(right: 16, bottom: 8),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Config().whiteColor,
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.flag_outlined,
                            size: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.topRight,
                    child: GestureDetector(
                      onTap: () {
                        files.removeAt(idx);
                        setState(() {});
                      },
                      child: Container(
                        alignment: Alignment.center,
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.red,
                        ),
                        child: Center(
                          child: Icon(
                            Icons.close,
                            size: 15,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
          itemCount: postType == 7
              ? gifUrls.length
              : postType == 2
                  ? 1
                  : files.length),
    );
  }

  InkWell _postItem({String? svgName, String? itemName, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            SvgPicture.asset(svgName!),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_forward_ios)
          ],
        ),
      ),
    );
  }

  InkWell _userFeed({String? title, bool? isUser, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: isUser == true ? Config().primary30Color : Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          title!,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: isUser == true ? Colors.white : Config().text90Color),
        ),
      ),
    );
  }

  // Bottom sheet for post privacy
  _showPrivacySheet(ctx) {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () {
                if (_privacy != 'public') {
                  _privacy = 'public';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/public.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // friends
            InkWell(
              onTap: () {
                if (_privacy != 'friends') {
                  _privacy = 'friends';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/person_remove.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // only me
            InkWell(
              onTap: () {
                if (_privacy != 'only_me') {
                  _privacy = 'only_me';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/private_connectivity.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Bottom sheet for post photo/video
  _showPhotoVideoSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (postType != Config().AlbumType) {
                  postType = 1;
                }
                pickMediaDialog(ctx, postType);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.add_photo_alternate_rounded),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            // InkWell(
            //   onTap: () async {
            //     Navigator.pop(context);
            //     await pickImage(true);
            //   },
            //   child: Padding(
            //     padding: const EdgeInsets.all(16.0),
            //     child: Row(
            //       children: [
            //         SvgPicture.asset('assets/images/camera.svg'),
            //         Padding(
            //           padding: const EdgeInsets.only(left: 16),
            //           child: Text(
            //             'camera'.tr(),
            //             style: TextStyle(
            //                 fontSize: 16,
            //                 fontWeight: FontWeight.w600,
            //                 color: Config().text90Color),
            //           ),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),
            // video
            InkWell(
              onTap: () {
                Navigator.pop(context);
                if (videoFile == null) {
                  postType = 2;
                  pickMediaDialog(ctx, 2);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.live_tv_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'video'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  pickMediaDialog(BuildContext ctx, int type) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1 || type == 9) {
                      await pickImage(false);
                    } else {
                      await pickVideo(false);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(type == 1 || type == 9
                            ? Icons.add_photo_alternate_outlined
                            : Icons.video_camera_front_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1 || type == 9) {
                      await pickImage(true);
                    } else {
                      await pickVideo(true);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  //////////////////////////////////////////////////////////////////////////////

  Future pickImage(bool camera) async {
    // XFile? image;
    List<XFile> images = [];
    if (camera) {
      var image = await ImagePicker()
          .pickImage(source: ImageSource.camera, imageQuality: 50);
      setState(() {
        files.add(File(image!.path));
      });
      // if (image != null) {
      //   var cropPath = await croppedImage(image.path);
      //   setState(() {
      //     files.add(File(cropPath));
      //     // files.add(File(image!.path));
      //   });
      // } else {
      //   print('No image selected!');
      // }
    } else {
      images = await ImagePicker().pickMultiImage(imageQuality: 50);
      if (images.isNotEmpty) {
        for (var image in images) {
          var size = await image.readAsBytes();
          if (size.lengthInBytes > 10 * 1024 * 1024) {
            openToast('The image size should be less than 10MB');
            continue;
          }
          files.add(File(image.path));
        }
        setState(() {});
      } else {
        print('===== No images selected! =====');
      }
      // image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    // var size = await image!.readAsBytes();
    // if (size.lengthInBytes > 10 * 1024 * 1024) {
    //   openToast('The image size should be less than 10MB');
    //   return;
    // }
    // if (image != null) {
    //   var cropPath = await croppedImage(image.path);
    //   setState(() {
    //     files.add(File(cropPath));
    //     // files.add(File(image!.path));
    //   });
    // } else {
    //   print('No image selected!');
    // }
  }

  Future pickVideo(bool camera) async {
    XFile? video;
    if (camera) {
      video = await ImagePicker().pickVideo(source: ImageSource.camera);
    } else {
      video = await ImagePicker().pickVideo(source: ImageSource.gallery);
    }
    var size = await video!.readAsBytes();
    if (size.lengthInBytes > 50 * 1024 * 1024) {
      openToast('The video size should be less than 50MB');
      return;
    }
    if (video != null) {
      // Generate thumbnail
      var thumbBytes = await VideoCompress.getByteThumbnail(video.path,
          quality: 50, position: -1);

      videoThumbBytes = thumbBytes;

      // Compress video
      setState(() {
        _isLoading = true;
      });
      MediaInfo? mi;
      try {
        await VideoCompress.setLogLevel(0);

        mi = await VideoCompress.compressVideo(video.path,
            quality: VideoQuality.LowQuality,
            includeAudio: true,
            deleteOrigin: true);

        setState(() {
          _isLoading = false;
          videoFile = File(mi!.path!);
        });
      } catch (e) {
        VideoCompress.cancelCompression();
        setState(() {
          _isLoading = false;
        });
      }
    } else {
      print('===== No video selected! =====');
    }
  }

  _post() async {
    // Hide keyboard
    FocusManager.instance.primaryFocus?.unfocus();

    final SignInBloc sb = context.read<SignInBloc>();
    final AlbumBloc ab = context.read<AlbumBloc>();
    final UserBlock ub = context.read<UserBlock>();
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    final GroupBloc gb = Provider.of<GroupBloc>(context, listen: false);

    var feeling = _feeling.isEmpty ? '' : _feeling;

    setState(() {
      _isLoading = true;
    });

    List<String> images = [];
    String video = '';
    switch (postType) {
      case PostType.image: // Image
        var temp = await uploadImageFiles(files);
        images.addAll(temp);
        break;
      case PostType.video: // Video
        video = await uploadVideoFile(videoFile!);
        // images.addAll(temp);
        break;
      case PostType.text: // Text
        break;
      case PostType.gif: // Gif
        images.addAll(gifUrls);
        break;
      case PostType.album:
        var temp = await uploadImageFiles(files);
        images.addAll(temp);
        feeling = '${album!.name} Album';
        break;
      default:
        break;
    }

    // Get tag friend
    if (_tagFriendNicknames != '') {
      feeling = _tagFriendNicknames;
    }

    // Content warning
    if (contentWarning != null && contentWarning!.isNotEmpty) {
      postType = PostType.contentwarning;
    }

    // Create time now
    DateTime now = DateTime.now();
    DateTime utc = now.toUtc();
    var timestamp = formatISOTime(utc);

    Map<String, Object?> poll = {};
    // Group post
    Map<String, dynamic> mapGroup = {};
    if (isGroupPost) {
      mapGroup = group!.toJson();
    }

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        //
        if (isSharedPost) {
          postType = widget.g == null
              ? PostType.share
              : PostType.sharegroup; // Shared Post
          var p = widget.p;
          feeling = widget.type == PostType.share
              ? 'Shared a post'
              : 'Shared to ${widget.g!.name} group';

          // group
          if (postType == PostType.sharegroup) {
            mapGroup = widget.g!.toJson();
          }
          pb
              .createPost(
                  sb,
                  postType,
                  [],
                  _desc,
                  _privacy,
                  timestamp,
                  feeling,
                  poll,
                  location,
                  '',
                  mapGroup,
                  widget.type == PostType.share ? false : true,
                  [],
                  p!.toJson(),
                  contentWarning: contentWarning)
              .then((value) async {
            setState(() {
              _isLoading = false;
            });
            if (pb.hasError == false) {
              // if (postType == PostType.album) {
              //   ab.updateImages(sb.uid!, album!.id, images);
              // }
              // openToast('You created a post');
              openToast(feeling);

              // update group
              if (isGroupPost ||
                  (!isGroupPost && postType == PostType.sharegroup)) {
                await gb
                    .updateGroupList(
                        group!.id!, 'posts', pb.post!.postId!, true)
                    .then((value) {
                  gb.addPostOnGroup(group!.id!, pb.post!);
                });
              }

              // if post type is tag, send fcm
              if (_tagFriendNicknames != '') {
                _sendFcmTag(pb.post!, sb.imageUrl!);
                // _sendFcmPost(ub, sb.uid!, sb.name!, sb.imageUrl!, pb.post!,
                //     ub.data!.fcmToken!, FcmType.tag);
              } else {
                if (widget.isCreatedGroup == true) {
                  nextScreenReplace(context, ManagedGroupPage(group: group));
                } else {
                  Navigator.pop(context, pb.post);
                }
              }
            }
          });
        } else {
          pb
              .createPost(
                  sb,
                  postType,
                  postType == PostType.image ||
                          postType == PostType.album ||
                          postType == PostType.contentwarning
                      ? images
                      : [video],
                  _desc,
                  _privacy,
                  timestamp,
                  feeling,
                  poll,
                  location,
                  articleUrl,
                  mapGroup,
                  isGroupPost,
                  _tagFriends,
                  {},
                  contentWarning: contentWarning)
              .then((value) async {
            setState(() {
              _isLoading = false;
            });
            if (pb.hasError == false) {
              if (postType == PostType.album) {
                ab.updateImages(sb.uid!, album!.id, images);
              }
              openToast('You created a post');

              // update group
              if (isGroupPost) {
                await gb
                    .updateGroupList(
                        group!.id!, 'posts', pb.post!.postId!, true)
                    .then((value) {
                  gb.addPostOnGroup(group!.id!, pb.post!);
                });
              }

              // if post type is tag, send fcm
              if (_tagFriendNicknames != '') {
                _sendFcmTag(pb.post!, sb.imageUrl!);

                // _sendFcmPost(ub, sb.uid!, sb.name!, sb.imageUrl!, pb.post!,
                //     ub.data!.fcmToken!, FcmType.tag);
              } else {
                if (widget.isCreatedGroup == true) {
                  nextScreenReplace(context, ManagedGroupPage(group: group));
                } else {
                  Navigator.pop(context, pb.post);
                }
              }
            }
          });
        }
      }
    });
  }

  // formatISOTime(DateTime date) {
  //   var val = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(date);
  //   var offset = date.timeZoneOffset;
  //   var hours =
  //       offset.inHours > 0 ? offset.inHours : 1; // For fixing divide by 0

  //   if (!offset.isNegative) {
  //     val = val +
  //         "+" +
  //         offset.inHours.toString().padLeft(2, '0') +
  //         ":" +
  //         (offset.inMinutes % (hours * 60)).toString().padLeft(2, '0');
  //   } else {
  //     val = val +
  //         "-" +
  //         (-offset.inHours).toString().padLeft(2, '0') +
  //         ":" +
  //         (offset.inMinutes % (hours * 60)).toString().padLeft(2, '0');
  //   }
  //   return val;
  // }

  Future<int> getTotalPostsCount() async {
    const String fieldName = 'count';
    final DocumentReference ref =
        FirebaseFirestore.instance.collection('item_count').doc('posts_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }

  Future increasePostCount() async {
    await getTotalPostsCount().then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('item_count')
          .doc('posts_count')
          .update({'count': documentCount + 1});
    });
  }

  // Upload image files
  Future<List<String>> uploadImageFiles(List<File> images) async {
    var imageUrls = await Future.wait(images.map((e) => uploadImageFile(e)));
    print('===== upload done =====');
    return imageUrls;
  }

  Future<String> uploadImageFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  // Upload videos
  Future<String> uploadVideoFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Videos/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
        print('===== upload done video =====');
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  // Loading managed groups
  loadingManagedGroups() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final GroupManageBloc gmb =
        Provider.of<GroupManageBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        gmb.getData(sb.uid!, mounted, 'timestamp').then((value) async {
          if (gmb.hasData == true) {
            _groups.clear();
            _groups.addAll(gmb.data);
          } else {
            print('Failed loading groups');
          }
        });
      }
    });
  }

  selectGroupDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
          contentPadding: const EdgeInsets.all(16),
          title: Text(
            'select_group'.tr(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          children: [
            SizedBox(
              height: 300,
              width: MediaQuery.of(context).size.width,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: _groups.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: () {
                      group = _groups[index];
                      setState(() {
                        isGroupPost = true;
                      });
                      Navigator.pop(context);
                    },
                    title: Text(_groups[index].name!),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  _sendFcmTag(Post p, String avatar) async {
    var title = "Post tag";
    var body = "You received tag post from ${p.username}.";

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");

    Future.forEach(tagUsers, (user) async {
      var res = await func.call(<String, dynamic>{
        "targetDevices": [user.fcmToken],
        "messageTitle": title,
        "messageBody": body,
      });

      print(
          "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

      // add notification
      if (res.data as bool == true) {
        _updateNotification(p, user.uid, body, FcmType.tag, p.postId, avatar);
      }
    });
  }

  _updateNotification(Post p, uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          // setState(() {});
          Navigator.pop(context, p);
        });
      }
    });
  }
}
