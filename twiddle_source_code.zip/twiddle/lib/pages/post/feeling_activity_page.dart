import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_emoji/flutter_emoji.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:twiddle/utils/feeling_utils.dart';

import '../../config/config.dart';

class FeelingActivityPage extends StatefulWidget {
  const FeelingActivityPage({super.key});

  @override
  State<FeelingActivityPage> createState() => _FeelingActivityPageState();
}

class _FeelingActivityPageState extends State<FeelingActivityPage>
    with TickerProviderStateMixin {
  TabController? _tabController;
  final _searchFeelingCtrl = TextEditingController();
  final _searchActivityCtrl = TextEditingController();
  var emojiParser = EmojiParser();

  final List<Tab> _tabs = [
    Tab(
      text: 'feeling'.tr(),
    ),
    Tab(
      text: 'activity'.tr(),
    ),
  ];

  @override
  void initState() {
    _tabController = TabController(length: _tabs.length, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _searchFeelingCtrl.dispose();
    _searchActivityCtrl.dispose();
    _tabController!.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'feeling_activity'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
      child: DefaultTabController(
        length: _tabs.length,
        child: Column(
          children: [
            SizedBox(
              height: 50,
              child: TabBar(
                controller: _tabController,
                labelStyle:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                labelColor: Config().text90Color,
                unselectedLabelStyle:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.w400),
                unselectedLabelColor: Config().text90Color,
                indicatorColor: Config().primary30Color,
                indicatorWeight: 3,
                labelPadding: const EdgeInsets.all(4),
                tabs: _tabs,
              ),
            ),
            Flexible(
              child: TabBarView(
                children: [
                  _feelingTab(),
                  _activityTab(),
                ],
                controller: _tabController,
              ),
            ),
          ],
        ),
      ),
    );
  }

  _feelingTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: TextField(
            controller: _searchFeelingCtrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              prefixIcon:
                  Icon(Icons.search_outlined, color: Config().text90Color),
              hintText: 'search'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView(
            children: [
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_happy.svg',
                      title: 'feeling_happy'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_happy');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_sad.svg',
                      title: 'feeling_sad'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_sad');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_loved.svg',
                      title: 'feeling_loved'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_loved');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_cool.svg',
                      title: 'feeling_cool'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_cool');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_confused.svg',
                      title: 'feeling_confused'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_confused');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_hot.svg',
                      title: 'feeling_hot'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_hot');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_strong.svg',
                      title: 'feeling_strong'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_strong');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_lonely.svg',
                      title: 'feeling_lonely'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_lonely');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_special.svg',
                      title: 'feeling_special'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_special');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_depressed.svg',
                      title: 'feeling_depressed'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_depressed');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_jolly.svg',
                      title: 'feeling_jolly'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_jolly');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_curious.svg',
                      title: 'feeling_curious'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_curious');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_great.svg',
                      title: 'feeling_great'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_great');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_cute.svg',
                      title: 'feeling_cute'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_cute');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_funny.svg',
                      title: 'feeling_funny'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_funny');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_bad.svg',
                      title: 'feeling_bad'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_bad');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_inspired.svg',
                      title: 'feeling_inspired'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_inspired');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_satisfied.svg',
                      title: 'feeling_satisfied'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_satisfied');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_calm.svg',
                      title: 'feeling_calm'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_calm');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_proud.svg',
                      title: 'feeling_proud'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_proud');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_fresh.svg',
                      title: 'feeling_fresh'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_fresh');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_lucky.svg',
                      title: 'feeling_lucky'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_lucky');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_bored.svg',
                      title: 'feeling_bored'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_bored');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_glad.svg',
                      title: 'feeling_glad'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_glad');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_sleepy.svg',
                      title: 'feeling_sleepy'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_sleepy');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_chill.svg',
                      title: 'feeling_chill'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_chill');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_hopeful.svg',
                      title: 'feeling_hopeful'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_hopeful');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_cool2.svg',
                      title: 'feeling_cool2'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_cool2');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_inlove.svg',
                      title: 'feeling_inlove'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_inlove');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_crazy.svg',
                      title: 'feeling_crazy'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_crazy');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_relaxed.svg',
                      title: 'feeling_relaxed'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_relaxed');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/feeling_silly.svg',
                      title: 'feeling_silly'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'feeling_silly');
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Expanded feelingActivityItem({
    required String? svgName,
    required String? title,
    required Function()? onPressed,
  }) {
    return Expanded(
      child: TextButton(
        onPressed: onPressed,
        child: Row(
          children: [
            SvgPicture.asset(svgName!),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                title!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Config().text100Color),
              ),
            ),
          ],
        ),
      ),
    );
  }

  _activityTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: TextField(
            controller: _searchActivityCtrl,
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              prefixIcon:
                  Icon(Icons.search_outlined, color: Config().text90Color),
              hintText: 'search'.tr(),
              hintStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView(
            children: [
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_celebrating.svg',
                      title: 'activity_celebrating'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_celebrating');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_watching.svg',
                      title: 'activity_watching'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_watching');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_eating.svg',
                      title: 'activity_eating'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_eating');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_drinking.svg',
                      title: 'activity_drinking'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_drinking');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_traveling.svg',
                      title: 'activity_traveling'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_traveling');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_attending.svg',
                      title: 'activity_attending'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_attending');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_listening.svg',
                      title: 'activity_listening'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_listening');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_looking.svg',
                      title: 'activity_looking'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_looking');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_thinking.svg',
                      title: 'activity_thinking'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_thinking');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_reading.svg',
                      title: 'activity_reading'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_reading');
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              IntrinsicHeight(
                child: Row(
                  children: [
                    feelingActivityItem(
                      svgName: 'assets/images/activity_playing.svg',
                      title: 'activity_playing'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_celebrating');
                      },
                    ),
                    const VerticalDivider(),
                    feelingActivityItem(
                      svgName: 'assets/images/activity_supporting.svg',
                      title: 'activity_supporting'.tr(),
                      onPressed: () {
                        Navigator.pop(context, 'activity_celebrating');
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
