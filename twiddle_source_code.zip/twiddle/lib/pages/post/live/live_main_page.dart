import 'dart:io';

import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as rtc_local_view;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as rtc_remote_view;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:screenshot/screenshot.dart';
import 'package:uuid/uuid.dart';

import '../../../blocs/friends_bloc.dart';
import '../../../blocs/notification_bloc.dart';
import '../../../blocs/posts_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../config/config.dart';
import '../../../models/user.dart';
import '../../../services/app_service.dart';
import '../../../utils/format_time.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import 'log_sink.dart';

class LiveMainPage extends StatefulWidget {
  const LiveMainPage({
    super.key,
    required this.isBroadcater,
    required this.channelId,
    required this.owner,
  });
  final bool? isBroadcater;
  final String? channelId;
  final bool? owner;

  @override
  State<LiveMainPage> createState() => _LiveMainPageState();
}

class _LiveMainPageState extends State<LiveMainPage> {
  final _descriptionCtrl = TextEditingController();
  final _screenshotController = ScreenshotController();
  // CameraController? _cameraController;
  late List<CameraDescription> cameras;
  double width = 0.0;
  double height = 0.0;
  String _privacy = 'public';

  late final RtcEngine _engine;

  bool isJoined = false, switchCamera = true, switchRender = true;
  List<int> remoteUid = [];
  List<WUser> inviteUsers = [];
  bool _isRenderSurfaceView = false;
  bool isMuted = false;
  bool isLive = false;
  bool isLoading = false;

  Future<void> _initEngine() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      await [Permission.microphone, Permission.camera].request();
    }

    _engine = await RtcEngine.createWithContext(
        RtcEngineContext(Config().agoraAppId));
    _addListeners();

    await _engine.enableVideo();
    await _engine.startPreview();
    await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    if (widget.isBroadcater!) {
      await _engine.setClientRole(ClientRole.Broadcaster);
      if (widget.owner == false) {
        print('===== Join channel =====');
        _joinChannel();
      }
    } else {
      await _engine.setClientRole(ClientRole.Audience);
    }
  }

  void _addListeners() {
    _engine.setEventHandler(RtcEngineEventHandler(
      warning: (warningCode) {
        // logSink.log('warning $warningCode');
      },
      error: (errorCode) {
        // logSink.log('error $errorCode');
      },
      joinChannelSuccess: (channel, uid, elapsed) {
        // logSink.log('joinChannelSuccess $channel $uid $elapsed');
        setState(() {
          isJoined = true;
        });
      },
      userJoined: (uid, elapsed) {
        // logSink.log('userJoined  $uid $elapsed');
        setState(() {
          remoteUid.add(uid);
        });
      },
      userOffline: (uid, reason) {
        // logSink.log('userOffline  $uid $reason');
        setState(() {
          remoteUid.removeWhere((element) => element == uid);
        });
      },
      leaveChannel: (stats) {
        // logSink.log('leaveChannel ${stats.toJson()}');
        setState(() {
          isJoined = false;
          remoteUid.clear();
        });
      },
    ));
  }

  _joinChannel() async {
    if (defaultTargetPlatform == TargetPlatform.android) {
      await [Permission.microphone, Permission.camera].request();
    }

    await _engine.joinChannel(
        Config().agoraTestToken, widget.channelId!, null, 0);
    // await _engine.joinChannelWithUserAccount(
    //     Config().agoraTestToken, 'test123', widget.uid!);
  }

  _leaveChannel() async {
    await _engine.leaveChannel();
  }

  _switchCamera() {
    _engine.switchCamera().then((value) {
      setState(() {
        switchCamera = !switchCamera;
      });
    }).catchError((err) {
      // logSink.log('switchCamera $err');
    });
  }

  _switchRender() {
    setState(() {
      switchRender = !switchRender;
      remoteUid = List.of(remoteUid.reversed);
    });
  }

  _toggleMute() async {
    setState(() {
      isMuted = !isMuted;
    });
    await _engine.muteLocalAudioStream(isMuted);
  }

  @override
  void initState() {
    super.initState();
    final sb = context.read<SignInBloc>();
    if (mounted) {
      context.read<FriendsBloc>().data.isNotEmpty
          ? print('data already loaded')
          : context.read<FriendsBloc>().getData(sb.uid, mounted);
    }

    _initEngine();
  }

  @override
  void dispose() {
    _descriptionCtrl.dispose();
    // _cameraController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;

    return WillPopScope(
      onWillPop: () async {
        await _leaveChannel();
        return Future.value(true);
      },
      child: SafeArea(
        child: Scaffold(
          body: _body(),
        ),
      ),
    );
  }

  _body() {
    return Stack(
      children: [
        _renderVideo(),
        // Image.asset(
        //   'assets/images/livestream_bg.png',
        //   width: width,
        //   height: height,
        //   fit: BoxFit.cover,
        // ),
        _header(),
        widget.owner == false
            ? Container()
            : Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: const EdgeInsets.only(top: 16.0, right: 4),
                  child: IconButton(
                      onPressed: () {
                        _switchCamera();
                      },
                      icon: Icon(
                        Icons.flip_camera_ios_outlined,
                        color: Config().whiteColor,
                      )),
                ),
              ),
        _bottom(),
        isLoading
            ? Container(
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            : Container(),
      ],
    );
  }

  _renderVideo() {
    return Stack(
      children: [
        widget.owner == true
            ? SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: (defaultTargetPlatform == TargetPlatform.android ||
                        defaultTargetPlatform == TargetPlatform.iOS)
                    ? const rtc_local_view.SurfaceView(
                        zOrderMediaOverlay: true,
                        zOrderOnTop: true,
                      )
                    : const rtc_local_view.TextureView(),
              )
            : SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: (isJoined &&
                            defaultTargetPlatform == TargetPlatform.android ||
                        isJoined && defaultTargetPlatform == TargetPlatform.iOS)
                    ? rtc_remote_view.SurfaceView(
                        uid: remoteUid.isEmpty ? 2 : remoteUid[0],
                        channelId: widget.channelId!,
                        // channelId: _controller.text,
                      )
                    : rtc_remote_view.TextureView(
                        uid: remoteUid.isEmpty ? 2 : remoteUid[0],
                        channelId: widget.channelId!,
                        // channelId: _controller.text,
                      ),
              ),
        // Align(
        //   alignment: Alignment.topLeft,
        //   child: SingleChildScrollView(
        //     scrollDirection: Axis.horizontal,
        //     child: Row(
        //       children: List.of(remoteUid.map(
        //         (e) => GestureDetector(
        //           onTap: _switchRender,
        //           child: Padding(
        //             padding: const EdgeInsets.only(top: 80, left: 16),
        //             child: SizedBox(
        //               width: 120,
        //               height: 150,
        //               child: (isJoined &&
        //                           defaultTargetPlatform ==
        //                               TargetPlatform.android ||
        //                       isJoined &&
        //                           defaultTargetPlatform == TargetPlatform.iOS)
        //                   ? rtc_remote_view.SurfaceView(
        //                       uid: e,
        //                       channelId: widget.channelId!,
        //                       // channelId: _controller.text,
        //                     )
        //                   : rtc_remote_view.TextureView(
        //                       uid: e,
        //                       channelId: widget.channelId!,
        //                       // channelId: _controller.text,
        //                     ),
        //             ),
        //           ),
        //         ),
        //       )),
        //     ),
        //   ),
        // )
      ],
    );
  }

  _header() {
    final sb = context.read<SignInBloc>();

    return Container(
      width: width,
      height: 70,
      margin: const EdgeInsets.only(left: 8, right: 16, top: 16),
      alignment: Alignment.centerLeft,
      child: Row(
        children: [
          IconButton(
            onPressed: () async {
              await _leaveChannel();
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Config().whiteColor,
            ),
          ),
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  sb.name!,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().whiteColor),
                ),
                // Privacy (Public, Friends, Friends of friends, Only me)
                widget.owner == false
                    ? Container()
                    : GestureDetector(
                        onTap: () {
                          _showPrivacySheet(context);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 8),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: Config().text4Color,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            children: [
                              SvgPicture.asset('assets/images/public.svg'),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8),
                                child: Text(
                                  _privacy.tr(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Config().text90Color),
                                ),
                              ),
                              SvgPicture.asset(
                                  'assets/images/arrow_drop_down.svg'),
                            ],
                          ),
                        ),
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _bottom() {
    final fb = context.watch<FriendsBloc>();
    final sb = context.read<SignInBloc>();

    return widget.owner == false
        ? Container()
        : Align(
            alignment: Alignment.bottomLeft,
            child: SizedBox(
              height: 140,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  isLive
                      ? Container()
                      : ListTile(
                          onTap: () {
                            _showDescriptionSheet(context);
                          },
                          dense: true,
                          visualDensity: VisualDensity(vertical: -3),
                          tileColor: Config().transparent,
                          leading: Icon(Icons.list, color: Config().whiteColor),
                          title: Text(
                            'tap_to_add_description'.tr(),
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Config().whiteColor),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: Config().whiteColor,
                            size: 15,
                          ),
                        ),
                  isLive
                      ? Container()
                      : ListTile(
                          onTap: () {
                            _showFriendSheet(context, fb, sb);
                          },
                          dense: true,
                          visualDensity: VisualDensity(vertical: -1),
                          leading: Icon(Icons.group_add_outlined,
                              color: Config().whiteColor),
                          title: Text(
                            'bring_friend'.tr(),
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Config().whiteColor),
                          ),
                          trailing: Icon(
                            Icons.arrow_forward_ios,
                            color: Config().whiteColor,
                            size: 15,
                          ),
                        ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: ElevatedButton(
                      onPressed: () async {
                        if (isLive == false) {
                          await _joinChannel();
                          _sendLiveFcm(sb.name!, sb.imageUrl!);
                          setState(() {
                            isLive = !isLive;
                          });
                        } else {
                          await _leaveChannel();
                          _sendEndLiveFcm(sb.name!, sb.imageUrl!);
                          setState(() {
                            isLive = !isLive;
                          });
                          // show bottom sheet
                          _showEndLiveSheet(context);
                        }
                      },
                      style: ElevatedButton.styleFrom(
                          minimumSize: const Size.fromHeight(40)),
                      child: Text(
                        isLive == false ? 'go_live'.tr() : 'end_live'.tr(),
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
  }

  // Bottom sheet for post privacy
  _showPrivacySheet(ctx) {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () {
                if (_privacy != 'public') {
                  _privacy = 'public';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/public.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // friends
            InkWell(
              onTap: () {
                if (_privacy != 'friends') {
                  _privacy = 'friends';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/person_remove.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // only me
            InkWell(
              onTap: () {
                if (_privacy != 'only_me') {
                  _privacy = 'only_me';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/private_connectivity.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // Bottom sheet to add description
  _showDescriptionSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back),
                  ),
                  Text(
                    'description'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: TextField(
                controller: _descriptionCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  hintText: 'tap_to_add_description'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                maxLines: 4,
              ),
            ),
          ],
        );
      },
    );
  }

  // Bottom sheet to add friend
  _showFriendSheet(ctx, FriendsBloc fb, SignInBloc sb) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setState) {
            print('===== bottom sheet setstate =====');
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pop(ctx);
                        },
                        icon: Icon(Icons.arrow_back),
                      ),
                      Text(
                        'invite_people_on_camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ),
                fb.hasData == false
                    ? Container()
                    : ListView.separated(
                        // key: PageStorageKey(widget.category),
                        padding: const EdgeInsets.only(top: 8),
                        physics: AlwaysScrollableScrollPhysics(),
                        itemCount: fb.data.isNotEmpty ? fb.data.length + 1 : 5,
                        separatorBuilder: (BuildContext context, int index) =>
                            SizedBox(
                          height: 3,
                        ),
                        shrinkWrap: true,
                        itemBuilder: (_, int index) {
                          if (index < fb.data.length) {
                            return ListTile(
                              onTap: () {
                                print('===== bottom sheet close =====');
                              },
                              leading: CircleAvatar(
                                radius: 20,
                                backgroundColor: Colors.grey[300],
                                backgroundImage: CachedNetworkImageProvider(
                                    fb.data[index].avatar!),
                              ),
                              title: Text(
                                fb.data[index].name!,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: Config().text90Color),
                              ),
                              trailing: ElevatedButton(
                                onPressed: () {
                                  if (fb.data[index].liveInvited!
                                      .contains(sb.uid)) {
                                    fb.data[index].liveInvited!.remove(sb.uid!);
                                    if (inviteUsers.contains(fb.data[index])) {
                                      inviteUsers.remove(fb.data[index]);
                                    }
                                  } else {
                                    fb.data[index].liveInvited!.add(sb.uid!);
                                    if (!inviteUsers.contains(fb.data[index])) {
                                      inviteUsers.add(fb.data[index]);
                                    }
                                  }
                                  setState(
                                    () {},
                                  );
                                  // Navigator.pop(ctx);
                                },
                                style: ElevatedButton.styleFrom(
                                    primary: fb.data[index].liveInvited!
                                            .contains(sb.uid)
                                        ? Config().primary10Color
                                        : Config().appColor),
                                child: Text(
                                  fb.data[index].liveInvited!.contains(sb.uid)
                                      ? 'sent'.tr()
                                      : 'invite'.tr(),
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Config().whiteColor),
                                ),
                              ),
                            );
                          }
                          return Opacity(
                            opacity: fb.isLoading ? 1.0 : 0.0,
                            child: fb.lastVisible == null
                                ? LoadingCard(height: 80)
                                : const Center(
                                    child: SizedBox(
                                        width: 32.0,
                                        height: 32.0,
                                        child: CupertinoActivityIndicator()),
                                  ),
                          );
                        },
                      ),
              ],
            );
          },
        );
      },
    );
  }

  // Bottom sheet to end stream
  _showEndLiveSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back),
                  ),
                  Text(
                    'invite_people_on_camera'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: Config().text90Color),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _post();
                      },
                      child: Text(
                        'post_now'.tr(),
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Config().primary10Color),
                      child: Text(
                        'back'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text90Color),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        );
      },
    );
  }

  _post() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);

    int postType = 5;

    setState(() {
      isLoading = true;
    });

    try {
      // String fileName = DateTime.now().microsecondsSinceEpoch.toString();

      // var uint8list = await _screenshotController.capture();
      // final direcotry = await getApplicationDocumentsDirectory();
      // final imagePath = await File('${direcotry.path}/$fileName.png').create();
      // await imagePath.writeAsBytes(uint8list!);

      // var imageUrl = await uploadImageFile(imagePath);

      // Create time now
      DateTime now = DateTime.now();
      DateTime utc = now.toUtc();
      var timestamp = formatISOTime(utc);

      Map<String, Object?> poll = {};
      Map<String, dynamic> location = {};
      await AppService().checkInternet().then((hasInternet) async {
        if (hasInternet == false) {
          openSnacbar(context, 'check your internet connection!'.tr());
        } else {
          pb
              .createPost(sb, postType, [], _descriptionCtrl.text, _privacy,
                  timestamp, '', poll, location, '', {}, false, [], {})
              .then((value) async {
            setState(() {
              isLoading = false;
            });
            if (pb.hasError == false) {
              openToast('You created a post');
              // await _sendFcmPost(sb.name!, sb.imageUrl!, pb.post!.postId!);
              Navigator.pop(context, pb.post);
            }
          });
        }
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  _sendLiveFcm(String name, String avatar) async {
    // final user = await ub.getWUser(p.uid);
    inviteUsers.forEach((user) async {
      print("===== fcm token ${user.fcmToken} =====");
      String body = "$name sent invitation to you on Live Stream";
      var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
      var res = await func.call(<String, dynamic>{
        "targetDevices": [user.fcmToken],
        "messageTitle": "Live stream invitation",
        "messageBody": body,
      });

      print(
          "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

      // add notification
      if (res.data as bool == true) {
        _updateNotification(user.uid, body, 3, '', avatar);
      }
    });
  }

  _sendEndLiveFcm(String name, String avatar) async {
    // final user = await ub.getWUser(p.uid);
    inviteUsers.forEach((user) async {
      print("===== fcm token ${user.fcmToken} =====");
      String body = "Live stream ended from $name";
      var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
      var res = await func.call(<String, dynamic>{
        "targetDevices": [user.fcmToken],
        "messageTitle": "Live stream ended",
        "messageBody": body,
      });

      print(
          "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

      // add notification
      if (res.data as bool == true) {
        _updateNotification(user.uid, body, 4, '', avatar);
      }
    });
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  Future<String> uploadImageFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('LiveStream Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }
}
