import 'package:flutter/material.dart';
import 'package:twiddle/pages/post/live/live_channel_video.dart';
import 'package:twiddle/utils/next_screen.dart';

class TempLivePage extends StatefulWidget {
  const TempLivePage({super.key});

  @override
  State<TempLivePage> createState() => _TempLivePageState();
}

class _TempLivePageState extends State<TempLivePage> {
  var channelCtrl = TextEditingController();
  bool isBroadCaster = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: _body(),
      ),
    );
  }

  _body() {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      alignment: Alignment.center,
      child: Column(
        children: [
          TextFormField(
            controller: channelCtrl,
            decoration: InputDecoration(hintText: 'channel id'),
          ),
          CheckboxListTile(
            value: isBroadCaster,
            onChanged: (value) {
              setState(() {
                isBroadCaster = value!;
              });
            },
          ),
          ElevatedButton(
              onPressed: () {
                if (channelCtrl.text.isNotEmpty) {
                  nextScreen(
                    context,
                    JoinChannelVideo(
                      isBroadcater: isBroadCaster,
                      channelId: channelCtrl.text,
                    ),
                  );
                }
              },
              child: Text('Join')),
        ],
      ),
    );
  }
}
