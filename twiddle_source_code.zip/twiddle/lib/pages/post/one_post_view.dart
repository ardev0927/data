import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/card1.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/cards/video_card.dart';
import 'package:twiddle/models/post.dart';
import 'package:twiddle/utils/convert_time_ago.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../blocs/group_bloc.dart';
import '../../blocs/notification_bloc.dart';
import '../../blocs/post_friends_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../config/config.dart';
import '../../models/group.dart';
import '../../services/app_service.dart';
import '../../utils/enums.dart';
import '../../utils/format_time.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../group/managed_group_page.dart';
import '../group/not_joined_group_page.dart';
import '../profile/profile_main_page.dart';
import '../profile/show_photo_page.dart';
import '../profile/user_profile_page.dart';
import '../tag_friends/tag_friends_page.dart';
import 'create_post_page.dart';
import 'view_comments_page.dart';
import 'view_likes_page.dart';
import 'view_shares_page.dart';

class OnePostView extends StatefulWidget {
  const OnePostView({super.key, required this.postId});

  final String? postId;

  @override
  State<OnePostView> createState() => _OnePostViewState();
}

class _OnePostViewState extends State<OnePostView> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final String _orderBy = 'timestamp';
  List<Group> _groups = [];
  bool isLoading = true;

  Post? post;
  Group? group;

  @override
  void initState() {
    getPostFromId(widget.postId!);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('post'.tr()),
      ),
      body: isLoading == true
          ? Container(
              child: Center(
                child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: CupertinoActivityIndicator()),
              ),
            )
          : ListView(
              children: [
                postWidget(),
              ],
            ),
    );
  }

  postWidget() {
    final sb = context.read<SignInBloc>();
    final pb = context.read<PostFriendsBloc>();
    final ub = context.read<UserBlock>();

    return post!.mediaType == 2
        // ? VideoCard(
        ? PostVideoCard(
            d: post!,
            time: convertToAgo(post!.timestamp!),
            heroTag: 'onepost',
            onLikePressed: () {},
            onLikesPressed: () {},
            isLiked: post!.likes!.contains(sb.uid),
            onSharePressed: () {},
            onSharesPressed: () {},
            isShared: false,
            onCommentPressed: () {},
            onCommentsPressed: () {},
            onPhotoTap: () {},
            onAvatarTap: () {})
        // : Card1(
        : PostCard(
            d: post!,
            time: convertToAgo(post!.timestamp!),
            heroTag: 'onepost',
            onLikePressed: () {
              if (sb.uid == post!.uid) {
                openToast('You can not like own post');
                return;
              }
              pb.setLike(sb.uid, post!).then((value) {
                if (pb.isLiked == true) {
                  post!.likes!.add(sb.uid!);
                  openToast('Liked Post');

                  // Notification
                  _sendFcmPost(ub, sb.uid!, sb.name!, sb.imageUrl!, post!,
                      ub.data!.fcmToken!, FcmType.react);
                } else {
                  post!.likes!.remove(sb.uid!);
                  openToast('Unliked Post');
                }
                setState(() {});
              });
            },
            onLikesPressed: () {
              nextScreen(context, ViewLikesPage(uids: post!.likes));
            },
            isLiked: post!.likes!.contains(sb.uid),
            onSharePressed: () {
              showShareSheet(context, post);
            },
            onSharesPressed: () {
              nextScreen(context, ViewSharesPage(uids: post!.shares));
            },
            isShared: post!.shares!.contains(sb.uid),
            onCommentPressed: () async {
              int ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ViewCommentsPage(p: post)));
              if (ret != null) {
                post!.comments = ret;
                setState(() {});
              }
            },
            onCommentsPressed: () async {
              int ret = await Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ViewCommentsPage(p: post)));
              if (ret != null) {
                post!.comments = ret;
                setState(() {});
              }
            },
            onPhotoTap: () {
              nextScreen(context, ShowPhotoPage(p: post, changedArray: false));
            },
            onAvatarTap: () {
              if (sb.uid != post!.uid) {
                nextScreen(context, UserProfilePage(uid: post!.uid));
              } else {
                nextScreen(context, ProfileMainPage(uid: post!.uid));
              }
            },
            onArticleTap: () {
              if (post!.mediaType == 11) {
                launchUrl(Uri.parse(post!.article!));
              }
            },
            onTypeTap: () async {
              if (post!.feeling!.contains('with ') &&
                  post!.tagFriends!.isNotEmpty) {
                nextScreen(
                  context,
                  TagFriendsPage(tags: post!.tagFriends),
                );
              } else {
                var g = post!.group;
                if (g!.name != null) {
                  if (g.ownerUid == sb.uid) {
                    nextScreen(context, ManagedGroupPage(group: g));
                  } else {
                    var gb = context.read<GroupBloc>();
                    await gb.getGroup(g.id!).then((value) async {
                      if (gb.group!.members!.contains(sb.uid)) {
                        nextScreen(context, ManagedGroupPage(group: gb.group));
                      } else {
                        var ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    NotJoinedGroupPage(group: g)));
                        if (ret != null) {
                          post!.group = ret;
                        }
                      }
                    });
                  }
                }
              }
            },
            onSharedTap: () {
              nextScreen(
                context,
                OnePostView(postId: post!.sharedPost!.postId),
              );
            },
          );
  }

  Future getPostFromId(String postId) async {
    await firestore.collection('posts').doc(postId).get().then((value) {
      post = Post.fromFirestore(value);
      setState(() {
        isLoading = false;
      });
    });
  }

  _sendFcmPost(UserBlock ub, String uid, String name, String avatar, Post p,
      String fcmToken, int fcmType) async {
    final user = await ub.getWUser(p.uid);
    print("===== fcm token ${user!.fcmToken} =====");
    String body = '';
    String title = '';
    if (fcmType == FcmType.react) {
      title = "Reaction post";
      body = "$name reacted to ${p.username} Post.";
    } else if (fcmType == FcmType.tag) {
      title = "Post tag";
      body = "You received tag post from ${p.username}.";
    }

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [user.fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(user.uid, body, fcmType, p.postId, avatar);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  showShareSheet(BuildContext ctx, Post? p) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Share to feed
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (p!.mediaType != PostType.share) {
                  var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CreatePostPage(type: PostType.share, p: p),
                    ),
                  );
                  if (ret != null) {
                    refreshPage();
                    // setState(() {});
                  }
                  // nextScreen(context, CreatePostPage(p: p));
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.feed_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_feed'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Share to group
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                selectGroupDialog(p!);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.groups_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_group'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  refreshPage() {
    final pb = context.read<PostFriendsBloc>();
    final sb = context.read<SignInBloc>();

    pb.onRefresh(sb.uid, mounted, _orderBy);

    setState(() {});
  }

  selectGroupDialog(Post p) {
    showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
          contentPadding: const EdgeInsets.all(16),
          title: Text(
            'select_group'.tr(),
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          children: [
            SizedBox(
              height: 300,
              width: MediaQuery.of(context).size.width,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: _groups.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: () async {
                      group = _groups[index];
                      // setState(() {
                      //   isGroupPost = true;
                      // });
                      Navigator.pop(context);
                      if (p.mediaType != PostType.share ||
                          p.mediaType != PostType.sharegroup) {
                        var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CreatePostPage(
                              type: PostType.sharegroup,
                              p: p,
                              g: group,
                            ),
                          ),
                        );
                        if (ret != null) {
                          refreshPage();
                          // setState(() {});
                        }
                      }
                    },
                    title: Text(_groups[index].name!),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
