import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../blocs/posts_bloc.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';

deletePost(BuildContext context, Post p) async {
  print('====== post id is ${p.postId} =====');
  final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
  await AppService().checkInternet().then((hasInternet) async {
    if (hasInternet == false) {
      openSnacbar(context, 'check your internet connection!'.tr());
    } else {
      print('===== post count is ${pb.data.length} =====');
      pb.deletePost(p).then((value) {
        if (pb.hasError == false) {
          pb.data.remove(p);
          openToast('Post is deleted');
        } else {
          openSnacbar(context, 'Something went wrong');
        }
        // setState(() {});
      });
    }
  });
}
