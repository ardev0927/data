import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';

import '../../blocs/posts_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';

class PostPollPage extends StatefulWidget {
  const PostPollPage({
    super.key,
    required this.question,
    required this.option1,
    required this.option2,
  });
  final String? question;
  final String? option1;
  final String? option2;

  @override
  State<PostPollPage> createState() => _PostPollPageState();
}

class _PostPollPageState extends State<PostPollPage> {
  String _privacy = 'public';
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, null);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'post'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _post();
            },
            child: Text(
              'post'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    return Stack(
      children: [
        Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sb.name!,
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Config().text100Color),
                        ),
                        // Privacy (Public, Friends, Friends of friends, Only me)
                        GestureDetector(
                          onTap: () {
                            _showPrivacySheet(context);
                          },
                          child: Container(
                            margin: const EdgeInsets.only(top: 8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: Config().text4Color,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/images/public.svg'),
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 8),
                                  child: Text(
                                    _privacy.tr(),
                                    style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        color: Config().text90Color),
                                  ),
                                ),
                                SvgPicture.asset(
                                    'assets/images/arrow_drop_down.svg'),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // Content
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              color: Config().text4Color,
              width: MediaQuery.of(context).size.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.question!,
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Config().text90Color),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8)),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            widget.option1!,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'votes'.tr(),
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text80Color),
                            ),
                            Text(
                              '0%',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text80Color),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8)),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            widget.option2!,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'votes'.tr(),
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text80Color),
                            ),
                            Text(
                              '0%',
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Config().text80Color),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            // const Spacer(),
            // Padding(
            //   padding: const EdgeInsets.all(16.0),
            //   child: ElevatedButton(
            //     onPressed: () {},
            //     style: ElevatedButton.styleFrom(
            //       shape: RoundedRectangleBorder(
            //           borderRadius: BorderRadius.circular(8)),
            //       minimumSize: const Size.fromHeight(50),
            //     ),
            //     child: Text(
            //       'edit'.tr(),
            //       style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            //     ),
            //   ),
            // ),
          ],
        ),
        _isLoading == true
            ? Container(
                child: Center(
                  child: CircularProgressIndicator(),
                ),
              )
            : Container(),
      ],
    );
  }

  // Bottom sheet for post privacy
  _showPrivacySheet(ctx) {
    showModalBottomSheet(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // public
            InkWell(
              onTap: () {
                if (_privacy != 'public') {
                  _privacy = 'public';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/public.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // friends
            InkWell(
              onTap: () {
                if (_privacy != 'friends') {
                  _privacy = 'friends';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/person_remove.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // only me
            InkWell(
              onTap: () {
                if (_privacy != 'only_me') {
                  _privacy = 'only_me';
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/private_connectivity.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  _post() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);

    var data = {
      'question': widget.question,
      'option1': widget.option1,
      'option2': widget.option2,
      'option1_votes': 0,
      'option2_votes': 0,
      'votes': 0,
      'is_voted': false,
    };

    setState(() {
      _isLoading = true;
    });
    DateTime now = DateTime.now().toUtc();
    String timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb
            .createPost(sb, 8, [], '', _privacy, timestamp, '', data, {}, '',
                {}, false, [], {})
            .then((value) {
          setState(() {
            _isLoading = false;
          });
          if (pb.hasError == false) {
            openToast('You created a post');
            Navigator.pop(context, pb.post);
          }
        });
      }
    });
  }
}
