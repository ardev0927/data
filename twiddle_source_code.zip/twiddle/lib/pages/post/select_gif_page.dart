import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/gifs_bloc.dart';
import 'package:twiddle/models/gif.dart';

import '../../config/config.dart';
import '../../utils/cached_image_with_dark.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class SelectGifPage extends StatefulWidget {
  const SelectGifPage({super.key});

  @override
  State<SelectGifPage> createState() => _SelectGifPageState();
}

class _SelectGifPageState extends State<SelectGifPage> {
  ScrollController? controller;
  final _searchCtrl = TextEditingController();
  final String _orderBy = 'timestamp';

  @override
  void initState() {
    controller = new ScrollController()..addListener(_scrollListener);
    context.read<GifsBloc>().data.isNotEmpty
        ? print('data already loaded')
        : context.read<GifsBloc>().getData(mounted, _orderBy);

    super.initState();
  }

  void _scrollListener() {
    final db = context.read<GifsBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<GifsBloc>().setLoading(true);
        context.read<GifsBloc>().getData(mounted, _orderBy);
      }
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gb = context.watch<GifsBloc>();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, null);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'select_gif'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: RefreshIndicator(
        child: gb.hasData == false
            ? ListView(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.35,
                  ),
                  EmptyPage(
                      icon: Icons.category_rounded,
                      message: 'no categories found'.tr(),
                      message1: ''),
                ],
              )
            : GridView.builder(
                controller: controller,
                padding:
                    EdgeInsets.only(left: 10, right: 10, top: 15, bottom: 15),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                    childAspectRatio: 1),
                itemCount: gb.data.length != 0 ? gb.data.length + 1 : 10,
                itemBuilder: (_, int index) {
                  if (index < gb.data.length) {
                    return _ItemList(d: gb.data[index], index: index);
                  }
                  return Opacity(
                    opacity: gb.isLoading ? 1.0 : 0.0,
                    child: gb.lastVisible == null
                        ? LoadingCard(height: null)
                        : Center(
                            child: SizedBox(
                                width: 32.0,
                                height: 32.0,
                                child: new CupertinoActivityIndicator()),
                          ),
                  );
                },
              ),
        onRefresh: () async {
          context.read<GifsBloc>().onRefresh(mounted, _orderBy);
        },
      ),
    );
  }
}

class _ItemList extends StatelessWidget {
  final Gif d;
  final int index;
  const _ItemList({Key? key, required this.d, required this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              boxShadow: <BoxShadow>[
                BoxShadow(
                    blurRadius: 10,
                    offset: Offset(0, 3),
                    color: Theme.of(context).shadowColor)
              ]),
          child: Stack(
            children: [
              Hero(
                tag: 'gif$index',
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: CustomCacheImageWithDarkFilterBottom(
                      imageUrl: d.gifUrl, radius: 5.0),
                ),
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  margin: EdgeInsets.only(left: 15, bottom: 15, right: 10),
                  child: Text(
                    d.name!,
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        letterSpacing: -0.6),
                  ),
                ),
              )
            ],
          )),
      onTap: () {
        Navigator.pop(context, d);
      },
    );
  }
}
