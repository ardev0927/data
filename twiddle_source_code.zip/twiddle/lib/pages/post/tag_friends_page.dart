import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/cards/friends_card3.dart';
import 'package:twiddle/models/user.dart';

import '../../blocs/friends_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../cards/friends_card.dart';
import '../../config/config.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class TagFriendsPage extends StatefulWidget {
  const TagFriendsPage({super.key});

  @override
  State<TagFriendsPage> createState() => _TagFriendsPageState();
}

class _TagFriendsPageState extends State<TagFriendsPage> {
  final _searchCtrl = TextEditingController();
  List<WUser> _users = [];

  @override
  void initState() {
    final sb = context.read<SignInBloc>();
    super.initState();
    if (mounted) {
      context.read<FriendsBloc>().getData(sb.uid, mounted);
      // context.read<FriendsBloc>().data.isNotEmpty
      //     ? print('data already loaded')
      //     : context.read<FriendsBloc>().getData(sb.uid, mounted);
    }
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'tab_prople'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () {
              if (_users.isNotEmpty) {
                Navigator.pop(context, _users);
              }
            },
            child: Text(
              'send'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    final fb = context.watch<FriendsBloc>();
    final sb = context.read<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        context.read<FriendsBloc>().onRefresh(sb.uid, mounted);
      },
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  // enabledBorder: ,
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Config().text4Color)),
                  fillColor: Config().text4Color,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  prefixIcon:
                      Icon(Icons.search_outlined, color: Config().text90Color),
                  hintText: 'search'.tr(),
                  hintStyle: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: Text(
                  'all_friends'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
              ),
              fb.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.40,
                        ),
                        EmptyPage(
                            icon: Icons.person_off_outlined,
                            message: 'no_friends'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      // key: PageStorageKey(widget.category),
                      padding: const EdgeInsets.only(top: 8),
                      physics: AlwaysScrollableScrollPhysics(),
                      itemCount: fb.data.length != 0 ? fb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 3,
                      ),
                      shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < fb.data.length) {
                          return FriendsCard3(
                            d: fb.data[index],
                            heroTag: 'friendcard3$index',
                            // setState: setState(() {}),
                            isSelected: isSelectedUser(fb.data[index]),
                            onChanged: (value) {
                              print('===== onChanged =====');
                              changedUser(value!, fb.data[index]);
                            },
                          );
                        }
                        return Opacity(
                          opacity: fb.isLoading ? 1.0 : 0.0,
                          child: fb.lastVisible == null
                              ? LoadingCard(height: 80)
                              : const Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ],
          ),
        ),
      ),
    );
  }

  changedUser(bool value, WUser user) {
    if (value && !_users.contains(user)) {
      _users.add(user);
    } else if (!value && _users.contains(user)) {
      _users.remove(user);
    }
    setState(() {});
  }

  isSelectedUser(WUser user) {
    if (_users.contains(user)) {
      return true;
    } else {
      return false;
    }
  }
}
