import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/comment_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/comment_card.dart';
import 'package:twiddle/utils/toast.dart';

import '../../config/config.dart';
import '../../models/post.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class ViewCommentsPage extends StatefulWidget {
  ViewCommentsPage({super.key, required this.p});
  Post? p;

  @override
  State<ViewCommentsPage> createState() => _ViewCommentsPageState();
}

class _ViewCommentsPageState extends State<ViewCommentsPage> {
  TextEditingController commentCtrl = TextEditingController();
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    context.read<CommentBloc>().getData(widget.p!.postId, _orderBy, mounted);
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.read<SignInBloc>();
    final cb = context.watch<CommentBloc>();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context, cb.data.length);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Config().text100Color,
            )),
        title: Text(
          'comments'.tr(),
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                context
                    .read<CommentBloc>()
                    .onRefresh(widget.p!.postId, _orderBy, mounted);
              },
              child: cb.hasData == false
                  ? ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.20,
                        ),
                        EmptyPage(
                            icon: Icons.comment_outlined,
                            message: 'post_has_no_comments'.tr(),
                            message1: ''),
                      ],
                    )
                  : ListView.separated(
                      // key: PageStorageKey(widget.category),
                      padding: const EdgeInsets.only(top: 8),
                      physics: AlwaysScrollableScrollPhysics(),
                      itemCount: cb.data.length != 0 ? cb.data.length + 1 : 5,
                      separatorBuilder: (BuildContext context, int index) =>
                          SizedBox(
                        height: 3,
                      ),
                      shrinkWrap: true,
                      itemBuilder: (_, int index) {
                        if (index < cb.data.length) {
                          return CommentCard(
                            d: cb.data[index],
                            heroTag: 'comment$index',
                            onLikePressed: () {},
                            onReplyPressed: () {},
                          );
                        }
                        return Opacity(
                          opacity: cb.isLoading ? 1.0 : 0.0,
                          child: cb.lastVisible == null
                              ? LoadingCard(height: 40)
                              : const Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
            ),
          ),
          Container(
            padding: const EdgeInsets.only(left: 16, top: 8, bottom: 8),
            height: 60,
            width: double.infinity,
            color: Config().text8Color,
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: commentCtrl,
                    decoration: InputDecoration(
                      // enabledBorder: ,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Colors.white)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: BorderSide(color: Colors.white)),
                      fillColor: Colors.white,
                      filled: true,
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 12),
                      hintText: 'write_here'.tr(),
                      hintStyle: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    if (commentCtrl.text.isEmpty) {
                      openToast('Please enter comment');
                      return;
                    }
                    await cb
                        .addComment(widget.p, sb.uid, sb.name, sb.imageUrl,
                            commentCtrl.text)
                        .then((value) {
                      commentCtrl.clear();
                      context
                          .read<CommentBloc>()
                          .onRefresh(widget.p!.postId, _orderBy, mounted);
                    });

                    // _addComment(cb);
                  },
                  child: SvgPicture.asset(
                    'assets/images/send_1.svg',
                    width: 20,
                    height: 20,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _addComment(CommentBloc cb) {}
}
