import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/likes_bloc.dart';
import 'package:twiddle/config/config.dart';

import '../../cards/likes_card.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class ViewLikesPage extends StatefulWidget {
  const ViewLikesPage({super.key, required this.uids});
  final List<String>? uids;

  @override
  State<ViewLikesPage> createState() => _ViewLikesPageState();
}

class _ViewLikesPageState extends State<ViewLikesPage> {
  @override
  void initState() {
    super.initState();

    context.read<LikesBloc>().getLikes(widget.uids!, mounted);
    // if (mounted) {
    //   context.read<LikesBloc>().data.isNotEmpty
    //       ? print('data already loaded')
    //       : context.read<LikesBloc>().getLikes(widget.uids!, mounted);
    // }
  }

  @override
  Widget build(BuildContext context) {
    final lb = context.watch<LikesBloc>();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Config().text100Color,
            )),
        title: Text(
          'likes'.tr(),
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(top: 16, right: 16),
            child: Text(
              '${widget.uids!.length} ${'likes'.tr()}'.tr(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          context.read<LikesBloc>().onRefresh(widget.uids!, mounted);
        },
        child: lb.hasData == false
            ? ListView(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.20,
                  ),
                  EmptyPage(
                      icon: Icons.thumb_up_outlined,
                      message: 'post_has_no_likes'.tr(),
                      message1: ''),
                ],
              )
            : ListView.separated(
                // key: PageStorageKey(widget.category),
                padding: const EdgeInsets.only(top: 8),
                physics: AlwaysScrollableScrollPhysics(),
                itemCount: lb.data.length != 0 ? lb.data.length + 1 : 5,
                separatorBuilder: (BuildContext context, int index) => SizedBox(
                  height: 3,
                ),
                shrinkWrap: true,
                itemBuilder: (_, int index) {
                  if (index < lb.data.length) {
                    return LikesCard(
                      d: lb.data[index],
                      heroTag: 'likes$index',
                    );
                  }
                  return Opacity(
                    opacity: lb.isLoading ? 1.0 : 0.0,
                    child: lb.lastVisible == null
                        ? LoadingCard(height: 40)
                        : const Center(
                            child: SizedBox(
                                width: 32.0,
                                height: 32.0,
                                child: CupertinoActivityIndicator()),
                          ),
                  );
                },
              ),
      ),
    );
  }
}
