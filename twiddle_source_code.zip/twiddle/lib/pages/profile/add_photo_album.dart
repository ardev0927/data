import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/album_bloc.dart';
import 'package:twiddle/blocs/posts_bloc.dart';
import 'package:twiddle/models/album.dart';
import 'package:twiddle/pages/profile/show_album_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:uuid/uuid.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image.dart';
import '../../utils/cached_image_with_dark.dart';
import '../../utils/snacbar.dart';

class AddPhotoAlbum extends StatefulWidget {
  AddPhotoAlbum({super.key, required this.album});

  Album? album;

  @override
  State<AddPhotoAlbum> createState() => _AddPhotoAlbumState();
}

class _AddPhotoAlbumState extends State<AddPhotoAlbum> {
  Album? p;
  List<String> _albums = [];
  List<File> _newPhotos = [];
  String firebasestorage = 'https://firebasestorage.googleapis.com';
  bool _isSaving = false;
  bool _isSaved = false;

  @override
  void initState() {
    super.initState();
    p = widget.album;
    print('===== Album ID: ${p!.id} =====');
    _albums.addAll(p!.images!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, _isSaved);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          p!.name!,
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              _savePhotos();
            },
            child: Text(
              'save'.tr(),
              style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  color: Config().text90Color),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          GridView.builder(
            padding:
                const EdgeInsets.only(left: 10, right: 10, top: 15, bottom: 15),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 4,
                crossAxisSpacing: 4,
                childAspectRatio: 0.9),
            itemCount: _albums.isNotEmpty ? _albums.length + 1 : 5,
            itemBuilder: (_, int index) {
              print('===== photo count is ${_albums.length} =====');
              if (index == 0) {
                return AddPhotoWidget(
                  onTap: () async {
                    var result = await pickImage();
                    if (result.isNotEmpty) {
                      setState(() {
                        _newPhotos = result.map((e) => File(e)).toList();
                        // _newPhotos.addAll(result);
                        _albums.addAll(result);
                      });
                    }
                  },
                );
              }
              // print('===== image path: ${_albums[index - 1]} =====');
              return InkWell(
                onTap: () {
                  List<String> urls = [];
                  for (int i = 0; i < p!.images!.length; i++) {
                    if (index - 1 == i) {
                      urls.insert(0, p!.images![i]);
                    } else if (index - 1 < i) {
                      urls.insert(i - (index - 1), p!.images![i]);
                    } else {
                      urls.add(p!.images![i]);
                    }
                  }
                  nextScreen(context, ShowAlbumPage(album: p));
                  // nextScreen(context,
                  //     ShowPhotoPage(p: p, changedArray: true, photos: urls));
                },
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                            blurRadius: 10,
                            offset: Offset(0, 3),
                            color: Theme.of(context).shadowColor)
                      ]),
                  child: Stack(
                    children: [
                      Hero(
                        tag: 'photoalbum$index',
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height,
                          child: _albums[index - 1].contains(firebasestorage)
                              ? CustomCacheImage(
                                  imageUrl: _albums[index - 1], radius: 0.0)
                              : Image.file(File(_albums[index - 1]),
                                  fit: BoxFit.cover),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          Container(
            child: Center(
              child: _isSaving ? CircularProgressIndicator() : Text(''),
            ),
          ),
        ],
      ),
    );
  }

  Future<List<String>> pickImage() async {
    List<String> images = [];
    var xfiles = await ImagePicker().pickMultiImage();
    if (xfiles != null) {
      xfiles.forEach((element) {
        images.add(File(element.path).path);
      });
      // if (xfiles.isNotEmpty) {
      //   images.addAll(await uploadFiles(files));
      // }
    } else {
      print('===== No images selected! =====');
    }
    return images;
  }

  Future<List<String>> uploadFiles(List<File> images) async {
    var imageUrls = await Future.wait(images.map((e) => uploadFile(e)));
    print('===== upload done =====');
    return imageUrls;
  }

  Future<String> uploadFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _savePhotos() async {
    final AlbumBloc ab = Provider.of<AlbumBloc>(context, listen: false);
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          _isSaving = true;
        });
        var images = await uploadFiles(_newPhotos);
        if (images.isEmpty) {
          openToast('Please add photos to album');
          return;
        }

        ab.updateImages(sb.uid, p!.id!, images).then((value) {
          setState(() {
            _isSaving = false;
          });
          if (ab.hasError == false) {
            openToast('You added photos to album successfully');
            _isSaved = true;
            // Navigator.pop(context, pb.post);
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}

class AddPhotoWidget extends StatelessWidget {
  const AddPhotoWidget({Key? key, required this.onTap}) : super(key: key);
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: InkWell(
            onTap: onTap,
            child: Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: Config().text4Color,
                  ),
                  child: Center(
                    child: SvgPicture.asset('assets/images/plus_large.svg'),
                  ),
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            'add_photos'.tr(),
            style: TextStyle(
                fontSize: 12,
                color: Config().text90Color,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.6),
          ),
        ),
      ],
    );
  }
}
