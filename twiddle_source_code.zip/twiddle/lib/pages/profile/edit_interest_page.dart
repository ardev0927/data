import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';

import '../../blocs/interest_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class EditInterestPage extends StatefulWidget {
  const EditInterestPage({super.key, required this.interests});
  final List<String>? interests;

  @override
  State<EditInterestPage> createState() => _EditInterestPageState();
}

class _EditInterestPageState extends State<EditInterestPage> {
  ScrollController? controller;
  List<String> interests = [];

  @override
  void initState() {
    super.initState();

    interests.addAll(widget.interests!);

    controller = ScrollController()..addListener(_scrollListener);
    context.read<InterestBloc>().getData(mounted);
  }

  void _scrollListener() {
    final db = context.read<InterestBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<InterestBloc>().setLoading(true);
        context.read<InterestBloc>().getData(mounted);
      }
    }
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ib = context.watch<InterestBloc>();
    final sb = context.read<SignInBloc>();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, null);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'interests'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          context.read<InterestBloc>().onRefresh(mounted);
        },
        child: Column(
          children: [
            ib.hasData == false
                ? Expanded(
                    child: ListView(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.20,
                        ),
                        EmptyPage(
                            icon: Icons.interests_outlined,
                            message: 'you_have_no_interest'.tr(),
                            message1: ''),
                      ],
                    ),
                  )
                : Expanded(
                    child: GridView.builder(
                      controller: controller,
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2, childAspectRatio: 5),
                      itemCount: ib.data.length != 0 ? ib.data.length + 1 : 10,
                      itemBuilder: (_, int index) {
                        if (index < ib.data.length) {
                          return GestureDetector(
                            onTap: () {
                              if (interests.contains(ib.data[index].name)) {
                                interests.remove(ib.data[index].name);
                              } else {
                                interests.add(ib.data[index].name!);
                              }
                              setState(() {});
                            },
                            child: Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    width: 0.5, color: Config().text8Color),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Config().text8Color,
                                      image: DecorationImage(
                                          image: CachedNetworkImageProvider(
                                              ib.data[index].image!)),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 12),
                                    child: Text(
                                      ib.data[index].name!,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          color: Config().text90Color),
                                    ),
                                  ),
                                  const Spacer(),
                                  interests.contains(ib.data[index].name)
                                      ? Icon(Icons.check)
                                      : Container(),
                                ],
                              ),
                            ),
                          );
                        }
                        return Opacity(
                          opacity: ib.isLoading ? 1.0 : 0.0,
                          child: ib.lastVisible == null
                              ? LoadingCard(height: 40)
                              : Center(
                                  child: SizedBox(
                                      width: 32.0,
                                      height: 32.0,
                                      child: CupertinoActivityIndicator()),
                                ),
                        );
                      },
                    ),
                  ),
            // Save button
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context, interests.join(', '));
                },
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                ),
                child: Text(
                  'save'.tr(),
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
