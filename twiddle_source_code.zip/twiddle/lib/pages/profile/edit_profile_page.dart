import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/models/relationship.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/profile/edit_interest_page.dart';
import 'package:twiddle/pages/profile/relationship_page.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:twiddle/widgets/app_relationship.dart';
import 'package:uuid/uuid.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../utils/cached_image.dart';
import '../../utils/other.dart';
import '../../utils/snacbar.dart';
import '../../utils/validate.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_picker_item.dart';
import '../../widgets/app_text_input.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key, required this.user});

  final WUser user;

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormFieldState>();

  final _hometownCtrl = TextEditingController();
  final _worksAtCtrl = TextEditingController();
  final _studiedCtrl = TextEditingController();
  final _livesCtrl = TextEditingController();
  final DateTime _selectedDate = DateTime.now();

  final _focusHometown = FocusNode();
  final _focusWorksat = FocusNode();
  final _focusStudiedat = FocusNode();
  final _focusLivesin = FocusNode();

  String? _validHometown;
  String? _validWorksat;
  String? _validStudiedat;
  String? _validLivesin;

  String? _relationshipImage;

  String hometown = '';
  String worksAt = '';
  String studiedAt = '';
  String livesIn = '';
  Relationship? relationship;
  String relationshipText = '';
  String gender = 'Male';
  List<String> interests = [];
  String interest = '';
  String birthday = '';
  bool _updating = false;

  File? coverFile, avatarFile;

  String hometownPrivacy = '';
  String worksatPrivacy = '';
  String livesinPrivacy = '';
  String relationshipPrivacy = '';
  String studiedatPrivacy = '';
  String birthdatePrivacy = '';
  String genderPrivacy = '';

  @override
  void initState() {
    interests.addAll(widget.user.interests!);
    if (interests.isNotEmpty) {
      interest = interests.join(', ');
    }

    setState(() {
      birthday = widget.user.info!.birthdate!;
      gender = widget.user.info!.gender!;
      hometown = widget.user.info!.hometown ?? '';
      worksAt = widget.user.info!.worksat ?? '';
      studiedAt = widget.user.info!.studiedat ?? '';
      livesIn = widget.user.info!.livesin ?? '';
      relationship = widget.user.info!.relationship;
      if (relationship != null) {
        relationshipText = relationship!.typeName!;
      }

      _hometownCtrl.text = hometown;
      _worksAtCtrl.text = worksAt;
      _studiedCtrl.text = studiedAt;
      _livesCtrl.text = livesIn;

      hometownPrivacy = widget.user.info!.hometownPrivacy ?? '';
      worksatPrivacy = widget.user.info!.worksatPrivacy ?? '';
      studiedatPrivacy = widget.user.info!.studiedatPrivacy ?? '';
      livesinPrivacy = widget.user.info!.livesinPrivacy ?? '';
      relationshipPrivacy = widget.user.info!.relationshipPrivacy ?? '';
      birthdatePrivacy = widget.user.info!.birthdatePrivacy ?? '';
      genderPrivacy = widget.user.info!.genderPrivacy ?? '';
    });

    super.initState();
  }

  @override
  void dispose() {
    _hometownCtrl.dispose();
    _worksAtCtrl.dispose();
    _studiedCtrl.dispose();
    _livesCtrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          _customAppBar(widget.user, context),
          SliverToBoxAdapter(
            child: Form(
              key: _formKey,
              child: Container(
                width: MediaQuery.of(context).size.width,
                // height: double.infinity,
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Profile Information
                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/cottage.svg',
                              type: 'hometown'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 1);
                          },
                          child: getIcon(hometownPrivacy),
                        ),
                      ],
                    ),
                    AppTextInput(
                      hintText: ''.tr(),
                      errorText: _validHometown,
                      focusNode: _focusHometown,
                      textInputAction: TextInputAction.next,
                      // trailing: Cont,
                      onSubmitted: (text) {
                        UtilOther.fieldFocusChange(
                          context,
                          _focusHometown,
                          _focusWorksat,
                        );
                      },
                      onChanged: (text) {
                        setState(() {
                          _validHometown = UtilValidator.validate(
                            _hometownCtrl.text,
                          );
                        });
                      },
                      controller: _hometownCtrl,
                    ),
                    const SizedBox(height: 8),

                    // textFieldWidget(
                    //     controller: _hometownCtrl, fieldValue: hometown),
                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/home_repair_service.svg',
                              type: 'works_at'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 2);
                          },
                          child: getIcon(worksatPrivacy),
                        ),
                      ],
                    ),
                    AppTextInput(
                      hintText: ''.tr(),
                      errorText: _validWorksat,
                      focusNode: _focusWorksat,
                      textInputAction: TextInputAction.next,
                      // trailing: Cont,
                      onSubmitted: (text) {
                        UtilOther.fieldFocusChange(
                          context,
                          _focusWorksat,
                          _focusStudiedat,
                        );
                      },
                      onChanged: (text) {
                        setState(() {
                          _validWorksat = UtilValidator.validate(
                            _worksAtCtrl.text,
                          );
                        });
                      },
                      controller: _worksAtCtrl,
                    ),
                    const SizedBox(height: 8),

                    // textFieldWidget(
                    //     controller: _worksAtCtrl, fieldValue: worksAt),
                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/menu_book.svg',
                              type: 'studied at'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 3);
                          },
                          child: getIcon(studiedatPrivacy),
                        ),
                      ],
                    ),
                    AppTextInput(
                      hintText: ''.tr(),
                      errorText: _validStudiedat,
                      focusNode: _focusStudiedat,
                      textInputAction: TextInputAction.next,
                      // trailing: Cont,
                      onSubmitted: (text) {
                        UtilOther.fieldFocusChange(
                          context,
                          _focusStudiedat,
                          _focusLivesin,
                        );
                      },
                      onChanged: (text) {
                        setState(() {
                          _validStudiedat = UtilValidator.validate(
                            _studiedCtrl.text,
                          );
                        });
                      },
                      controller: _studiedCtrl,
                    ),
                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/home_pin.svg',
                              type: 'lives_in'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 4);
                          },
                          child: getIcon(livesinPrivacy),
                        ),
                      ],
                    ),
                    AppTextInput(
                      hintText: ''.tr(),
                      errorText: _validLivesin,
                      focusNode: _focusLivesin,
                      textInputAction: TextInputAction.done,
                      // trailing: Cont,
                      onSubmitted: (text) {},
                      onChanged: (text) {
                        setState(() {
                          _validLivesin = UtilValidator.validate(
                            _livesCtrl.text,
                          );
                        });
                      },
                      controller: _livesCtrl,
                    ),
                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/favorite.svg',
                              type: 'relationship_status'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 5);
                          },
                          child: getIcon(relationshipPrivacy),
                        ),
                      ],
                    ),
                    AppPickerItem(
                      title: 'Relationship'.tr(),
                      value: relationshipText,
                      onPressed: _showRelationDialog,
                    ),
                    relationship != null && relationshipText != 'Single'
                        ? _relationshipImage == null &&
                                relationship!.avatar == null
                            ? Container()
                            : AppRelationship(
                                relationship!,
                                isEdit: true,
                                imageFilePath: relationship!.avatar == null
                                    ? _relationshipImage
                                    : null,
                                onPressed: () async {
                                  var ret = await Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              RelationshipPage(
                                                isFileImage:
                                                    relationship!.avatar == null
                                                        ? true
                                                        : false,
                                                image: relationship!.avatar ??
                                                    _relationshipImage,
                                                name: relationship!.title,
                                                desc: relationship!.description,
                                              )));
                                  if (ret != null) {
                                    relationship ??= Relationship();

                                    setState(() {
                                      _relationshipImage = ret['image'];

                                      relationship!.title = ret['name'];
                                      relationship!.description = ret['desc'];
                                    });
                                  }
                                },
                              )
                        : Container(),
                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/calendar_month.svg',
                              type: 'date_of_birth'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 6);
                          },
                          child: getIcon(birthdatePrivacy),
                        ),
                      ],
                    ),
                    AppPickerItem(
                      title: 'date_of_birth'.tr(),
                      value: birthday,
                      onPressed: _selectDate,
                    ),
                    const SizedBox(height: 8),

                    Row(
                      children: [
                        Expanded(
                          child: InfoItem(
                              svgName: 'assets/images/wc.svg',
                              type: 'gender'.tr()),
                        ),
                        InkWell(
                          onTap: () {
                            showPrivacySheet(context, 7);
                          },
                          child: getIcon(genderPrivacy),
                        ),
                      ],
                    ),
                    AppPickerItem(
                      title: 'gender'.tr(),
                      value: gender,
                      onPressed: _showGenderDialog,
                    ),
                    const SizedBox(height: 16),

                    // Save button
                    ElevatedButton(
                      onPressed: _updating == true ? null : _save,
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size.fromHeight(50),
                      ),
                      child: _updating
                          ? CircularProgressIndicator()
                          : Text(
                              'save'.tr(),
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w700),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  _customAppBar(WUser user, context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: coverFile == null
            ? user.coverUrl != ''
                ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
                : Image.asset(
                    'assets/images/blank.png',
                    fit: BoxFit.cover,
                  )
            : Image.file(coverFile!, fit: BoxFit.cover),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context, false);
        },
      ),
      title: Text(
        'profile'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 60,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5),
                          child: avatarFile == null
                              ? CustomCacheImage(
                                  imageUrl: user.avatar,
                                  radius: 45.0,
                                  circularShape: true)
                              : Container(
                                  width: 90,
                                  height: 90,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    image: DecorationImage(
                                      image: Image.file(
                                        avatarFile!,
                                      ).image,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                        ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: GestureDetector(
                            onTap: () {
                              print('===== avatar button =====');
                              _showPhotoSheet(context, true);
                            },
                            child: Container(
                              width: 24,
                              height: 24,
                              margin:
                                  const EdgeInsets.only(bottom: 5, right: 5),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Config().text8Color,
                              ),
                              child: Center(
                                child: SvgPicture.asset(
                                    'assets/images/android_camera.svg'),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      Text(
                        user.name!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        '@${user.name!.replaceAll(' ', '').toLowerCase()}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: GestureDetector(
                onTap: () {
                  print('===== cover button =====');
                  _showPhotoSheet(context, false);
                },
                child: Container(
                  width: 24,
                  height: 24,
                  margin: const EdgeInsets.only(bottom: 70, right: 16),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Config().text4Color,
                  ),
                  child: Center(
                    child: SvgPicture.asset('assets/images/android_camera.svg'),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _selectDate() async {
    final DateTime? selected = await showDatePicker(
        context: context,
        initialDate: _selectedDate,
        firstDate: DateTime(1900),
        lastDate: DateTime(2050));
    if (selected != null && selected != _selectedDate) {
      setState(() {
        birthday = DateFormat('MM/dd/yyyy').format(selected);
      });
    }
  }

  void _showRelationDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Single
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Single';
                  });
                  Navigator.pop(context);

                  ///
                  relationship ??= Relationship();

                  setState(() {
                    relationship!.type = 1;
                    relationship!.typeName = 'Single';
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Single',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Married
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Married';
                  });
                  Navigator.pop(context);

                  if (relationship == null) {
                    _selectedMarried();
                  } else {
                    if (relationship!.type == 1 && _relationshipImage == null) {
                      _selectedMarried();
                    }
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Married',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Engaged
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Engaged';
                  });
                  Navigator.pop(context);

                  if (relationship == null) {
                    _selectEngaged();
                  } else {
                    if (relationship!.type == 1 && _relationshipImage == null) {
                      _selectEngaged();
                    }
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Engaged',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  _selectedMarried() async {
    var ret = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RelationshipPage(
                  isFileImage: false,
                  image: null,
                  name: null,
                  desc: null,
                )));
    if (ret != null) {
      relationship ??= Relationship();

      setState(() {
        _relationshipImage = ret['image'];

        relationship!.type = 2;
        relationship!.typeName = 'Married';
        relationship!.title = ret['name'];
        relationship!.description = ret['desc'];
      });
    } else {
      setState(() {
        relationshipText = '';
      });
    }
  }

  _selectEngaged() async {
    var ret = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RelationshipPage(
                  isFileImage: false,
                  image: null,
                  name: null,
                  desc: null,
                )));

    if (ret != null) {
      relationship ??= Relationship();
      setState(() {
        _relationshipImage = ret['image'];

        relationship!.type = 3;
        relationship!.typeName = 'Engaged';
        relationship!.title = ret['name'];
        relationship!.description = ret['desc'];
      });
    } else {
      setState(() {
        relationshipText = '';
      });
    }
  }

  _showGenderDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Male
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Male';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Male',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Female
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Female';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Female',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Other
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Other';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Other',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Bottom sheet for cover or avata
  _showPhotoSheet(ctx, isAvatar) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (isAvatar) {
                  await pickAvatarImage(false);
                } else {
                  await pickCoverImage(false);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/images/add_photo_alternate.svg',
                      color: Config().text90Color,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (isAvatar) {
                  await pickAvatarImage(true);
                } else {
                  await pickCoverImage(true);
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/camera.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  showPrivacySheet(BuildContext ctx, int type) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Public
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Public');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.public_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Friends
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Friends');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.group_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Only Me
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Only Me');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.person_outline),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  getInfo(int type, String privacy) {
    switch (type) {
      case 1:
        setState(() {
          hometownPrivacy = privacy;
        });
        break;
      case 2:
        setState(() {
          worksatPrivacy = privacy;
        });
        break;
      case 3:
        setState(() {
          studiedatPrivacy = privacy;
        });
        break;
      case 4:
        setState(() {
          livesinPrivacy = privacy;
        });
        break;
      case 5:
        setState(() {
          relationshipPrivacy = privacy;
        });
        break;
      case 6:
        setState(() {
          birthdatePrivacy = privacy;
        });
        break;
      case 7:
        setState(() {
          genderPrivacy = privacy;
        });
        break;
      default:
    }
  }

  getIcon(String privacy) {
    IconData? icon;
    if (privacy == 'Public') {
      icon = Icons.public_outlined;
    } else if (privacy == 'Friends') {
      icon = Icons.group_outlined;
    } else {
      icon = Icons.person_outlined;
    }
    return Icon(icon, size: 20);
  }

  Future pickCoverImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      coverFile = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  Future pickAvatarImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      avatarFile = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  Future<String> uploadFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Cover Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  Future<String> uploadRelationFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Relationship Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _save() async {
    final ub = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();
    String? coverPath, avatarPath;

    UtilOther.hiddenKeyboard(context);
    hometown = _hometownCtrl.text;
    worksAt = _worksAtCtrl.text;
    studiedAt = _studiedCtrl.text;
    livesIn = _livesCtrl.text;

    setState(() {
      _updating = true;
    });

    // Upload cover photo to firebase storage
    if (coverFile != null) {
      coverPath = await uploadFile(coverFile!);
      if (coverPath != null) {
        ub.updateCoverPhoto(sb.uid!, coverPath);
      }
    }
    // Upload avatar photo to firebase storage
    if (avatarFile != null) {
      avatarPath = await uploadFile(avatarFile!);
      if (avatarPath != null) {
        ub.updateAvatarPhoto(sb.uid!, avatarPath);
      }
    }

    if (relationshipText == 'Married' || relationshipText == 'Engaged') {
      if (_relationshipImage != null) {
        var path = await uploadRelationFile(File(_relationshipImage!));
        if (relationship != null && relationship!.typeName != 'Single') {
          relationship!.avatar = path;
        }
      }
    } else if (relationshipText == 'Single') {
      if (relationship!.typeName == 'Single') {
        relationship!.avatar = null;
        relationship!.title = null;
        relationship!.description = null;
      }
    }

    //
    ub
        .updateProfile(
            sb.uid!,
            hometown,
            worksAt,
            studiedAt,
            livesIn,
            relationship,
            interest,
            birthday,
            gender,
            hometownPrivacy,
            worksatPrivacy,
            studiedatPrivacy,
            livesinPrivacy,
            relationshipPrivacy,
            birthdatePrivacy,
            genderPrivacy)
        .then((value) {
      setState(() {
        _updating = false;
      });
      if (ub.hasError == false) {
        openToast('You updated profile successfully');
        Navigator.pop(context, true);
      } else {
        openSnacbar(context, ub.errorCode);
      }
    });
  }
}

class InfoItem extends StatelessWidget {
  const InfoItem({
    Key? key,
    required this.svgName,
    required this.type,
  }) : super(key: key);

  final String svgName;
  final String type;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SvgPicture.asset(svgName),
        Padding(
          padding: const EdgeInsets.only(left: 12),
          child: Text(
            type,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
        ),
      ],
    );
  }
}
