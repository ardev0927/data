import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/album_bloc.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/models/album.dart';
import 'package:twiddle/pages/profile/photo_tabs/create_album_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../../models/post.dart';
import '../../../utils/cached_image_with_dark.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../add_photo_album.dart';

class AlbumsTab extends StatefulWidget {
  const AlbumsTab({super.key, required this.uid});
  final String? uid;

  @override
  State<AlbumsTab> createState() => _AlbumsTabState();
}

class _AlbumsTabState extends State<AlbumsTab> {
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = new ScrollController()..addListener(_scrollListener);
      context.read<AlbumBloc>().getAlbums(widget.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<AlbumBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<AlbumBloc>().setLoading(true);
        context.read<AlbumBloc>().getAlbums(widget.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ab = context.watch<AlbumBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        // ab.onTypeRefresh(widget.uid, 9, mounted, _orderBy);
      },
      child: ab.hasData == false
          ? GridView.builder(
              controller: controller,
              padding: const EdgeInsets.only(
                  left: 10, right: 10, top: 15, bottom: 15),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 0.9),
              itemCount: 1,
              itemBuilder: (_, int index) {
                return CreateAlbumItem(
                  onTap: () {
                    nextScreen(context, CreateAlbumPage(type: 2));
                  },
                );
              },
            )
          : GridView.builder(
              controller: controller,
              padding: const EdgeInsets.only(
                  left: 10, right: 10, top: 15, bottom: 15),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 0.9),
              itemCount: ab.albums.isNotEmpty ? ab.albums.length + 2 : 10,
              itemBuilder: (_, int index) {
                print('===== ${ab.albums.length} =====');
                if (index < ab.albums.length + 1) {
                  if (index == 0) {
                    return CreateAlbumItem(
                      onTap: () async {
                        var ret = await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    CreateAlbumPage(type: 2)));
                        if (ret != null) {
                          // ab.onTypeRefresh(widget.uid, 9, mounted, _orderBy);
                        }
                      },
                    );
                  }
                  print('===== AlbumItem =====');
                  return AlbumItem(
                    d: ab.albums[index - 1],
                    index: index - 1,
                    onTap: () async {
                      var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  AddPhotoAlbum(album: ab.albums[index - 1])));
                      if (ret != null && ret == true) {
                        ab.getAlbums(widget.uid, mounted, _orderBy);
                      }
                    },
                  );
                }
                return Opacity(
                  opacity: ab.isLoading ? 1.0 : 0.0,
                  child: ab.lastVisible == null
                      ? LoadingCard(height: null)
                      : Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }
}

class CreateAlbumItem extends StatelessWidget {
  const CreateAlbumItem({Key? key, required this.onTap}) : super(key: key);
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: InkWell(
            child: Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: Config().text4Color,
                  ),
                  child: Center(
                    child: SvgPicture.asset('assets/images/plus_large.svg'),
                  ),
                ),
              ],
            ),
            onTap: onTap,
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            'create_album'.tr(),
            style: TextStyle(
                fontSize: 12,
                color: Config().text90Color,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.6),
          ),
        ),
      ],
    );
  }
}

class AlbumItem extends StatelessWidget {
  final Album d;
  final int index;
  final Function()? onTap;
  const AlbumItem(
      {Key? key, required this.d, required this.index, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('===== ${d.id} =====');
    return Column(
      children: [
        Expanded(
          child: InkWell(
            onTap: onTap,
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  boxShadow: <BoxShadow>[
                    BoxShadow(
                        blurRadius: 10,
                        offset: Offset(0, 3),
                        color: Theme.of(context).shadowColor)
                  ]),
              child: Stack(
                children: [
                  Hero(
                    tag: 'photo$index',
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width,
                      child: d.images!.isNotEmpty
                          ? CustomCacheImageWithDarkFilterBottom(
                              imageUrl: d.images![0], radius: 0.0)
                          : Align(
                              alignment: Alignment.bottomRight,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(bottom: 8, right: 8),
                                child: Text('Empty',
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Config().text90Color,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: -0.6)),
                              ),
                            ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Color(0x33000000),
                  ),
                  d.images!.length < 2
                      ? Container()
                      : Align(
                          alignment: Alignment.center,
                          child: Container(
                            margin:
                                EdgeInsets.only(left: 15, bottom: 8, right: 10),
                            child: Text(
                              '+ ${d.images!.length - 1}',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: -0.6),
                            ),
                          ),
                        )
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            d.name!,
            style: TextStyle(
                fontSize: 12,
                color: Config().text90Color,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.6),
          ),
        ),
      ],
    );
  }
}
