import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/album_bloc.dart';
import 'package:uuid/uuid.dart';

import '../../../blocs/posts_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../config/config.dart';
import '../../../services/app_service.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';

class CreateAlbumPage extends StatefulWidget {
  const CreateAlbumPage({super.key, required this.type});
  final int? type;

  @override
  State<CreateAlbumPage> createState() => _CreateAlbumPageState();
}

class _CreateAlbumPageState extends State<CreateAlbumPage> {
  final _albumCtrl = TextEditingController();
  String albumName = '';
  List<File> _albums = [];
  int postType = 9; // Post type is 9 (Album)
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {});
  }

  @override
  void dispose() {
    _albumCtrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, null);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'create_album'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Column(
      children: [
        // Input album name
        Padding(
          padding: const EdgeInsets.only(top: 8, left: 16, right: 16),
          child: TextFormField(
            decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                hintText: 'album_name'.tr()),
            controller: _albumCtrl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                albumName = value;
              });
            },
          ),
        ),
        // Album
        widget.type == 1
            ? Container()
            : _albums.isEmpty
                ? Expanded(
                    child: GridView.builder(
                      // controller: controller,
                      padding: EdgeInsets.only(
                          left: 10, right: 10, top: 15, bottom: 15),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 4,
                          crossAxisSpacing: 4,
                          childAspectRatio: 1),
                      itemCount: 1,
                      itemBuilder: (_, int index) {
                        return CreatePhotoItem(
                          onTap: () async {
                            await pickImage();
                          },
                        );
                      },
                    ),
                  )
                : Expanded(
                    child: GridView.builder(
                      // controller: controller,
                      padding: EdgeInsets.only(
                          left: 10, right: 10, top: 15, bottom: 15),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisSpacing: 4,
                          crossAxisSpacing: 4,
                          childAspectRatio: 1),
                      itemCount: _albums.length != 0 ? _albums.length : 10,
                      itemBuilder: (_, int index) {
                        if (index == 0) {
                          return CreatePhotoItem(
                            onTap: () async {
                              await pickImage();
                            },
                          );
                        }
                        return AlbumItem(d: _albums[index], index: index);
                      },
                    ),
                  ),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: ElevatedButton(
            onPressed: () {
              if (widget.type == 1) {
                _createAlbum();
              } else {
                if (_albumCtrl.text.isNotEmpty && _albums.isNotEmpty) {
                  _post();
                } else {
                  openToast('Please enter album name or add photos');
                }
              }
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
            ),
            child: _isLoading == true
                ? CircularProgressIndicator()
                : Text(
                    'create'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
          ),
        ),
      ],
    );
  }

  Future pickImage() async {
    List<XFile>? images;
    XFile? image;
    images = await ImagePicker().pickMultiImage();
    if (images != null) {
      images.forEach((element) {
        _albums.add(File(element.path));
      });
      _albums.insert(0, File(''));
      setState(() {});
    } else {
      print('===== No images selected! =====');
    }
    // image = await ImagePicker().pickImage(source: ImageSource.gallery);
  }

  _createAlbum() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final AlbumBloc ab = Provider.of<AlbumBloc>(context, listen: false);
    setState(() {
      _isLoading = true;
    });

    DateTime now = DateTime.now().toUtc();
    String timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ab.createAlbum(sb.uid!, _albumCtrl.text, [], timestamp).then((value) {
          setState(() {
            _isLoading = false;
          });
          if (ab.hasError == false) {
            openToast('You created a album');
            Navigator.pop(context, ab.album);
          }
        });
      }
    });
  }

  _post() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    setState(() {
      _isLoading = true;
    });

    List<File> files = List.from(_albums);
    files.remove(files.removeAt(0));
    List<String>? images = await uploadFiles(files);
    var feeling = '${_albumCtrl.text} Album';

    DateTime now = DateTime.now().toUtc();
    String timestamp = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
    Map<String, Object?> poll = {};

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb
            .createPost(sb, postType, images, _albumCtrl.text, 'public',
                timestamp, feeling, poll, {}, '', {}, false, [], {})
            .then((value) {
          setState(() {
            _isLoading = false;
          });
          if (pb.hasError == false) {
            openToast('You created a album');
            Navigator.pop(context, pb.post);
          }
        });
      }
    });
  }

  Future<List<String>> uploadFiles(List<File> images) async {
    var imageUrls = await Future.wait(images.map((e) => uploadFile(e)));
    print('===== upload done =====');
    return imageUrls;
  }

  Future<String> uploadFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Post Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }
}

class CreatePhotoItem extends StatelessWidget {
  const CreatePhotoItem({Key? key, required this.onTap}) : super(key: key);
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: InkWell(
            child: Stack(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: Config().text4Color,
                  ),
                  child: Center(
                    child: SvgPicture.asset('assets/images/plus_large.svg'),
                  ),
                ),
              ],
            ),
            onTap: onTap,
          ),
        ),
        // Padding(
        //   padding: const EdgeInsets.only(top: 4),
        //   child: Text(
        //     'add_photo_video'.tr(),
        //     style: TextStyle(
        //         fontSize: 12,
        //         color: Config().text90Color,
        //         fontWeight: FontWeight.w700,
        //         letterSpacing: -0.6),
        //   ),
        // ),
      ],
    );
  }
}

class AlbumItem extends StatelessWidget {
  final File? d;
  final int index;
  const AlbumItem({Key? key, required this.d, required this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              boxShadow: <BoxShadow>[
                BoxShadow(
                    blurRadius: 10,
                    offset: Offset(0, 3),
                    color: Theme.of(context).shadowColor)
              ]),
          child: Stack(
            children: [
              Hero(
                tag: 'album_photo$index',
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: Image.file(d!, fit: BoxFit.cover),
                ),
              ),
            ],
          )),
      onTap: () {
        // Navigator.pop(context, d);
      },
    );
  }
}
