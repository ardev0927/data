import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/post_type_bloc.dart';
import 'package:twiddle/models/post.dart';

import '../../../utils/cached_image_with_dark.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../show_photo_page.dart';

class PhotoTab extends StatefulWidget {
  const PhotoTab({super.key, required this.uid});
  final String? uid;

  @override
  State<PhotoTab> createState() => _PhotoTabState();
}

class _PhotoTabState extends State<PhotoTab> {
  ScrollController? controller;
  String _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      controller = new ScrollController()..addListener(_scrollListener);
      context
          .read<PostTypeBloc>()
          .getDataWithType(widget.uid, 1, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<PostTypeBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<PostTypeBloc>().setLoading(true);
        context
            .read<PostTypeBloc>()
            .getDataWithType(widget.uid, 1, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pb = context.watch<PostTypeBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        pb.onTypeRefresh(widget.uid, 1, mounted, _orderBy);
      },
      child: pb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.35,
                ),
                EmptyPage(
                    icon: Icons.image_outlined,
                    message: 'no image found'.tr(),
                    message1: ''),
              ],
            )
          : GridView.builder(
              controller: controller,
              padding:
                  EdgeInsets.only(left: 10, right: 10, top: 15, bottom: 15),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 4,
                  crossAxisSpacing: 4,
                  childAspectRatio: 1),
              itemCount: pb.data.length != 0 ? pb.data.length + 1 : 10,
              itemBuilder: (_, int index) {
                if (index < pb.data.length) {
                  return PhotoItem(
                    d: pb.data[index],
                    index: index,
                    onTap: () {
                      nextScreen(
                          context,
                          ShowPhotoPage(
                              p: pb.data[index], changedArray: false));
                    },
                  );
                }
                return Opacity(
                  opacity: pb.isLoading ? 1.0 : 0.0,
                  child: pb.lastVisible == null
                      ? LoadingCard(height: null)
                      : Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }
}

class PhotoItem extends StatelessWidget {
  final Post d;
  final int index;
  final Function() onTap;
  const PhotoItem(
      {Key? key, required this.d, required this.index, required this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              boxShadow: <BoxShadow>[
                BoxShadow(
                    blurRadius: 10,
                    offset: Offset(0, 3),
                    color: Theme.of(context).shadowColor)
              ]),
          child: Stack(
            children: [
              Hero(
                tag: 'photo$index',
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: CustomCacheImageWithDarkFilterBottom(
                      imageUrl: d.mediaUrls![0], radius: 0.0),
                ),
              ),
              d.mediaUrls!.length == 1
                  ? Container()
                  : Align(
                      alignment: Alignment.bottomRight,
                      child: Container(
                        margin: EdgeInsets.only(left: 15, bottom: 8, right: 10),
                        child: Text(
                          '+ ${d.mediaUrls!.length - 1}',
                          style: TextStyle(
                              fontSize: 14,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              letterSpacing: -0.6),
                        ),
                      ),
                    )
            ],
          )),
    );
  }
}
