import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/profile/photo_tabs/albums_tab.dart';
import 'package:twiddle/pages/profile/photo_tabs/photo_tab.dart';

import '../../blocs/posts_bloc.dart';
import '../../blocs/tab_index_bloc.dart';
import '../../config/config.dart';
import '../../models/user.dart';

class PhotosPage extends StatefulWidget {
  const PhotosPage({super.key, required this.user});
  final WUser? user;

  @override
  State<PhotosPage> createState() => _PhotosPageState();
}

class _PhotosPageState extends State<PhotosPage> with TickerProviderStateMixin {
  TabController? _tabController;

  final List<Tab> _tabs = [
    Tab(
      text: 'photos_of_you'.tr(),
    ),
    Tab(
      text: 'albums'.tr(),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController!.addListener(() {
      context.read<TabIndexBloc>().setTabIndex(_tabController!.index);
    });
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          widget.user!.name!,
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return DefaultTabController(
      length: _tabs.length,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 50,
            child: TabBar(
              controller: _tabController,
              labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
              labelColor: Config().text90Color,
              unselectedLabelStyle:
                  TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              unselectedLabelColor: Config().text90Color,
              indicatorColor: Config().primary30Color,
              indicatorWeight: 4,
              labelPadding: const EdgeInsets.all(4),
              tabs: _tabs,
            ),
          ),
          Flexible(
            child: TabBarView(
              controller: _tabController,
              children: [
                PhotoTab(uid: widget.user!.uid),
                AlbumsTab(uid: widget.user!.uid),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
