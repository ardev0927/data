import 'dart:io';
import 'dart:typed_data';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/post_pinned_bloc.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:url_launcher/url_launcher.dart';
// import 'package:webview_flutter/webview_flutter.dart';

import '../../blocs/notification_bloc.dart';
// import '../../blocs/post_friends_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../bottom_sheet/post_sheet.dart';
import '../../cards/card1.dart';
import '../../cards/video_card.dart';
import '../../config/config.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/empty.dart';
import '../../utils/enums.dart';
import '../../utils/format_time.dart';
import '../../utils/loading_cards.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../post/view_comments_page.dart';
import '../post/view_likes_page.dart';

class PinnedPostPage extends StatefulWidget {
  const PinnedPostPage({super.key});

  @override
  State<PinnedPostPage> createState() => _PinnedPostPageState();
}

class _PinnedPostPageState extends State<PinnedPostPage> {
  ScrollController? controller;
  String _orderBy = 'timestamp';
  Uint8List? videoThumbBytes;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // if (Platform.isAndroid) WebView.platform = AndroidWebView();
    Future.delayed(Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      controller = ScrollController()..addListener(_scrollListener);
      context.read<PostPinnedBloc>().getData(sb.uid, mounted, _orderBy);
      context.read<UserBlock>().getUser(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    super.dispose();
    controller!.removeListener(_scrollListener);
  }

  void _scrollListener() {
    final db = context.read<PostPinnedBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        print('===== post scroll listener =====');
        context.read<PostPinnedBloc>().setLoading(true);
        context.read<PostPinnedBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'pinned_post'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    List<Post> posts = [];

    final pb = context.watch<PostPinnedBloc>();
    final sb = context.watch<SignInBloc>();
    final ub = context.watch<UserBlock>();

    posts.addAll(pb.data);

    return RefreshIndicator(
      onRefresh: () async {
        pb.onRefresh(sb.uid, mounted, _orderBy);
      },
      child: Stack(
        children: [
          pb.hasData == false
              ? Expanded(
                  child: ListView(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      EmptyPage(
                          icon: Icons.post_add_outlined,
                          message: 'no_post_found'.tr(),
                          message1: ''),
                    ],
                  ),
                )
              : ListView.separated(
                  // padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                  controller: controller,
                  // physics: NeverScrollableScrollPhysics(),
                  // physics: ScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: posts.isNotEmpty ? posts.length + 1 : 5,
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                    height: 15,
                  ),

                  //shrinkWrap: true,
                  itemBuilder: (_, int index) {
                    if (index < posts.length) {
                      if (posts[index].mediaType == 2) {
                        // VIDEO
                        // return VideoCard(
                        return PostVideoCard(
                          d: posts[index],
                          time: convertToAgo(posts[index].timestamp!),
                          heroTag: 'post${index}',
                          onLikePressed: () {
                            if (sb.uid == posts[index].uid) {
                              openToast('You can not like own post');
                              return;
                            }
                            pb.setLike(sb.uid, posts[index]).then((value) {
                              if (pb.isLiked == true) {
                                // Update post for like
                                posts[index].likes!.add(sb.uid!);
                                openToast('Liked Post');

                                // Notification
                                _sendFcmPost(
                                    ub,
                                    sb.uid!,
                                    sb.name!,
                                    sb.imageUrl!,
                                    posts[index],
                                    ub.data!.fcmToken!,
                                    FcmType.react);
                              } else {
                                posts[index].likes!.remove(sb.uid!);
                                openToast('Unliked Post');
                              }
                              setState(() {});
                            });
                          },
                          onLikesPressed: () {
                            nextScreen(context,
                                ViewLikesPage(uids: posts[index].likes));
                          },
                          isLiked: posts[index].likes!.contains(sb.uid),
                          onSharePressed: () {
                            if (sb.uid == posts[index].uid) {
                              openToast('You can not share own post');
                              return;
                            }
                          },
                          onSharesPressed: () {
                            // nextScreen(context,
                            //     ViewSharesPage(uids: posts[index].shares));
                          },
                          isShared: posts[index].shares!.contains(sb.uid),
                          onCommentPressed: () async {
                            if (sb.uid == posts[index].uid) {
                              openToast('You can not comment own post');
                              return;
                            }
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: posts[index])));
                            if (ret != null) {
                              posts[index].comments = ret;
                              setState(() {});
                            }
                          },
                          onCommentsPressed: () async {
                            int ret = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ViewCommentsPage(p: posts[index])));
                            if (ret != null) {
                              posts[index].comments = ret;
                              setState(() {});
                            }
                          },
                          onMoreTap: () {
                            // More Tap
                            showMoreSheet(
                                context,
                                ub.data!,
                                posts[index],
                                false,
                                sb.uid!,
                                sb.uid == posts[index].uid ? false : true,
                                onPinTap: () {
                                  Navigator.pop(context);
                                  _pinUnpinPost(posts[index]);
                                },
                                onFollowTap: () {},
                                onReportTap: () {},
                                onHideTap: () {
                                  Navigator.pop(context);
                                  _hidePost(posts[index], sb.uid);
                                },
                                onDeleteTap: () {
                                  Navigator.pop(context);
                                  _deletePost(posts[index]);
                                });
                            // _showMoreSheet(context, posts[index-1], sb.uid!);
                          },
                          onPhotoTap: () {
                            nextScreen(
                                context,
                                ShowPhotoPage(
                                    p: posts[index], changedArray: false));
                          },
                          onAvatarTap: () {
                            if (sb.uid != posts[index].uid) {
                              nextScreen(context,
                                  UserProfilePage(uid: posts[index].uid));
                            } else {
                              nextScreen(context,
                                  ProfileMainPage(uid: posts[index].uid));
                            }
                          },
                        );
                      }
                      // return Card1(
                      return PostCard(
                        d: posts[index],
                        time: convertToAgo(posts[index].timestamp!),
                        heroTag: 'post${index}',
                        onLikePressed: () {
                          if (sb.uid == posts[index].uid) {
                            openToast('You can not like own post');
                            return;
                          }
                          pb.setLike(sb.uid, posts[index]).then((value) {
                            if (pb.isLiked == true) {
                              posts[index].likes!.add(sb.uid!);
                              openToast('Liked Post');

                              // Notification
                              _sendFcmPost(
                                  ub,
                                  sb.uid!,
                                  sb.name!,
                                  sb.imageUrl!,
                                  posts[index],
                                  ub.data!.fcmToken!,
                                  FcmType.react);
                            } else {
                              posts[index].likes!.remove(sb.uid!);
                              openToast('Unliked Post');
                            }
                            setState(() {});
                          });
                        },
                        onLikesPressed: () {
                          nextScreen(
                              context, ViewLikesPage(uids: posts[index].likes));
                        },
                        isLiked: posts[index].likes!.contains(sb.uid),
                        onSharePressed: () {
                          if (sb.uid == posts[index].uid) {
                            openToast('You can not share own post');
                            return;
                          }
                          // pb.setShare(sb.uid, posts[index-1]).then((value) {
                          //   if (pb.isShared == true) {
                          //     posts[index-1].shares!.add(sb.uid!);
                          //     openToast('Shared Post');
                          //   } else {
                          //     posts[index-1].shares!.remove(sb.uid!);
                          //     openToast('Unshared Post');
                          //   }
                          //   setState(() {});
                          // });
                        },
                        onSharesPressed: () {
                          // nextScreen(context,
                          //     ViewSharesPage(uids: posts[index].shares));
                        },
                        isShared: posts[index].shares!.contains(sb.uid),
                        onCommentPressed: () async {
                          if (sb.uid == posts[index].uid) {
                            openToast('You can not comment own post');
                            return;
                          }
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: posts[index])));
                          if (ret != null) {
                            posts[index].comments = ret;
                            setState(() {});
                          }
                        },
                        onCommentsPressed: () async {
                          int ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ViewCommentsPage(p: posts[index])));
                          if (ret != null) {
                            posts[index].comments = ret;
                            setState(() {});
                          }
                        },
                        onMoreTap: () {
                          // More Tap
                          showMoreSheet(
                              context,
                              ub.data!,
                              posts[index],
                              false,
                              sb.uid!,
                              sb.uid == posts[index].uid ? false : true,
                              onPinTap: () {
                                Navigator.pop(context);
                                _pinUnpinPost(posts[index]);
                              },
                              onFollowTap: () {},
                              onReportTap: () {},
                              onHideTap: () {
                                Navigator.pop(context);
                                _hidePost(posts[index], sb.uid);
                              },
                              onDeleteTap: () {
                                Navigator.pop(context);
                                _deletePost(posts[index]);
                              });
                          // _showMoreSheet(context, posts[index-1], sb.uid!);
                        },
                        onPhotoTap: () {
                          nextScreen(
                              context,
                              ShowPhotoPage(
                                  p: posts[index], changedArray: false));
                        },
                        onAvatarTap: () {
                          if (sb.uid != posts[index].uid) {
                            nextScreen(context,
                                UserProfilePage(uid: posts[index].uid));
                          } else {
                            nextScreen(context,
                                ProfileMainPage(uid: posts[index].uid));
                          }
                        },
                        onArticleTap: () {
                          if (posts[index].mediaType == 11) {
                            launchUrl(Uri.parse(posts[index].article!));
                          }
                        },
                      );
                    }
                    return Opacity(
                      opacity: pb.isLoading ? 1.0 : 0.0,
                      child: pb.lastVisible == null
                          ? LoadingCard(height: 250)
                          : Center(
                              child: SizedBox(
                                  width: 32.0,
                                  height: 32.0,
                                  child: CupertinoActivityIndicator()),
                            ),
                    );
                  },
                ),
          _isLoading
              ? Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Container(),
        ],
      ),
    );
  }

  _sendFcmPost(UserBlock ub, String uid, String name, String avatar, Post p,
      String fcmToken, int fcmType) async {
    final user = await ub.getWUser(p.uid);
    print("===== fcm token ${user!.fcmToken} =====");
    String body = '';
    String title = '';
    if (fcmType == FcmType.react) {
      title = "Reaction post";
      body = "$name reacted to ${p.username} Post.";
    } else if (fcmType == FcmType.tag) {
      title = "Post tag";
      body = "You received tag post from ${p.username}.";
    }

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [user.fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(user.uid, body, fcmType, p.postId, avatar);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Post notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== pinned/unpinnned post id: ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
