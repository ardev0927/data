import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';

import '../../blocs/friends_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../cards/friends_card.dart';
import '../../config/config.dart';
import '../../models/user.dart';
import '../../services/app_service.dart';
import '../../utils/empty.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';

class ProfileFriendsPage extends StatefulWidget {
  ProfileFriendsPage({super.key, required this.uid});

  String? uid;

  @override
  State<ProfileFriendsPage> createState() => _ProfileFriendsPageState();
}

class _ProfileFriendsPageState extends State<ProfileFriendsPage> {
  final List<String> _uids = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();

    if (mounted) {
      _handleGetFriendUids(widget.uid!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appbar(),
      body: _body(),
    );
  }

  _appbar() {
    return AppBar(
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(Icons.arrow_back),
      ),
      title: Text(
        'friends'.tr(),
        style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Config().text100Color),
      ),
    );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    return _uids.isEmpty
        ? Container()
        : StreamBuilder<QuerySnapshot>(
            stream: getFriends(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.separated(
                  // key: PageStorageKey(widget.category),
                  padding: const EdgeInsets.only(top: 8),
                  physics: AlwaysScrollableScrollPhysics(),
                  itemCount: snapshot.data!.size != 0 ? snapshot.data!.size : 5,
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                    height: 3,
                  ),
                  shrinkWrap: true,
                  itemBuilder: (_, int index) {
                    var doc = snapshot.data!.docs[index];
                    var user = WUser.fromFirestore(doc);
                    return FriendsCard(
                      d: user,
                      heroTag: 'tab1$index',
                      onPressed: () async {
                        Navigator.pop(context);
                        final ub = context.read<UserBlock>();
                        await ub
                            .removeFriend(widget.uid, user.uid)
                            .then((value) {
                          if (ub.isFriend == false) {
                            // fb.data.remove(fb.data[index]);
                            setState(() {});
                          }
                        });
                      },
                      onItemTapped: () {
                        // Open profile page
                        nextScreen(context, UserProfilePage(uid: user.uid));
                      },
                    );
                  },
                );
              } else {
                return ListView(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.20,
                    ),
                    EmptyPage(
                        icon: Icons.person_off_outlined,
                        message: 'no_friends'.tr(),
                        message1: ''),
                  ],
                );
              }
            },
          );
  }

  _handleGetFriendUids(String uid) async {
    final FriendsBloc fb = Provider.of<FriendsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        var uids = await fb.getFriendsUid(uid);
        _uids.addAll(uids);
        if (!mounted) return;
        setState(() {});
      }
    });
  }

  Stream<QuerySnapshot> getFriends() {
    return firestore
        .collection('users')
        .where('uid', whereIn: _uids)
        .snapshots();
  }
}
