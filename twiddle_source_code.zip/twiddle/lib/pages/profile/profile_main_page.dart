import 'dart:io';
import 'dart:typed_data';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/interest_bloc.dart';
import 'package:twiddle/blocs/post_user_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/bottom_sheet/post_sheet.dart';
import 'package:twiddle/cards/friends_card2.dart';
import 'package:twiddle/cards/interest_card3.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/profile/edit_profile_page.dart';
import 'package:twiddle/pages/profile/photos_page.dart';
import 'package:twiddle/pages/profile/setting_profile_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:video_compress/video_compress.dart';

import '../../blocs/friends_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../cards/card1.dart';
import '../../cards/video_card.dart';
import '../../config/config.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../../widgets/app_relationship.dart';
import '../post/show_cw_post_page.dart';
import '../post/view_comments_page.dart';
import '../post/view_likes_page.dart';
import '../post/view_shares_page.dart';
import '../stories/add_story_page.dart';

class ProfileMainPage extends StatefulWidget {
  const ProfileMainPage({super.key, required this.uid});
  final String? uid;

  @override
  State<ProfileMainPage> createState() => _ProfileMainPageState();
}

class _ProfileMainPageState extends State<ProfileMainPage> {
  final String _orderBy = 'timestamp';
  bool _isLoading = false;
  ScrollController? controller;
  Uint8List? videoThumbBytes;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final ub = context.read<UserBlock>();
      final pb = context.read<PostUserBloc>();
      final fb = context.read<FriendsBloc>();

      ub.onInit();
      ub.getUser(widget.uid, mounted).then((value) {
        context
            .read<InterestBloc>()
            .filterDataWithName(ub.data!.interests!, mounted);
      });
      fb.getData(widget.uid, mounted);
      controller = ScrollController()..addListener(_scrollListener);
      pb.onInit();
      pb.getMyData(widget.uid, mounted, _orderBy);
      // context.read<InterestBloc>().getMyData(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<PostUserBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<PostUserBloc>().setLoading(true);
        context.read<PostUserBloc>().getMyData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;

    final ub = context.watch<UserBlock>();
    final fb = context.watch<FriendsBloc>();
    final ib = context.watch<InterestBloc>();
    final pb = context.watch<PostUserBloc>();
    final sb = context.watch<SignInBloc>();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ub.isLoading == true
          ? Container(
              child: Center(child: CircularProgressIndicator()),
            )
          : RefreshIndicator(
              onRefresh: () async {
                pb.onMyRefresh(sb.uid, mounted, _orderBy);
              },
              child: CustomScrollView(
                slivers: [
                  _customAppBar(ub.data!, context),
                  SliverToBoxAdapter(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      // height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Button(Add story, Edit profile)
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                ExpandedIconButton(
                                  title: 'add_story'.tr(),
                                  iconData: Icons.add,
                                  onPressed: () {
                                    showAddStorySheet(context);
                                  },
                                ),
                                const SizedBox(width: 16),
                                ExpandedIconButton(
                                  title: 'edit_profile'.tr(),
                                  iconData: Icons.edit_outlined,
                                  onPressed: () async {
                                    var ret = await Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                EditProfilePage(
                                                    user: ub.data!)));
                                    if (ret) {
                                      ub.getUser(sb.uid, mounted);
                                      setState(() {});
                                      // pb.onMyRefresh(sb.uid, mounted, _orderBy);
                                    }
                                  },
                                ),
                              ],
                            ),
                          ),
                          // Profile Information
                          ub.data!.info!.hometown == null
                              ? Container()
                              : ProfileItem(
                                  name: ub.data!.info!.hometown!,
                                  svgName: 'assets/images/cottage.svg',
                                  type: 'hometown'.tr()),
                          ub.data!.info!.worksat == null
                              ? Container()
                              : ProfileItem(
                                  name: ub.data!.info!.worksat!,
                                  svgName:
                                      'assets/images/home_repair_service.svg',
                                  type: 'works_at'.tr()),
                          ub.data!.info!.studiedat == null
                              ? Container()
                              : ProfileItem(
                                  name: ub.data!.info!.studiedat!,
                                  svgName: 'assets/images/menu_book.svg',
                                  type: 'studied at'.tr()),
                          ub.data!.info!.livesin == null
                              ? Container()
                              : ProfileItem(
                                  name: ub.data!.info!.livesin!,
                                  svgName: 'assets/images/home_pin.svg',
                                  type: 'lives_in'.tr()),
                          // ub.data!.interests!.isEmpty
                          //     ? Container()
                          //     : ProfileItem(
                          //         name: ub.data!.interests!.join(', '),
                          //         svgName: 'assets/images/interests.svg',
                          //         type: 'interest'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.birthdate!,
                              svgName: 'assets/images/calendar_month.svg',
                              type: 'date_of_birth'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.gender!,
                              svgName: 'assets/images/wc.svg',
                              type: 'gender'.tr()),
                          ub.data!.info!.relationship == null
                              ? Container()
                              : ub.data!.info!.relationship!.typeName ==
                                      'Single'
                                  ? ProfileItem(
                                      name: ub
                                          .data!.info!.relationship!.typeName!,
                                      svgName: 'assets/images/favorite.svg',
                                      type: 'relationship_status'.tr())
                                  : ProfileItem(
                                      name: ub.data!.info!.relationship!.title!,
                                      svgName: 'assets/images/favorite.svg',
                                      type:
                                          '${ub.data!.info!.relationship!.typeName!} with '),

                          // : Column(
                          //     children: [
                          //       ProfileItem(
                          //           name: ub.data!.info!.relationship!
                          //               .title!,
                          //           svgName:
                          //               'assets/images/favorite.svg',
                          //           type:
                          //               '${ub.data!.info!.relationship!.typeName!} with '),
                          //       Padding(
                          //         padding:
                          //             const EdgeInsets.only(left: 16.0),
                          //         child: AppRelationship(
                          //             ub.data!.info!.relationship!,
                          //             isEdit: false),
                          //       ),
                          //     ],
                          //   ),
                          const Divider(),
                          // Friends
                          friendsWidget(fb),
                          const Divider(),
                          // Interests
                          // interestWidget(ib),
                          // const Divider(),
                          // Photo button
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: ElevatedButton(
                              onPressed: () {
                                nextScreen(context, PhotosPage(user: ub.data));
                              },
                              style: ElevatedButton.styleFrom(
                                  primary: Config().text4Color),
                              child: Text(
                                'photo_video'.tr(),
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: Config().text90Color),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Posts
                  pb.hasData == false
                      ? SliverFillRemaining(
                          child: Column(
                            children: [
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.35,
                              // ),
                              EmptyPage(
                                  icon: Icons.post_add_outlined,
                                  message: 'no_post_found'.tr(),
                                  message1: ''),
                            ],
                          ),
                        )
                      : SliverPadding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          sliver: SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                if (index < pb.data.length) {
                                  if (pb.data[index].mediaType == 2) {
                                    // VIDEO
                                    // return VideoCard(
                                    return PostVideoCard(
                                      d: pb.data[index],
                                      time: convertToAgo(
                                          pb.data[index].timestamp!),
                                      heroTag: 'post${index - 1}',
                                      onLikePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not like own post');
                                          return;
                                        }
                                        pb
                                            .setLike(sb.uid, pb.data[index])
                                            .then((value) {
                                          if (pb.isLiked == true) {
                                            pb.data[index].likes!.add(sb.uid!);
                                            openToast('Liked Post');
                                          } else {
                                            pb.data[index].likes!
                                                .remove(sb.uid!);
                                            openToast('Unliked Post');
                                          }
                                          setState(() {});
                                        });
                                      },
                                      onLikesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewLikesPage(
                                                uids: pb.data[index].likes));
                                      },
                                      isLiked: pb.data[index].likes!
                                          .contains(sb.uid),
                                      onSharePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not share own post');
                                          return;
                                        }
                                      },
                                      onSharesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewSharesPage(
                                                uids: pb.data[index].shares));
                                      },
                                      isShared: pb.data[index].shares!
                                          .contains(sb.uid),
                                      onCommentPressed: () async {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not comment own post');
                                          return;
                                        }
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        if (ret != null) {
                                          pb.data[index].comments = ret;
                                          setState(() {});
                                        }
                                      },
                                      onCommentsPressed: () async {
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        if (ret != null) {
                                          pb.data[index].comments = ret;
                                          setState(() {});
                                        }
                                      },
                                      onMoreTap: () {
                                        // More Tap
                                        showMoreSheet(
                                            context,
                                            ub.data!,
                                            pb.data[index],
                                            true,
                                            sb.uid!,
                                            sb.uid == pb.data[index].uid
                                                ? false
                                                : true,
                                            onPinTap: () {
                                              Navigator.pop(context);
                                              _pinUnpinPost(pb.data[index]);
                                            },
                                            onFollowTap: () {},
                                            onReportTap: () {},
                                            onHideTap: () {
                                              Navigator.pop(context);
                                              _hidePost(pb.data[index], sb.uid);
                                            },
                                            onDeleteTap: () {
                                              Navigator.pop(context);
                                              _deletePost(pb.data[index]);
                                            });
                                        // _showMoreSheet(context, pb.data[index], sb.uid!);
                                      },
                                      onPhotoTap: () {
                                        nextScreen(
                                            context,
                                            ShowPhotoPage(
                                                p: pb.data[index],
                                                changedArray: false));
                                      },
                                      onAvatarTap: () {
                                        if (sb.uid != pb.data[index].uid) {
                                          nextScreen(
                                              context,
                                              UserProfilePage(
                                                  uid: pb.data[index].uid));
                                        } else {
                                          nextScreen(
                                              context,
                                              ProfileMainPage(
                                                  uid: pb.data[index].uid));
                                        }
                                      },
                                    );
                                  }
                                  return Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 8),
                                    // child: Card1(
                                    child: PostCard(
                                      d: pb.data[index],
                                      time: convertToAgo(
                                          pb.data[index].timestamp!),
                                      heroTag: 'post$index',
                                      onLikePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not like own post');
                                          return;
                                        }
                                        pb
                                            .setLike(sb.uid, pb.data[index])
                                            .then((value) {
                                          if (pb.isLiked == true) {
                                            pb.data[index].likes!.add(sb.uid!);
                                            openToast('Liked Post');
                                          } else {
                                            pb.data[index].likes!
                                                .remove(sb.uid!);
                                            openToast('Unliked Post');
                                          }
                                          setState(() {});
                                        });
                                      },
                                      onLikesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewLikesPage(
                                                uids: pb.data[index].likes));
                                      },
                                      isLiked: pb.data[index].likes!
                                          .contains(sb.uid),
                                      onSharePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not share own post');
                                          return;
                                        }
                                        // pb
                                        //     .setShare(sb.uid, pb.data[index])
                                        //     .then((value) {
                                        //   if (pb.isShared == true) {
                                        //     pb.data[index].shares!.add(sb.uid!);
                                        //     openToast('Shared Post');
                                        //   } else {
                                        //     pb.data[index].shares!
                                        //         .remove(sb.uid!);
                                        //     openToast('Unshared Post');
                                        //   }
                                        //   setState(() {});
                                        // });
                                      },
                                      onSharesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewSharesPage(
                                                uids: pb.data[index].shares));
                                      },
                                      isShared: pb.data[index].shares!
                                          .contains(sb.uid),
                                      onCommentPressed: () async {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not comment own post');
                                          return;
                                        }
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        pb.data[index].comments = ret;
                                        setState(() {});
                                      },
                                      onCommentsPressed: () async {
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        pb.data[index].comments = ret;
                                        setState(() {});
                                      },
                                      onMoreTap: () {
                                        // More Tap
                                        showMoreSheet(
                                            context,
                                            ub.data!,
                                            pb.data[index],
                                            true,
                                            sb.uid!,
                                            sb.uid == pb.data[index].uid
                                                ? false
                                                : true,
                                            onPinTap: () {
                                              Navigator.pop(context);
                                              _pinUnpinPost(pb.data[index]);
                                            },
                                            onFollowTap: () {},
                                            onReportTap: () {},
                                            onHideTap: () {
                                              Navigator.pop(context);
                                              _hidePost(pb.data[index], sb.uid);
                                            },
                                            onDeleteTap: () {
                                              Navigator.pop(context);
                                              _deletePost(pb.data[index]);
                                            });
                                        // _showMoreSheet(context, pb.data[index]);
                                      },
                                      onPhotoTap: () {
                                        nextScreen(
                                            context,
                                            ShowPhotoPage(
                                                p: pb.data[index],
                                                changedArray: false));
                                      },
                                      onAvatarTap: () {},
                                      onCWShowPressed: () {
                                        nextScreen(
                                            context,
                                            ShowContentWarningPostPage(
                                                post: pb.data[index]));
                                      },
                                    ),
                                  );
                                }
                                return Opacity(
                                  opacity: pb.isLoading ? 1.0 : 0.0,
                                  child: pb.lastVisible == null
                                      ? LoadingCard(height: 250)
                                      : Center(
                                          child: SizedBox(
                                              width: 32.0,
                                              height: 32.0,
                                              child:
                                                  new CupertinoActivityIndicator()),
                                        ),
                                );
                              },
                              childCount:
                                  pb.data.length == 0 ? 5 : pb.data.length + 1,
                            ),
                          ),
                        ),
                ],
              ),
            ),
    );
  }

  Container interestWidget(InterestBloc ib) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'interests'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          ib.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_interests'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: ib.myInterests.isNotEmpty
                        ? ib.myInterests.length + 1
                        : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < ib.myInterests.length) {
                        return InterestCard3(
                          d: ib.myInterests[index],
                          heroTag: 'card3$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: ib.isLoading ? 1.0 : 0.0,
                        child: ib.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  Container friendsWidget(FriendsBloc fb) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'friends'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          fb.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_friends'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: fb.data.length != 0 ? fb.data.length + 1 : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < fb.data.length) {
                        return FriendsCard2(
                          d: fb.data[index],
                          heroTag: 'friends$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: fb.isLoading ? 1.0 : 0.0,
                        child: fb.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  _customAppBar(WUser user, context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: user.coverUrl != ''
            ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
            : Image.asset(
                'assets/images/blank.png',
                fit: BoxFit.cover,
              ),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        'profile'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      actions: <Widget>[
        IconButton(
          icon: const Icon(Icons.settings_outlined,
              size: 22, color: Colors.white),
          onPressed: () {
            nextScreen(context, SettingProfilePage(user: user));
          },
        ),
        SizedBox(
          width: 5,
        )
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 60,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: CustomCacheImage(
                          imageUrl: user.avatar,
                          radius: 45.0,
                          circularShape: true),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      Text(
                        user.name!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        '@${user.name!.replaceAll(' ', '').toLowerCase()}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  showAddStorySheet(BuildContext ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                  },
                  icon: Icon(Icons.clear),
                ),
              ],
            ),
            // Image
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 1);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.image_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // video
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                pickMediaDialog(ctx, 2);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.live_tv_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'video'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // text
            InkWell(
              onTap: () async {
                Navigator.pop(context);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    const Icon(Icons.text_snippet_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'text'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  pickMediaDialog(BuildContext ctx, int type) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(false);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(type == 1
                            ? Icons.add_photo_alternate_outlined
                            : Icons.video_camera_front_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'gallery'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () async {
                    Navigator.pop(context);
                    if (type == 1) {
                      var file = await pickImage(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Image",
                            ));
                      }
                    } else {
                      var file = await pickVideo(true);
                      if (file != null) {
                        nextScreen(
                            context,
                            AddStoryPage(
                              storyFile: file,
                              storyType: "Video",
                              thumbnail: videoThumbBytes,
                            ));
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        Icon(Icons.camera_outlined),
                        Padding(
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            'camera'.tr(),
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Config().text90Color),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<File?> pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      return File(image.path);
    } else {
      print('No image selected!');
      return null;
    }
  }

  Future<File?> pickVideo(bool camera) async {
    XFile? video;
    if (camera) {
      video = await ImagePicker().pickVideo(source: ImageSource.camera);
    } else {
      video = await ImagePicker().pickVideo(source: ImageSource.gallery);
    }

    var size = await video!.readAsBytes();
    if (size.lengthInBytes > 50 * 1024 * 1024) {
      openToast('The video size should be less than 50MB');
      return null;
    }

    if (video != null) {
      // Generate thumbnail
      var thumbBytes = await VideoCompress.getByteThumbnail(video.path,
          quality: 50, position: -1);

      videoThumbBytes = thumbBytes;

      // Compress video
      setState(() {
        _isLoading = true;
      });
      MediaInfo? mi;
      try {
        await VideoCompress.setLogLevel(0);

        mi = await VideoCompress.compressVideo(video.path,
            quality: VideoQuality.LowQuality,
            includeAudio: true,
            deleteOrigin: true);

        setState(() {
          _isLoading = false;
        });
        return File(mi!.path!);
      } catch (e) {
        VideoCompress.cancelCompression();
        setState(() {
          _isLoading = false;
        });
        return null;
      }
      // return File(video.path);
    } else {
      print('No image selected!');
      return null;
    }
  }
}

class ProfileItem extends StatelessWidget {
  const ProfileItem({
    Key? key,
    required this.name,
    required this.svgName,
    required this.type,
  }) : super(key: key);

  final String name;
  final String svgName;
  final String type;

  @override
  Widget build(BuildContext context) {
    return name == ''
        ? Container()
        : Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 8),
            child: Row(
              children: [
                SvgPicture.asset(svgName),
                Padding(
                  padding: const EdgeInsets.only(left: 12),
                  child: Text(
                    type,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                ),
                Text(
                  ' $name'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Config().text90Color),
                ),
              ],
            ),
          );
  }
}

class ExpandedIconButton extends StatelessWidget {
  final String? title;
  final IconData? iconData;
  final Function()? onPressed;
  const ExpandedIconButton(
      {Key? key, this.title, this.iconData, this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        onPressed: onPressed,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(iconData, color: Colors.white),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                title!,
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
