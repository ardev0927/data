import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:twiddle/models/relationship.dart';
import 'package:twiddle/utils/toast.dart';

import '../../config/config.dart';
import '../../utils/cached_image.dart';
import '../../utils/other.dart';
import '../../utils/validate.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_text_input.dart';

class RelationshipPage extends StatefulWidget {
  RelationshipPage({
    super.key,
    required this.isFileImage,
    required this.image,
    required this.name,
    required this.desc,
  });

  // final Relationship? relationship;
  final bool? isFileImage;
  String? image;
  String? name;
  String? desc;

  @override
  State<RelationshipPage> createState() => _RelationshipPageState();
}

class _RelationshipPageState extends State<RelationshipPage> {
  final _textNameCtrl = TextEditingController();
  final _textDescCtrl = TextEditingController();
  final _focusName = FocusNode();
  final _focusDesc = FocusNode();
  final _divide = 3;

  String? _validName;
  String? _validDesc;

  File? _avatarFile;
  // Relationship? _relationship;
  // bool _isFile = false;
  String? _image;
  String? _name;
  String? _desc;

  bool _updating = false;

  @override
  void initState() {
    // _isFile = widget.isFileImage!;
    _image = widget.image;
    _name = widget.name;
    _desc = widget.desc;

    if (_name != null) {
      _textNameCtrl.text = _name!;
    }
    if (_desc != null) {
      _textDescCtrl.text = _desc!;
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'relationship'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    var width = MediaQuery.of(context).size.width;

    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: width / _divide,
            height: width / _divide,
            child: Stack(
              children: [
                Padding(
                    padding: const EdgeInsets.all(5),
                    child: _avatarFile == null
                        ? widget.isFileImage!
                            ? Container(
                                width: width / _divide,
                                height: width / _divide,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    image: Image.file(
                                      File(_image!),
                                    ).image,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              )
                            : CustomCacheImage(
                                imageUrl:
                                    _image ?? Config().defaultUserImageUrl,
                                radius: width / _divide / 2,
                                circularShape: true)
                        : Container(
                            width: width / _divide,
                            height: width / _divide,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: Image.file(
                                  _avatarFile!,
                                ).image,
                                fit: BoxFit.cover,
                              ),
                            ),
                          )),
                Align(
                  alignment: Alignment.bottomRight,
                  child: GestureDetector(
                    onTap: () {
                      print('===== avatar button =====');
                      _showPhotoSheet(context);
                    },
                    child: Container(
                      width: width / _divide / 5,
                      height: width / _divide / 5,
                      margin: const EdgeInsets.only(bottom: 5, right: 5),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Config().text8Color,
                      ),
                      child: Center(
                        child: SvgPicture.asset(
                            'assets/images/android_camera.svg'),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          AppTextInput(
            hintText: 'name'.tr(),
            errorText: _validName,
            focusNode: _focusName,
            textInputAction: TextInputAction.next,
            onSubmitted: (text) {
              UtilOther.fieldFocusChange(
                context,
                _focusName,
                _focusDesc,
              );
            },
            onChanged: (text) {
              setState(() {
                _validName = UtilValidator.validate(
                  _textNameCtrl.text,
                );
              });
            },
            controller: _textNameCtrl,
          ),
          const SizedBox(height: 16),
          AppTextInput(
            hintText: 'description'.tr(),
            errorText: _validDesc,
            focusNode: _focusDesc,
            maxLines: 3,
            textInputAction: TextInputAction.done,
            // trailing: Cont,
            onSubmitted: (text) {},
            onChanged: (text) {
              setState(() {
                _validDesc = UtilValidator.validate(
                  _textDescCtrl.text,
                );
              });
            },
            controller: _textDescCtrl,
          ),
          const Spacer(),
          AppButton(
            'save'.tr(),
            mainAxisSize: MainAxisSize.max,
            onPressed: _save,
            loading: _updating,
          ),
        ],
      ),
    );
  }

  // Bottom sheet for cover or avata
  _showPhotoSheet(ctx) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // photo
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickAvatarImage(false);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/images/add_photo_alternate.svg',
                      color: Config().text90Color,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'photo'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // camera
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                await pickAvatarImage(true);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    SvgPicture.asset('assets/images/camera.svg'),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'camera'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future pickAvatarImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }
    if (image != null) {
      _avatarFile = File(image.path);
      setState(() {});
    } else {
      print('No image selected!');
    }
  }

  _save() {
    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validName = UtilValidator.validate(
        _textNameCtrl.text,
      );
      _validDesc = UtilValidator.validate(
        _textDescCtrl.text,
      );
    });

    if (_avatarFile == null && _image == null) {
      openToast('Please select photo');
    } else {
      if (_validName == null && _validDesc == null) {
        Map<String, dynamic>? data = {
          'image': _avatarFile == null ? null : _avatarFile!.path,
          'name': _textNameCtrl.text,
          'desc': _textDescCtrl.text,
        };

        Navigator.pop(context, data);
      }
    }
  }
}
