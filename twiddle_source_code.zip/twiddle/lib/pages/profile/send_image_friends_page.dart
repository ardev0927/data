import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/cards/friends_card5.dart';
import 'package:twiddle/pages/chat_story/chat/user_message_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../blocs/my_friends_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';
import '../chat_story/chat/message_details_page.dart';

class SendImageFriendsPage extends StatefulWidget {
  final String? imageUrl;
  const SendImageFriendsPage({super.key, required this.imageUrl});

  @override
  State<SendImageFriendsPage> createState() => _SendImageFriendsPageState();
}

class _SendImageFriendsPageState extends State<SendImageFriendsPage> {
  ScrollController? controller, storyController;
  String? imageUrl;

  @override
  void initState() {
    super.initState();

    imageUrl = widget.imageUrl;

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();

      controller = ScrollController()..addListener(_scrollListener);
      context.read<MyFriendsBloc>().getData(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final fb = context.read<MyFriendsBloc>();
    final sb = context.read<SignInBloc>();

    if (!fb.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        print('===== friends scroll listener =====');
        context.read<MyFriendsBloc>().setLoading(true);
        context.read<MyFriendsBloc>().getData(sb.uid, mounted);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: const Icon(Icons.arrow_back),
        ),
        title: Text(
          'friends'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final fb = context.watch<MyFriendsBloc>();
    final sb = context.read<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        context.read<MyFriendsBloc>().onRefresh(sb.uid, mounted);
      },
      child: fb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.20,
                ),
                EmptyPage(
                    icon: Icons.person_off_outlined,
                    message: 'no_friends'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              // key: PageStorageKey(widget.category),
              padding: const EdgeInsets.only(top: 8),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: fb.data.isNotEmpty ? fb.data.length + 1 : 5,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(height: 4),
              shrinkWrap: true,
              itemBuilder: (_, int index) {
                if (index < fb.data.length) {
                  return FriendsCard5(
                    d: fb.data[index],
                    heroTag: 'tab1$index',
                    onItemTapped: () {
                      var user = fb.data[index];
                      nextScreen(
                        context,
                        UserMessagePage(
                            user: user, isSend: true, url: imageUrl),
                      );
                    },
                  );
                }
                return Opacity(
                  opacity: fb.isLoading ? 1.0 : 0.0,
                  child: fb.lastVisible == null
                      ? const LoadingCard(height: 50)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }
}
