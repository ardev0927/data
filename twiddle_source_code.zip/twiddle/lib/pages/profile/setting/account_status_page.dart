import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/models/user.dart';

import '../../../blocs/my_group_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/manage_group_card.dart';
import '../../../config/config.dart';
import '../../../utils/cached_image.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../group/managed_group_page.dart';
import '../../group/not_joined_group_page.dart';

class AccountStatusPage extends StatefulWidget {
  const AccountStatusPage({super.key, required this.user});
  final WUser? user;

  @override
  State<AccountStatusPage> createState() => _AccountStatusPageState();
}

class _AccountStatusPageState extends State<AccountStatusPage> {
  ScrollController? myCtrl;
  final _orderBy = 'timestamp';

  @override
  void initState() {
    super.initState();

    Future.delayed(Duration(milliseconds: 0)).then((value) {
      var sb = context.read<SignInBloc>();

      myCtrl = ScrollController()..addListener(_myScrollListener);
      context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);
    });
  }

  @override
  void dispose() {
    super.dispose();

    myCtrl!.removeListener(_myScrollListener);
  }

  void _myScrollListener() {
    final mgb = context.read<MyGroupBloc>();
    final sb = context.read<SignInBloc>();

    if (!mgb.isLoading) {
      if (myCtrl!.position.pixels == myCtrl!.position.maxScrollExtent) {
        context.read<MyGroupBloc>().setLoading(true);
        context.read<MyGroupBloc>().getData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mgb = context.watch<MyGroupBloc>();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          _customAppBar(widget.user!, context),
          SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.all(16),
              width: MediaQuery.of(context).size.width,
              // height: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'things_you_manage'.tr(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Config().text90Color),
                  ),
                  _manageGroupWidget(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  _manageGroupWidget() {
    final mgb = context.watch<MyGroupBloc>();
    final sb = context.watch<SignInBloc>();

    return mgb.hasData == false
        ? Container()
        : SizedBox(
            width: MediaQuery.of(context).size.width,
            child: ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: mgb.data.isNotEmpty ? mgb.data.length + 1 : 5,
              controller: myCtrl,
              itemBuilder: (ctx, index) {
                print('manage group count is ${mgb.data.length}');
                if (index < mgb.data.length) {
                  if (mgb.data[index].ownerUid != sb.uid) {
                    return Container();
                  }
                  return ManageGroupCard(
                    d: mgb.data[index],
                    heroTag: 'manage$index',
                    onTap: () async {
                      if (mgb.data[index].ownerUid == sb.uid) {
                        nextScreen(
                            context, ManagedGroupPage(group: mgb.data[index]));
                      } else {
                        if (mgb.data[index].members!.contains(sb.uid)) {
                          nextScreen(context,
                              ManagedGroupPage(group: mgb.data[index]));
                        } else {
                          var ret = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => NotJoinedGroupPage(
                                      group: mgb.data[index])));
                          if (ret != null) {}
                        }
                      }
                      // _validateGroup(mgb, mgb.data[index - 1], sb.uid);
                    },
                  );
                }
                return Opacity(
                  opacity: mgb.isLoading ? 1.0 : 0.0,
                  child: mgb.lastVisible == null
                      ? LoadingCard(height: 80)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
          );
  }

  _customAppBar(WUser user, context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: user.coverUrl != ''
            ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
            : Image.asset(
                'assets/images/profile_cover.png',
                fit: BoxFit.cover,
              ),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        'account_status'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 60,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: CustomCacheImage(
                          imageUrl: user.avatar,
                          radius: 45.0,
                          circularShape: true),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      Text(
                        user.name!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        '@${user.name!.split(' ')[0]}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
