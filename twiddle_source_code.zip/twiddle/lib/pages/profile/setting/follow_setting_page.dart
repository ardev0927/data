import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../config/config.dart';

class FollowSettingPage extends StatefulWidget {
  const FollowSettingPage({super.key});

  @override
  State<FollowSettingPage> createState() => _FollowSettingPageState();
}

class _FollowSettingPageState extends State<FollowSettingPage> {
  String? _follow, _prople, _comments, _notifications, _profile;
  // var _follow, _prople, _comments, _notifications, _profile;
  List<String> followSettings = [
    'follow_me',
    'see_people',
    'public_post_comments',
    'public_post_notification',
    'publish_profile_info',
  ];

  @override
  void initState() {
    super.initState();

    getValues();
  }

  getValues() async {
    var sp = await SharedPreferences.getInstance();

    _follow = sp.getString(followSettings[0]);
    _prople = sp.getString(followSettings[1]);
    _comments = sp.getString(followSettings[2]);
    _notifications = sp.getString(followSettings[3]);
    _profile = sp.getString(followSettings[4]);

    setState(() {
      _follow = _follow ?? 'Public';
      _prople = _prople ?? 'Public';
      _comments = _comments ?? 'Public';
      _notifications = _notifications ?? 'Public';
      _profile = _profile ?? 'Public';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'follow_setting'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: ListView(
        children: [
          // Who can Follow me
          Text(
            'who_can_follow_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          publicFollowWidget(0),
          // Who can see prople
          Text(
            'who_can_see_the_prople'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          publicPeopleWidget(1),
          // Public Post Comments?
          Text(
            'public_post_comments'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          publicCommentWidget(2),
          // Public Post Notifications?
          Text(
            'public_post_notification'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          publicNotificationWidget(3),
          // Public profile info?
          Text(
            'public_profile_info'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          publicProfileWidget(4),
        ],
      ),
    );
  }

  publicFollowWidget(int index) {
    return Column(
      children: [
        RadioListTile(
          title: Text(
            'public'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Public',
          groupValue: _follow,
          onChanged: (value) {
            setFollowSetting(value, index);

            setState(() {
              _follow = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'friends'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Friends',
          groupValue: _follow,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _follow = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'only_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Only Me',
          groupValue: _follow,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _follow = value;
            });
          },
        ),
      ],
    );
  }

  publicPeopleWidget(int index) {
    return Column(
      children: [
        RadioListTile(
          title: Text(
            'public'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Public',
          groupValue: _prople,
          onChanged: (value) {
            setFollowSetting(value, index);

            setState(() {
              _prople = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'friends'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Friends',
          groupValue: _prople,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _prople = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'only_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Only Me',
          groupValue: _prople,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _prople = value;
            });
          },
        ),
      ],
    );
  }

  publicCommentWidget(int index) {
    return Column(
      children: [
        RadioListTile(
          title: Text(
            'public'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Public',
          groupValue: _comments,
          onChanged: (value) {
            setFollowSetting(value, index);

            setState(() {
              _comments = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'friends'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Friends',
          groupValue: _comments,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _comments = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'only_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Only Me',
          groupValue: _comments,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _comments = value;
            });
          },
        ),
      ],
    );
  }

  publicNotificationWidget(int index) {
    return Column(
      children: [
        RadioListTile(
          title: Text(
            'public'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Public',
          groupValue: _notifications,
          onChanged: (value) {
            setFollowSetting(value, index);

            setState(() {
              _notifications = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'friends'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Friends',
          groupValue: _notifications,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _notifications = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'only_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Only Me',
          groupValue: _notifications,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _notifications = value;
            });
          },
        ),
      ],
    );
  }

  publicProfileWidget(int index) {
    return Column(
      children: [
        RadioListTile(
          title: Text(
            'public'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Public',
          groupValue: _profile,
          onChanged: (value) {
            setFollowSetting(value, index);

            setState(() {
              _profile = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'friends'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Friends',
          groupValue: _profile,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _profile = value;
            });
          },
        ),
        RadioListTile(
          title: Text(
            'only_me'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
          value: 'Only Me',
          groupValue: _profile,
          onChanged: (value) {
            setFollowSetting(value, index);
            setState(() {
              _profile = value;
            });
          },
        ),
      ],
    );
  }

  setFollowSetting(String? groupValue, int settingIndex) async {
    var sp = await SharedPreferences.getInstance();

    sp.setString(followSettings[settingIndex], groupValue!);
  }
}
