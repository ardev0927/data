import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';

// import '../../blocs/post_user_bloc.dart';
import '../../../blocs/my_post_bloc.dart';
import '../../../blocs/posts_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../blocs/user_bloc.dart';
import '../../../cards/card1.dart';
import '../../../cards/video_card.dart';
import '../../../config/config.dart';
import '../../../models/post.dart';
import '../../../services/app_service.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../post/view_comments_page.dart';
import '../../post/view_likes_page.dart';
import '../../post/view_shares_page.dart';

class ManagePostPage extends StatefulWidget {
  const ManagePostPage({super.key});

  @override
  State<ManagePostPage> createState() => _ManagePostPageState();
}

class _ManagePostPageState extends State<ManagePostPage> {
  final _orderBy = 'timestamp';
  ScrollController? controller;
  int index = 0;

  List<Post> posts = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    getPosts();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appbar(),
      body: _body(),
    );
  }

  _appbar() {
    return AppBar(
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(Icons.arrow_back),
      ),
      title: Text(
        'manage_post'.tr(),
        style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Config().text100Color),
      ),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              if (posts.length - 1 > index) {
                index += 1;
              }
            });
          },
          child: Text(
            'next'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text100Color),
          ),
        ),
      ],
    );
  }

  _body() {
    final sb = context.watch<SignInBloc>();

    return Stack(
      children: [
        isLoading
            ? const Center(
                child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: CupertinoActivityIndicator()),
              )
            : posts.isEmpty
                ? Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      EmptyPage(
                          icon: Icons.post_add_outlined,
                          message: 'no_post_found'.tr(),
                          message1: ''),
                    ],
                  )
                : getItem(sb),
        isLoading
            ? Container()
            : posts.isEmpty
                ? Container()
                : Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      height: 40,
                      width: 150,
                      margin: const EdgeInsets.symmetric(vertical: 32),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        color: Config().text4Color,
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                _hidePost(posts[index], sb.uid);
                              },
                              icon: Icon(
                                Icons.hide_source,
                                color: Config().text60Color,
                              ),
                            ),
                          ),
                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                _tagPost();
                              },
                              icon: Icon(
                                Icons.loyalty_outlined,
                                color: posts[index].hasTag!
                                    ? Config().primary30Color
                                    : Config().text60Color,
                              ),
                            ),
                          ),
                          Expanded(
                            child: IconButton(
                              onPressed: () {
                                openPopupDialog(context);
                              },
                              icon: Icon(
                                Icons.delete_outline,
                                color: Config().text60Color,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
      ],
    );
  }

  getItem(SignInBloc sb) {
    var pb = context.read<MyPostBloc>();

    if (index < posts.length) {
      if (posts[index].mediaType == 2) {
        // VIDEO
        // return VideoCard(
        return PostVideoCard(
          d: posts[index],
          time: convertToAgo(posts[index].timestamp!),
          heroTag: 'post${index - 1}',
          onLikePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not like own post');
              return;
            }
            pb.setLike(sb.uid, posts[index]).then((value) {
              if (pb.isLiked == true) {
                posts[index].likes!.add(sb.uid!);
                openToast('Liked Post');
              } else {
                posts[index].likes!.remove(sb.uid!);
                openToast('Unliked Post');
              }
              setState(() {});
            });
          },
          onLikesPressed: () {
            nextScreen(context, ViewLikesPage(uids: posts[index].likes));
          },
          isLiked: posts[index].likes!.contains(sb.uid),
          onSharePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not share own post');
              return;
            }
          },
          onSharesPressed: () {
            nextScreen(context, ViewSharesPage(uids: posts[index].shares));
          },
          isShared: posts[index].shares!.contains(sb.uid),
          onCommentPressed: () async {
            if (sb.uid == posts[index].uid) {
              openToast('You can not comment own post');
              return;
            }
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            if (ret != null) {
              posts[index].comments = ret;
              setState(() {});
            }
          },
          onCommentsPressed: () async {
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            if (ret != null) {
              posts[index].comments = ret;
              setState(() {});
            }
          },
          // onMoreTap: () {
          //   // More Tap
          //   showMoreSheet(context, ub.data!, posts[index], true, sb.uid!,
          //       onPinTap: () {
          //         Navigator.pop(context);
          //         _pinUnpinPost(posts[index]);
          //       },
          //       onFollowTap: () {},
          //       onReportTap: () {},
          //       onHideTap: () {
          //         Navigator.pop(context);
          //         _hidePost(posts[index], sb.uid);
          //       },
          //       onDeleteTap: () {
          //         Navigator.pop(context);
          //         _deletePost(posts[index]);
          //       });
          //   // _showMoreSheet(context, posts[index], sb.uid!);
          // },
          onPhotoTap: () {
            nextScreen(
                context, ShowPhotoPage(p: posts[index], changedArray: false));
          },
          onAvatarTap: () {
            if (sb.uid != posts[index].uid) {
              nextScreen(context, UserProfilePage(uid: posts[index].uid));
            } else {
              nextScreen(context, ProfileMainPage(uid: posts[index].uid));
            }
          },
        );
      }
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        // child: Card1(
        child: PostCard(
          d: posts[index],
          time: convertToAgo(posts[index].timestamp!),
          heroTag: 'post$index',
          onLikePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not like own post');
              return;
            }
            pb.setLike(sb.uid, posts[index]).then((value) {
              if (pb.isLiked == true) {
                posts[index].likes!.add(sb.uid!);
                openToast('Liked Post');
              } else {
                posts[index].likes!.remove(sb.uid!);
                openToast('Unliked Post');
              }
              setState(() {});
            });
          },
          onLikesPressed: () {
            nextScreen(context, ViewLikesPage(uids: posts[index].likes));
          },
          isLiked: posts[index].likes!.contains(sb.uid),
          onSharePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not share own post');
              return;
            }
            // pb
            //     .setShare(sb.uid, posts[index])
            //     .then((value) {
            //   if (pb.isShared == true) {
            //     posts[index].shares!.add(sb.uid!);
            //     openToast('Shared Post');
            //   } else {
            //     posts[index].shares!
            //         .remove(sb.uid!);
            //     openToast('Unshared Post');
            //   }
            //   setState(() {});
            // });
          },
          onSharesPressed: () {
            nextScreen(context, ViewSharesPage(uids: posts[index].shares));
          },
          isShared: posts[index].shares!.contains(sb.uid),
          onCommentPressed: () async {
            if (sb.uid == posts[index].uid) {
              openToast('You can not comment own post');
              return;
            }
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            posts[index].comments = ret;
            setState(() {});
          },
          onCommentsPressed: () async {
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            posts[index].comments = ret;
            setState(() {});
          },
          // onMoreTap: () {
          //   // More Tap
          //   showMoreSheet(context, ub.data!, posts[index], true, sb.uid!,
          //       onPinTap: () {
          //         Navigator.pop(context);
          //         _pinUnpinPost(posts[index]);
          //       },
          //       onFollowTap: () {},
          //       onReportTap: () {},
          //       onHideTap: () {
          //         Navigator.pop(context);
          //         _hidePost(posts[index], sb.uid);
          //       },
          //       onDeleteTap: () {
          //         Navigator.pop(context);
          //         _deletePost(posts[index]);
          //       });
          //   // _showMoreSheet(context, posts[index]);
          // },
          onPhotoTap: () {
            nextScreen(
                context, ShowPhotoPage(p: posts[index], changedArray: false));
          },
          onAvatarTap: () {},
        ),
      );
    }
  }

  openPopupDialog(ctx) {
    final ub = context.read<UserBlock>();

    showDialog(
      context: ctx,
      builder: (BuildContext context) {
        return Dialog(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(ub.data!.avatar!),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    ub.data!.name!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Config().text90Color),
                  ),
                ),
                Divider(height: 2, color: Config().text8Color),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    'are_you_sure_you_want_to_delete_this_post'.tr(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text100Color),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Config().text20Color,
                          fixedSize: Size(100, 40)),
                      child: Text(
                        'no'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                    ),
                    const SizedBox(width: 30),
                    ElevatedButton(
                      onPressed: () {
                        _deletePost(posts[index]);
                      },
                      style: ElevatedButton.styleFrom(fixedSize: Size(100, 40)),
                      child: Text(
                        'yes'.tr(),
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  getPosts() async {
    final MyPostBloc pb = Provider.of<MyPostBloc>(context, listen: false);
    final SignInBloc sb = context.read<SignInBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          isLoading = true;
        });
        pb.getMyData(sb.uid, mounted, _orderBy).then((value) {
          if (pb.hasError == false) {
            posts.clear();
            posts.addAll(pb.data);
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {
            isLoading = false;
          });
        });
      }
    });
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${posts.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            posts.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _tagPost() async {
    print('====== post id is ${posts[index].postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        bool tag = !posts[index].hasTag!;
        pb.tagPost(posts[index], tag).then((value) {
          if (pb.hasError == false) {
            posts[index].hasTag = tag;
            // openToast('Post has tag');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
