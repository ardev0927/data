import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/post_tag_bloc.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';

import '../../../blocs/posts_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../cards/card1.dart';
import '../../../cards/video_card.dart';
import '../../../config/config.dart';
import '../../../models/post.dart';
import '../../../services/app_service.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/empty.dart';
import '../../../utils/next_screen.dart';
import '../../../utils/snacbar.dart';
import '../../../utils/toast.dart';
import '../../post/view_comments_page.dart';
import '../../post/view_likes_page.dart';
import '../../post/view_shares_page.dart';

class ReviewPostTagsPage extends StatefulWidget {
  const ReviewPostTagsPage({super.key});

  @override
  State<ReviewPostTagsPage> createState() => _ReviewPostTagsPageState();
}

class _ReviewPostTagsPageState extends State<ReviewPostTagsPage> {
  final _orderBy = 'timestamp';
  ScrollController? controller;
  int index = 0;

  List<Post> posts = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();

    getPosts();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appbar(),
      body: _body(),
    );
  }

  _appbar() {
    return AppBar(
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(Icons.arrow_back),
      ),
      title: Text(
        'review_post_and_tags'.tr(),
        style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Config().text100Color),
      ),
      actions: [
        TextButton(
          onPressed: () {
            setState(() {
              if (posts.length - 1 > index) {
                index += 1;
              }
            });
          },
          child: Text(
            'next'.tr(),
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text100Color),
          ),
        ),
      ],
    );
  }

  _body() {
    final sb = context.watch<SignInBloc>();

    return Column(
      children: [
        isLoading
            ? const Center(
                child: SizedBox(
                    width: 32.0,
                    height: 32.0,
                    child: CupertinoActivityIndicator()),
              )
            : posts.isEmpty
                ? Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      EmptyPage(
                          icon: Icons.post_add_outlined,
                          message: 'no_post_found'.tr(),
                          message1: ''),
                    ],
                  )
                : getItem(sb),
        posts.isEmpty
            ? Container()
            : Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () {
                    _hidePost(posts[index], sb.uid);
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    backgroundColor: Config().text10Color,
                  ),
                  child: Text(
                    'hide'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Config().text90Color),
                  ),
                ),
              ),
        posts.isEmpty
            ? Container()
            : Padding(
                padding: const EdgeInsets.all(16.0),
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                  ),
                  child: Text(
                    'add_to_profile'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
      ],
    );
  }

  getItem(SignInBloc sb) {
    var pb = context.read<PostTagBloc>();

    if (index < posts.length) {
      if (posts[index].mediaType == 2) {
        // VIDEO
        // return VideoCard(
        return PostVideoCard(
          d: posts[index],
          time: convertToAgo(posts[index].timestamp!),
          heroTag: 'post${index - 1}',
          onLikePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not like own post');
              return;
            }
            pb.setLike(sb.uid, posts[index]).then((value) {
              if (pb.isLiked == true) {
                posts[index].likes!.add(sb.uid!);
                openToast('Liked Post');
              } else {
                posts[index].likes!.remove(sb.uid!);
                openToast('Unliked Post');
              }
              setState(() {});
            });
          },
          onLikesPressed: () {
            nextScreen(context, ViewLikesPage(uids: posts[index].likes));
          },
          isLiked: posts[index].likes!.contains(sb.uid),
          onSharePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not share own post');
              return;
            }
          },
          onSharesPressed: () {
            nextScreen(context, ViewSharesPage(uids: posts[index].shares));
          },
          isShared: posts[index].shares!.contains(sb.uid),
          onCommentPressed: () async {
            if (sb.uid == posts[index].uid) {
              openToast('You can not comment own post');
              return;
            }
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            if (ret != null) {
              posts[index].comments = ret;
              setState(() {});
            }
          },
          onCommentsPressed: () async {
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            if (ret != null) {
              posts[index].comments = ret;
              setState(() {});
            }
          },
          // onMoreTap: () {
          //   // More Tap
          //   showMoreSheet(context, ub.data!, posts[index], true, sb.uid!,
          //       onPinTap: () {
          //         Navigator.pop(context);
          //         _pinUnpinPost(posts[index]);
          //       },
          //       onFollowTap: () {},
          //       onReportTap: () {},
          //       onHideTap: () {
          //         Navigator.pop(context);
          //         _hidePost(posts[index], sb.uid);
          //       },
          //       onDeleteTap: () {
          //         Navigator.pop(context);
          //         _deletePost(posts[index]);
          //       });
          //   // _showMoreSheet(context, posts[index], sb.uid!);
          // },
          onPhotoTap: () {
            nextScreen(
                context, ShowPhotoPage(p: posts[index], changedArray: false));
          },
          onAvatarTap: () {
            if (sb.uid != posts[index].uid) {
              nextScreen(context, UserProfilePage(uid: posts[index].uid));
            } else {
              nextScreen(context, ProfileMainPage(uid: posts[index].uid));
            }
          },
        );
      }
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        // child: Card1(
        child: PostCard(
          d: posts[index],
          time: convertToAgo(posts[index].timestamp!),
          heroTag: 'post$index',
          onLikePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not like own post');
              return;
            }
            pb.setLike(sb.uid, posts[index]).then((value) {
              if (pb.isLiked == true) {
                posts[index].likes!.add(sb.uid!);
                openToast('Liked Post');
              } else {
                posts[index].likes!.remove(sb.uid!);
                openToast('Unliked Post');
              }
              setState(() {});
            });
          },
          onLikesPressed: () {
            nextScreen(context, ViewLikesPage(uids: posts[index].likes));
          },
          isLiked: posts[index].likes!.contains(sb.uid),
          onSharePressed: () {
            if (sb.uid == posts[index].uid) {
              openToast('You can not share own post');
              return;
            }
            // pb
            //     .setShare(sb.uid, posts[index])
            //     .then((value) {
            //   if (pb.isShared == true) {
            //     posts[index].shares!.add(sb.uid!);
            //     openToast('Shared Post');
            //   } else {
            //     posts[index].shares!
            //         .remove(sb.uid!);
            //     openToast('Unshared Post');
            //   }
            //   setState(() {});
            // });
          },
          onSharesPressed: () {
            nextScreen(context, ViewSharesPage(uids: posts[index].shares));
          },
          isShared: posts[index].shares!.contains(sb.uid),
          onCommentPressed: () async {
            if (sb.uid == posts[index].uid) {
              openToast('You can not comment own post');
              return;
            }
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            posts[index].comments = ret;
            setState(() {});
          },
          onCommentsPressed: () async {
            int ret = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ViewCommentsPage(p: posts[index])));
            posts[index].comments = ret;
            setState(() {});
          },
          // onMoreTap: () {
          //   // More Tap
          //   showMoreSheet(context, ub.data!, posts[index], true, sb.uid!,
          //       onPinTap: () {
          //         Navigator.pop(context);
          //         _pinUnpinPost(posts[index]);
          //       },
          //       onFollowTap: () {},
          //       onReportTap: () {},
          //       onHideTap: () {
          //         Navigator.pop(context);
          //         _hidePost(posts[index], sb.uid);
          //       },
          //       onDeleteTap: () {
          //         Navigator.pop(context);
          //         _deletePost(posts[index]);
          //       });
          //   // _showMoreSheet(context, posts[index]);
          // },
          onPhotoTap: () {
            nextScreen(
                context, ShowPhotoPage(p: posts[index], changedArray: false));
          },
          onAvatarTap: () {},
        ),
      );
    }
  }

  getPosts() async {
    final PostTagBloc pb = Provider.of<PostTagBloc>(context, listen: false);
    final SignInBloc sb = context.read<SignInBloc>();

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          isLoading = true;
        });
        pb.getMyData(sb.uid, mounted, _orderBy).then((value) {
          if (pb.hasError == false) {
            posts.clear();
            posts.addAll(pb.data);
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {
            isLoading = false;
          });
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }
}
