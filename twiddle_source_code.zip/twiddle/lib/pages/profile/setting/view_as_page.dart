import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/post_user_bloc.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/widgets/app_relationship.dart';

import '../../../blocs/friends_bloc.dart';
import '../../../blocs/interest_bloc.dart';
import '../../../blocs/sign_in_bloc.dart';
import '../../../blocs/user_bloc.dart';
import '../../../cards/card1.dart';
import '../../../cards/friends_card2.dart';
import '../../../cards/interest_card3.dart';
import '../../../cards/video_card.dart';
import '../../../config/config.dart';
import '../../../models/post.dart';
import '../../../models/user.dart';
import '../../../utils/cached_image.dart';
import '../../../utils/convert_time_ago.dart';
import '../../../utils/empty.dart';
import '../../../utils/loading_cards.dart';

class ViewAsPage extends StatefulWidget {
  const ViewAsPage({super.key});

  @override
  State<ViewAsPage> createState() => _ViewAsPageState();
}

class _ViewAsPageState extends State<ViewAsPage> {
  String _orderBy = 'timestamp';
  ScrollController? controller;

  @override
  void initState() {
    super.initState();

    final SignInBloc sb = context.read<SignInBloc>();
    final ub = context.read<UserBlock>();
    ub.getUser(sb.uid, mounted).then((value) {
      context
          .read<InterestBloc>()
          .filterDataWithName(ub.data!.interests!, mounted);
    });
    context.read<FriendsBloc>().getData(sb.uid, mounted);
    controller = ScrollController()..addListener(_scrollListener);
    context.read<PostUserBloc>().getMyData(sb.uid, mounted, _orderBy);
    // context.read<InterestBloc>().getMyData(sb.uid, mounted);
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<PostUserBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<PostUserBloc>().setLoading(true);
        context.read<PostUserBloc>().getMyData(sb.uid, mounted, _orderBy);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<UserBlock>();
    final fb = context.watch<FriendsBloc>();
    final ib = context.watch<InterestBloc>();
    final pb = context.watch<PostUserBloc>();
    final sb = context.watch<SignInBloc>();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ub.isLoading == true
          ? Container(
              child: Center(child: CircularProgressIndicator()),
            )
          : RefreshIndicator(
              onRefresh: () async {
                pb.onMyRefresh(sb.uid, mounted, _orderBy);
              },
              child: CustomScrollView(
                slivers: [
                  _customAppBar(ub.data!, context),
                  SliverToBoxAdapter(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      // height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Profile Information
                          ProfileItem(
                              name: ub.data!.info!.hometown!,
                              svgName: 'assets/images/cottage.svg',
                              type: 'hometown'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.worksat!,
                              svgName: 'assets/images/home_repair_service.svg',
                              type: 'works_at'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.studiedat!,
                              svgName: 'assets/images/menu_book.svg',
                              type: 'studied_at'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.livesin!,
                              svgName: 'assets/images/home_pin.svg',
                              type: 'lives_in'.tr()),
                          ub.data!.info!.relationship == null
                              ? Container()
                              : ub.data!.info!.relationship!.typeName ==
                                      'Single'
                                  ? ProfileItem(
                                      name: ub
                                          .data!.info!.relationship!.typeName!,
                                      svgName: 'assets/images/favorite.svg',
                                      type: 'relationship_status'.tr())
                                  : AppRelationship(
                                      ub.data!.info!.relationship!,
                                      isEdit: false),
                          // ub.data!.interests!.isEmpty
                          //     ? Container()
                          //     : ProfileItem(
                          //         name: ub.data!.interests!.join(', '),
                          //         svgName: 'assets/images/interests.svg',
                          //         type: 'interest'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.birthdate!,
                              svgName: 'assets/images/calendar_month.svg',
                              type: 'date_of_birth'.tr()),
                          ProfileItem(
                              name: ub.data!.info!.gender!,
                              svgName: 'assets/images/wc.svg',
                              type: 'gender'.tr()),
                          const Divider(),
                          // Friends
                          friendsWidget(fb),
                          const Divider(),
                          // Interests
                          // interestWidget(ib),
                          // const Divider(),
                          // Photo button
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                  primary: Config().text4Color),
                              child: Text(
                                'photo_video'.tr(),
                                style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    color: Config().text90Color),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Posts
                  pb.hasData == false
                      ? SliverFillRemaining(
                          child: Column(
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.35,
                              ),
                              EmptyPage(
                                  icon: Icons.post_add_outlined,
                                  message: 'no_post_found'.tr(),
                                  message1: ''),
                            ],
                          ),
                        )
                      : SliverPadding(
                          padding: EdgeInsets.fromLTRB(10, 15, 10, 15),
                          sliver: SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                if (index < pb.data.length) {
                                  if (pb.data[index].mediaType == 2) {
                                    // VIDEO
                                    // return VideoCard(
                                    return PostVideoCard(
                                      d: pb.data[index],
                                      time: convertToAgo(
                                          pb.data[index].timestamp!),
                                      heroTag: 'post${index - 1}',
                                      onLikePressed: () {},
                                      onLikesPressed: () {},
                                      isLiked: pb.data[index].likes!
                                          .contains(sb.uid),
                                      onSharePressed: () {},
                                      onSharesPressed: () {},
                                      isShared: pb.data[index].shares!
                                          .contains(sb.uid),
                                      onCommentPressed: () async {},
                                      onCommentsPressed: () async {},
                                      onMoreTap: () {},
                                      onPhotoTap: () {},
                                      onAvatarTap: () {},
                                    );
                                  }
                                  // return Card1(
                                  return PostCard(
                                    d: pb.data[index],
                                    time:
                                        convertToAgo(pb.data[index].timestamp!),
                                    heroTag: 'post$index',
                                    onLikePressed: () {},
                                    onLikesPressed: () {},
                                    isLiked:
                                        pb.data[index].likes!.contains(sb.uid),
                                    onSharePressed: () {},
                                    onSharesPressed: () {},
                                    isShared:
                                        pb.data[index].shares!.contains(sb.uid),
                                    onCommentPressed: () async {},
                                    onCommentsPressed: () async {},
                                    onMoreTap: () {},
                                    onPhotoTap: () {},
                                    onAvatarTap: () {},
                                  );
                                }
                                return Opacity(
                                  opacity: pb.isLoading ? 1.0 : 0.0,
                                  child: pb.lastVisible == null
                                      ? LoadingCard(height: 250)
                                      : Center(
                                          child: SizedBox(
                                              width: 32.0,
                                              height: 32.0,
                                              child:
                                                  new CupertinoActivityIndicator()),
                                        ),
                                );
                              },
                              childCount:
                                  pb.data.length == 0 ? 5 : pb.data.length + 1,
                            ),
                          ),
                        ),
                ],
              ),
            ),
    );
  }

  Container interestWidget(InterestBloc ib) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'interests'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          ib.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_interests'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: ib.data.length != 0 ? ib.data.length + 1 : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < ib.data.length) {
                        return InterestCard3(
                          d: ib.data[index],
                          heroTag: 'card3$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: ib.isLoading ? 1.0 : 0.0,
                        child: ib.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  Container friendsWidget(FriendsBloc fb) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'friends'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          fb.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_friends'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: fb.data.length != 0 ? fb.data.length + 1 : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < fb.data.length) {
                        return FriendsCard2(
                          d: fb.data[index],
                          heroTag: 'friends$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: fb.isLoading ? 1.0 : 0.0,
                        child: fb.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  _customAppBar(WUser user, context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: user.coverUrl != ''
            ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
            : Image.asset(
                'assets/images/profile_cover.png',
                fit: BoxFit.cover,
              ),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        '${'profile'.tr()} (Only View)',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      actions: <Widget>[
        IconButton(
          icon: const Icon(Icons.settings_outlined,
              size: 22, color: Colors.white),
          onPressed: () {},
        ),
        SizedBox(
          width: 5,
        )
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 60,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: CustomCacheImage(
                          imageUrl: user.avatar,
                          radius: 45.0,
                          circularShape: true),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      Text(
                        user.name!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        '@${user.name!.split(' ')[0]}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProfileItem extends StatelessWidget {
  const ProfileItem({
    Key? key,
    required this.name,
    required this.svgName,
    required this.type,
  }) : super(key: key);

  final String name;
  final String svgName;
  final String type;

  @override
  Widget build(BuildContext context) {
    return name == ''
        ? Container()
        : Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 8),
            child: Row(
              children: [
                SvgPicture.asset(svgName),
                Padding(
                  padding: const EdgeInsets.only(left: 12),
                  child: Text(
                    type,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                ),
                Text(
                  ' $name'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Config().text90Color),
                ),
              ],
            ),
          );
  }
}

class ExpandedIconButton extends StatelessWidget {
  final String? title;
  final IconData? iconData;
  final Function()? onPressed;
  const ExpandedIconButton(
      {Key? key, this.title, this.iconData, this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        onPressed: onPressed,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(iconData, color: Colors.white),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                title!,
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
