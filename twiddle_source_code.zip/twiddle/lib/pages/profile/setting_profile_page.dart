import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/pages/profile/setting/account_status_page.dart';
import 'package:twiddle/pages/profile/setting/follow_setting_page.dart';
import 'package:twiddle/pages/profile/setting/manage_post_page.dart';
import 'package:twiddle/pages/profile/setting/review_post_tags_page.dart';
import 'package:twiddle/pages/profile/setting/view_as_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';

class SettingProfilePage extends StatefulWidget {
  const SettingProfilePage({super.key, required this.user});
  final WUser? user;

  @override
  State<SettingProfilePage> createState() => _SettingProfilePageState();
}

class _SettingProfilePageState extends State<SettingProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'profile_setting'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView(
        children: [
          SettingItem(
            svgname: 'assets/images/person_add.svg',
            name: 'follow_setting'.tr(),
            onTap: () {
              nextScreen(context, FollowSettingPage());
            },
          ),
          const Divider(),
          SettingItem(
            svgname: 'assets/images/person.svg',
            name: 'account_status'.tr(),
            onTap: () {
              nextScreen(context, AccountStatusPage(user: widget.user));
            },
          ),
          const Divider(),
          SettingItem(
            svgname: 'assets/images/visibility.svg',
            name: 'view_as'.tr(),
            onTap: () {
              nextScreen(context, ViewAsPage());
            },
          ),
          const Divider(),
          SettingItem(
            svgname: 'assets/images/post_add.svg',
            name: 'manage_post'.tr(),
            onTap: () {
              nextScreen(context, ManagePostPage());
            },
          ),
          const Divider(),
          SettingItem(
            svgname: 'assets/images/loyalty.svg',
            name: 'review_post_and_tags'.tr(),
            onTap: () {
              nextScreen(context, ReviewPostTagsPage());
            },
          ),
          const Divider(),
          const SizedBox(height: 12),
          // Text(
          //   'profile_link'.tr(),
          //   style: TextStyle(
          //       fontSize: 16,
          //       fontWeight: FontWeight.w600,
          //       color: Config().text90Color),
          // ),
          // Container(
          //   height: 50,
          //   padding: const EdgeInsets.all(12),
          //   margin: const EdgeInsets.only(top: 5, bottom: 16),
          //   decoration: BoxDecoration(
          //       color: Config().text4Color,
          //       borderRadius: BorderRadius.circular(8)),
          //   child: Row(
          //     children: [
          //       Expanded(
          //         child: Text(
          //           'www.twiddle.com/${widget.user!.uid}',
          //           overflow: TextOverflow.ellipsis,
          //           style: TextStyle(
          //               fontSize: 12,
          //               fontWeight: FontWeight.w400,
          //               color: Config().text90Color),
          //         ),
          //       ),
          //       // const Spacer(),
          //       SvgPicture.asset('assets/images/file_copy.svg')
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }
}

class SettingItem extends StatelessWidget {
  const SettingItem({
    Key? key,
    required this.svgname,
    required this.name,
    required this.onTap,
  }) : super(key: key);
  final String? svgname;
  final String? name;
  final Function()? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          children: [
            SvgPicture.asset(svgname!),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                name!,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }
}
