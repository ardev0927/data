import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/models/album.dart';

class ShowAlbumPage extends StatefulWidget {
  const ShowAlbumPage({super.key, required this.album});

  final Album? album;

  @override
  State<ShowAlbumPage> createState() => _ShowAlbumPageState();
}

class _ShowAlbumPageState extends State<ShowAlbumPage> {
  List<String> photos = [];

  @override
  void initState() {
    super.initState();
    photos.addAll(widget.album!.images!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Config().whiteColor,
            )),
      ),
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: PhotoViewGallery.builder(
          itemCount: photos.length,
          builder: (context, index) {
            return PhotoViewGalleryPageOptions(
              imageProvider: NetworkImage(photos[index]),
              initialScale: PhotoViewComputedScale.contained * 1,
              heroAttributes: PhotoViewHeroAttributes(tag: 'gallery$index'),
            );
          },
        ),
      ),
    );
  }
}
