import 'dart:io';

import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
// import 'package:gallery_saver/gallery_saver.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:twiddle/blocs/posts_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as path;
import 'package:twiddle/pages/profile/send_image_friends_page.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:uuid/uuid.dart';

import '../../blocs/group_manage_bloc.dart';
import '../../blocs/post_friends_bloc.dart';
import '../../config/config.dart';
import '../../models/group.dart';
import '../../models/post.dart';
import '../../services/app_service.dart';
import '../../utils/enums.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../post/create_post_page.dart';
import '../post/view_comments_page.dart';

class ShowPhotoPage extends StatefulWidget {
  ShowPhotoPage(
      {super.key, required this.p, required this.changedArray, this.photos});
  Post? p;
  bool? changedArray;
  List<String>? photos;

  @override
  State<ShowPhotoPage> createState() => _ShowPhotoPageState();
}

class _ShowPhotoPageState extends State<ShowPhotoPage> {
  int currentIndex = 0;
  bool isLiked = false;
  bool isShared = false;
  List<String> photos = [];

  List<Group> _groups = [];
  Group? group;

  @override
  void initState() {
    super.initState();

    photos.addAll(
        widget.changedArray == false ? widget.p!.mediaUrls! : widget.photos!);
    // context.read<PostsBloc>().getData(mounted, _orderBy);
    // PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    var sb = context.read<SignInBloc>();
    context.read<PostsBloc>().getLike(sb.uid, widget.p!);
    context.read<PostsBloc>().getShare(sb.uid, widget.p!);

    print('===== Photo count: ${photos.length} =====');

    loadingManagedGroups();
  }

  @override
  Widget build(BuildContext context) {
    var sb = context.read<SignInBloc>();
    var pb = context.watch<PostsBloc>();

    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            PhotoViewGallery.builder(
              itemCount: photos.length,
              builder: (context, index) {
                return PhotoViewGalleryPageOptions(
                  imageProvider: NetworkImage(photos[index]),
                  initialScale: PhotoViewComputedScale.contained * 1,
                  heroAttributes: PhotoViewHeroAttributes(tag: 'gallery$index'),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
              child: Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(Icons.arrow_back, color: Colors.white)),
                  const Spacer(),
                  IconButton(
                      onPressed: () {
                        _showMoreSheet(context, widget.p!);
                      },
                      icon: Icon(Icons.more_vert, color: Colors.white)),
                ],
              ),
            ),
            // bottom
            Container(
              // margin: EdgeInsets.all(20),
              height: MediaQuery.of(context).size.height,
              alignment: Alignment.bottomLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              TextButton(
                                onPressed: () {},
                                child: Text(
                                  '${widget.p!.likes!.length} ${'likes'.tr()}',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(
                                onPressed: () {},
                                child: Text(
                                  '${widget.p!.comments} ${'comments'.tr()}',
                                  // '${d.comments!.length.length} ${'comments'.tr()}',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                onPressed: () {},
                                child: Text(
                                  '${widget.p!.shares!.length} ${'shares'.tr()}',
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Divider(
                    color: Config().text10Color,
                    height: 2,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Expanded(
                          child: TextButton(
                            onPressed: () {
                              if (sb.uid == widget.p!.uid) {
                                openToast('You can not like own post');
                                return;
                              }
                              pb.setLike(sb.uid, widget.p!).then((value) {
                                if (pb.isLiked == true) {
                                  widget.p!.likes!.add(sb.uid!);
                                  openToast('Liked Post');
                                } else {
                                  widget.p!.likes!.remove(sb.uid!);
                                  openToast('Unliked Post');
                                }
                                setState(() {});
                              });
                            },
                            child: Row(
                              children: [
                                SvgPicture.asset('assets/images/like.svg',
                                    color: pb.isLiked == false
                                        ? Colors.white
                                        : Config().primary30Color),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'like'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: pb.isLiked == false
                                            ? FontWeight.w400
                                            : FontWeight.w700,
                                        color: pb.isLiked == false
                                            ? Colors.white
                                            : Config().primary30Color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextButton(
                            onPressed: () async {
                              if (sb.uid == widget.p!.uid) {
                                openToast('You can not comment own post');
                                return;
                              }
                              int ret = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ViewCommentsPage(p: widget.p!)));
                              if (ret != null) {
                                widget.p!.comments = ret;
                                setState(() {});
                              }
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  'assets/images/comment.svg',
                                  color: Colors.white,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'comment'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextButton(
                            onPressed: () {
                              if (sb.uid == widget.p!.uid) {
                                openToast('You can not share own post');
                                return;
                              }
                              showShareSheet(context, widget.p);
                              // pb.setShare(sb.uid, widget.p!).then((value) {
                              //   if (pb.isShared == true) {
                              //     widget.p!.shares!.add(sb.uid!);
                              //     openToast('Shared Post');
                              //   } else {
                              //     widget.p!.shares!.remove(sb.uid!);
                              //     openToast('Unshared Post');
                              //   }
                              //   setState(() {});
                              // });
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                SvgPicture.asset('assets/images/send.svg',
                                    color: pb.isShared == false
                                        ? Colors.white
                                        : Config().primary30Color),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: Text(
                                    'share'.tr(),
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: pb.isShared == false
                                            ? FontWeight.w400
                                            : FontWeight.w700,
                                        color: pb.isShared == false
                                            ? Colors.white
                                            : Config().primary30Color),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Bottom sheet for post more
  _showMoreSheet(ctx, Post p) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Save to phone
            InkWell(
              onTap: () {
                Navigator.pop(context);
                // _pinUnpinPost(p);
                saveImageToStorage();
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.file_download_outlined,
                        color: Config().text90Color),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'save_to_phone'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Send in Message
            InkWell(
              onTap: () {
                Navigator.pop(context);

                sendInMessage();
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.chat_outlined, color: Config().text90Color),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'send_in_message'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Share external
            // InkWell(
            //   onTap: () {
            //     shareExternal();
            //   },
            //   child: Padding(
            //     padding: const EdgeInsets.all(16.0),
            //     child: Row(
            //       children: [
            //         Icon(Icons.send_outlined, color: Config().text90Color),
            //         Padding(
            //           padding: const EdgeInsets.only(left: 16),
            //           child: Text(
            //             'share_external'.tr(),
            //             style: TextStyle(
            //                 fontSize: 16,
            //                 fontWeight: FontWeight.w600,
            //                 color: Config().text90Color),
            //           ),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),
          ],
        );
      },
    );
  }

  saveImageToStorage() async {
    String url = photos[currentIndex];

    var response = await Dio()
        .get(url, options: Options(responseType: ResponseType.bytes));
    final result = await ImageGallerySaver.saveImage(
        Uint8List.fromList(response.data),
        quality: 60,
        name: "twiddle_${const Uuid().v1()}");
    if (result['isSuccess'] == true) {
      openToast('Image saved successfully!');
    } else {
      openToast('Something went wrong!');
    }
    print(result);
  }

  shareExternal() async {
    String url = photos[currentIndex];
    Share.shareFiles([photos[currentIndex]]);
  }

  sendInMessage() {
    var image = photos[currentIndex];
    nextScreen(context, SendImageFriendsPage(imageUrl: image));
  }

  showShareSheet(BuildContext ctx, Post? p) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Share to feed
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                if (p!.mediaType != PostType.share) {
                  var ret = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CreatePostPage(type: PostType.share, p: p),
                    ),
                  );
                  if (ret != null) {
                    // refreshPage();
                    // setState(() {});
                  }
                  // nextScreen(context, CreatePostPage(p: p));
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.feed_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_feed'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Share to group
            InkWell(
              onTap: () async {
                Navigator.pop(context);
                selectGroupDialog(p!);
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.groups_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'share_to_group'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  selectGroupDialog(Post p) {
    showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
          contentPadding: const EdgeInsets.all(16),
          title: Text(
            'select_group'.tr(),
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          children: [
            SizedBox(
              height: 300,
              width: MediaQuery.of(context).size.width,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: _groups.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    onTap: () async {
                      group = _groups[index];
                      // setState(() {
                      //   isGroupPost = true;
                      // });
                      Navigator.pop(context);
                      if (p.mediaType != PostType.share ||
                          p.mediaType != PostType.sharegroup) {
                        var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => CreatePostPage(
                              type: PostType.sharegroup,
                              p: p,
                              g: group,
                            ),
                          ),
                        );
                        if (ret != null) {
                          // refreshPage();
                          // setState(() {});
                        }
                      }
                    },
                    title: Text(_groups[index].name!),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  // Loading managed groups
  loadingManagedGroups() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final GroupManageBloc gmb =
        Provider.of<GroupManageBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        gmb.getData(sb.uid!, mounted, 'timestamp').then((value) async {
          if (gmb.hasData == true) {
            _groups.clear();
            _groups.addAll(gmb.data);
          } else {
            print('Failed loading groups');
          }
        });
      }
    });
  }

  // refreshPage() {
  //   final pb = context.read<PostFriendsBloc>();
  //   final sb = context.read<SignInBloc>();
  //   final ssb = context.read<StoriesBloc>();

  //   pb.onRefresh(sb.uid, mounted, _orderBy);
  //   ssb.onRefresh(mounted, _orderBy);

  //   setState(() {});
  // }
}
