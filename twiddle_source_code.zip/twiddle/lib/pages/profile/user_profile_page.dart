import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/bottom_sheet/post_sheet.dart';
import 'package:twiddle/cards/post_card.dart';
import 'package:twiddle/cards/post_video_card.dart';
import 'package:twiddle/pages/chat_story/chat/user_message_page.dart';
import 'package:twiddle/pages/profile/photos_page.dart';
import 'package:twiddle/pages/profile/profile_friends_page.dart';
import 'package:twiddle/pages/profile/profile_main_page.dart';
import 'package:twiddle/pages/profile/setting_profile_page.dart';
import 'package:twiddle/pages/profile/show_photo_page.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../blocs/friends_bloc.dart';
import '../../blocs/group_bloc.dart';
import '../../blocs/interest_bloc.dart';
import '../../blocs/notification_bloc.dart';
import '../../blocs/post_user_bloc.dart';
import '../../blocs/posts_bloc.dart';
import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../cards/card1.dart';
import '../../cards/friends_card2.dart';
import '../../cards/interest_card3.dart';
import '../../cards/video_card.dart';
import '../../config/config.dart';
import '../../models/post.dart';
import '../../models/user.dart';
import '../../services/app_service.dart';
import '../../utils/cached_image.dart';
import '../../utils/convert_time_ago.dart';
import '../../utils/empty.dart';
import '../../utils/enums.dart';
import '../../utils/format_time.dart';
import '../../utils/loading_cards.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../../widgets/app_relationship.dart';
import '../group/managed_group_page.dart';
import '../group/not_joined_group_page.dart';
import '../post/show_cw_post_page.dart';
import '../post/view_comments_page.dart';
import '../post/view_likes_page.dart';
import '../post/view_shares_page.dart';
import '../tag_friends/tag_friends_page.dart';

class UserProfilePage extends StatefulWidget {
  const UserProfilePage({super.key, required this.uid});
  final String? uid;

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  String _orderBy = 'timestamp';
  ScrollController? controller;

  @override
  void initState() {
    super.initState();

    print('===== UID: ${widget.uid} =====');

    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      final ub = context.read<UserBlock>();
      final pb = context.read<PostUserBloc>();
      final fb = context.read<FriendsBloc>();

      ub.onInit();
      ub.getUser(widget.uid, mounted).then((value) {
        context
            .read<InterestBloc>()
            .filterDataWithName(ub.data!.interests!, mounted);
      });

      fb.getData(widget.uid, mounted);
      controller = ScrollController()..addListener(_scrollListener);
      pb.onInit();
      pb.getMyData(widget.uid, mounted, _orderBy);
      // context.read<InterestBloc>().getMyData(sb.uid, mounted);
    });
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<PostUserBloc>();
    // final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<PostUserBloc>().setLoading(true);
        context.read<PostUserBloc>().getMyData(widget.uid, mounted, _orderBy);
      }
    }
  }

  _isFriend(UserBlock ub, SignInBloc sb) {
    bool isfind = false;
    ub.data!.friends!.forEach((uid) {
      if (uid == sb.uid) {
        // if (uid == widget.uid) {
        isfind = true;
      }
    });
    return isfind;
  }

  _isRequested(UserBlock ub, SignInBloc sb) {
    bool isRequested = false;
    ub.data!.friendResponses!.forEach((uid) {
      if (uid == sb.uid) {
        isRequested = true;
      }
    });
    return isRequested;
  }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<UserBlock>();
    final fb = context.watch<FriendsBloc>();
    final ib = context.watch<InterestBloc>();
    final pb = context.watch<PostUserBloc>();
    final sb = context.watch<SignInBloc>();

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: ub.isLoading == true
          ? Container(
              child: Center(child: CircularProgressIndicator()),
            )
          : RefreshIndicator(
              onRefresh: () async {
                pb.onMyRefresh(widget.uid, mounted, _orderBy);
              },
              child: CustomScrollView(
                slivers: [
                  _customAppBar(ub.data!, context),
                  SliverToBoxAdapter(
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      // height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Button(Add story, Edit profile)
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Row(
                              children: [
                                _isFriend(ub, sb) == false
                                    ? _isRequested(ub, sb) == false
                                        ? ExpandedIconButton(
                                            title: 'add_friend'.tr(),
                                            iconData: Icons.person_add_outlined,
                                            bgColor: Config().appColor,
                                            textColor: Config().whiteColor,
                                            onPressed: () {
                                              _handleRequestFriend(
                                                  ub,
                                                  sb.uid!,
                                                  sb.name!,
                                                  sb.imageUrl!,
                                                  widget.uid!,
                                                  true);
                                            },
                                          )
                                        : ExpandedIconButton(
                                            title: 'requested'.tr(),
                                            iconData: Icons.person_add_outlined,
                                            bgColor: Config().secondary21Color,
                                            textColor: Config().blackColor,
                                            onPressed: () {
                                              _handleRequestFriend(
                                                  ub,
                                                  sb.uid!,
                                                  sb.name!,
                                                  sb.imageUrl!,
                                                  widget.uid!,
                                                  false);
                                            },
                                          )
                                    : ExpandedIconButton(
                                        title: 'friends'.tr(),
                                        iconData: Icons.person_outlined,
                                        bgColor: Config().secondary21Color,
                                        textColor: Config().blackColor,
                                        onPressed: () {
                                          _handleRemoveFriend(
                                              ub, sb.uid!, widget.uid!);
                                          // nextScreen(
                                          //     context,
                                          //     ProfileFriendsPage(
                                          //         uid: ub.data!.uid!));
                                        },
                                      ),
                                const SizedBox(width: 16),
                                ExpandedIconButton(
                                  title: 'message'.tr(),
                                  iconData: Icons.message_outlined,
                                  bgColor: Config().appColor,
                                  textColor: Config().whiteColor,
                                  onPressed: () async {
                                    nextScreen(context,
                                        UserMessagePage(user: ub.data));
                                  },
                                ),
                              ],
                            ),
                          ),
                          // Profile Information
                          ProfileItem(
                            name: ub.data!.info!.hometown ?? '',
                            svgName: 'assets/images/cottage.svg',
                            type: 'hometown'.tr(),
                            privacy: ub.data!.info!.hometownPrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          ProfileItem(
                            name: ub.data!.info!.worksat ?? '',
                            svgName: 'assets/images/home_repair_service.svg',
                            type: 'works_at'.tr(),
                            privacy: ub.data!.info!.worksatPrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          ProfileItem(
                            name: ub.data!.info!.studiedat ?? '',
                            svgName: 'assets/images/menu_book.svg',
                            type: 'studied at'.tr(),
                            privacy:
                                ub.data!.info!.studiedatPrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          ProfileItem(
                            name: ub.data!.info!.livesin ?? '',
                            svgName: 'assets/images/home_pin.svg',
                            type: 'lives_in'.tr(),
                            privacy: ub.data!.info!.livesinPrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          // ub.data!.info!.relationship == null
                          //     ? Container()
                          //     : ub.data!.info!.relationship!.typeName ==
                          //             'Single'
                          //         ? ProfileItem(
                          //             name: ub
                          //                 .data!.info!.relationship!.typeName!,
                          //             svgName: 'assets/images/favorite.svg',
                          //             type: 'relationship_status'.tr(),
                          //             privacy:
                          //                 ub.data!.info!.relationshipPrivacy!,
                          //             friends: ub.data!.friends!,
                          //             uid: sb.uid!,
                          //           )
                          //         : AppRelationship(
                          //             ub.data!.info!.relationship!,
                          //             isEdit: false),
                          // ProfileItem(
                          //   name: ub.data!.info!.relationship!,
                          //   svgName: 'assets/images/favorite.svg',
                          //   type: 'relationship_status'.tr(),
                          //   privacy: ub.data!.info!.relationshipPrivacy!,
                          //   friends: ub.data!.friends!,
                          //   uid: sb.uid!,
                          // ),
                          // ub.data!.interests!.isEmpty
                          //     ? Container()
                          //     : ProfileItem(
                          //         name: ub.data!.interests!.join(', '),
                          //         svgName: 'assets/images/interests.svg',
                          //         type: 'interest'.tr()),
                          ProfileItem(
                            name: ub.data!.info!.birthdate ?? '',
                            svgName: 'assets/images/calendar_month.svg',
                            type: 'date_of_birth'.tr(),
                            privacy:
                                ub.data!.info!.birthdatePrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          ProfileItem(
                            name: ub.data!.info!.gender ?? '',
                            svgName: 'assets/images/wc.svg',
                            type: 'gender'.tr(),
                            privacy: ub.data!.info!.genderPrivacy ?? 'Public',
                            friends: ub.data!.friends!,
                            uid: sb.uid!,
                          ),
                          ub.data!.info!.relationship == null
                              ? Container()
                              : ub.data!.info!.relationship!.typeName ==
                                      'Single'
                                  ? ProfileItem(
                                      name: ub
                                          .data!.info!.relationship!.typeName!,
                                      svgName: 'assets/images/favorite.svg',
                                      type: 'relationship_status'.tr(),
                                      privacy:
                                          ub.data!.info!.relationshipPrivacy!,
                                      friends: ub.data!.friends!,
                                      uid: sb.uid!,
                                    )
                                  : ProfileItem(
                                      name: ub.data!.info!.relationship!.title!,
                                      svgName: 'assets/images/favorite.svg',
                                      type:
                                          '${ub.data!.info!.relationship!.typeName!} with ',
                                      privacy:
                                          ub.data!.info!.relationshipPrivacy!,
                                      friends: ub.data!.friends!,
                                      uid: sb.uid!,
                                    ),
                          // : Column(
                          //     children: [
                          //       ProfileItem(
                          //         name: ub
                          //             .data!.info!.relationship!.title!,
                          //         svgName: 'assets/images/favorite.svg',
                          //         type:
                          //             '${ub.data!.info!.relationship!.typeName!} with ',
                          //         privacy: ub
                          //             .data!.info!.relationshipPrivacy!,
                          //         friends: ub.data!.friends!,
                          //         uid: sb.uid!,
                          //       ),
                          //       Padding(
                          //         padding:
                          //             const EdgeInsets.only(left: 16.0),
                          //         child: AppRelationship(
                          //             ub.data!.info!.relationship!,
                          //             isEdit: false),
                          //       ),
                          //     ],
                          //   ),
                          const Divider(),
                          // Friends
                          friendsWidget(fb),
                          const Divider(),
                          // Interests
                          // interestWidget(ib),
                          // const Divider(),
                          // // Photo button
                          // Padding(
                          //   padding: const EdgeInsets.symmetric(horizontal: 16),
                          //   child: ElevatedButton(
                          //     onPressed: () {
                          //       nextScreen(context, PhotosPage(user: ub.data));
                          //     },
                          //     style: ElevatedButton.styleFrom(
                          //         primary: Config().text4Color),
                          //     child: Text(
                          //       'photo_video'.tr(),
                          //       style: TextStyle(
                          //           fontSize: 14,
                          //           fontWeight: FontWeight.w700,
                          //           color: Config().text90Color),
                          //     ),
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                  // Posts
                  pb.hasData == false
                      ? SliverFillRemaining(
                          child: Column(
                            children: [
                              // SizedBox(
                              //   height:
                              //       MediaQuery.of(context).size.height * 0.35,
                              // ),
                              EmptyPage(
                                  icon: Icons.post_add_outlined,
                                  message: 'no_post_found'.tr(),
                                  message1: ''),
                            ],
                          ),
                        )
                      : SliverPadding(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          sliver: SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                if (index < pb.data.length) {
                                  if (pb.data[index].mediaType == 2) {
                                    // VIDEO
                                    // return VideoCard(
                                    return PostVideoCard(
                                      d: pb.data[index],
                                      time: convertToAgo(
                                          pb.data[index].timestamp!),
                                      heroTag: 'post${index - 1}',
                                      onLikePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not like own post');
                                          return;
                                        }
                                        pb
                                            .setLike(sb.uid, pb.data[index])
                                            .then((value) {
                                          if (pb.isLiked == true) {
                                            pb.data[index].likes!.add(sb.uid!);
                                            openToast('Liked Post');
                                          } else {
                                            pb.data[index].likes!
                                                .remove(sb.uid!);
                                            openToast('Unliked Post');
                                          }
                                          setState(() {});
                                        });
                                      },
                                      onLikesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewLikesPage(
                                                uids: pb.data[index].likes));
                                      },
                                      isLiked: pb.data[index].likes!
                                          .contains(sb.uid),
                                      onSharePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not share own post');
                                          return;
                                        }
                                      },
                                      onSharesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewSharesPage(
                                                uids: pb.data[index].shares));
                                      },
                                      isShared: pb.data[index].shares!
                                          .contains(sb.uid),
                                      onCommentPressed: () async {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not comment own post');
                                          return;
                                        }
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        if (ret != null) {
                                          pb.data[index].comments = ret;
                                          setState(() {});
                                        }
                                      },
                                      onCommentsPressed: () async {
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        if (ret != null) {
                                          pb.data[index].comments = ret;
                                          setState(() {});
                                        }
                                      },
                                      onMoreTap: () {
                                        // More Tap
                                        showMoreSheet(
                                            context,
                                            ub.data!,
                                            pb.data[index],
                                            false,
                                            sb.uid!,
                                            sb.uid == pb.data[index].uid
                                                ? false
                                                : true,
                                            onPinTap: () {
                                              Navigator.pop(context);
                                              _pinUnpinPost(pb.data[index]);
                                            },
                                            onFollowTap: () {},
                                            onReportTap: () {},
                                            onHideTap: () {
                                              Navigator.pop(context);
                                              _hidePost(pb.data[index], sb.uid);
                                            },
                                            onDeleteTap: () {
                                              Navigator.pop(context);
                                              _deletePost(pb.data[index]);
                                            });
                                        // _showMoreSheet(context, pb.data[index], sb.uid!);
                                      },
                                      onPhotoTap: () {
                                        nextScreen(
                                            context,
                                            ShowPhotoPage(
                                                p: pb.data[index],
                                                changedArray: false));
                                      },
                                      onAvatarTap: () {
                                        if (sb.uid != pb.data[index].uid) {
                                          nextScreen(
                                              context,
                                              UserProfilePage(
                                                  uid: pb.data[index].uid));
                                        } else {
                                          nextScreen(
                                              context,
                                              ProfileMainPage(
                                                  uid: pb.data[index].uid));
                                        }
                                      },
                                    );
                                  }
                                  return Padding(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 8),
                                    // child: Card1(
                                    child: PostCard(
                                      d: pb.data[index],
                                      time: convertToAgo(
                                          pb.data[index].timestamp!),
                                      heroTag: 'post$index',
                                      onLikePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not like own post');
                                          return;
                                        }
                                        pb
                                            .setLike(sb.uid, pb.data[index])
                                            .then((value) {
                                          if (pb.isLiked == true) {
                                            pb.data[index].likes!.add(sb.uid!);
                                            openToast('Liked Post');
                                          } else {
                                            pb.data[index].likes!
                                                .remove(sb.uid!);
                                            openToast('Unliked Post');
                                          }
                                          setState(() {});
                                        });
                                      },
                                      onLikesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewLikesPage(
                                                uids: pb.data[index].likes));
                                      },
                                      isLiked: pb.data[index].likes!
                                          .contains(sb.uid),
                                      onSharePressed: () {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not share own post');
                                          return;
                                        }
                                        // pb
                                        //     .setShare(sb.uid, pb.data[index])
                                        //     .then((value) {
                                        //   if (pb.isShared == true) {
                                        //     pb.data[index].shares!.add(sb.uid!);
                                        //     openToast('Shared Post');
                                        //   } else {
                                        //     pb.data[index].shares!
                                        //         .remove(sb.uid!);
                                        //     openToast('Unshared Post');
                                        //   }
                                        //   setState(() {});
                                        // });
                                      },
                                      onSharesPressed: () {
                                        nextScreen(
                                            context,
                                            ViewSharesPage(
                                                uids: pb.data[index].shares));
                                      },
                                      isShared: pb.data[index].shares!
                                          .contains(sb.uid),
                                      onCommentPressed: () async {
                                        if (sb.uid == pb.data[index].uid) {
                                          openToast(
                                              'You can not comment own post');
                                          return;
                                        }
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        pb.data[index].comments = ret;
                                        setState(() {});
                                      },
                                      onCommentsPressed: () async {
                                        int ret = await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    ViewCommentsPage(
                                                        p: pb.data[index])));
                                        pb.data[index].comments = ret;
                                        setState(() {});
                                      },
                                      onMoreTap: () {
                                        // More Tap
                                        showMoreSheet(
                                            context,
                                            ub.data!,
                                            pb.data[index],
                                            false,
                                            sb.uid!,
                                            sb.uid == pb.data[index].uid
                                                ? false
                                                : true,
                                            onPinTap: () {},
                                            onFollowTap: () {},
                                            onReportTap: () {},
                                            onHideTap: () {},
                                            onDeleteTap: () {});
                                        // _showMoreSheet(context, pb.data[index]);
                                      },
                                      onPhotoTap: () {
                                        nextScreen(
                                            context,
                                            ShowPhotoPage(
                                                p: pb.data[index],
                                                changedArray: false));
                                      },
                                      onAvatarTap: () {
                                        if (sb.uid != pb.data[index].uid) {
                                          nextScreen(
                                              context,
                                              UserProfilePage(
                                                  uid: pb.data[index].uid));
                                        } else {
                                          nextScreen(
                                              context,
                                              ProfileMainPage(
                                                  uid: pb.data[index].uid));
                                        }
                                      },
                                      onArticleTap: () {
                                        if (pb.data[index].mediaType == 11) {
                                          launchUrl(Uri.parse(
                                              pb.data[index].article!));
                                        }
                                      },
                                      onTypeTap: () async {
                                        var d = pb.data[index];
                                        if (d.feeling!.contains('with ') &&
                                            d.tagFriends!.isNotEmpty) {
                                          nextScreen(
                                            context,
                                            TagFriendsPage(
                                                tags:
                                                    pb.data[index].tagFriends),
                                          );
                                        } else {
                                          var g = d.group;
                                          if (g!.name != null) {
                                            if (g.ownerUid == sb.uid) {
                                              nextScreen(context,
                                                  ManagedGroupPage(group: g));
                                            } else {
                                              var gb =
                                                  context.read<GroupBloc>();
                                              await gb
                                                  .getGroup(g.id!)
                                                  .then((value) async {
                                                if (gb.group!.members!
                                                    .contains(sb.uid)) {
                                                  nextScreen(
                                                      context,
                                                      ManagedGroupPage(
                                                          group: gb.group));
                                                } else {
                                                  var ret = await Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (context) =>
                                                              NotJoinedGroupPage(
                                                                  group: g)));
                                                  if (ret != null) {
                                                    d.group = ret;
                                                  }
                                                }
                                              });
                                            }
                                          }
                                        }
                                      },
                                      onCWShowPressed: () {
                                        nextScreen(
                                            context,
                                            ShowContentWarningPostPage(
                                                post: pb.data[index]));
                                      },
                                    ),
                                  );
                                }
                                return Opacity(
                                  opacity: pb.isLoading ? 1.0 : 0.0,
                                  child: pb.lastVisible == null
                                      ? const LoadingCard(height: 250)
                                      : const Center(
                                          child: SizedBox(
                                              width: 32.0,
                                              height: 32.0,
                                              child:
                                                  CupertinoActivityIndicator()),
                                        ),
                                );
                              },
                              childCount:
                                  pb.data.length == 0 ? 5 : pb.data.length + 1,
                            ),
                          ),
                        ),
                ],
              ),
            ),
    );
  }

  Container interestWidget(InterestBloc ib) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'interests'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          ib.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_interests'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: ib.data.length != 0 ? ib.data.length + 1 : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < ib.data.length) {
                        return InterestCard3(
                          d: ib.data[index],
                          heroTag: 'card3$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: ib.isLoading ? 1.0 : 0.0,
                        child: ib.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  Container friendsWidget(FriendsBloc fb) {
    return Container(
      padding: const EdgeInsets.only(left: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'friends'.tr(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Config().text100Color),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 16),
                child: GestureDetector(
                  onTap: () {},
                  child: Text(
                    'see_all'.tr(),
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Config().text80Color),
                  ),
                ),
              ),
            ],
          ),
          fb.hasData == false
              ? SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      'no_friends'.tr(),
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Config().text80Color),
                    ),
                  ),
                )
              : SizedBox(
                  height: 70,
                  child: ListView.builder(
                    // key: PageStorageKey(widget.category),
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.only(top: 8),
                    physics: AlwaysScrollableScrollPhysics(),
                    itemCount: fb.data.length != 0 ? fb.data.length + 1 : 5,
                    shrinkWrap: true,
                    itemBuilder: (_, int index) {
                      if (index < fb.data.length) {
                        return FriendsCard2(
                          d: fb.data[index],
                          heroTag: 'friends$index',
                          onPressed: () async {},
                        );
                      }
                      return Opacity(
                        opacity: fb.isLoading ? 1.0 : 0.0,
                        child: fb.lastVisible == null
                            ? LoadingCard2(height: 60, width: 60)
                            : const Center(
                                child: SizedBox(
                                    width: 32.0,
                                    height: 32.0,
                                    child: CupertinoActivityIndicator()),
                              ),
                      );
                    },
                  ),
                ),
        ],
      ),
    );
  }

  _customAppBar(WUser user, context) {
    return SliverAppBar(
      automaticallyImplyLeading: false,
      expandedHeight: 250,
      flexibleSpace: FlexibleSpaceBar(
        background: user.coverUrl != ''
            ? CustomCacheImage(imageUrl: user.coverUrl, radius: 0.0)
            : Image.asset(
                'assets/images/blank.png',
                fit: BoxFit.cover,
              ),
      ),
      leading: IconButton(
        icon:
            const Icon(Icons.keyboard_backspace, size: 22, color: Colors.white),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
      title: Text(
        'profile'.tr(),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
      ),
      actions: <Widget>[
        // IconButton(
        //   icon: const Icon(Icons.settings_outlined,
        //       size: 22, color: Colors.white),
        //   onPressed: () {
        //     // nextScreen(context, SettingProfilePage(user: user));
        //   },
        // ),
        // SizedBox(
        //   width: 5,
        // )
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(100.0),
        child: Stack(
          alignment: Alignment.bottomLeft,
          children: [
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: 60,
                color: Colors.white,
              ),
            ),
            Align(
              alignment: Alignment.bottomLeft,
              child: Row(
                children: [
                  Container(
                    margin: const EdgeInsets.only(left: 16, right: 16),
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: CustomCacheImage(
                          imageUrl: user.avatar,
                          radius: 45.0,
                          circularShape: true),
                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      Text(
                        user.name!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Config().text100Color),
                      ),
                      Text(
                        '@${user.name!.replaceAll(' ', '').toLowerCase()}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _deletePost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.deletePost(p).then((value) {
          if (pb.hasError == false) {
            pb.data.remove(p);
            openToast('Post is deleted');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _pinUnpinPost(Post p) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        print('===== post count is ${pb.data.length} =====');
        pb.pinUnpinPost(p).then((value) {
          if (pb.hasError == false) {
            p.pinned = pb.isPinned;
            openToast(p.pinned == true ? 'Post is pinned' : 'Post is unpinned');
            setState(() {});
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _hidePost(Post p, uid) async {
    print('====== post id is ${p.postId} =====');
    final PostsBloc pb = Provider.of<PostsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        pb.hideUnhidePost(p, uid).then((value) {
          if (pb.hasError == false && pb.isHidden == true) {
            pb.data.remove(p);
            openToast('post_hidden'.tr());
          } else {
            openSnacbar(context, 'Something went wrong');
          }
          setState(() {});
        });
      }
    });
  }

  _handleRequestFriend(UserBlock ub, String myUid, String myUsername,
      String myAvatar, String otherUid, bool request) async {
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        if (request) {
          ub.setRequestFriend(myUid, otherUid).then((value) {
            if (ub.isRequested == true) {
              setState(() {
                ub.data!.friendResponses!.add(myUid);
              });
              _sendFcmPost(ub.data!, myUid, myUsername, myAvatar);
            } else {
              openSnacbar(context, 'Something went wrong');
            }
          });
        } else {
          ub.setUnRequestFriend(myUid, otherUid).then((value) {
            if (ub.isRequested == true) {
              setState(() {
                ub.data!.friendResponses!.remove(myUid);
              });
            } else {
              openSnacbar(context, 'Something went wrong');
            }
          });
        }
      }
    });
  }

  _handleRemoveFriend(UserBlock ub, String myUid, String otherUid) async {
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        ub.removeFriend(myUid, otherUid).then((value) {
          if (ub.isRequested == true) {
            setState(() {
              ub.data!.friends!.remove(myUid);
            });
            openSnacbar(context, 'You removed this user from friends');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
        });
      }
    });
  }

  _sendFcmPost(WUser user, String loggedUid, String loggedUsername,
      String loggedAvatar) async {
    print("===== fcm token ${user.fcmToken} =====");
    String body = 'Request friend';
    String title = 'You received a request friend from $loggedUsername';

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [user.fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(
          user.uid, body, FcmType.requestfriend, loggedUid, loggedAvatar);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Request friend notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
        });
      }
    });
  }
}

class ProfileItem extends StatelessWidget {
  const ProfileItem({
    Key? key,
    required this.name,
    required this.svgName,
    required this.type,
    required this.privacy,
    required this.friends,
    required this.uid,
  }) : super(key: key);

  final String name;
  final String svgName;
  final String type;
  final String privacy;
  final List<String> friends;
  final String uid;

  @override
  Widget build(BuildContext context) {
    return name == ''
        ? Container()
        : isFriend()
            ? Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, bottom: 8),
                child: Row(
                  children: [
                    SvgPicture.asset(svgName),
                    Padding(
                      padding: const EdgeInsets.only(left: 12),
                      child: Text(
                        type,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Config().text90Color),
                      ),
                    ),
                    Text(
                      ' $name'.tr(),
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Config().text90Color),
                    ),
                  ],
                ),
              )
            : Container();
  }

  isFriend() {
    bool isFriend = false;
    if (privacy == 'Public') {
      isFriend = true;
    } else if (privacy == 'Friends') {
      if (friends.contains(uid)) {
        isFriend = true;
      }
    } else {
      isFriend = false;
    }
    return isFriend;
  }
}

class ExpandedIconButton extends StatelessWidget {
  final String? title;
  final IconData? iconData;
  final Color? bgColor;
  final Color? textColor;
  final Function()? onPressed;
  const ExpandedIconButton(
      {Key? key,
      required this.title,
      required this.iconData,
      required this.bgColor,
      required this.textColor,
      this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(backgroundColor: bgColor),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(iconData, color: textColor),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                title!,
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: textColor),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
