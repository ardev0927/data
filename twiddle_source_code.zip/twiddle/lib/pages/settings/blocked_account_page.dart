import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/blocked_user_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/user_card3.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../models/user.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class BlockedAccountPage extends StatefulWidget {
  const BlockedAccountPage({super.key});

  @override
  State<BlockedAccountPage> createState() => _BlockedAccountPageState();
}

class _BlockedAccountPageState extends State<BlockedAccountPage> {
  ScrollController? controller;
  List<String> uids = [];

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 0)).then((value) {
      controller = ScrollController()..addListener(_scrollListener);

      final sb = context.read<SignInBloc>();
      final ub = context.read<UserBlock>();

      ub.getOwner(sb.uid).then((value) {
        uids.addAll(ub.data!.blockedUsers!);
        context.read<BlockedUserBloc>().getData(sb.uid, uids, mounted);
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    controller!.removeListener(_scrollListener);
    super.dispose();
  }

  void _scrollListener() {
    final db = context.read<BlockedUserBloc>();
    final sb = context.read<SignInBloc>();

    if (!db.isLoading) {
      if (controller!.position.pixels == controller!.position.maxScrollExtent) {
        context.read<BlockedUserBloc>().setLoading(true);
        context.read<BlockedUserBloc>().getData(sb.uid, uids, mounted);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back),
        ),
        title: Text(
          'block'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final bub = context.watch<BlockedUserBloc>();
    final height = MediaQuery.of(context).size.height;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: bub.hasData == false
          ? SizedBox(
              height: height,
              child: ListView(
                children: [
                  SizedBox(
                    height: height * 0.25,
                  ),
                  EmptyPage(
                      icon: Icons.person_off_outlined,
                      message: 'no_blocked_user'.tr(),
                      message1: ''),
                ],
              ),
            )
          : ListView.separated(
              controller: controller,
              shrinkWrap: true,
              itemCount: bub.data.isNotEmpty ? bub.data.length + 1 : 5,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(
                height: 10,
              ),

              //shrinkWrap: true,
              itemBuilder: (_, int index) {
                if (index < bub.data.length) {
                  WUser d = bub.data[index];
                  return UserCard3(
                    d: d,
                    heroTag: 'blockedUser$index',
                    onItemTap: () {
                      nextScreen(context, UserProfilePage(uid: d.uid));
                    },
                  );
                }
                return Opacity(
                  opacity: bub.isLoading ? 1.0 : 0.0,
                  child: bub.lastVisible == null
                      ? const LoadingCard(height: 100)
                      : const Center(
                          child: SizedBox(
                            width: 32.0,
                            height: 32.0,
                            child: CupertinoActivityIndicator(),
                          ),
                        ),
                );
              },
            ),
    );
  }
}
