import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/utils/toast.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../widgets/elevated_button_widget.dart';

class ChangePassword2Page extends StatefulWidget {
  const ChangePassword2Page({super.key});

  @override
  State<ChangePassword2Page> createState() => _ChangePassword2PageState();
}

class _ChangePassword2PageState extends State<ChangePassword2Page> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _pwControl = TextEditingController();
  final _pwNewControl = TextEditingController();
  final _pwConfirmControl = TextEditingController();
  bool _isSaving = false;

  @override
  void dispose() {
    _pwControl.dispose();
    _pwNewControl.dispose();
    _pwConfirmControl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    var appbarHeight =
        AppBar().preferredSize.height + MediaQuery.of(context).padding.top;
    return Form(
      key: _formKey,
      child: Container(
        height: height - appbarHeight,
        child: Column(
          children: [
            Expanded(
              child: Image(
                  image: AssetImage(Config().splashIcon),
                  width: 250,
                  height: 250),
            ),
            _content(),
          ],
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.bottomCenter,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 10,
            blurRadius: 5,
            offset: Offset(0, 7), // changes position of shadow
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Enter Your Name
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'change_password'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 30),
          // New Password
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {});
            },
          ),
          const SizedBox(height: 16),
          // New Password
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'new_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwNewControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {});
            },
          ),
          const SizedBox(height: 16),
          // Confirm password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'confirm_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwConfirmControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {});
            },
          ),
          const SizedBox(height: 30),
          // Sign In button
          ElevatedButton(
            onPressed: () {
              _save();
            },
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              minimumSize: const Size.fromHeight(50), // NEW
            ),
            child: _isSaving == true
                ? CircularProgressIndicator()
                : Text(
                    'save'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
          ),
        ],
      ),
    );
  }

  _save() async {
    final sb = context.read<SignInBloc>();

    if (_pwNewControl.text != _pwConfirmControl.text) {
      openToast('Password does not match');
    }
    String newPassword = _pwNewControl.text;
    String originalPassword = _pwControl.text;

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          _isSaving = true;
        });

        sb.changePassword(originalPassword, newPassword).then((value) {
          setState(() {
            _isSaving = false;
          });
          if (sb.hasError == false) {
            openToast('Successfully changed password');
            Navigator.pop(context);
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}
