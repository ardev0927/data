import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/follow_setting_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';

import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';

class FollowSetting2Page extends StatefulWidget {
  const FollowSetting2Page({super.key});

  @override
  State<FollowSetting2Page> createState() => _FollowSetting2PageState();
}

class _FollowSetting2PageState extends State<FollowSetting2Page> {
  String? _follow, _people, _story, _friendlist;
  List<String> follows = ['public', 'friends', 'only_me'];
  bool _isLoading = true;
  bool _isSaving = false;
  bool _isExist = false;

  @override
  void initState() {
    super.initState();

    loadFollowSetting();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'follow_setting'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
        actions: [
          TextButton(
            onPressed: save,
            child: _isSaving
                ? const CircularProgressIndicator()
                : Text(
                    'save'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
          ),
        ],
      ),
      body: _body(),
    );
  }

  _body() {
    return _isLoading
        ? SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: const Center(
              child: SizedBox(
                  width: 32.0,
                  height: 32.0,
                  child: CupertinoActivityIndicator(color: Colors.white)),
            ),
          )
        : Padding(
            padding: const EdgeInsets.all(16),
            child: ListView(
              children: [
                // Who can Follow me
                Text(
                  'who_can_follow_me'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                RadioListTile(
                  title: Text(
                    'public'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Public',
                  groupValue: _follow,
                  onChanged: (value) {
                    setState(() {
                      _follow = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'friends'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Friends',
                  groupValue: _follow,
                  onChanged: (value) {
                    setState(() {
                      _follow = value;
                    });
                  },
                ),
                // Who can see prople
                Text(
                  'who_can_see_the_prople'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                RadioListTile(
                  title: Text(
                    'public'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Public',
                  groupValue: _people,
                  onChanged: (value) {
                    setState(() {
                      _people = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'friends'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Friends',
                  groupValue: _people,
                  onChanged: (value) {
                    setState(() {
                      _people = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'only_me'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Only me',
                  groupValue: _people,
                  onChanged: (value) {
                    setState(() {
                      _people = value;
                    });
                  },
                ),
                // Public Post Comments?
                Text(
                  'who_can_see_your_story'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                RadioListTile(
                  title: Text(
                    'public'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Public',
                  groupValue: _story,
                  onChanged: (value) {
                    setState(() {
                      _story = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'friends'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Friends',
                  groupValue: _story,
                  onChanged: (value) {
                    setState(() {
                      _story = value;
                    });
                  },
                ),
                Text(
                  'who_can_see_my_friends_list'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                RadioListTile(
                  title: Text(
                    'public'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Public',
                  groupValue: _friendlist,
                  onChanged: (value) {
                    setState(() {
                      _friendlist = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'friends'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Friends',
                  groupValue: _friendlist,
                  onChanged: (value) {
                    setState(() {
                      _friendlist = value;
                    });
                  },
                ),
                RadioListTile(
                  title: Text(
                    'only_me'.tr(),
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Config().text90Color),
                  ),
                  value: 'Only me',
                  groupValue: _friendlist,
                  onChanged: (value) {
                    setState(() {
                      _people = value;
                    });
                  },
                ),
              ],
            ),
          );
  }

  loadFollowSetting() async {
    final FollowSettingBloc fsb =
        Provider.of<FollowSettingBloc>(context, listen: false);
    final SignInBloc sb = context.read<SignInBloc>();

    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        fsb.getData(sb.uid, mounted).then((value) {
          if (fsb.hasError == true) {
            if (fsb.errorCode == 'setting_no_exist') {
              setState(() {
                _isExist = false;
                _follow = 'Public';
                _people = 'Public';
                _story = 'Public';
                _friendlist = 'Public';
              });
            }
          } else {
            var fs = fsb.followSetting;
            setState(() {
              _isExist = true;
              _follow = fs!.followMe;
              _people = fs.seePeople;
              _story = fs.seeStory;
              _friendlist = fs.seeFriendList;
            });
          }
        });
      }
      setState(() {
        _isLoading = false;
      });
    });
  }

  save() async {
    try {
      final FollowSettingBloc fsb = context.read<FollowSettingBloc>();
      final SignInBloc sb = context.read<SignInBloc>();

      await AppService().checkInternet().then((value) {
        setState(() {
          _isSaving = true;
        });
        if (_isExist) {
          fsb
              .updateUserFollowSetting(
                  sb.uid!, _follow, _people, _story, _friendlist)
              .then((value) {
            _isSaving = false;
            Navigator.pop(context);
          });
        } else {
          fsb
              .createData(sb.uid!, _follow, _people, _story, _friendlist)
              .then((value) {
            _isSaving = false;
            Navigator.pop(context);
          });
        }
      });
    } catch (e) {
      if (_isSaving == true) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }
}
