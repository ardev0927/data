import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/help_support_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/utils/toast.dart';
import 'package:twiddle/widgets/app_text_input.dart';

import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/other.dart';
import '../../utils/snacbar.dart';
import '../../utils/validate.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_picker_item.dart';

class HelpSupportPage extends StatefulWidget {
  const HelpSupportPage({super.key});

  @override
  State<HelpSupportPage> createState() => _HelpSupportPageState();
}

class _HelpSupportPageState extends State<HelpSupportPage> {
  final _textNameController = TextEditingController();
  final _textDescribeController = TextEditingController();
  final _focusName = FocusNode();
  final _focusDescribe = FocusNode();

  String? _validName;
  String? _validDescribe;
  String? _validIssue;

  String _issue = '';
  bool _loading = false;

  List<String> _issueTypes = [
    'Album issue',
    'Post issue',
    'Group issue',
    'Add friend issue',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'help_support'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          AppTextInput(
            hintText: 'your_name'.tr(),
            errorText: _validName,
            focusNode: _focusName,
            textInputAction: TextInputAction.next,
            // trailing: Cont,
            onSubmitted: (text) {
              UtilOther.fieldFocusChange(
                context,
                _focusName,
                _focusDescribe,
              );
            },
            onChanged: (text) {
              setState(() {
                _validName = UtilValidator.validate(
                  _textNameController.text,
                );
              });
            },
            controller: _textNameController,
          ),
          const SizedBox(height: 16),
          AppPickerItem(
            title: 'issue'.tr(),
            value: _issue,
            onPressed: _onSelectIssue,
          ),
          const SizedBox(height: 16),
          AppTextInput(
            hintText: 'describe_issue'.tr(),
            errorText: _validDescribe,
            focusNode: _focusDescribe,
            textInputAction: TextInputAction.done,
            maxLines: 5,
            // trailing: Cont,
            onSubmitted: (text) {
              // UtilOther.fieldFocusChange(
              //   context,
              //   _focusName,
              //   _focusDescribe,
              // );
            },
            onChanged: (text) {
              setState(() {
                _validDescribe = UtilValidator.validate(
                  _textDescribeController.text,
                );
              });
            },
            controller: _textDescribeController,
          ),
          const Spacer(),
          AppButton(
            'submit'.tr(),
            mainAxisSize: MainAxisSize.max,
            onPressed: _onSubmit,
            loading: _loading,
          ),
        ],
      ),
    );
  }

  /// On select issue
  void _onSelectIssue() async {
    UtilOther.hiddenKeyboard(context);

    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _issueTypes.length,
              itemBuilder: (context, index) {
                return ListTile(
                  onTap: () {
                    Navigator.pop(context);
                    setState(() {
                      _issue = _issueTypes[index];
                    });
                  },
                  title: Text(
                    _issueTypes[index],
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Config().text100Color),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  ///On submit
  void _onSubmit() async {
    final HelpSupportBloc hsb =
        Provider.of<HelpSupportBloc>(context, listen: false);
    final SignInBloc sb = context.read<SignInBloc>();

    UtilOther.hiddenKeyboard(context);
    setState(() {
      _validName = UtilValidator.validate(
        _textNameController.text,
      );
      _validDescribe = UtilValidator.validate(
        _textDescribeController.text,
      );
      _validIssue = UtilValidator.validate(_issue);
    });

    if (_validName == null && _validDescribe == null && _validIssue == null) {
      await AppService().checkInternet().then((hasInternet) async {
        setState(() {
          _loading = true;
        });
        if (hasInternet == false) {
          openSnacbar(context, 'check your internet connection!'.tr());
        } else {
          await hsb
              .submit(sb.uid!, _textNameController.text, _issue,
                  _textDescribeController.text)
              .then((value) {
            setState(() {
              _loading = false;
              _textNameController.clear();
              _textDescribeController.clear();
              _issue = '';
            });
            openToast('You sent issue to twiddle support team successfully');
          });
        }
      });
    }
  }
}
