import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../../config/config.dart';

class LanguagePage extends StatefulWidget {
  const LanguagePage({super.key});

  @override
  State<LanguagePage> createState() => _LanguagePageState();
}

class _LanguagePageState extends State<LanguagePage> {
  var _language;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'language'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: Config().languages.length,
        itemBuilder: (context, index) {
          return _itemList(Config().languages[index], index);
        },
      ),
      // body: Padding(
      //   padding: const EdgeInsets.all(16),
      //   child: ListView(
      //     children: [
      //       RadioListTile(
      //         title: Text(
      //           'english'.tr(),
      //           style: TextStyle(
      //               fontSize: 16,
      //               fontWeight: FontWeight.w400,
      //               color: Config().text90Color),
      //         ),
      //         value: 'English',
      //         groupValue: _language,
      //         onChanged: (value) {
      //           print('===== $value =====');
      //           context.setLocale(Locale('en'));
      //           setState(() {
      //             _language = value;
      //           });
      //         },
      //       ),
      //       RadioListTile(
      //         title: Text(
      //           'spanish'.tr(),
      //           style: TextStyle(
      //               fontSize: 16,
      //               fontWeight: FontWeight.w400,
      //               color: Config().text90Color),
      //         ),
      //         value: 'Spanish',
      //         groupValue: _language,
      //         onChanged: (value) {
      //           context.setLocale(Locale('es'));
      //           setState(() {
      //             _language = value;
      //           });
      //         },
      //       ),
      //     ],
      //   ),
      // ),
    );
  }

  Widget _itemList(d, index) {
    return Column(
      children: [
        ListTile(
          leading: Icon(Icons.language),
          title: Text(d),
          onTap: () async {
            if (d == 'English') {
              context.setLocale(Locale('en'));
            } else if (d == 'Spanish') {
              context.setLocale(Locale('es'));
            }
            Navigator.pop(context);
          },
        ),
        Divider(
          height: 3,
          color: Colors.grey[400],
        )
      ],
    );
  }
}
