import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/models/relationship.dart';
import 'package:uuid/uuid.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/other.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';
import '../../utils/validate.dart';
import '../../widgets/app_picker_item.dart';
import '../../widgets/app_relationship.dart';
import '../../widgets/app_text_input.dart';
import '../profile/edit_interest_page.dart';
import '../profile/relationship_page.dart';

class PersonalInformationPage extends StatefulWidget {
  const PersonalInformationPage({super.key});

  @override
  State<PersonalInformationPage> createState() =>
      _PersonalInformationPageState();
}

class _PersonalInformationPageState extends State<PersonalInformationPage> {
  final _formKey = GlobalKey<FormFieldState>();

  final _hometownCtrl = TextEditingController();
  final _worksAtCtrl = TextEditingController();
  final _studiedCtrl = TextEditingController();
  final _livesCtrl = TextEditingController();
  final DateTime _selectedDate = DateTime.now();

  final _focusHometown = FocusNode();
  final _focusWorksat = FocusNode();
  final _focusStudiedat = FocusNode();
  final _focusLivesin = FocusNode();

  String? _validHometown;
  String? _validWorksat;
  String? _validStudiedat;
  String? _validLivesin;

  String? _relationshipImage;

  String hometown = '';
  String worksAt = '';
  String studiedAt = '';
  String livesIn = '';
  String relationshipText = '';
  Relationship? relationship;
  String gender = 'Male';
  List<String> interests = [];
  String interest = '';
  String birthday = '';
  bool _updating = false;
  bool _isLoading = false;

  String hometownPrivacy = '';
  String worksatPrivacy = '';
  String livesinPrivacy = '';
  String relationshipPrivacy = '';
  String studiedatPrivacy = '';
  String birthdatePrivacy = '';
  String genderPrivacy = '';

  @override
  void initState() {
    super.initState();

    _load();
  }

  @override
  void dispose() {
    _hometownCtrl.dispose();
    _worksAtCtrl.dispose();
    _studiedCtrl.dispose();
    _livesCtrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, false);
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: Text(
          'personal_account_information'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final ub = context.watch<UserBlock>();

    if (ub.hasData == true) {}

    return Form(
      key: _formKey,
      child: Container(
        width: MediaQuery.of(context).size.width,
        // height: double.infinity,
        padding: const EdgeInsets.all(16),
        child: _isLoading == true
            ? Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: ListView(
                      shrinkWrap: true,
                      physics: AlwaysScrollableScrollPhysics(),
                      // crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/cottage.svg',
                                  type: 'hometown'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 1);
                              },
                              child: Row(
                                children: [
                                  getIcon(hometownPrivacy),
                                  getText(hometownPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppTextInput(
                          hintText: ''.tr(),
                          errorText: _validHometown,
                          focusNode: _focusHometown,
                          textInputAction: TextInputAction.next,
                          // trailing: Cont,
                          onSubmitted: (text) {
                            UtilOther.fieldFocusChange(
                              context,
                              _focusHometown,
                              _focusWorksat,
                            );
                          },
                          onChanged: (text) {
                            setState(() {
                              _validHometown = UtilValidator.validate(
                                _hometownCtrl.text,
                              );
                            });
                          },
                          controller: _hometownCtrl,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName:
                                      'assets/images/home_repair_service.svg',
                                  type: 'works_at'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 2);
                              },
                              child: Row(
                                children: [
                                  getIcon(worksatPrivacy),
                                  getText(worksatPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppTextInput(
                          hintText: ''.tr(),
                          errorText: _validWorksat,
                          focusNode: _focusWorksat,
                          textInputAction: TextInputAction.next,
                          // trailing: Cont,
                          onSubmitted: (text) {
                            UtilOther.fieldFocusChange(
                              context,
                              _focusWorksat,
                              _focusStudiedat,
                            );
                          },
                          onChanged: (text) {
                            setState(() {
                              _validWorksat = UtilValidator.validate(
                                _worksAtCtrl.text,
                              );
                            });
                          },
                          controller: _worksAtCtrl,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/menu_book.svg',
                                  type: 'studied at'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 3);
                              },
                              child: Row(
                                children: [
                                  getIcon(studiedatPrivacy),
                                  getText(studiedatPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppTextInput(
                          hintText: ''.tr(),
                          errorText: _validStudiedat,
                          focusNode: _focusStudiedat,
                          textInputAction: TextInputAction.next,
                          // trailing: Cont,
                          onSubmitted: (text) {
                            UtilOther.fieldFocusChange(
                              context,
                              _focusStudiedat,
                              _focusLivesin,
                            );
                          },
                          onChanged: (text) {
                            setState(() {
                              _validStudiedat = UtilValidator.validate(
                                _studiedCtrl.text,
                              );
                            });
                          },
                          controller: _studiedCtrl,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/home_pin.svg',
                                  type: 'lives_in'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 4);
                              },
                              child: Row(
                                children: [
                                  getIcon(livesinPrivacy),
                                  getText(livesinPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppTextInput(
                          hintText: ''.tr(),
                          errorText: _validLivesin,
                          focusNode: _focusLivesin,
                          textInputAction: TextInputAction.done,
                          // trailing: Cont,
                          onSubmitted: (text) {},
                          onChanged: (text) {
                            setState(() {
                              _validLivesin = UtilValidator.validate(
                                _livesCtrl.text,
                              );
                            });
                          },
                          controller: _livesCtrl,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/favorite.svg',
                                  type: 'relationship_status'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 5);
                              },
                              child: Row(
                                children: [
                                  getIcon(relationshipPrivacy),
                                  getText(relationshipPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppPickerItem(
                          title: 'Relationship'.tr(),
                          value: relationshipText,
                          onPressed: _showRelationDialog,
                        ),
                        relationship != null && relationshipText != 'Single'
                            ? _relationshipImage == null &&
                                    relationship!.avatar == null
                                ? Container()
                                : AppRelationship(
                                    relationship!,
                                    isEdit: true,
                                    imageFilePath: _relationshipImage,
                                    // imageFilePath:
                                    //     relationship!.avatar == null ||
                                    //             relationship!.avatar!.isEmpty
                                    //         ? _relationshipImage
                                    //         : null,
                                    onPressed: () async {
                                      var ret = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  RelationshipPage(
                                                    isFileImage:
                                                        _relationshipImage !=
                                                                null
                                                            ? true
                                                            : false,
                                                    image: _relationshipImage ??
                                                        relationship!.avatar,
                                                    name: relationship!.title,
                                                    desc: relationship!
                                                        .description,
                                                  )));
                                      if (ret != null) {
                                        relationship ??= Relationship();

                                        setState(() {
                                          _relationshipImage = ret['image'];

                                          relationship!.title = ret['name'];
                                          relationship!.description =
                                              ret['desc'];
                                        });
                                      }
                                    },
                                  )
                            : Container(),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/calendar_month.svg',
                                  type: 'date_of_birth'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 6);
                              },
                              child: Row(
                                children: [
                                  getIcon(birthdatePrivacy),
                                  getText(birthdatePrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppPickerItem(
                          title: 'date_of_birth'.tr(),
                          value: birthday,
                          onPressed: _selectDate,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: InfoItem(
                                  svgName: 'assets/images/wc.svg',
                                  type: 'gender'.tr()),
                            ),
                            InkWell(
                              onTap: () {
                                showPrivacySheet(context, 7);
                              },
                              child: Row(
                                children: [
                                  getIcon(genderPrivacy),
                                  getText(genderPrivacy),
                                ],
                              ),
                            ),
                          ],
                        ),
                        AppPickerItem(
                          title: 'gender'.tr(),
                          value: gender,
                          onPressed: _showGenderDialog,
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                  // Save button
                  ElevatedButton(
                    onPressed: _updating == true ? null : _save,
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                    ),
                    child: _updating
                        ? CircularProgressIndicator()
                        : Text(
                            'save'.tr(),
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700),
                          ),
                  ),
                ],
              ),
      ),
    );
  }

  getIcon(String privacy) {
    IconData? icon;
    if (privacy == 'Public') {
      icon = Icons.public_outlined;
    } else if (privacy == 'Friends') {
      icon = Icons.group_outlined;
    } else {
      icon = Icons.person_outlined;
    }
    return Icon(icon, size: 15);
  }

  getText(String privacy) {
    String? text;
    if (privacy == 'Public') {
      text = 'Public';
    } else if (privacy == 'Friends') {
      text = 'Friends';
    } else {
      text = 'Only Me';
    }
    return Text(
      ' $text',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w400,
          color: Config().text90Color),
    );
  }

  _selectDate() async {
    final DateTime? selected = await showDatePicker(
        context: context,
        initialDate: _selectedDate,
        firstDate: DateTime(1900),
        lastDate: DateTime(2050));
    if (selected != null && selected != _selectedDate) {
      setState(() {
        birthday = DateFormat('MM/dd/yyyy').format(selected);
      });
    }
  }

  showPrivacySheet(BuildContext ctx, int type) {
    showModalBottomSheet(
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(16), topRight: Radius.circular(16))),
      elevation: 10,
      context: ctx,
      builder: (ctx) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                    },
                    icon: Icon(Icons.clear)),
              ],
            ),
            // Public
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Public');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.public_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'public'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Friends
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Friends');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.group_outlined),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'friends'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Only Me
            InkWell(
              onTap: () async {
                Navigator.pop(ctx);
                getInfo(type, 'Only Me');
              },
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Icon(Icons.person_outline),
                    Padding(
                      padding: const EdgeInsets.only(left: 16),
                      child: Text(
                        'only_me'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Config().text90Color),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  getInfo(int type, String privacy) {
    switch (type) {
      case 1:
        setState(() {
          hometownPrivacy = privacy;
        });
        break;
      case 2:
        setState(() {
          worksatPrivacy = privacy;
        });
        break;
      case 3:
        setState(() {
          studiedatPrivacy = privacy;
        });
        break;
      case 4:
        setState(() {
          livesinPrivacy = privacy;
        });
        break;
      case 5:
        setState(() {
          relationshipPrivacy = privacy;
        });
        break;
      case 6:
        setState(() {
          birthdatePrivacy = privacy;
        });
        break;
      case 7:
        setState(() {
          genderPrivacy = privacy;
        });
        break;
      default:
    }
  }

  void _showRelationDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Single
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Single';
                  });
                  Navigator.pop(context);

                  ///
                  relationship ??= Relationship();

                  setState(() {
                    relationship!.type = 1;
                    relationship!.typeName = 'Single';
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Single',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Married
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Married';
                  });
                  Navigator.pop(context);

                  if (relationship == null) {
                    _selectedMarried();
                  } else {
                    if (relationship!.type == 1 && _relationshipImage == null) {
                      _selectedMarried();
                    }
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Married',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Engaged
              InkWell(
                onTap: () async {
                  setState(() {
                    relationshipText = 'Engaged';
                  });
                  Navigator.pop(context);

                  if (relationship == null) {
                    _selectEngaged();
                  } else {
                    if (relationship!.type == 1 && _relationshipImage == null) {
                      _selectEngaged();
                    }
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Engaged',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  _selectedMarried() async {
    var ret = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RelationshipPage(
                  isFileImage: false,
                  image: null,
                  name: null,
                  desc: null,
                )));
    if (ret != null) {
      relationship ??= Relationship();

      setState(() {
        _relationshipImage = ret['image'];

        relationship!.type = 2;
        relationship!.typeName = 'Married';
        relationship!.title = ret['name'];
        relationship!.description = ret['desc'];
      });
    } else {
      setState(() {
        relationshipText = '';
      });
    }
  }

  _selectEngaged() async {
    var ret = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => RelationshipPage(
                  isFileImage: false,
                  image: null,
                  name: null,
                  desc: null,
                )));

    if (ret != null) {
      relationship ??= Relationship();
      setState(() {
        _relationshipImage = ret['image'];

        relationship!.type = 3;
        relationship!.typeName = 'Engaged';
        relationship!.title = ret['name'];
        relationship!.description = ret['desc'];
      });
    } else {
      setState(() {
        relationshipText = '';
      });
    }
  }

  _showGenderDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Male
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Male';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Male',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Female
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Female';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Female',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Other
              InkWell(
                onTap: () async {
                  setState(() {
                    gender = 'Other';
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'Other',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<String> uploadRelationFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Relationship Pictures/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
      });
    } catch (e) {
      openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _save() async {
    final ub = context.read<UserBlock>();
    final sb = context.read<SignInBloc>();

    setState(() {
      _updating = true;
    });

    UtilOther.hiddenKeyboard(context);

    hometown = _hometownCtrl.text;
    worksAt = _worksAtCtrl.text;
    studiedAt = _studiedCtrl.text;
    livesIn = _livesCtrl.text;

    if (relationshipText == 'Married' || relationshipText == 'Engaged') {
      if (_relationshipImage != null) {
        var path = await uploadRelationFile(File(_relationshipImage!));
        if (relationship != null && relationship!.typeName != 'Single') {
          relationship!.avatar = path;
        }
      }
    } else if (relationshipText == 'Single') {
      if (relationship!.typeName == 'Single') {
        relationship!.avatar = null;
        relationship!.title = null;
        relationship!.description = null;
      }
    }

    //
    ub
        .updateProfile(
            sb.uid!,
            hometown,
            worksAt,
            studiedAt,
            livesIn,
            relationship,
            interest,
            birthday,
            gender,
            hometownPrivacy,
            worksatPrivacy,
            studiedatPrivacy,
            livesinPrivacy,
            relationshipPrivacy,
            birthdatePrivacy,
            genderPrivacy)
        .then((value) {
      setState(() {
        _updating = false;
      });
      if (ub.hasError == false) {
        openToast('You updated profile successfully');
      } else {
        openSnacbar(context, ub.errorCode);
      }
    });
  }

  _load() async {
    final SignInBloc sb = context.read<SignInBloc>();
    final UserBlock ub = Provider.of<UserBlock>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          _isLoading = true;
        });

        ub.getOwner(sb.uid).then((value) {
          setState(() {
            _isLoading = false;
          });
          if (ub.hasError == false) {
            // interests.addAll(ub.data!.interests!);
            // if (interests.isNotEmpty) {
            //   interest = interests.join(', ');
            // }
            birthday = ub.data!.info!.birthdate!;
            gender = ub.data!.info!.gender!;
            hometown = ub.data!.info!.hometown ?? '';
            worksAt = ub.data!.info!.worksat ?? '';
            studiedAt = ub.data!.info!.studiedat ?? '';
            livesIn = ub.data!.info!.livesin ?? '';
            relationship = ub.data!.info!.relationship;
            if (relationship != null) {
              relationshipText = relationship!.typeName!;
            }

            hometownPrivacy = ub.data!.info!.hometownPrivacy!;
            worksatPrivacy = ub.data!.info!.worksatPrivacy!;
            studiedatPrivacy = ub.data!.info!.studiedatPrivacy!;
            livesinPrivacy = ub.data!.info!.livesinPrivacy!;
            birthdatePrivacy = ub.data!.info!.birthdatePrivacy!;
            genderPrivacy = ub.data!.info!.genderPrivacy!;
            relationshipPrivacy = ub.data!.info!.relationshipPrivacy!;

            setState(() {
              _hometownCtrl.text = hometown;
              _worksAtCtrl.text = worksAt;
              _studiedCtrl.text = studiedAt;
              _livesCtrl.text = livesIn;
            });
          } else {
            openToast("Something went wrong");
          }
        });
      }
    });
  }
}

class InfoItem extends StatelessWidget {
  const InfoItem({
    Key? key,
    required this.svgName,
    required this.type,
  }) : super(key: key);

  final String svgName;
  final String type;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SvgPicture.asset(svgName),
        Padding(
          padding: const EdgeInsets.only(left: 12),
          child: Text(
            type,
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Config().text90Color),
          ),
        ),
      ],
    );
  }
}
