import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/pages/settings/blocked_account_page.dart';
import 'package:twiddle/pages/settings/change_password2_page.dart';
import 'package:twiddle/pages/settings/delete_account_page.dart';
import 'package:twiddle/pages/settings/follow_setting2_page.dart';
import 'package:twiddle/pages/settings/language_page.dart';
import 'package:twiddle/pages/settings/personal_information_page.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';

class SettingPrivacyPage extends StatefulWidget {
  const SettingPrivacyPage({super.key});

  @override
  State<SettingPrivacyPage> createState() => _SettingPrivacyPageState();
}

class _SettingPrivacyPageState extends State<SettingPrivacyPage>
    with AutomaticKeepAliveClientMixin {
  late SharedPreferences sp;
  bool isAutoPlay = false;

  @override
  void initState() {
    super.initState();

    initSP();
  }

  initSP() async {
    sp = await SharedPreferences.getInstance();
    isAutoPlay = sp.getBool('video_auto_play') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final SignInBloc sb = context.read<SignInBloc>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'setting_privacy'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    final SignInBloc sb = context.read<SignInBloc>();

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'account'.tr(),
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          settingItem(
            iconData: Icons.settings_outlined,
            itemName: 'personal_account_information',
            onTap: () {
              nextScreen(context, PersonalInformationPage());
            },
          ),
          const Divider(),
          settingItem(
            iconData: Icons.lock_outline,
            itemName: 'change_password',
            onTap: () {
              nextScreen(context, ChangePassword2Page());
            },
          ),
          const Divider(),
          const SizedBox(height: 24),
          Text(
            'others'.tr(),
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Config().text100Color),
          ),
          const Divider(),
          _videoAutoSwitch(),
          const Divider(),
          settingItem(
            iconData: Icons.language_outlined,
            itemName: 'language',
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                    fullscreenDialog: true,
                    builder: (context) => LanguagePage()),
              );
              setState(() {});
              // nextScreenPopup(context, LanguagePage());
            },
          ),
          const Divider(),
          settingItem(
            iconData: Icons.amp_stories_outlined,
            itemName: 'follow_setting',
            onTap: () {
              nextScreen(context, FollowSetting2Page());
              // nextScreen(context, FollowSetting2Page());
            },
          ),
          const Divider(),
          settingItem(
            iconData: Icons.block_outlined,
            itemName: 'block',
            onTap: () {
              nextScreen(context, BlockedAccountPage());
            },
          ),
          const Divider(),
          settingItem(
            iconData: Icons.delete_outline,
            itemName: 'delete_account',
            onTap: () {
              _showConfirmDialog(context, sb);
            },
          ),
          const Divider(),
        ],
      ),
    );
  }

  _showConfirmDialog(ctx, sb) {
    showDialog(
      context: ctx,
      builder: (ctx) {
        return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
                ),
                Text(
                  sb.name!,
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      color: Config().text100Color),
                ),
                const Divider(),
                Text(
                  'are_you_sure_delete_your_account'.tr(),
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Config().text10Color),
                      child: Text(
                        'no'.tr(),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Config().text90Color),
                      ),
                    ),
                    const SizedBox(width: 20),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        nextScreen(context, DeleteAccountPage());
                      },
                      child: Text(
                        'yes'.tr(),
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  InkWell settingItem(
      {IconData? iconData, String? itemName, Function()? onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(iconData, size: 16),
            Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Text(
                itemName!.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Config().text90Color),
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_forward_ios, size: 16),
          ],
        ),
      ),
    );
  }

  _videoAutoSwitch() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(Icons.play_circle_outline_outlined, size: 16),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text(
              'auto_play_video'.tr(),
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Config().text90Color),
            ),
          ),
          const Spacer(),
          Switch(
            value: isAutoPlay,
            onChanged: (value) {
              print('===== auto play changed $value =====');
              setState(() {
                isAutoPlay = value;
              });
              setAutoPlay(value);
            },
          ),
        ],
      ),
    );
  }

  getAutoPlay() async {
    return sp.getBool('video_auto_play');
  }

  setAutoPlay(bool value) {
    sp.setBool('video_auto_play', value);
  }

  @override
  bool get wantKeepAlive => true;
}
