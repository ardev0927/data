import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/widgets/app_button.dart';

class AccountCompleteFull extends StatefulWidget {
  AccountCompleteFull({super.key, required this.onSuccess});

  Function() onSuccess;

  @override
  State<AccountCompleteFull> createState() => _AccountCompleteFullState();
}

class _AccountCompleteFullState extends State<AccountCompleteFull> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Account Completed
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            'account_completed'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 15),
        // Content
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            'account_complete_content'.tr(),
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            textAlign: TextAlign.center,
          ),
        ),
        Image.asset('assets/images/happy_man_1.png'),
        // Sign In button
        AppButton(
          'done'.tr(),
          mainAxisSize: MainAxisSize.max,
          onPressed: () {
            widget.onSuccess();
          },
        ),
        // elevatedButtonWidget(
        //   name: 'done',
        //   onPressed: () {
        //     nextScreenCloseOthers(context, MainPage());
        //   },
        // ),
      ],
    );
  }
}
