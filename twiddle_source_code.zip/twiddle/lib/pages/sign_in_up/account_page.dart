import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/sign_in_up/account_complete_full.dart';
import 'package:twiddle/pages/sign_in_up/birthday_full.dart';
import 'package:twiddle/pages/sign_in_up/gender_full.dart';
import 'package:twiddle/pages/sign_in_up/profile_photo_full.dart';
import 'package:twiddle/pages/sign_in_up/setup_password_full.dart';
import 'package:twiddle/pages/sign_in_up/sign_in_up_full.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';
import '../main_page.dart';
import 'enter_name_full.dart';
import 'verify_full.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  final PageController _pageController = PageController();
  int accountPages = 8;
  int _pageIndex = 0;

  bool _isVerified = false;
  bool _isSignUp = false;

  String? _emailPhone, _password, _firstname, _lastname, _birthday, _gender;
  int? _method;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;

    return WillPopScope(
      onWillPop: () async {
        var result = await showDialog<bool>(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text('close_app'.tr()),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, true);
                  },
                  child: Text('yes'.tr()),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context, false);
                  },
                  child: Text('no'.tr()),
                ),
              ],
            );
          },
        );
        return result!;
      },
      child: Scaffold(
        backgroundColor: Config().text4Color,
        body: SafeArea(
          child: Stack(
            children: [
              // _pageIndex > 0
              //     ? IconButton(
              //         onPressed: () {
              //           print('===== $_pageIndex =====');
              //           // if (_pageIndex == 1) {
              //           //   setState(() {
              //           //     _pageIndex = 0;
              //           //   });
              //           // }
              //         },
              //         icon: const Icon(Icons.arrow_back),
              //       )
              //     : Container(),
              ListView(
                reverse: true,
                children: [
                  Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 32),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16)),
                      boxShadow: <BoxShadow>[
                        BoxShadow(
                            color: Config().primarySilverColor,
                            blurRadius: 10,
                            offset: Offset(0, 5))
                      ],
                    ),
                    child: getPage(),
                  ),
                  Padding(
                    padding: EdgeInsets.only(
                        left: 60, right: 60, bottom: height / 6),
                    child: const Image(
                      image: AssetImage('assets/images/logo_mini.png'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  getPage() {
    if (_pageIndex == 0) {
      // Sign In/Up
      return SignInUpFull(
        signInPressed: () {
          afterSignIn();
        },
        facebookPressed: () {
          afterSignIn();
        },
        googlePressed: () {
          afterSignIn();
        },
        signUpPressed: ({emailPhone, method, isSignUp}) {
          if (method == 0) {
            setState(() {
              _pageIndex = 1;
              _method = method;
              _emailPhone = emailPhone;
              _isSignUp = isSignUp!;
            });
          } else {
            setState(() {
              _pageIndex = 2;
              _method = method;
              _emailPhone = emailPhone;
              _isSignUp = isSignUp!;
            });
          }
        },
      );
    } else if (_pageIndex == 1) {
      print('===== $_pageIndex =====');
      // Setup Password
      return SetupPasswordFull(
        method: _method,
        email: _emailPhone,
        onContinuePressed: () {
          setState(() {
            _pageIndex = 2;
          });
        },
      );
    } else if (_pageIndex == 2) {
      // Verify email or phone
      return VerifyFull(
        method: _method,
        isSignUp: _isSignUp,
        emailPhone: _emailPhone,
        password: _password,
        emailVerified: (value) {
          if (value) {
            setState(() {
              _pageIndex = 3;
            });
          } else {
            setState(() {
              _pageIndex = 0;
            });
          }
        },
        phoneVerified: (value, isSignUp) {
          if (value) {
            if (isSignUp) {
              setState(() {
                _pageIndex = 3;
              });
            } else {
              nextScreenCloseOthers(context, MainPage());
            }
          } else {
            setState(() {
              _pageIndex = 0;
            });
          }
        },
      );
    } else if (_pageIndex == 3) {
      // Enter your name
      return EnterNameFull(
        method: _method,
        name: (firstname, lastname) {
          setState(() {
            _firstname = firstname;
            _lastname = lastname;
            _pageIndex = 4;
          });
        },
      );
    } else if (_pageIndex == 4) {
      // Birth day
      return BirthdayFull(
        birthday: (date) {
          setState(() {
            _birthday = date;
            _pageIndex = 5;
          });
        },
      );
    } else if (_pageIndex == 5) {
      // Gender
      return GenderFull(
        gender: (gender) {
          setState(() {
            _gender = gender;
            _pageIndex = 6;
          });
        },
      );
    } else if (_pageIndex == 6) {
      // Photo
      return ProfilePhotoFull(
        firstname: _firstname,
        lastname: _lastname,
        birthday: _birthday,
        gender: _gender,
        onSuccess: () {
          setState(() {
            _pageIndex = 7;
          });
        },
      );
    } else if (_pageIndex == 7) {
      // Complete account
      return AccountCompleteFull(
        onSuccess: () {
          nextScreenCloseOthers(context, MainPage());
        },
      );
    }
  }

  afterSignIn() {
    Future.delayed(const Duration(milliseconds: 1000)).then((f) {
      nextScreenReplace(context, const MainPage());
    });
    // nextScreenReplace(context, MainPage());
  }
}
