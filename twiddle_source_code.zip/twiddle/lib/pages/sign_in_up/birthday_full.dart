import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/widgets/app_button.dart';

class BirthdayFull extends StatefulWidget {
  BirthdayFull({super.key, required this.birthday});

  Function(String date) birthday;

  @override
  State<BirthdayFull> createState() => _BirthdayFullState();
}

class _BirthdayFullState extends State<BirthdayFull> {
  final _dateControl = TextEditingController();

  final DateTime _selectedDate = DateTime.now();
  String _date = '';

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Date of birth
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            'date_of_birth'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 45),
        // Calendar
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'MM_dd_yyyy'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: IconButton(
              onPressed: () {
                _selectDate(context);
              },
              icon: Icon(Icons.calendar_month_outlined),
            ),
          ),
          controller: _dateControl,
          validator: (String? value) {
            if (value!.isEmpty) return "This field can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              // emailPhone = value;
            });
          },
        ),
        const SizedBox(height: 75),
        AppButton(
          'continue'.tr(),
          mainAxisSize: MainAxisSize.max,
          onPressed: () {
            if (_date.isNotEmpty) {
              widget.birthday(_date);
            }
          },
        ),
        // elevatedButtonWidget(
        //   name: 'continue',
        //   onPressed: () {
        //     if (_formKey.currentState!.validate()) {
        //       nextScreen(
        //           context,
        //           SignUpGenderPage(
        //             method: widget.method,
        //             firstName: widget.firstName,
        //             lastName: widget.lastName,
        //             birthDate: _date,
        //           ));
        //     }
        //   },
        // ),
      ],
    );
  }

  _selectDate(BuildContext context) async {
    final DateTime? selected = await showDatePicker(
        context: context,
        initialDate: _selectedDate,
        firstDate: DateTime(1900),
        lastDate: DateTime(2050));
    if (selected != null && selected != _selectedDate) {
      setState(() {
        _date = DateFormat('MM/dd/yyyy').format(selected);
        _dateControl.text = _date;
      });
    }
  }
}
