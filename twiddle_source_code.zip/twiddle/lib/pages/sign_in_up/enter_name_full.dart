import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/widgets/app_button.dart';

import '../../config/config.dart';

class EnterNameFull extends StatefulWidget {
  EnterNameFull({super.key, required this.method, required this.name});

  final int? method;
  Function(String firstname, String lastname) name;

  @override
  State<EnterNameFull> createState() => _EnterNameFullState();
}

class _EnterNameFullState extends State<EnterNameFull> {
  final _firstnameControl = TextEditingController();
  final _lastnameControl = TextEditingController();

  String _firstName = '';
  String _lastName = '';

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Enter Your Name
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            'enter_name'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 40),
        // Email Or Phone number
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'first_name'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: InkWell(
              onTap: () {
                _firstnameControl.clear();
              },
              child: Icon(Icons.close),
            ),
          ),
          controller: _firstnameControl,
          textInputAction: TextInputAction.next,
          validator: (String? value) {
            if (value!.isEmpty) return "This field can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              _firstName = value;
            });
          },
        ),
        const SizedBox(height: 16),
        // Password
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'last_name'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: InkWell(
              onTap: () {
                _lastnameControl.clear();
              },
              child: Icon(Icons.close),
            ),
          ),
          controller: _lastnameControl,
          validator: (String? value) {
            if (value!.isEmpty) return "This field can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              _lastName = value;
            });
          },
        ),
        const SizedBox(height: 75),
        // Sign In button
        AppButton(
          'continue'.tr(),
          mainAxisSize: MainAxisSize.max,
          onPressed: () {
            if (_firstName.isNotEmpty && _lastName.isNotEmpty) {
              widget.name(_firstName, _lastName);
            }
          },
        ),
        // elevatedButtonWidget(
        //   name: 'continue',
        //   onPressed: () {
        //     nextScreen(
        //         context,
        //         SignUpTwoPage(
        //           method: widget.method,
        //           firstName: _firstName,
        //           lastName: _lastName,
        //         ));
        //   },
        // ),
      ],
    );
  }
}
