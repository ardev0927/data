import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/widgets/app_button.dart';
import 'package:twiddle/widgets/app_picker_item.dart';

import '../../config/config.dart';

class GenderFull extends StatefulWidget {
  GenderFull({super.key, required this.gender});

  Function(String gender) gender;

  @override
  State<GenderFull> createState() => _GenderFullState();
}

class _GenderFullState extends State<GenderFull> {
  String? _gender;
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Date of birth
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            'what_gender'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 23),
        AppPickerItem(
          title: 'choose_gender'.tr(),
          value: _gender,
          onPressed: () => chooseGender(),
        ),
        const SizedBox(height: 32),
        AppButton(
          'continue'.tr(),
          mainAxisSize: MainAxisSize.max,
          onPressed: () {
            if (_gender != null) {
              widget.gender(_gender!);
            }
          },
        ),
      ],
    );
  }

  chooseGender() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Gender
              InkWell(
                onTap: () async {
                  setState(() {
                    _gender = 'male'.tr();
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'male'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Female
              InkWell(
                onTap: () async {
                  setState(() {
                    _gender = 'female'.tr();
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'female'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Other
              InkWell(
                onTap: () async {
                  setState(() {
                    _gender = 'other'.tr();
                  });
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'other'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
