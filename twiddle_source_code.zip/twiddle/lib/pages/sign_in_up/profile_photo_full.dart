import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/widgets/app_button.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';

class ProfilePhotoFull extends StatefulWidget {
  ProfilePhotoFull(
      {super.key,
      required this.firstname,
      required this.lastname,
      required this.birthday,
      required this.gender,
      required this.onSuccess});

  final String? firstname, lastname;
  final String? birthday;
  final String? gender;
  Function() onSuccess;

  @override
  State<ProfilePhotoFull> createState() => _ProfilePhotoFullState();
}

class _ProfilePhotoFullState extends State<ProfilePhotoFull> {
  File? imageFile;
  String? fileName;
  String? _imageUrl;

  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Date of birth
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            'set_profile_photo'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 33),
        // Avatar
        CircleAvatar(
          radius: 75,
          backgroundColor: Config().primary10Color,
          child: Container(
            height: 150,
            width: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(
                  image: (imageFile == null
                      ? CachedNetworkImageProvider(Config().defaultUserImageUrl)
                      : FileImage(imageFile!)) as ImageProvider<Object>,
                  fit: BoxFit.cover),
            ),
          ),
        ),
        const SizedBox(height: 23),
        // Select Photo
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 50),
          child: Row(
            children: [
              GestureDetector(
                onTap: () {
                  pickImage(true);
                },
                child: Container(
                  alignment: Alignment.center,
                  color: Config().primary10Color,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: Text('take_photo'.tr(),
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  pickImage(false);
                },
                child: Container(
                  alignment: Alignment.center,
                  color: Config().primary10Color,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                  child: Text('gallery'.tr(),
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 65),
        AppButton(
          'continue'.tr(),
          loading: _isLoading,
          mainAxisSize: MainAxisSize.max,
          onPressed: () {
            if (imageFile == null) {
              openSnacbar(context, 'upload photo'.tr());
              return;
            }
            processUser();
          },
        ),
        // ElevatedButton(
        //   onPressed: () {
        //     if (imageFile == null) {
        //       openSnacbar(context, 'Please select photo');
        //       return;
        //     }
        //     processUser();
        //   },
        //   style: ElevatedButton.styleFrom(
        //     shape:
        //         RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        //     minimumSize: const Size.fromHeight(50), // NEW
        //   ),
        //   child: _isProcess
        //       ? CircularProgressIndicator()
        //       : Text(
        //           'continue'.tr(),
        //           style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        //         ),
        // ),
      ],
    );
  }

  Future pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker()
          .pickImage(source: ImageSource.camera, imageQuality: 50);
    } else {
      image = await ImagePicker()
          .pickImage(source: ImageSource.gallery, imageQuality: 50);
    }

    if (image != null) {
      setState(() {
        imageFile = File(image!.path);
        fileName = (imageFile!.path);
      });
    } else {
      print('No image selected!');
    }
  }

  Future uploadPicture() async {
    try {
      final SignInBloc sb = context.read<SignInBloc>();
      Reference storageReference =
          FirebaseStorage.instance.ref().child('Profile Pictures/${sb.uid}');
      UploadTask uploadTask = storageReference.putFile(imageFile!);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        _imageUrl = url.toString();
      });
    } catch (e) {
      openSnacbar(context, e.toString());
      // setState(() {
      //   _isProcess = true;
      // });
    }
  }

  processUser() async {
    final sb = context.read<SignInBloc>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        setState(() {
          _isLoading = true;
        });
        // print('===== phone number is ${widget.phoneNumber} =====');
        await uploadPicture().then((value) {
          var name = '${widget.firstname!} ${widget.lastname!}';
          sb.setUserData(name, widget.birthday, widget.gender, _imageUrl);
          sb.getTimestamp().then(
                (value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then(
                      (value) => sb.guestSignout().then(
                            (value) => sb.saveDataToSP().then(
                                  (value) => sb.setSignIn().then(
                                    (value) {
                                      setState(() {
                                        _isLoading = false;
                                      });
                                      //
                                      widget.onSuccess();
                                    },
                                  ),
                                ),
                          ),
                    ),
              );
        });
      }
    });
  }
}
