import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../widgets/app_button.dart';

class SetupPasswordFull extends StatefulWidget {
  SetupPasswordFull(
      {super.key,
      required this.method,
      required this.email,
      required this.onContinuePressed});

  final int? method;
  final String? email;
  Function()? onContinuePressed;

  @override
  State<SetupPasswordFull> createState() => _SetupPasswordFullState();
}

class _SetupPasswordFullState extends State<SetupPasswordFull> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _passControl = TextEditingController();
  final _passConfirmControl = TextEditingController();

  String _password = '';
  String _passwordConfirm = '';

  bool _isSignUpLoading = false;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          //
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'setup_password'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 40),
          // Email Or Phone number
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,

              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            textInputAction: TextInputAction.next,
            obscureText: true,
            controller: _passControl,
            validator: (String? value) {
              if (value!.isEmpty) return "This field can't be empty";
              if (value.length < 8) {
                return "Your password must be at least 8 characters long";
              }
              return null;
            },
            onChanged: (value) {
              setState(() {
                _password = value;
              });
            },
          ),
          const SizedBox(height: 16),
          // Password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'confirm_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _passConfirmControl,
            textInputAction: TextInputAction.done,
            validator: (String? value) {
              if (value!.isEmpty) return "This field can't be empty";
              if (value.length < 8) {
                return "Your password must be at least 8 characters long";
              }
              if (_password != value) {
                return "The password confirmation does not match";
              }
              return null;
            },
            onChanged: (value) {
              setState(() {
                _passwordConfirm = value;
              });
            },
          ),
          const SizedBox(height: 100),
          AppButton(
            'continue'.tr(),
            mainAxisSize: MainAxisSize.max,
            loading: _isSignUpLoading,
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                if (_password != _passwordConfirm) {
                  openSnacbar(
                      context, 'The password confirmation does not match');
                  return;
                }
                handleVerifyEmail();
              }
            },
          ),
        ],
      ),
    );
  }

  Future handleVerifyEmail() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        setState(() {
          _isSignUpLoading = true;
        });
        sb.verifyEmail(widget.email, _password).then((_) async {
          setState(() {
            _isSignUpLoading = false;
          });
          if (sb.hasError == false) {
            widget.onContinuePressed!();
            // Send verification email
            // sb.sendVerificationEmail();
          } else {
            openSnacbar(context, sb.errorCode);
          }
        });
      }
    });
  }
}
