import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl_phone_field/countries.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:phone_number/phone_number.dart';
import 'package:provider/provider.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:twiddle/widgets/app_button.dart';
import 'package:twiddle/widgets/app_picker_item.dart';
import 'package:twiddle/widgets/app_text_input.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../forget_password/forget_password_page.dart';

class SignInUpFull extends StatefulWidget {
  SignInUpFull({
    super.key,
    required this.signInPressed,
    required this.signUpPressed,
    required this.facebookPressed,
    required this.googlePressed,
  });

  Function()? signInPressed;
  Function(
      {required int? method,
      required String? emailPhone,
      required bool? isSignUp})? signUpPressed;
  Function()? facebookPressed;
  Function()? googlePressed;

  @override
  State<SignInUpFull> createState() => _SignInUpFullState();
}

class _SignInUpFullState extends State<SignInUpFull> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final _emailPhoneController = TextEditingController();
  final _passwordController = TextEditingController();

  final _fbController = RoundedLoadingButtonController();
  final _googleController = RoundedLoadingButtonController();

  String _emailPhone = '';
  String _password = '';
  String _phoneNumber = '';

  int _signInMethod = -1;
  int _signUpMethod = -1;

  bool _isSignInMethod = true;
  bool _isSignInLoading = false;
  bool _isSignUpLoading = false;
  bool _visiblePassword = false;

  String? _signInType, _signUpType;
  String? signInPhoneNumber, signUpPhoneNumber;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Sign In and Up
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    _isSignInMethod = true;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: _isSignInMethod
                        ? Config().primary30Color
                        : Config().text4Color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  child: Text('sign_in',
                          style: TextStyle(
                              fontSize: _isSignInMethod ? 16 : 14,
                              fontWeight: _isSignInMethod
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                              color: _isSignInMethod
                                  ? Colors.white
                                  : Config().text90Color))
                      .tr(),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    _isSignInMethod = false;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: _isSignInMethod
                        ? Config().text4Color
                        : Config().primary30Color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  child: Text('sign_up',
                          style: TextStyle(
                              fontSize: _isSignInMethod ? 14 : 16,
                              fontWeight: _isSignInMethod
                                  ? FontWeight.w400
                                  : FontWeight.w700,
                              color: _isSignInMethod
                                  ? Config().text90Color
                                  : Config().whiteColor))
                      .tr(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          _isSignInMethod ? signInWidget() : signUpWidget(),
        ],
      ),
    );
  }

  Widget signInWidget() {
    return Column(
      children: [
        // Choose email or phone
        AppPickerItem(
          title: 'choose_email_phone_signin'.tr(),
          value: _signInType,
          onPressed: () => chooseSignInType(true),
        ),
        _signInType == null
            ? const SizedBox(height: 16)
            : _signInType == 'email'.tr()
                ? emailSignInWidget()
                : phoneSignInWidget(),
        //
        Text('or_sign_in'.tr(),
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
        const SizedBox(height: 12),
        //
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 56),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              RoundedLoadingButton(
                  onPressed: () {
                    handleFacebookLogin();
                  },
                  controller: _fbController,
                  color: Config().text4Color,
                  valueColor: Config().appColor,
                  width: 40,
                  height: 40,
                  borderRadius: 4,
                  elevation: 1,
                  child: SvgPicture.asset('assets/images/fb.svg')),
              const Spacer(),
              RoundedLoadingButton(
                  onPressed: () {
                    handleGoogleSignIn();
                  },
                  controller: _googleController,
                  color: Config().text4Color,
                  valueColor: Config().appColor,
                  width: 40,
                  height: 40,
                  borderRadius: 4,
                  elevation: 1,
                  child: SvgPicture.asset('assets/images/google.svg')),
              Platform.isIOS ? Spacer() : Container(),
              Platform.isIOS
                  ? GestureDetector(
                      onTap: () {},
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                            color: Config().text4Color,
                            borderRadius: BorderRadius.circular(8)),
                        child: const Image(
                            image: AssetImage('assets/images/ic_apple.png'),
                            width: 24,
                            height: 24),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
        const SizedBox(height: 32),
        // Sign In button
        AppButton(
          'sign_in'.tr(),
          loading: _isSignInLoading,
          mainAxisSize: MainAxisSize.max,
          onPressed: () async {
            if (_signInType == null) return;
            if (_signInMethod == 0) {
              var isValid = checkEmailValid();
              if (isValid) {
                // Sign in with email
                handleSignInwithemailPassword();
              }
            } else {
              var isValid = await checkSignInPhoneValid();
              if (isValid) {
                // Sign in with phone number
                widget.signUpPressed!(
                    method: _signInMethod,
                    emailPhone: _phoneNumber,
                    isSignUp: false);
              }
            }
          },
        ),
      ],
    );
  }

  Widget emailSignInWidget() {
    return Column(
      children: [
        //
        const SizedBox(height: 32),

        // Email Or Phone number
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'email'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: InkWell(
              onTap: () {
                _emailPhoneController.clear();
              },
              child: Icon(Icons.close),
            ),
          ),
          controller: _emailPhoneController,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.next,
          validator: (String? value) {
            if (value!.isEmpty) return "Email can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              _emailPhone = value;
            });
          },
        ),
        const SizedBox(height: 16),
        // Password
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'password'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: InkWell(
              onTap: () {
                setState(() {
                  _visiblePassword = !_visiblePassword;
                });
              },
              child: Icon(_visiblePassword
                  ? Icons.visibility_outlined
                  : Icons.visibility_off_outlined),
            ),
          ),
          obscureText: _visiblePassword ? false : true,
          controller: _passwordController,
          textInputAction: TextInputAction.done,
          validator: (String? value) {
            if (value!.isEmpty) return "Password can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              _password = value;
            });
          },
        ),
        // Forget Password
        Row(
          children: [
            const Spacer(),
            TextButton(
                onPressed: () async {
                  var ret = await Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ForgetPasswordPage()));
                  if (ret == true) {
                    openSnacbar(context, 'Password reset email sent');
                    return;
                  }
                  // nextScreen(context, ForgetPasswordPage());
                },
                child: Text(
                  'forget_password'.tr(),
                  style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w400,
                      color: Colors.black),
                ))
          ],
        ),
      ],
    );
  }

  Widget phoneSignInWidget() {
    return Column(
      children: [
        //
        const SizedBox(height: 32),
        IntlPhoneField(
          decoration: InputDecoration(
            labelText: 'phone'.tr(),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          initialCountryCode: 'US',
          onChanged: (phone) {
            // Run anything here
            print(phone.completeNumber);
            signInPhoneNumber = phone.completeNumber;
          },
        ),
      ],
    );
  }

  Widget signUpWidget() {
    return Column(
      children: [
        // Choose email or phone
        AppPickerItem(
          title: 'choose_email_phone_signup'.tr(),
          value: _signUpType,
          onPressed: () => chooseSignInType(false),
        ),
        _signUpType == null
            ? const SizedBox(height: 16)
            : _signUpType == 'email'.tr()
                ? emailSignUpWidget()
                : phoneSignUpWidget(),

        const SizedBox(height: 32),
        AppButton(
          'continue'.tr(),
          loading: _isSignUpLoading,
          mainAxisSize: MainAxisSize.max,
          onPressed: () async {
            if (_signUpMethod == 0) {
              var isValid = checkEmailValid();
              if (isValid) {
                widget.signUpPressed!(
                    method: _signUpMethod,
                    emailPhone: _emailPhone,
                    isSignUp: true);
              }
            } else if (_signUpMethod == 1) {
              var isValid = await checkSignUpPhoneValid();
              if (isValid) {
                widget.signUpPressed!(
                    method: _signUpMethod,
                    emailPhone: _phoneNumber,
                    isSignUp: true);
              }
            }
          },
        ),
      ],
    );
  }

  Widget emailSignUpWidget() {
    return Column(
      children: [
        //
        const SizedBox(height: 32),

        // Email Or Phone number
        TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 12),
            hintText: 'email'.tr(),
            hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            suffixIcon: InkWell(
              onTap: () {
                _emailPhoneController.clear();
              },
              child: Icon(Icons.close),
            ),
          ),
          controller: _emailPhoneController,
          keyboardType: TextInputType.emailAddress,
          validator: (String? value) {
            if (value!.length == 0) return "Email can't be empty";
            return null;
          },
          onChanged: (value) {
            setState(() {
              _emailPhone = value;
            });
          },
        ),
      ],
    );
  }

  Widget phoneSignUpWidget() {
    return Column(
      children: [
        //
        const SizedBox(height: 32),
        IntlPhoneField(
          decoration: InputDecoration(
            labelText: 'phone'.tr(),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          initialCountryCode: 'US',
          onChanged: (phone) {
            // Run anything here
            print('===== Phone: ${phone.completeNumber} =====');
            signUpPhoneNumber = phone.completeNumber;
          },
        ),
      ],
    );
  }

  chooseSignInType(bool isSignInBody) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Email
              InkWell(
                onTap: () async {
                  if (isSignInBody) {
                    setState(() {
                      _signInType = 'email'.tr();
                      _signInMethod = 0;
                    });
                  } else {
                    setState(() {
                      _signUpType = 'email'.tr();
                      _signUpMethod = 0;
                    });
                  }
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      const Icon(Icons.email_outlined),
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'email'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              // Phone
              InkWell(
                onTap: () async {
                  if (isSignInBody) {
                    setState(() {
                      _signInType = 'phone'.tr();
                      _signInMethod = 1;
                    });
                  } else {
                    setState(() {
                      _signUpType = 'phone'.tr();
                      _signUpMethod = 1;
                    });
                  }
                  Navigator.pop(context);
                },
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      const Icon(Icons.phone_android_outlined),
                      Padding(
                        padding: const EdgeInsets.only(left: 16),
                        child: Text(
                          'phone'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Config().text90Color),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  checkEmailOrPhone() async {
    int method = -1;
    try {
      if (!_formKey.currentState!.validate()) {
        return method;
      }
      // Validate email
      final bool isValidEmail = EmailValidator.validate(_emailPhone);
      if (isValidEmail) {
        method = 0;
        return method;
      }

      // Validate phone number
      // String springFieldUSASimple = '+14175555470';
      PhoneNumber phoneNumber =
          await PhoneNumberUtil().parse(signUpPhoneNumber!);
      _phoneNumber = phoneNumber.e164;
      method = 1;
    } catch (e) {
      print(e.toString());
      openSnacbar(context, 'Invalid email or phone number');
    }

    return method;
  }

  bool checkEmailValid() {
    bool isValidEmail = false;
    try {
      if (!_formKey.currentState!.validate()) {
        return isValidEmail;
      } else {}
      // Validate email
      isValidEmail = EmailValidator.validate(_emailPhone);
    } catch (e) {
      print(e.toString());
      openSnacbar(context, 'Invalid email');
    }

    return isValidEmail;
  }

  checkSignInPhoneValid() async {
    bool isValidPhone = false;
    try {
      if ((signInPhoneNumber == null) ||
          (signInPhoneNumber != null && signInPhoneNumber!.isEmpty)) {
        return isValidPhone;
      }
      // Validate phone number
      // String springFieldUSASimple = '+14175555470';
      PhoneNumber phoneNumber =
          await PhoneNumberUtil().parse(signInPhoneNumber!);
      _phoneNumber = phoneNumber.e164;
      isValidPhone = true;
    } catch (e) {
      print(e.toString());
      openSnacbar(context, 'Invalid phone number');
    }

    return isValidPhone;
  }

  checkSignUpPhoneValid() async {
    bool isValidPhone = false;
    try {
      if ((signUpPhoneNumber == null) ||
          (signUpPhoneNumber != null && signUpPhoneNumber!.isEmpty)) {
        return isValidPhone;
      }
      // Validate phone number
      // String springFieldUSASimple = '+14175555470';
      PhoneNumber phoneNumber =
          await PhoneNumberUtil().parse(signUpPhoneNumber!);
      _phoneNumber = phoneNumber.e164;
      isValidPhone = true;
    } catch (e) {
      print(e.toString());
      openSnacbar(context, 'Invalid phone number');
    }

    return isValidPhone;
  }

  handleSignInwithemailPassword() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      FocusScope.of(context).requestFocus(new FocusNode());
      await AppService().checkInternet().then((hasInternet) {
        if (hasInternet == false) {
          openSnacbar(context, 'no internet'.tr());
        } else {
          setState(() {
            _isSignInLoading = true;
          });
          sb.signInwithEmailPassword(_emailPhone, _password).then((_) async {
            if (sb.hasError == false) {
              sb
                  .getUserDatafromFirebase(sb.uid)
                  .then((value) => sb.guestSignout())
                  .then((value) => sb
                      .saveDataToSP()
                      .then((value) => sb.setSignIn().then((value) {
                            // setState(() {
                            //   signInComplete = true;
                            // });

                            ///
                            setUserState(sb, 'Online');

                            ///
                            widget.signInPressed!();
                            // afterSignIn();
                          })));
            } else {
              openSnacbar(context, sb.errorCode);
            }
            setState(() {
              _isSignInLoading = false;
            });
          });
        }
      });
    }
  }

  /// Handle verify phone number
  handleVerifyPhoneNumber() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        await sb.verifyPhoneNumber(
          _emailPhone,
          timeout: 120,
          codeSent: (verificationId, visibility) {},
          codeAutoRetrievalTimeout: (verificationId) {},
        );
      }
    });
  }

  setUserState(SignInBloc sb, String status) {
    var ub = context.read<UserBlock>();

    ub.updateState(sb.uid!, status);
  }

  handleGoogleSignIn() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await sb.signInWithGoogle().then((_) {
          if (sb.hasError == true) {
            openSnacbar(context, 'something is wrong. please try again.'.tr());
            _googleController.reset();
          } else {
            setState(() {
              _isSignInLoading = true;
            });
            sb.checkUserExists().then((value) {
              if (value == true) {
                sb
                    .getUserDatafromFirebase(sb.uid)
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _googleController.success();
                              // setState(() {
                              //   signInComplete = true;
                              // });
                              // afterSignIn();
                              widget.googlePressed!();
                            })));
              } else {
                sb.getTimestamp().then((value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _googleController.success();
                              // setState(() {
                              //   signInComplete = true;
                              // });
                              firstNotificationCount(sb.uid!);
                              // afterSignIn();
                              widget.googlePressed!();
                            }))));
              }
            });
          }
        });
      }
    });
  }

  void handleFacebookLogin() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await sb.signInwithFacebook().then((_) {
          if (sb.hasError == true) {
            openSnacbar(context, 'error fb login'.tr());
            _fbController.reset();
          } else {
            sb.checkUserExists().then((value) {
              if (value == true) {
                sb
                    .getUserDatafromFirebase(sb.uid)
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _fbController.success();
                              // afterSignIn();
                              widget.facebookPressed!();
                            })));
              } else {
                sb.getTimestamp().then((value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then((value) => sb.guestSignout().then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _fbController.success();
                              firstNotificationCount(sb.uid!);
                              // afterSignIn();
                              widget.facebookPressed!();
                            })))));
              }
            });
          }
        });
      }
    });
  }

  Future firstNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount});
    });
  }

  Future<int> getTotalNotificationsCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }
}
