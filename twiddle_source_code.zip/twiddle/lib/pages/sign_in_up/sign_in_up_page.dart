import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:phone_number/phone_number.dart';
import 'package:provider/provider.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/forget_password/forget_password_page.dart';
import 'package:twiddle/pages/main_page.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_password_page.dart';
import 'package:twiddle/pages/sign_in_up/verify_page.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../blocs/user_bloc.dart';
import '../../services/app_service.dart';
import '../../utils/next_screen.dart';
import '../../utils/snacbar.dart';
import '../../widgets/elevated_button_widget.dart';

class SignInUpPage extends StatefulWidget {
  const SignInUpPage({super.key});

  @override
  State<SignInUpPage> createState() => _SignInUpPageState();
}

class _SignInUpPageState extends State<SignInUpPage> {
  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController _emailPhoneController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  bool _isSignInMethod = true;
  bool _isSignUpMethod = false;
  bool signInStart = false;
  bool signInComplete = false;

  int method = 0;

  String emailPhone = '';
  String password = '';
  String _phoneNumber = '';

  final _fbController = RoundedLoadingButtonController();
  final _googleController = RoundedLoadingButtonController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      backgroundColor: Config().text4Color,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              method == 0 ? _signInWidget() : _signUpBody(),
            ],
          ),
        ),
      ),
    );
  }

  _signInWidget() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Sign In and Up
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  if (method == 0) return;
                  setState(() {
                    method = 0;
                    _isSignInMethod = true;
                    _isSignUpMethod = false;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: _isSignInMethod
                        ? Config().primary30Color
                        : Config().text4Color,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  child: Text('sign_in',
                          style: TextStyle(
                              fontSize: _isSignInMethod ? 16 : 14,
                              fontWeight: _isSignInMethod
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                              color: _isSignInMethod
                                  ? Colors.white
                                  : Config().text90Color))
                      .tr(),
                ),
              ),
              GestureDetector(
                onTap: () {
                  if (method == 1) return;
                  setState(() {
                    method = 1;
                    _isSignInMethod = false;
                    _isSignUpMethod = true;
                  });
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: _isSignUpMethod
                        ? Config().primary30Color
                        : Config().text4Color,
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(8),
                        bottomRight: Radius.circular(8)),
                  ),
                  // color:
                  //     _isSignUpMethod ? Config().primary10Color : Colors.white,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                  child: Text('sign_up',
                          style: TextStyle(
                              fontSize: _isSignUpMethod ? 16 : 14,
                              fontWeight: _isSignUpMethod
                                  ? FontWeight.w700
                                  : FontWeight.w400,
                              color: _isSignUpMethod
                                  ? Colors.white
                                  : Config().text90Color))
                      .tr(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 50),
          // Email Or Phone number
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'email_or_phone'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            controller: _emailPhoneController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.next,
            validator: (String? value) {
              if (value!.isEmpty) return "Email or Phone can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                emailPhone = value;
              });
            },
          ),
          const SizedBox(height: 24),
          // Password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().text4Color)),
              fillColor: Config().text4Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _passwordController,
            textInputAction: TextInputAction.done,
            validator: (String? value) {
              if (value!.isEmpty) return "Password can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                password = value;
              });
            },
          ),
          // Forget Password
          Row(
            children: [
              const Spacer(),
              TextButton(
                  onPressed: () async {
                    var ret = await Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ForgetPasswordPage()));
                    if (ret == true) {
                      openSnacbar(context, 'Password reset email sent');
                      return;
                    }
                    // nextScreen(context, ForgetPasswordPage());
                  },
                  child: Text(
                    'forget_password'.tr(),
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w400,
                        color: Colors.black),
                  ))
            ],
          ),
          //
          Text('or_sign_in'.tr(),
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
          const SizedBox(height: 12),
          //
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 56),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                RoundedLoadingButton(
                    onPressed: () {
                      handleFacebookLogin();
                    },
                    controller: _fbController,
                    color: Config().text4Color,
                    valueColor: Config().appColor,
                    width: 40,
                    height: 40,
                    borderRadius: 4,
                    elevation: 1,
                    child: SvgPicture.asset('assets/images/fb.svg')),
                const Spacer(),
                RoundedLoadingButton(
                    onPressed: () {
                      handleGoogleSignIn();
                    },
                    controller: _googleController,
                    color: Config().text4Color,
                    valueColor: Config().appColor,
                    width: 40,
                    height: 40,
                    borderRadius: 4,
                    elevation: 1,
                    child: SvgPicture.asset('assets/images/google.svg')),
                Platform.isIOS ? Spacer() : Container(),
                Platform.isIOS
                    ? GestureDetector(
                        onTap: () {},
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                              color: Config().text4Color,
                              borderRadius: BorderRadius.circular(8)),
                          child: Image(
                              image: AssetImage('assets/images/ic_apple.png'),
                              width: 24,
                              height: 24),
                        ),
                      )
                    : Container(),
              ],
            ),
          ),
          const SizedBox(height: 32),
          // Sign In button
          ElevatedButton(
            onPressed: () async {
              int method = await checkEmailOrPhone();
              if (method == 0) {
                handleSignInwithemailPassword();
              } else {
                // handleSignInwithPhoneNumber();
              }
            },
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              minimumSize: const Size.fromHeight(50), // NEW
            ),
            child: signInStart == false
                ? Text(
                    'sign_in'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ).tr()
                : signInComplete == false
                    ? CircularProgressIndicator(
                        backgroundColor: Colors.white,
                      )
                    : Text('sign_in'.tr(),
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700))
                        .tr(),
          ),
        ],
      ),
    );
  }

  _signUpBody() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Sign In and Up
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    if (method == 0) return;
                    setState(() {
                      method = 0;
                      _isSignInMethod = true;
                      _isSignUpMethod = false;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: _isSignInMethod
                            ? Config().primary30Color
                            : Config().text4Color,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(8),
                            bottomLeft: Radius.circular(8))),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 32, vertical: 12),
                    child: Text('sign_in',
                            style: TextStyle(
                                fontSize: _isSignInMethod ? 16 : 14,
                                fontWeight: _isSignInMethod
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                                color: _isSignInMethod
                                    ? Colors.white
                                    : Config().text90Color))
                        .tr(),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    if (method == 1) return;
                    setState(() {
                      method = 1;
                      _isSignInMethod = false;
                      _isSignUpMethod = true;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                        color: _isSignUpMethod
                            ? Config().primary30Color
                            : Config().text4Color,
                        borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 32, vertical: 12),
                    child: Text('sign_up',
                            style: TextStyle(
                                fontSize: _isSignUpMethod ? 16 : 14,
                                fontWeight: _isSignUpMethod
                                    ? FontWeight.w700
                                    : FontWeight.w400,
                                color: _isSignUpMethod
                                    ? Colors.white
                                    : Config().text90Color))
                        .tr(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 50),
            // Email Or Phone number
            TextFormField(
              decoration: InputDecoration(
                // enabledBorder: ,
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Config().text4Color)),
                fillColor: Config().text4Color,
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                hintText: 'email_or_phone'.tr(),
                hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              ),
              controller: _emailPhoneController,
              keyboardType: TextInputType.emailAddress,
              validator: (String? value) {
                if (value!.length == 0) return "Email or Phone can't be empty";
                return null;
              },
              onChanged: (value) {
                setState(() {
                  emailPhone = value;
                });
              },
            ),
            const SizedBox(height: 30),
            const SizedBox(height: 32),
            // Sign In button
            elevatedButtonWidget(
              name: 'continue',
              onPressed: () async {
                var input = await checkEmailOrPhone();
                if (input == 0) {
                  // nextScreen(context, VerifyPage(method: 0));
                  nextScreen(
                      context,
                      SignUpPasswordPage(
                        method: input,
                        email: emailPhone,
                      ));
                } else if (input == 1) {
                  nextScreen(
                      context,
                      VerifyPage(
                        method: 1,
                        phone: _phoneNumber,
                      ));
                  // nextScreen(
                  //     context,
                  //     SignUpPasswordPage(
                  //       method: input,
                  //       phone: _phoneNumber,
                  //     ));
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  checkEmailOrPhone() async {
    int method = -1;
    try {
      if (!_formKey.currentState!.validate()) {
        return method;
      }
      // Validate email
      final bool isValidEmail = EmailValidator.validate(emailPhone);
      if (isValidEmail) {
        method = 0;
        return method;
      }

      // Validate phone number
      // String springFieldUSASimple = '+14175555470';
      PhoneNumber phoneNumber = await PhoneNumberUtil().parse(emailPhone);
      _phoneNumber = phoneNumber.e164;
      method = 1;
    } catch (e) {
      print(e.toString());
      openSnacbar(context, 'Invalid email or phone number');
    }

    return method;
  }

  handleSignInwithemailPassword() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      FocusScope.of(context).requestFocus(new FocusNode());
      await AppService().checkInternet().then((hasInternet) {
        if (hasInternet == false) {
          openSnacbar(context, 'no internet'.tr());
        } else {
          setState(() {
            signInStart = true;
          });
          sb.signInwithEmailPassword(emailPhone, password).then((_) async {
            if (sb.hasError == false) {
              sb
                  .getUserDatafromFirebase(sb.uid)
                  .then((value) => sb.guestSignout())
                  .then((value) => sb
                      .saveDataToSP()
                      .then((value) => sb.setSignIn().then((value) {
                            setState(() {
                              signInComplete = true;
                            });

                            ///
                            setUserState(sb, 'Online');

                            ///
                            afterSignIn();
                          })));
            } else {
              setState(() {
                signInStart = false;
              });
              openSnacbar(context, sb.errorCode);
            }
          });
        }
      });
    }
  }

  setUserState(SignInBloc sb, String status) {
    var ub = context.read<UserBlock>();

    ub.updateState(sb.uid!, status);
  }

  handleSignInwithPhoneNumber() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        setState(() {
          signInStart = true;
        });
        print('===== Phone number is $emailPhone =====');
        await sb.getFirebaseAuth().verifyPhoneNumber(
              phoneNumber: emailPhone,
              verificationCompleted: (phoneAuthCredential) async {
                print('===== Verification Completed ======');
              },
              verificationFailed: (error) {
                if (error.code == 'invalid-phone-number') {
                  print('===== The provided phone number is not valid. =====');
                }
              },
              codeSent: (verificationId, forceResendingToken) {
                print('===== Verification Id is $verificationId =====');
              },
              codeAutoRetrievalTimeout: (verificationId) {},
              timeout: Duration(seconds: 60),
            );
        // sb.signInwithEmailPassword(emailPhone, password).then((_) async {
        //   if (sb.hasError == false) {
        //     sb
        //         .getUserDatafromFirebase(sb.uid)
        //         .then((value) => sb.guestSignout())
        //         .then((value) => sb
        //             .saveDataToSP()
        //             .then((value) => sb.setSignIn().then((value) {
        //                   setState(() {
        //                     signInComplete = true;
        //                   });
        //                   afterSignIn();
        //                 })));
        //   } else {
        //     setState(() {
        //       signInStart = false;
        //     });
        //     openSnacbar(context, sb.errorCode);
        //   }
        // });
      }
    });
  }

  afterSignIn() {
    Future.delayed(Duration(milliseconds: 1000)).then((f) {
      nextScreenReplace(context, MainPage());
    });
    // nextScreenReplace(context, MainPage());
  }

  handleGoogleSignIn() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await sb.signInWithGoogle().then((_) {
          if (sb.hasError == true) {
            openSnacbar(context, 'something is wrong. please try again.'.tr());
            _googleController.reset();
          } else {
            setState(() {
              signInStart = true;
            });
            sb.checkUserExists().then((value) {
              if (value == true) {
                sb
                    .getUserDatafromFirebase(sb.uid)
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _googleController.success();
                              setState(() {
                                signInComplete = true;
                              });
                              afterSignIn();
                            })));
              } else {
                sb.getTimestamp().then((value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _googleController.success();
                              setState(() {
                                signInComplete = true;
                              });
                              firstNotificationCount(sb.uid!);
                              afterSignIn();
                            }))));
              }
            });
          }
        });
      }
    });
  }

  void handleFacebookLogin() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await sb.signInwithFacebook().then((_) {
          if (sb.hasError == true) {
            openSnacbar(context, 'error fb login'.tr());
            _fbController.reset();
          } else {
            sb.checkUserExists().then((value) {
              if (value == true) {
                sb
                    .getUserDatafromFirebase(sb.uid)
                    .then((value) => sb.guestSignout())
                    .then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _fbController.success();
                              // firstNotificationCount(sb.uid!);
                              afterSignIn();
                            })));
              } else {
                sb.getTimestamp().then((value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then((value) => sb.guestSignout().then((value) => sb
                        .saveDataToSP()
                        .then((value) => sb.setSignIn().then((value) {
                              _fbController.success();
                              firstNotificationCount(sb.uid!);
                              afterSignIn();
                            })))));
              }
            });
          }
        });
      }
    });
  }

  Future firstNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount});
    });
  }

  Future<int> getTotalNotificationsCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }
}
