import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/main_page.dart';
import 'package:twiddle/pages/sign_in_up/sign_in_up_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';
import '../../widgets/elevated_button_widget.dart';

class SignUpComplete extends StatefulWidget {
  const SignUpComplete({super.key});

  @override
  State<SignUpComplete> createState() => _SignUpCompleteState();
}

class _SignUpCompleteState extends State<SignUpComplete> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Account Completed
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'account_completed'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 15),
          // Content
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'account_complete_content'.tr(),
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
              textAlign: TextAlign.center,
            ),
          ),
          Image.asset('assets/images/happy_man_1.png'),
          // Sign In button
          elevatedButtonWidget(
            name: 'done',
            onPressed: () {
              nextScreenCloseOthers(context, MainPage());
            },
          ),
        ],
      ),
    );
  }
}
