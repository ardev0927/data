import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_photo_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';
import '../../widgets/elevated_button_widget.dart';

class SignUpGenderPage extends StatefulWidget {
  const SignUpGenderPage({
    super.key,
    required this.method,
    required this.firstName,
    required this.lastName,
    required this.birthDate,
  });

  final int? method;
  final String? firstName;
  final String? lastName;
  final String? birthDate;

  @override
  State<SignUpGenderPage> createState() => _SignUpGenderPageState();
}

class _SignUpGenderPageState extends State<SignUpGenderPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  int selectGender = 0;
  String _gender = 'Male';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Date of birth
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'what_gender'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 23),
          // Select Gender
          GestureDetector(
            onTap: () {
              if (selectGender == 0) return;
              _gender = 'Male';
              setState(() {
                selectGender = 0;
              });
            },
            child: Container(
              height: 50,
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.only(left: 12),
              decoration: BoxDecoration(
                color: selectGender == 0
                    ? Config().primary10Color
                    : Config().secondary20Color,
                border: Border.all(
                  color: Config().primary10Color,
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('male'.tr(),
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
            ),
          ),
          GestureDetector(
            onTap: () {
              if (selectGender == 1) return;
              _gender = 'Female';
              setState(() {
                selectGender = 1;
              });
            },
            child: Container(
              height: 50,
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.only(left: 12),
              decoration: BoxDecoration(
                color: selectGender == 1
                    ? Config().primary10Color
                    : Config().secondary20Color,
                border: Border.all(
                  color: Config().primary10Color,
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('female'.tr(),
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
            ),
          ),
          GestureDetector(
            onTap: () {
              if (selectGender == 2) return;
              _gender = 'Other';
              setState(() {
                selectGender = 2;
              });
            },
            child: Container(
              height: 50,
              alignment: Alignment.centerLeft,
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.only(left: 12),
              decoration: BoxDecoration(
                color: selectGender == 2
                    ? Config().primary10Color
                    : Config().secondary20Color,
                border: Border.all(
                  color: Config().primary10Color,
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('other'.tr(),
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
            ),
          ),
          // Sign In button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              nextScreen(
                  context,
                  SignUpPhotoPage(
                    method: widget.method,
                    firstName: widget.firstName,
                    lastName: widget.lastName,
                    birthDate: widget.birthDate,
                    gender: _gender,
                  ));
            },
          ),
        ],
      ),
    );
  }
}
