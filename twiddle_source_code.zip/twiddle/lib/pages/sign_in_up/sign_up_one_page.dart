import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_two_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../config/config.dart';
import '../../widgets/elevated_button_widget.dart';

class SignUpOnePage extends StatefulWidget {
  const SignUpOnePage({super.key, required this.method});

  final int? method;

  @override
  State<SignUpOnePage> createState() => _SignUpOnePageState();
}

class _SignUpOnePageState extends State<SignUpOnePage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _firstnameControl = TextEditingController();
  final _lastnameControl = TextEditingController();

  String _firstName = '';
  String _lastName = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      backgroundColor: Config().text4Color,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Enter Your Name
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'enter_name'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 40),
          // Email Or Phone number
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'first_name'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            controller: _firstnameControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                _firstName = value;
              });
            },
          ),
          const SizedBox(height: 16),
          // Password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'last_name'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            controller: _lastnameControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              return null;
            },
            onChanged: (value) {
              setState(() {
                _lastName = value;
              });
            },
          ),
          const SizedBox(height: 75),
          // Sign In button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              nextScreen(
                  context,
                  SignUpTwoPage(
                    method: widget.method,
                    firstName: _firstName,
                    lastName: _lastName,
                  ));
            },
          ),
        ],
      ),
    );
  }
}
