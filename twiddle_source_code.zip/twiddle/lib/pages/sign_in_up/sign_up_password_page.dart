import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_complete_page.dart';
import 'package:twiddle/pages/sign_in_up/verify_page.dart';
import 'package:twiddle/utils/snacbar.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';
import '../../widgets/elevated_button_widget.dart';

class SignUpPasswordPage extends StatefulWidget {
  SignUpPasswordPage({super.key, required this.method, this.email, this.phone});

  final int? method;
  String? email;
  String? phone;

  @override
  State<SignUpPasswordPage> createState() => _SignUpPasswordPageState();
}

class _SignUpPasswordPageState extends State<SignUpPasswordPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final _pwControl = TextEditingController();
  final _pwConfirmControl = TextEditingController();

  String pw1 = '';
  String pw2 = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Enter Your Name
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'setup_password'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 40),
          // Email Or Phone number
          TextFormField(
            decoration: InputDecoration(
              // enabledBorder: ,
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              if (value.length < 8) {
                return "Your password must be at least 8 characters long";
              }
              return null;
            },
            onChanged: (value) {
              setState(() {
                pw1 = value;
              });
            },
          ),
          const SizedBox(height: 16),
          // Password
          TextFormField(
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(color: Config().primary10Color)),
              fillColor: Config().primary10Color,
              filled: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              hintText: 'confirm_password'.tr(),
              hintStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            obscureText: true,
            controller: _pwConfirmControl,
            validator: (String? value) {
              if (value!.length == 0) return "This field can't be empty";
              if (value.length < 8) {
                return "Your password must be at least 8 characters long";
              }
              if (pw1 != value) {
                return "The password confirmation does not match";
              }
              return null;
            },
            onChanged: (value) {
              setState(() {
                pw2 = value;
              });
            },
          ),
          const SizedBox(height: 100),
          // Sign In button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                if (pw1 != pw2) {
                  openSnacbar(
                      context, 'The password confirmation does not match');
                  return;
                }

                if (widget.method == 0) {
                  nextScreen(
                      context,
                      VerifyPage(
                        method: widget.method,
                        email: widget.email,
                        password: pw1,
                      ));
                } else {
                  nextScreen(
                      context,
                      VerifyPage(
                        method: widget.method,
                        phone: widget.phone,
                        password: pw1,
                      ));
                }
              }
            },
          ),
        ],
      ),
    );
  }
}
