import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_complete_page.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_password_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../widgets/elevated_button_widget.dart';

class SignUpPhotoPage extends StatefulWidget {
  SignUpPhotoPage({
    super.key,
    required this.method,
    required this.firstName,
    required this.lastName,
    required this.birthDate,
    required this.gender,
    this.phoneNumber,
  });

  final int? method;
  final String? firstName;
  final String? lastName;
  final String? birthDate;
  final String? gender;
  String? phoneNumber;

  @override
  State<SignUpPhotoPage> createState() => _SignUpPhotoPageState();
}

class _SignUpPhotoPageState extends State<SignUpPhotoPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  File? imageFile;
  String? fileName;
  String? _imageUrl;

  bool _isProcess = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: Container(
          height: height,
          padding: EdgeInsets.only(top: height / 10),
          child: Column(
            children: [
              Image(
                  image: AssetImage(Config().splashIcon),
                  width: 190,
                  height: 190),
              Spacer(),
              // method == 0 ? _signInWidget() : _signUpBody(),
              _content(),
            ],
          ),
        ),
      ),
    );
  }

  _content() {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Date of birth
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              'set_profile_photo'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 33),
          // Avatar
          CircleAvatar(
            radius: 75,
            backgroundColor: Config().primary10Color,
            child: Container(
              height: 150,
              width: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                    image: (imageFile == null
                        ? CachedNetworkImageProvider(
                            Config().defaultUserImageUrl)
                        : FileImage(imageFile!)) as ImageProvider<Object>,
                    fit: BoxFit.cover),
              ),
            ),
          ),
          const SizedBox(height: 23),
          // Select Photo
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 50),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () {
                    pickImage(true);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    color: Config().primary10Color,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: Text('take_photo'.tr(), 
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w400)),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    pickImage(false);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    color: Config().primary10Color,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                    child: Text('gallery'.tr(),
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w400)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 65),
          // Sign In button
          ElevatedButton(
            onPressed: () {
              if (imageFile == null) {
                openSnacbar(context, 'Please select photo');
                return;
              }
              processUser();
            },
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
              minimumSize: const Size.fromHeight(50), // NEW
            ),
            child: _isProcess
                ? CircularProgressIndicator()
                : Text(
                    'continue'.tr(),
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
          ),
        ],
      ),
    );
  }

  Future pickImage(bool camera) async {
    XFile? image;
    if (camera) {
      image = await ImagePicker().pickImage(source: ImageSource.camera);
    } else {
      image = await ImagePicker().pickImage(source: ImageSource.gallery);
    }

    if (image != null) {
      setState(() {
        imageFile = File(image!.path);
        fileName = (imageFile!.path);
      });
    } else {
      print('No image selected!');
    }
  }

  Future uploadPicture() async {
    try {
      final SignInBloc sb = context.read<SignInBloc>();
      Reference storageReference =
          FirebaseStorage.instance.ref().child('Profile Pictures/${sb.uid}');
      UploadTask uploadTask = storageReference.putFile(imageFile!);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        _imageUrl = url.toString();
      });
    } catch (e) {
      openSnacbar(context, e.toString());
      setState(() {
        _isProcess = true;
      });
    }
  }

  processUser() async {
    final sb = context.read<SignInBloc>();
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        setState(() {
          _isProcess = true;
        });
        print('===== phone number is ${widget.phoneNumber} =====');
        await uploadPicture().then((value) {
          var name = '${widget.firstName!} ${widget.lastName!}';
          sb.setUserData(name, widget.birthDate, widget.gender, _imageUrl);
          sb.getTimestamp().then(
                (value) => sb
                    .saveToFirebase()
                    .then((value) => sb.increaseUserCount())
                    .then(
                      (value) => sb.guestSignout().then(
                            (value) => sb.saveDataToSP().then(
                                  (value) => sb.setSignIn().then(
                                    (value) {
                                      setState(() {
                                        _isProcess = false;
                                      });
                                      //
                                      _after();
                                    },
                                  ),
                                ),
                          ),
                    ),
              );
        });
      }
    });
  }

  _after() {
    nextScreen(context, SignUpComplete());
  }
}
