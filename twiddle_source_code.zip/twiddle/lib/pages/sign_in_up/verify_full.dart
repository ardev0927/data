import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/widgets/app_button.dart';

import '../../blocs/user_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';

class VerifyFull extends StatefulWidget {
  VerifyFull(
      {super.key,
      required this.method,
      this.isSignUp = true,
      required this.emailPhone,
      required this.password,
      required this.emailVerified,
      required this.phoneVerified});

  final bool? isSignUp;
  final int? method;
  final String? emailPhone;
  final String? password;
  Function(bool value)? emailVerified;
  Function(bool value, bool isSignUp)? phoneVerified;

  @override
  State<VerifyFull> createState() => _VerifyFullState();
}

class _VerifyFullState extends State<VerifyFull> {
  final _pinputController = TextEditingController();
  final _pinputFocusNode = FocusNode();

  String _verificationId = '';

  int _time = 120;

  bool _otpVisibility = false;
  bool _isEmailVerified = false;
  bool _isPhoneVerified = false;
  bool _codeSent = false;

  Timer? _timer;
  int? _reduceSecond;

  @override
  void initState() {
    Future.delayed(const Duration(seconds: 0)).then((value) {
      final sb = context.read<SignInBloc>();
      if (widget.method == 0) {
        handleVerifyEmail(sb);
      } else {
        handleVerifyPhoneNumber();
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final sb = context.read<SignInBloc>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        // Verify your email or phone
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Text(
            widget.method == 0
                ? 'verify_email_account'.tr()
                : 'verify_phone_number'.tr(),
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 50),
        widget.method == 0
            ? _verifyEmailBody()
            : _otpVisibility
                ? _pinputBody()
                : CupertinoActivityIndicator(),
        const SizedBox(height: 23),
        // Time remaining
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('time_remaining'.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().primarySilverColor)),
            Text(': ${_reduceSecond ?? 120}s',
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().primarySilverColor)),
          ],
        ),
        const SizedBox(height: 150),
        // Resend
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('didnt_receive_code'.tr(),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Config().primarySilverColor)),
            const SizedBox(width: 5),
            AppButton(
              widget.method == 0 ? 'resend_email'.tr() : 'resend_sms'.tr(),
              type: ButtonType.text,
              onPressed: () {
                if (widget.method == 0) {
                  if (_timer != null) {
                    _timer!.cancel();
                    _reduceSecond = _time;
                    handleVerifyEmail(sb);
                  }
                } else {
                  if (_timer != null) {
                    _timer!.cancel();
                    _reduceSecond = _time;
                    handleVerifyPhoneNumber();
                  }
                }
              },
            ),
            // Text(widget.method == 0 ? 'resend_email'.tr() : 'resend_sms'.tr(),
            //     style: TextStyle(
            //         fontSize: 14,
            //         fontWeight: FontWeight.w400,
            //         color: Colors.black)),
          ],
        ),
        const SizedBox(height: 50),
        // Continue button
        // elevatedButtonWidget(
        //   name: 'continue',
        //   onPressed: () {
        //     if (widget.method == 0) {
        //       // Email
        //       if (_isEmailVerified) {
        //         nextScreen(context, SignUpOnePage(method: widget.method));
        //       }
        //     } else {
        //       // Phone
        //       if (_otpVisibility) {
        //         verifyOTP();
        //       }
        //     }
        //   },
        // ),
      ],
    );
  }

  _verifyEmailBody() {
    return _isEmailVerified == false
        ? Container()
        : Text(
            _isEmailVerified == false
                ? 'verification_email_sent'.tr()
                : 'email_verified'.tr(),
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
            textAlign: TextAlign.center,
          );
  }

  _pinputBody() {
    const borderColor = Color.fromRGBO(114, 178, 238, 1);
    const errorColor = Color.fromRGBO(255, 234, 238, 1);

    final defaultPinTheme = PinTheme(
      width: 40,
      height: 40,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      textStyle: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w400,
      ),
      decoration: BoxDecoration(
        color: Config().text4Color,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Colors.transparent),
      ),
    );

    return SizedBox(
      height: 50,
      child: Pinput(
        length: 6,
        controller: _pinputController,
        focusNode: _pinputFocusNode,
        defaultPinTheme: defaultPinTheme,
        onCompleted: (pin) async {
          // setState(() => showError = pin != '5555');
          print('===== PIN is $pin =====');
          verifyOtp();
        },
        focusedPinTheme: defaultPinTheme.copyWith(
          height: 50,
          width: 50,
          decoration: defaultPinTheme.decoration!.copyWith(
            border: Border.all(color: borderColor),
          ),
        ),
        errorPinTheme: defaultPinTheme.copyWith(
          decoration: BoxDecoration(
            color: errorColor,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
      ),
    );
  }

  checkEmailVerified(SignInBloc sb) {
    _isEmailVerified = sb.checkEmailVerified();

    // if (_isEmailVerified) {
    //   _timer?.cancel();
    // }
  }

  handleVerifyEmail(SignInBloc sb) {
    sb.sendVerificationEmail();
    _reduceSecond = _time;

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        checkEmailVerified(sb);

        if (!_isEmailVerified) {
          //
          if (_reduceSecond! < 0) {
            _timer!.cancel();

            sb.deleteUser();

            widget.emailVerified!(_isEmailVerified);
          } else {
            setState(() {
              _reduceSecond = _reduceSecond! - 1;
            });
          }
        } else {
          _timer!.cancel();
          firstNotificationCount(sb.uid!);
          widget.emailVerified!(_isEmailVerified);
        }
        //
      },
    );
  }

  verifyOtp() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);

    PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: _verificationId, smsCode: _pinputController.text);

    await sb
        .signInwithPhoneNumber(credential, widget.emailPhone!)
        .then((value) {
      print("===== You are logged in successfully ======");

      _isPhoneVerified = true;
    });
  }

  /// Handle verify phone number
  handleVerifyPhoneNumber() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        await sb.verifyPhoneNumber(
          widget.emailPhone,
          timeout: 120,
          codeSent: (verificationId, visibility) {
            setState(() {
              _codeSent = true;
              _verificationId = verificationId;
              _otpVisibility = visibility;
            });

            handlePhone(sb);
          },
          codeAutoRetrievalTimeout: (verificationId) {},
        );
      }
    });
  }

  handlePhone(SignInBloc sb) {
    _reduceSecond = _time;

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        if (!_isPhoneVerified) {
          //
          if (_reduceSecond! < 0) {
            _timer!.cancel();

            widget.phoneVerified!(_isPhoneVerified, widget.isSignUp!);
          } else {
            setState(() {
              _reduceSecond = _reduceSecond! - 1;
            });
          }
        } else {
          _timer!.cancel();
          if (widget.isSignUp == true) {
            firstNotificationCount(sb.uid!);
            widget.phoneVerified!(_isPhoneVerified, widget.isSignUp!);
          } else {
            signInPhone();
          }
        }
        //
      },
    );
  }

  signInPhone() {
    var sb = context.read<SignInBloc>();
    sb.getUserDatafromFirebase(sb.uid).then((value) {
      if (sb.hasError == true) {
        firstNotificationCount(sb.uid!);
        widget.phoneVerified!(_isPhoneVerified, true);
      } else {
        sb.guestSignout().then((value) =>
            sb.saveDataToSP().then((value) => sb.setSignIn().then((value) {
                  // setState(() {
                  //   signInComplete = true;
                  // });

                  ///
                  setUserState(sb, 'Online');

                  ///
                  widget.phoneVerified!(_isPhoneVerified, widget.isSignUp!);
                  // afterSignIn();
                })));
      }
    });
  }

  setUserState(SignInBloc sb, String status) {
    var ub = context.read<UserBlock>();

    ub.updateState(sb.uid!, status);
  }

  Future firstNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount});
    });
  }

  Future<int> getTotalNotificationsCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }
}
