import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_verification_code/flutter_verification_code.dart';
import 'package:pinput/pinput.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/pages/sign_in_up/sign_up_one_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/snacbar.dart';
import '../../widgets/elevated_button_widget.dart';

class VerifyPage extends StatefulWidget {
  VerifyPage(
      {super.key, required this.method, this.email, this.password, this.phone});

  final int? method;
  String? email;
  String? phone;
  String? password;

  @override
  State<VerifyPage> createState() => _VerifyPageState();
}

class _VerifyPageState extends State<VerifyPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Timer? totalTimer, remainTimer, verifyTimer;
  final controller = TextEditingController();
  final focusNode = FocusNode();
  bool showError = false;
  bool _isEmailVerified = false;
  bool _isSentEmail = false;
  bool _isLoading = true;
  bool _otpVisibility = true;

  int timeLength = 60;
  String remainSec = '60';
  String _verificationCode = '';

  @override
  void initState() {
    if (widget.method == 0) {
      handleVerifyEmail();
    } else {
      handleVerifyPhoneNumber();
    }

    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    focusNode.dispose();
    remainTimer?.cancel();
    verifyTimer?.cancel();
    totalTimer?.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // key: _scaffoldKey,
      body: _body(),
    );
  }

  _body() {
    var height = MediaQuery.of(context).size.height;
    return Form(
      key: _formKey,
      child: SingleChildScrollView(
        child: _isLoading
            ? Container(
                height: height,
                child: Center(child: CircularProgressIndicator()))
            : Container(
                height: height,
                padding: EdgeInsets.only(top: height / 10),
                child: Column(
                  children: [
                    Image(
                        image: AssetImage(Config().splashIcon),
                        width: 190,
                        height: 190),
                    Spacer(),
                    _verifyBody(),
                  ],
                ),
              ),
      ),
    );
  }

  _verifyBody() {
    const borderColor = Color.fromRGBO(114, 178, 238, 1);
    const errorColor = Color.fromRGBO(255, 234, 238, 1);
    final defaultPinTheme = PinTheme(
      width: 40,
      height: 40,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      textStyle: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w400,
      ),
      decoration: BoxDecoration(
        color: Config().secondary21Color,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: Colors.transparent),
      ),
    );
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
      decoration: BoxDecoration(
        color: Config().secondary20Color,
        borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Verify your email or phone
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              widget.method == 0
                  ? 'verify_email_account'.tr()
                  : 'verify_phone_number'.tr(),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 50),
          widget.method == 0
              ? _verifyEmailBody()
              : SizedBox(
                  height: 50,
                  child: Pinput(
                    length: 6,
                    controller: controller,
                    focusNode: focusNode,
                    defaultPinTheme: defaultPinTheme,
                    onCompleted: (pin) async {
                      // setState(() => showError = pin != '5555');
                      print('===== PIN is $pin =====');
                    },
                    focusedPinTheme: defaultPinTheme.copyWith(
                      height: 50,
                      width: 50,
                      decoration: defaultPinTheme.decoration!.copyWith(
                        border: Border.all(color: borderColor),
                      ),
                    ),
                    errorPinTheme: defaultPinTheme.copyWith(
                      decoration: BoxDecoration(
                        color: errorColor,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
          const SizedBox(height: 23),
          // Time remaining
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('time_remaining'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
              Text(': ${remainSec}s',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
            ],
          ),
          const SizedBox(height: 150),
          // Resend
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('didnt_receive_code'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Config().primarySilverColor)),
              const SizedBox(width: 5),
              Text(widget.method == 0 ? 'resend_email'.tr() : 'resend_sms'.tr(),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.black)),
            ],
          ),
          const SizedBox(height: 50),
          // Continue button
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              if (widget.method == 0) {
                // Email
                if (_isEmailVerified) {
                  nextScreen(context, SignUpOnePage(method: widget.method));
                }
              } else {
                // Phone
                if (_otpVisibility) {
                  verifyOTP();
                }
              }
            },
          ),
        ],
      ),
    );
  }

  _verifyEmailBody() {
    return _isSentEmail == false
        ? Container()
        : Text(
            _isEmailVerified == false
                ? 'verification_email_sent'.tr()
                : 'email_verified'.tr(),
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400),
            textAlign: TextAlign.center,
          );
  }

  // Verfication timer
  _startTimer(SignInBloc sb) {
    totalTimer = Timer.periodic(Duration(seconds: timeLength), (timer) {
      print('===============Timer End=======================');
      remainTimer?.cancel();
      if (widget.method == 0) {
        verifyTimer?.cancel();
      }
      totalTimer?.cancel();
    });
    // Future.delayed(Duration(seconds: timeLength)).then((value) {
    //   print('===============Timer End=======================');
    //   remainTimer?.cancel();
    //   verifyTimer?.cancel();
    // });
  }

  // Time discount
  _remainTime(SignInBloc sb) {
    remainTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        remainSec = (timeLength - timer.tick).toString();
        print('=========== remaining: $remainSec ============');
      });
    });
  }

  // Verify request timer
  _verifyTime(SignInBloc sb) {
    verifyTimer = Timer.periodic(Duration(seconds: 3), (timer) async {
      _isEmailVerified = await sb.checkEmailVerified();
      if (_isEmailVerified) {
        firstNotificationCount(sb.uid!);
        remainTimer?.cancel();
        verifyTimer?.cancel();
        totalTimer?.cancel();
      }
      setState(() {});
    });
  }

  Future handleVerifyEmail() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        sb.verifyEmail(widget.email, widget.password).then((_) async {
          if (sb.hasError == false) {
            // Send verification email
            sb.sendVerificationEmail();
            // Start verification timer
            _startTimer(sb);
            // Remain time
            _remainTime(sb);
            // Verify time
            _verifyTime(sb);

            setState(() {
              _isSentEmail = true;
              _isEmailVerified = sb.emailVerified;
            });
          } else {
            openSnacbar(context, sb.errorCode);
            if (sb.errorCode ==
                'The email address is already in use by another account') {
              Navigator.pop(context);
            }
          }
          setState(() {
            _isLoading = false;
          });
        });
      }
    });
  }

  handleVerifyPhoneNumber() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        await sb.getFirebaseAuth().verifyPhoneNumber(
              phoneNumber: widget.phone!,
              verificationCompleted: (phoneAuthCredential) async {
                print('===== Verification Completed ======');
                // setState(() {
                //   _isLoading = false;
                // });

                // await sb
                //     .getFirebaseAuth()
                //     .signInWithCredential(phoneAuthCredential)
                //     .then((value) {
                //   print('You are logged in successfully');
                //   if (value.user != null) {
                //     // pr
                //   }
                // });
              },
              verificationFailed: (error) {},
              codeSent: (verificationId, forceResendingToken) {
                print('===== Verification Id is $verificationId =====');
                _isLoading = false;
                _otpVisibility = true;
                setState(() {
                  _verificationCode = verificationId;
                });
                setState(() {});

                // Start verification timer
                _startTimer(sb);
                // Remain time
                _remainTime(sb);
                // Verify time
                // _verifyTime(sb);
              },
              codeAutoRetrievalTimeout: (verificationId) {
                setState(() {
                  _verificationCode = verificationId;
                });
              },
              timeout: Duration(seconds: 60),
            );
      }
    });
  }

  void verifyOTP() async {
    final SignInBloc sb = Provider.of<SignInBloc>(context, listen: false);
    PhoneAuthCredential credential = PhoneAuthProvider.credential(
        verificationId: _verificationCode, smsCode: controller.text);

    await sb.signInwithPhoneNumber(credential, widget.phone!).then((value) {
      print("===== You are logged in successfully ======");

      remainTimer?.cancel();
      verifyTimer?.cancel();
      totalTimer?.cancel();

      firstNotificationCount(sb.uid!);

      nextScreen(context, SignUpOnePage(method: widget.method));
    });
  }

  Future firstNotificationCount(String uid) async {
    await getTotalNotificationsCount(uid).then((int documentCount) async {
      await FirebaseFirestore.instance
          .collection('notifications')
          .doc(uid)
          .collection('count')
          .doc('notification_count')
          .update({'count': documentCount});
    });
  }

  Future<int> getTotalNotificationsCount(String uid) async {
    const String fieldName = 'count';
    final DocumentReference ref = FirebaseFirestore.instance
        .collection('notifications')
        .doc(uid)
        .collection('count')
        .doc('notification_count');
    DocumentSnapshot snap = await ref.get();
    if (snap.exists == true) {
      int itemCount = snap[fieldName] ?? 0;
      return itemCount;
    } else {
      await ref.set({fieldName: 0});
      return 0;
    }
  }
}
