import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/main_page.dart';
import 'package:twiddle/pages/walkthrough/select_language_page.dart';

import '../blocs/sign_in_bloc.dart';
import '../utils/next_screen.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  afterSplash() {
    final SignInBloc sb = context.read<SignInBloc>();
    Future.delayed(Duration(milliseconds: 1500)).then((value) {
      sb.isSignedIn == true || sb.guestUser == true
          ? gotoHomePage()
          : gotoSignInPage();
    });
  }

  gotoHomePage() {
    final SignInBloc sb = context.read<SignInBloc>();
    if (sb.isSignedIn == true) {
      sb.getDataFromSp();
    }
    nextScreenReplace(context, MainPage());
  }

  gotoSignInPage() {
    nextScreenReplace(context, SelectLanguagePage());
  }

  @override
  void initState() {
    afterSplash();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: Center(
        child: Image(
          image: AssetImage(Config().splashIcon),
          fit: BoxFit.contain,
          width: MediaQuery.of(context).size.width * 3 / 4,
        ),
      ),
    );
  }
}
