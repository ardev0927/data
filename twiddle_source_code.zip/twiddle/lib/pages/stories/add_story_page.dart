import 'dart:ui' as ui;
import 'dart:io';
import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/stories_bloc.dart';
import 'package:twiddle/blocs/story_details_bloc.dart';
import 'package:uuid/uuid.dart';

import '../../blocs/sign_in_bloc.dart';
import '../../config/config.dart';
import '../../services/app_service.dart';
import '../../utils/format_time.dart';
import '../../utils/snacbar.dart';
import '../../utils/toast.dart';

class AddStoryPage extends StatefulWidget {
  const AddStoryPage({
    super.key,
    required this.storyFile,
    required this.storyType,
    this.thumbnail,
  });

  final File? storyFile;
  final String? storyType;
  final Uint8List? thumbnail;

  @override
  State<AddStoryPage> createState() => _AddStoryPageState();
}

class _AddStoryPageState extends State<AddStoryPage> {
  var captionController = TextEditingController();
  var isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Config().text100Color,
            )),
        title: Text(
          'add_story'.tr(),
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: _body(),
    );
  }

  _body() {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    var realHeight =
        AppBar().preferredSize.height + MediaQuery.of(context).padding.top;
    return Container(
      width: width,
      height: height - realHeight,
      child: Stack(
        children: [
          Column(
            children: [
              Expanded(
                  child: widget.storyType == 'Image'
                      ? Image.file(widget.storyFile!)
                      : Image.memory(widget.thumbnail!)),
              _bottom(),
            ],
          ),
          isLoading ? Center(child: CircularProgressIndicator()) : Container(),
        ],
      ),
    );
  }

  _bottom() {
    final sb = context.read<SignInBloc>();

    return Container(
      width: MediaQuery.of(context).size.width,
      height: 60,
      padding: const EdgeInsets.only(left: 16),
      color: Config().primary10Color,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(sb.imageUrl!),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextFormField(
              controller: captionController,
              decoration: InputDecoration(
                hintText: 'add_caption'.tr(),
                hintStyle: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: Config().textParagraphColor),
              ),
              validator: (value) {
                if (value!.isEmpty) {
                  return "This field can't be empty";
                }
                return null;
              },
              onChanged: (value) {},
            ),
          ),
          IconButton(
              onPressed: () async {
                setState(() {
                  isLoading = true;
                });
                // media url
                var downloadUrl = await uploadStoryFile(widget.storyFile!);

                // thumbnail url
                var thumbnailUrl = '';
                if (widget.storyType == 'Video') {
                  var file = await bytesToImage(widget.thumbnail!);
                  thumbnailUrl = await uploadStoryFile(file!);
                }
                if (downloadUrl.isNotEmpty) {
                  _addStory(downloadUrl, thumbnailUrl);
                }
              },
              icon: Icon(Icons.send, color: Config().primary30Color)),
        ],
      ),
    );
  }

  Future<File?> bytesToImage(Uint8List imgBytes) async {
    final tempDir = await getTemporaryDirectory();
    File file = await File('${tempDir.path}/image.png').create();
    file.writeAsBytesSync(imgBytes);
    return file;
  }

  Future<String> uploadStoryFile(File file) async {
    var downloadUrl = '';
    var uuid = Uuid();
    try {
      final SignInBloc sb = context.read<SignInBloc>();

      Reference storageReference = FirebaseStorage.instance
          .ref()
          .child('Story files/${sb.uid}/${uuid.v1()}');
      UploadTask uploadTask = storageReference.putFile(file);

      await uploadTask.whenComplete(() async {
        var url = await storageReference.getDownloadURL();
        downloadUrl = url;
        print('===== uploaded story file =====');
      });
    } catch (e) {
      print(e.toString());
      // openSnacbar(context, e.toString());
    }
    return downloadUrl;
  }

  _addStory(String mediaUrl, String thumbnail) async {
    final SignInBloc sb = context.read<SignInBloc>();
    final StoryDetialBloc sdb =
        Provider.of<StoryDetialBloc>(context, listen: false);
    final StoriesBloc ssb = Provider.of<StoriesBloc>(context, listen: false);

    DateTime now = DateTime.now();
    DateTime utc = now.toUtc();
    var timestamp = formatISOTime(utc);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        sdb
            .addStory(
          sb.uid!,
          sb.name!,
          sb.imageUrl!,
          widget.storyType!,
          mediaUrl,
          thumbnail,
          captionController.text,
          timestamp,
        )
            .then((value) async {
          setState(() {
            isLoading = false;
          });

          if (sdb.hasError == false) {
            print('===== Added story successfully =====');
            ssb.addUserStory(
                sb.uid!,
                sb.name!,
                sb.imageUrl!,
                thumbnail.isNotEmpty ? thumbnail : sdb.userStory!.media!,
                timestamp);
            Navigator.pop(context);
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}
