import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:story_view/controller/story_controller.dart';
import 'package:story_view/story_view.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/story_details_bloc.dart';
import 'package:twiddle/models/story.dart';
import 'package:twiddle/utils/convert_time_ago.dart';
import 'package:twiddle/utils/toast.dart';

import '../../services/app_service.dart';
import '../../utils/snacbar.dart';

class StoriesViewpage extends StatefulWidget {
  const StoriesViewpage(
      {super.key,
      this.uid,
      required this.username,
      required this.useravatar,
      required this.timestamp});
  final String? username;
  final String? useravatar;
  final String? uid;
  final String? timestamp;

  @override
  State<StoriesViewpage> createState() => _StoriesViewpageState();
}

class _StoriesViewpageState extends State<StoriesViewpage> {
  final String _orderBy = 'timestamp';
  List<Story> _stories = [];
  List<StoryItem> _storyItems = [];
  bool isLoading = false;
  final _storyController = StoryController();
  String time = '';

  @override
  void initState() {
    time = widget.timestamp!;
    handleGetStories();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _appbar(),
      body: _body(),
    );
  }

  _appbar() {
    return AppBar(
      backgroundColor: Colors.black,
      leadingWidth: 30,
      leading: IconButton(
        onPressed: () {
          Navigator.pop(context);
        },
        icon: Icon(
          Icons.arrow_back,
          color: Colors.white,
        ),
      ),
      title: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          CircleAvatar(
            radius: 24,
            backgroundColor: Colors.grey[300],
            backgroundImage: CachedNetworkImageProvider(widget.useravatar!),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username!,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white),
                ),
                Text(
                  convertToAgo(time),
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        // IconButton(
        //   onPressed: () {},
        //   icon: Icon(Icons.delete_outline, color: Colors.white),
        //   iconSize: 20,
        // ),
        // IconButton(onPressed: () {}, icon: Icon(Icons.more_vert_outlined)),
      ],
    );
  }

  _body() {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                _storyItems.isEmpty
                    ? Container()
                    : StoryView(
                        storyItems: _storyItems,
                        controller: _storyController,
                        onComplete: () => Navigator.pop(context),
                        onStoryShow: (value) {
                          // var idx = _storyItems.indexOf(value);
                          // setState(() {
                          //   time = _stories[idx].timestamp!;
                          // });
                        },
                      ),
              ],
            ),
    );
  }

  handleGetStories() async {
    List<Story> _deleteStories = [];
    final StoryDetialBloc sdb =
        Provider.of<StoryDetialBloc>(context, listen: false);

    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        setState(() {
          isLoading = true;
        });
        await sdb.getStoriesDetail(widget.uid, _orderBy).then((value) {
          if (sdb.hasError == false) {
            // Real stories
            _stories.addAll(sdb.data
                .where((element) => twoDaysAgo(element.timestamp!) == false));
            // To delete stories
            _deleteStories.addAll(
                sdb.data.where((element) => twoDaysAgo(element.timestamp!)));
            // _stories.addAll(sdb.data);
            _stories.forEach((element) {
              if (element.storyType == 'Image') {
                _storyItems.add(StoryItem.pageImage(
                    url: element.media!,
                    caption: element.caption,
                    controller: _storyController));
              } else if (element.storyType == 'Video') {
                _storyItems.add(StoryItem.pageVideo(element.media!,
                    caption: element.caption, controller: _storyController));
              }
            });
            if (_deleteStories.isNotEmpty) {
              _deleteStories.forEach((element) {
                handleDeleteStory(sdb, element);
              });
            }
          } else {
            openToast('Something went wrong');
          }
          setState(() {
            isLoading = false;
          });
        });
      }
    });
  }

  handleDeleteStory(StoryDetialBloc sdb, Story story) async {
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        await sdb.deleteUserStory(story.uid!, story.id!).then((value) {
          if (sdb.hasError == false) {
          } else {
            openToast('Something went wrong');
          }
        });
      }
    });
  }
}
