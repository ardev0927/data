import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/tag_friends_bloc.dart';
import 'package:twiddle/cards/friends_card4.dart';
import 'package:twiddle/pages/profile/user_profile_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../cards/friends_card3.dart';
import '../../config/config.dart';
import '../../utils/empty.dart';
import '../../utils/loading_cards.dart';

class TagFriendsPage extends StatefulWidget {
  TagFriendsPage({super.key, required this.tags});

  List<String>? tags;

  @override
  State<TagFriendsPage> createState() => _TagFriendsPageState();
}

class _TagFriendsPageState extends State<TagFriendsPage> {
  List<String> tags = [];
  @override
  void initState() {
    tags.addAll(widget.tags!);

    final tfb = context.read<TagFriendsBloc>();
    tfb.getUsers(tags, mounted);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final ub = context.watch<TagFriendsBloc>();

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back),
        ),
        title: Text(
          'tab_prople'.tr(),
          style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
        ),
      ),
      body: ub.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.40,
                ),
                EmptyPage(
                    icon: Icons.person_off_outlined,
                    message: 'no_friends'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              padding: const EdgeInsets.only(top: 8),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: ub.users.isNotEmpty ? ub.users.length : 5,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(height: 4),
              shrinkWrap: true,
              itemBuilder: (_, int index) {
                if (index < ub.users.length) {
                  return FriendsCard4(
                    d: ub.users[index],
                    heroTag: 'friendcard4$index',
                    onTapped: () {
                      nextScreen(
                          context, UserProfilePage(uid: ub.users[index].uid));
                    },
                  );
                }
                return Opacity(
                  opacity: ub.isLoading ? 1.0 : 0.0,
                  child: ub.lastVisible == null
                      ? const LoadingCard(height: 50)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }
}
