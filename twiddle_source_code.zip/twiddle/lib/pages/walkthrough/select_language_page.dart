import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:twiddle/config/config.dart';
import 'package:twiddle/pages/walkthrough/walkthrough_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../../widgets/elevated_button_widget.dart';

class SelectLanguagePage extends StatefulWidget {
  const SelectLanguagePage({super.key});

  @override
  State<SelectLanguagePage> createState() => _SelectLanguagePageState();
}

class _SelectLanguagePageState extends State<SelectLanguagePage> {
  int languageIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(),
    );
  }

  _body() {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return Container(
      width: width,
      padding:
          EdgeInsets.only(left: 20, right: 20, bottom: 40, top: height / 6),
      child: Column(
        children: [
          Text(
            'select_your_language',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700),
          ).tr(),
          const SizedBox(height: 12),
          Text(
            'select_language_content',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            textAlign: TextAlign.center,
          ).tr(),
          const SizedBox(height: 50),
          GestureDetector(
            onTap: () {
              if (languageIndex == 0) return;
              setState(() {
                languageIndex = 0;
              });
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: languageIndex == 0
                    ? Config().primary4Color
                    : Theme.of(context).scaffoldBackgroundColor,
                shape: BoxShape.rectangle,
                border: Border.all(color: Config().primary4Color, width: 1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Image(image: AssetImage('assets/images/us.png'), width: 32),
                  const SizedBox(width: 16),
                  Text('english'.tr(),
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
                ],
              ),
            ),
          ), // _languageItem('assets/images/us.png', 'english'),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () {
              if (languageIndex == 1) return;
              setState(() {
                languageIndex = 1;
              });
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: languageIndex == 1
                    ? Config().primary4Color
                    : Theme.of(context).scaffoldBackgroundColor,
                shape: BoxShape.rectangle,
                border: Border.all(color: Config().primary4Color, width: 1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Image(image: AssetImage('assets/images/es.png'), width: 32),
                  const SizedBox(width: 16),
                  Text('spanish'.tr(),
                      style:
                          TextStyle(fontSize: 14, fontWeight: FontWeight.w400)),
                ],
              ),
            ),
          ),
          // _languageItem('assets/images/es.png', 'spanish'),
          const Spacer(),
          elevatedButtonWidget(
            name: 'continue',
            onPressed: () {
              if (languageIndex == 0) {
                context.setLocale(Locale('en'));
              } else {
                context.setLocale(Locale('es'));
              }
              nextScreen(context, WalkthroughPage());
            },
          ),
        ],
      ),
    );
  }

  _languageItem(String flag, String name) {
    return GestureDetector(
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: languageIndex == -1
              ? Theme.of(context).scaffoldBackgroundColor
              : Config().primary4Color,
          shape: BoxShape.rectangle,
          border: Border.all(color: Config().primary4Color, width: 1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Image(image: AssetImage(flag), width: 32),
            const SizedBox(width: 16),
            Text(name,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400))
                .tr(),
          ],
        ),
      ),
    );
  }
}
