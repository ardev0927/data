import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:twiddle/pages/sign_in_up/account_page.dart';

import '../../config/config.dart';
import '../../utils/next_screen.dart';
import '../../widgets/elevated_button_widget.dart';
import '../sign_in_up/sign_in_up_page.dart';

class WalkthroughPage extends StatefulWidget {
  const WalkthroughPage({super.key});

  @override
  State<WalkthroughPage> createState() => _WalkthroughPageState();
}

class _WalkthroughPageState extends State<WalkthroughPage> {
  bool permissionGranted = false;
  final PageController _pageController = PageController();
  int pageIndex = 0;
  int pageLength = 3;
  bool skip = true;

  Future _getStoragePermission() async {
    if (await Permission.storage.request().isGranted) {
      setState(() {
        permissionGranted = true;
      });
    } else if (await Permission.storage.request().isPermanentlyDenied) {
      await openAppSettings();
    } else if (await Permission.storage.request().isDenied) {
      setState(() {
        permissionGranted = false;
      });
    }
  }

  @override
  void initState() {
    _getStoragePermission();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Container(
        width: width,
        height: height,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          children: [
            Row(
              children: [
                const Spacer(),
                skip == false
                    ? SizedBox(height: 40)
                    : TextButton(
                        onPressed: () {
                          // nextScreenCloseOthers(context, SignInUpPage());
                          nextScreenCloseOthers(context, AccountPage());
                        },
                        child: Text(
                          'skip'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ),
                      ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: PageView(
                controller: _pageController,
                allowImplicitScrolling: false,
                onPageChanged: (value) {
                  if (value == 2) {
                    setState(() {
                      skip = false;
                      pageIndex = value;
                    });
                  } else {
                    setState(() {
                      skip = true;
                      pageIndex = value;
                    });
                  }
                },
                children: [
                  WalkthroughFirst(),
                  WalkthroughSecond(),
                  WalkthroughThird(),
                ],
              ),
            ),
            indicatorWidget(),
            const SizedBox(height: 32),
            elevatedButtonWidget(
              name: 'continue',
              onPressed: () {
                if (pageIndex == 2) {
                  // nextScreenCloseOthers(context, SignInUpPage());
                  nextScreenCloseOthers(context, AccountPage());
                } else {
                  pageIndex += 1;
                  changePage(pageIndex);
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  indicatorWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = 0; i < pageLength; i++)
          if (i == pageIndex) ...[circleBar(true)] else circleBar(false),
      ],
    );
  }

  circleBar(bool isActive) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      margin: const EdgeInsets.symmetric(horizontal: 4),
      height: 6,
      width: isActive ? 24 : 8,
      decoration: BoxDecoration(
        color: isActive ? Config().primary30Color : Config().primary10Color,
        borderRadius: const BorderRadius.all(Radius.circular(2)),
      ),
    );
  }

  void changePage(int index) {
    // setState(() {
    //   pageIndex = index;
    // });
    print('====== currentIndex $pageIndex');
    _pageController.animateToPage(index,
        curve: Curves.easeIn, duration: Duration(milliseconds: 250));
  }
}

class WalkthroughFirst extends StatelessWidget {
  const WalkthroughFirst({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'walkthrough_title1',
          style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          textAlign: TextAlign.center,
        ).tr(),
        const SizedBox(height: 25),
        Text(
          'walkthrough_desc1',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Config().text90Color),
          textAlign: TextAlign.center,
        ).tr(),
        const Spacer(),
        Image(
          image: AssetImage('assets/images/intro_1.png'),
        ),
        const Spacer(),
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   children: [
        //     Container(
        //       width: 24,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary30Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //   ],
        // ),
      ],
    );
  }
}

class WalkthroughSecond extends StatelessWidget {
  const WalkthroughSecond({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'walkthrough_title2',
          style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          textAlign: TextAlign.center,
        ).tr(),
        const SizedBox(height: 25),
        Text(
          'walkthrough_desc2',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Config().text90Color),
          textAlign: TextAlign.center,
        ).tr(),
        const Spacer(),
        Image(
          image: AssetImage('assets/images/intro_2.png'),
        ),
        const Spacer(),
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   children: [
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 24,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary30Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //   ],
        // ),
      ],
    );
  }
}

class WalkthroughThird extends StatelessWidget {
  const WalkthroughThird({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'walkthrough_title3',
          style: TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w700,
              color: Config().text100Color),
          textAlign: TextAlign.center,
        ).tr(),
        const SizedBox(height: 25),
        Text(
          'walkthrough_desc3',
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Config().text90Color),
          textAlign: TextAlign.center,
        ).tr(),
        const Spacer(),
        Image(
          image: AssetImage('assets/images/intro_3.png'),
        ),
        const Spacer(),
        // Row(
        //   mainAxisAlignment: MainAxisAlignment.center,
        //   children: [
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 8,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary10Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //     const SizedBox(width: 8),
        //     Container(
        //       width: 24,
        //       height: 6,
        //       decoration: BoxDecoration(
        //           color: Config().primary30Color,
        //           borderRadius: const BorderRadius.all(Radius.circular(2))),
        //     ),
        //   ],
        // ),
      ],
    );
  }
}
