import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/friends_bloc.dart';
import 'package:twiddle/blocs/my_friends_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/user_bloc.dart';
import 'package:twiddle/cards/friends_card.dart';
import 'package:twiddle/models/user.dart';
import 'package:twiddle/utils/next_screen.dart';
import 'package:twiddle/utils/toast.dart';

import '../config/config.dart';
import '../pages/profile/user_profile_page.dart';
import '../services/app_service.dart';
import '../utils/empty.dart';
import '../utils/loading_cards.dart';
import '../utils/snacbar.dart';

class FriendsTab extends StatefulWidget {
  const FriendsTab({super.key});

  @override
  State<FriendsTab> createState() => _FriendsTabState();
}

class _FriendsTabState extends State<FriendsTab> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<String> _uids = [];

  @override
  void initState() {
    final sb = context.read<SignInBloc>();
    super.initState();
    if (mounted) {
      _handleGetFriendUids(sb.uid!);
      //   context.read<MyFriendsBloc>().data.isNotEmpty
      //       ? print('data already loaded')
      //       : context.read<MyFriendsBloc>().getData(sb.uid, mounted);
    }
  }

  @override
  Widget build(BuildContext context) {
    // final fb = context.watch<MyFriendsBloc>();
    // final sb = context.read<SignInBloc>();

    return _body();
  }

  _body() {
    final sb = context.read<SignInBloc>();
    return _uids.isEmpty
        ? ListView(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.20,
              ),
              EmptyPage(
                  icon: Icons.person_off_outlined,
                  message: 'no_friends'.tr(),
                  message1: ''),
            ],
          )
        : StreamBuilder<QuerySnapshot>(
            stream: getFriends(),
            builder: (context, snapshot) {
              print('===== ${snapshot.hasData} =====');
              if (snapshot.hasData) {
                return ListView.separated(
                  // key: PageStorageKey(widget.category),
                  padding: const EdgeInsets.only(top: 8),
                  physics: AlwaysScrollableScrollPhysics(),
                  itemCount: snapshot.data!.size != 0 ? snapshot.data!.size : 5,
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                    height: 3,
                  ),
                  shrinkWrap: true,
                  itemBuilder: (_, int index) {
                    var doc = snapshot.data!.docs[index];
                    var user = WUser.fromFirestore(doc);
                    return FriendsCard(
                      d: user,
                      heroTag: 'tab1$index',
                      onPressed: () async {
                        selectDialog(context, user, sb.uid!);
                        // openPopupDialog(context, user, sb.uid!);
                      },
                      onItemTapped: () {
                        // Open profile page
                        nextScreen(context, UserProfilePage(uid: user.uid));
                      },
                    );
                  },
                );
              } else {
                return ListView(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.20,
                    ),
                    EmptyPage(
                        icon: Icons.person_off_outlined,
                        message: 'no_friends'.tr(),
                        message1: ''),
                  ],
                );
              }
            },
          );
  }

  Stream<QuerySnapshot> getFriends() {
    return firestore
        .collection('users')
        .where('uid', whereIn: _uids)
        .snapshots();
  }

  _handleGetFriendUids(String uid) async {
    final FriendsBloc fb = Provider.of<FriendsBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        var uids = await fb.getFriendsUid(uid);
        _uids.addAll(uids);
        if (!mounted) return;
        setState(() {});
      }
    });
  }

  openPopupDialog(context, WUser d, String uid, int type) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.grey[300],
                    backgroundImage: CachedNetworkImageProvider(d.avatar!),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      d.name!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Config().text90Color),
                    ),
                  ),
                  Divider(height: 2, color: Config().text8Color),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    child: Text(
                      '${type == 1 ? d.blockedUsers!.contains(uid) ? 'want_unblock_frind'.tr() : 'want_block_frind'.tr() : 'want_unfollow_friend'.tr()} ${d.name!}?',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          color: Config().text100Color),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                            primary: Config().text20Color,
                            fixedSize: Size(100, 40)),
                        child: Text(
                          'no'.tr(),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Config().text100Color),
                        ),
                      ),
                      const SizedBox(width: 30),
                      ElevatedButton(
                        onPressed: () async {
                          Navigator.pop(context);
                          final ub = context.read<UserBlock>();
                          if (type == 1) {
                            if (d.blockedUsers!.contains(uid)) {
                              await ub.unblockUser(uid, d.uid).then((value) {
                                openToast('User is unblocked successfully');
                                setState(() {});
                              });
                            } else {
                              await ub.blockUser(uid, d.uid).then((value) {
                                openToast('User is blocked successfully');
                                setState(() {});
                              });
                            }
                          } else {
                            await ub.removeFriend(uid, d.uid).then((value) {
                              if (ub.isFriend == false) {
                                // fb.data.remove(fb.data[index]);
                                setState(() {});
                              }
                            });
                          }
                        },
                        style:
                            ElevatedButton.styleFrom(fixedSize: Size(100, 40)),
                        child: Text(
                          'yes'.tr(),
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }

  selectDialog(context, WUser d, String uid) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    onTap: () {
                      Navigator.pop(context);
                      openPopupDialog(context, d, uid, 1);
                    },
                    title: Text(
                      d.blockedUsers!.contains(uid) ? 'Unblock' : 'Block',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text90Color),
                    ),
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.pop(context);
                      openPopupDialog(context, d, uid, 2);
                    },
                    title: Text(
                      'Unfollow',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}
