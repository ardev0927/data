import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/interest_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/cards/interest_card.dart';
import 'package:twiddle/pages/interest/interest_view_page.dart';
import 'package:twiddle/utils/next_screen.dart';

import '../utils/empty.dart';
import '../utils/loading_cards.dart';

class InterestsTab extends StatefulWidget {
  const InterestsTab({super.key});

  @override
  State<InterestsTab> createState() => _InterestsTabState();
}

class _InterestsTabState extends State<InterestsTab> {
  @override
  void initState() {
    super.initState();

    if (mounted) {
      context.read<InterestBloc>().data.isNotEmpty
          ? print('data already loaded')
          : context.read<InterestBloc>().getData(mounted);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ib = context.watch<InterestBloc>();
    final sb = context.read<SignInBloc>();

    return RefreshIndicator(
      onRefresh: () async {
        context.read<InterestBloc>().onRefresh(mounted);
      },
      child: ib.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.20,
                ),
                EmptyPage(
                    icon: Icons.interests_outlined,
                    message: 'you_have_no_interest'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              // key: PageStorageKey(widget.category),
              padding: const EdgeInsets.only(top: 8),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: ib.data.length != 0 ? ib.data.length + 1 : 5,
              separatorBuilder: (BuildContext context, int index) => SizedBox(
                height: 3,
              ),
              shrinkWrap: true,
              itemBuilder: (_, int index) {
                if (index < ib.data.length) {
                  return InterestCard(
                    d: ib.data[index],
                    heroTag: 'tab3$index',
                    onTap: () async {
                      var ret = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  InterestViewPage(interest: ib.data[index])));
                      if (ret) {
                        if (!ib.data[index].uids!.contains(sb.uid)) {
                          ib.data[index].uids!.add(sb.uid!);
                        }
                      } else {
                        if (ib.data[index].uids!.contains(sb.uid)) {
                          ib.data[index].uids!.remove(sb.uid!);
                        }
                      }
                      setState(() {});
                      // nextScreen(
                      //     context, InterestViewPage(interest: ib.data[index]));
                    },
                  );
                }
                return Opacity(
                  opacity: ib.isLoading ? 1.0 : 0.0,
                  child: ib.lastVisible == null
                      ? LoadingCard(height: 120)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }
}
