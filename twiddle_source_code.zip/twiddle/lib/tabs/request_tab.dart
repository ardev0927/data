import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/request_bloc.dart';
import 'package:twiddle/cards/request_card.dart';

import '../blocs/sign_in_bloc.dart';
import '../blocs/user_bloc.dart';
import '../models/user.dart';
import '../pages/profile/user_profile_page.dart';
import '../services/app_service.dart';
import '../utils/empty.dart';
import '../utils/loading_cards.dart';
import '../utils/next_screen.dart';
import '../utils/snacbar.dart';

class RequestTab extends StatefulWidget {
  const RequestTab({super.key});

  @override
  State<RequestTab> createState() => _RequestTabState();
}

class _RequestTabState extends State<RequestTab> {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  List<String> _uids = [];

  @override
  void initState() {
    super.initState();

    final sb = context.read<SignInBloc>();
    if (mounted) {
      _handleGetRequestUids(sb.uid!);
      // context.read<RequestBloc>().data.isNotEmpty
      //     ? print(
      //         'data already loaded ${context.read<RequestBloc>().data.length}')
      //     : context.read<RequestBloc>().getData(sb.uid!, mounted);
    }
  }

  @override
  Widget build(BuildContext context) {
    // final rb = context.watch<RequestBloc>();
    // final sb = context.read<SignInBloc>();
    // final ub = context.read<UserBlock>();

    return _body();

    // return RefreshIndicator(
    //   onRefresh: () async {
    //     context.read<RequestBloc>().onRefresh(sb.uid!, mounted);
    //   },
    //   child: rb.hasData == false
    //       ? ListView(
    //           children: [
    //             SizedBox(
    //               height: MediaQuery.of(context).size.height * 0.20,
    //             ),
    //             EmptyPage(
    //                 icon: Icons.interests_outlined,
    //                 message: 'you_have_no_request'.tr(),
    //                 message1: ''),
    //           ],
    //         )
    //       : ListView.separated(
    //           // key: PageStorageKey(widget.category),
    //           padding: const EdgeInsets.only(top: 8),
    //           physics: AlwaysScrollableScrollPhysics(),
    //           itemCount: rb.data.length != 0 ? rb.data.length + 1 : 5,
    //           separatorBuilder: (BuildContext context, int index) => SizedBox(
    //             height: 3,
    //           ),
    //           shrinkWrap: true,
    //           itemBuilder: (_, int index) {
    //             if (index < rb.data.length) {
    //               return RequestCard(
    //                 uid: sb.uid!,
    //                 d: rb.data[index],
    //                 heroTag: 'tab4$index',
    //                 onConfirmPressed: () {
    //                   ub
    //                       .setConfirmFriend(sb.uid!, rb.data[index].uid)
    //                       .then((value) {
    //                     // openSnacbar(context, 'You sent request friend');
    //                     if (ub.isFriend == true) {
    //                       rb.data.remove(rb.data[index]);
    //                       setState(() {});
    //                     }
    //                   });
    //                 },
    //                 onRemovePressed: () async {
    //                   final ub = context.read<UserBlock>();
    //                   await ub
    //                       .removeRequestFriend(sb.uid, rb.data[index].uid)
    //                       .then((value) {
    //                     if (ub.isFriend == false) {
    //                       rb.data.remove(rb.data[index]);
    //                       setState(() {});
    //                     }
    //                   });
    //                 },
    //               );
    //             }
    //             return Opacity(
    //               opacity: rb.isLoading ? 1.0 : 0.0,
    //               child: rb.lastVisible == null
    //                   ? LoadingCard(height: 120)
    //                   : const Center(
    //                       child: SizedBox(
    //                           width: 32.0,
    //                           height: 32.0,
    //                           child: CupertinoActivityIndicator()),
    //                     ),
    //             );
    //           },
    //         ),
    // );
  }

  _body() {
    final sb = context.read<SignInBloc>();
    final ub = context.read<UserBlock>();

    return _uids.isEmpty
        ? ListView(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.20,
              ),
              EmptyPage(
                  icon: Icons.interests_outlined,
                  message: 'you_have_no_request'.tr(),
                  message1: ''),
            ],
          )
        : StreamBuilder<QuerySnapshot>(
            stream: getRequests(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return ListView.separated(
                  padding: const EdgeInsets.only(top: 8),
                  physics: AlwaysScrollableScrollPhysics(),
                  itemCount: snapshot.data!.size != 0 ? snapshot.data!.size : 5,
                  separatorBuilder: (BuildContext context, int index) =>
                      SizedBox(
                    height: 3,
                  ),
                  shrinkWrap: true,
                  itemBuilder: (_, int index) {
                    var doc = snapshot.data!.docs[index];
                    var user = WUser.fromFirestore(doc);
                    return RequestCard(
                      uid: sb.uid!,
                      d: user,
                      heroTag: 'tab1$index',
                      onConfirmPressed: () async {
                        ub.setConfirmFriend(sb.uid!, user.uid).then((value) {
                          if (ub.isFriend == true) {
                            _handleGetRequestUids(sb.uid!);
                            setState(() {});
                          }
                        });
                      },
                      onRemovePressed: () async {
                        await ub
                            .removeRequestFriend(sb.uid, user.uid)
                            .then((value) {
                          if (ub.isFriend == false) {
                            // rb.data.remove(rb.data[index]);
                            _handleGetRequestUids(sb.uid!);
                            setState(() {});
                          }
                        });
                      },
                      onItemTapped: () {
                        // Open profile page
                        nextScreen(context, UserProfilePage(uid: user.uid));
                      },
                    );
                  },
                );
              } else {
                return ListView(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.20,
                    ),
                    EmptyPage(
                        icon: Icons.interests_outlined,
                        message: 'you_have_no_request'.tr(),
                        message1: ''),
                  ],
                );
              }
            },
          );
  }

  Stream<QuerySnapshot> getRequests() {
    return firestore
        .collection('users')
        .where('uid', whereIn: _uids)
        .snapshots();
  }

  _handleGetRequestUids(String uid) async {
    final RequestBloc rb = Provider.of<RequestBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'no internet'.tr());
      } else {
        var uids = await rb.getResponsesUid(uid);
        _uids.clear();
        _uids.addAll(uids);
        if (!mounted) return;
        setState(() {});
      }
    });
  }
}
