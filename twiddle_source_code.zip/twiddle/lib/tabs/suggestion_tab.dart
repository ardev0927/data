import 'package:cloud_functions/cloud_functions.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:flutter_icons/flutter_icons.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/suggestion_bloc.dart';
import 'package:twiddle/cards/suggestion_card.dart';

import '../blocs/notification_bloc.dart';
import '../blocs/user_bloc.dart';
import '../models/user.dart';
import '../pages/profile/user_profile_page.dart';
import '../services/app_service.dart';
import '../utils/empty.dart';
import '../utils/enums.dart';
import '../utils/format_time.dart';
import '../utils/loading_cards.dart';
import '../utils/next_screen.dart';
import '../utils/snacbar.dart';

class SuggestionTab extends StatefulWidget {
  const SuggestionTab({super.key});

  @override
  State<SuggestionTab> createState() => _SuggestionTabState();
}

class _SuggestionTabState extends State<SuggestionTab> {
  @override
  void initState() {
    super.initState();

    final sb = context.read<SignInBloc>();
    if (mounted) {
      context.read<SuggestionBloc>().onInit();
      context.read<SuggestionBloc>().data.isNotEmpty
          ? print('data already loaded')
          : context.read<SuggestionBloc>().getData(sb.uid!, mounted);
    }
  }

  @override
  Widget build(BuildContext context) {
    final sgb = context.watch<SuggestionBloc>();
    final sb = context.read<SignInBloc>();
    final ub = context.read<UserBlock>();

    return RefreshIndicator(
      onRefresh: () async {
        context.read<SuggestionBloc>().onRefresh(sb.uid!, mounted);
      },
      child: sgb.hasData == false
          ? ListView(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.20,
                ),
                EmptyPage(
                    icon: Icons.person_outline,
                    message: 'you_have_no_suggestion'.tr(),
                    message1: ''),
              ],
            )
          : ListView.separated(
              // key: PageStorageKey(widget.category),
              padding: const EdgeInsets.only(top: 8),
              physics: AlwaysScrollableScrollPhysics(),
              itemCount: sgb.data.isNotEmpty ? sgb.data.length + 1 : 5,
              separatorBuilder: (BuildContext context, int index) =>
                  const SizedBox(height: 3),
              shrinkWrap: true,
              itemBuilder: (_, int index) {
                if (index < sgb.data.length) {
                  return SuggestionCard(
                    uid: sb.uid!,
                    d: sgb.data[index],
                    heroTag: 'tab2$index',
                    onAddFriendPressed: () {
                      if (sgb.data[index].friendResponses!.contains(sb.uid)) {
                        ub
                            .setUnRequestFriend(sb.uid!, sgb.data[index].uid)
                            .then((value) {
                          sgb.data[index].friendResponses!.remove(sb.uid!);
                          sgb.setData(sgb.data[index], index);

                          setState(() {});
                        });
                      } else {
                        ub
                            .setRequestFriend(sb.uid!, sgb.data[index].uid)
                            .whenComplete(() {
                          if (!sgb.data[index].friendResponses!
                              .contains(sb.uid)) {
                            sgb.data[index].friendResponses!.add(sb.uid!);
                            sgb.setData(sgb.data[index], index);

                            setState(() {});

                            // FCM
                            _sendFcmPost(sgb.data[index], sb.uid!, sb.name!,
                                sb.imageUrl!);
                          }
                          // openSnacbar(context, 'You sent request friend');

                          // print('You sent request friend');
                          // context
                          //     .read<SuggestionBloc>()
                          //     .onRefresh(sb.uid!, mounted);
                        });
                      }
                    },
                    onRemovePressed: () {
                      setState(() {
                        sgb.data.removeAt(index);
                      });
                    },
                    onItemTapped: () {
                      // Open profile page
                      nextScreen(
                          context, UserProfilePage(uid: sgb.data[index].uid));
                    },
                  );
                }
                return Opacity(
                  opacity: sgb.isLoading ? 1.0 : 0.0,
                  child: sgb.lastVisible == null
                      ? LoadingCard(height: 120)
                      : const Center(
                          child: SizedBox(
                              width: 32.0,
                              height: 32.0,
                              child: CupertinoActivityIndicator()),
                        ),
                );
              },
            ),
    );
  }

  _sendFcmPost(WUser user, String loggedUid, String loggedUsername,
      String loggedAvatar) async {
    print("===== fcm token ${user.fcmToken} =====");
    String body = 'Request friend';
    String title = 'You received a request friend from $loggedUsername';

    var func = FirebaseFunctions.instance.httpsCallable("notifySubscribers");
    var res = await func.call(<String, dynamic>{
      "targetDevices": [user.fcmToken],
      "messageTitle": title,
      "messageBody": body,
    });

    print(
        "===== firebase cloud message was ${res.data as bool ? "sent!" : "not sent!"} =====");

    // add notification
    if (res.data as bool == true) {
      _updateNotification(
          user.uid, body, FcmType.requestfriend, loggedUid, loggedAvatar);
    }
  }

  _updateNotification(uid, title, type, typedata, useravatar) async {
    final NotificationBloc nb =
        Provider.of<NotificationBloc>(context, listen: false);
    await AppService().checkInternet().then((hasInternet) async {
      if (hasInternet == false) {
        openSnacbar(context, 'check your internet connection!'.tr());
      } else {
        DateTime now = DateTime.now();
        DateTime utc = now.toUtc();
        var timestamp = formatISOTime(utc);

        nb
            .addNotification(uid, title, type, typedata, useravatar, timestamp)
            .then((value) {
          if (nb.hasError == false) {
            //
            print('Request friend notification is added successfully');
          } else {
            openSnacbar(context, 'Something went wrong');
          }
        });
      }
    });
  }
}
