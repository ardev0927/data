String convertToAgo(String timestamp) {
  var input = DateTime.parse(timestamp);
  var now = DateTime.now().toUtc();
  Duration diff = now.difference(input);

  if (diff.inDays >= 1) {
    if (diff.inDays >= 30) {
      return '${(diff.inDays / 30).round()} months ago';
    }
    return '${diff.inDays} days ago';
  } else if (diff.inHours >= 1) {
    return '${diff.inHours} hours ago';
  } else if (diff.inMinutes >= 1) {
    return '${diff.inMinutes} minutes ago';
  } else if (diff.inSeconds >= 1) {
    return '${diff.inSeconds} seconds ago';
  } else {
    return 'Just now';
  }
}

bool twoDaysAgo(String timestamp) {
  var input = DateTime.parse(timestamp);
  var now = DateTime.now().toUtc();
  Duration diff = now.difference(input);

  if (diff.inDays >= 2) {
    return true;
  }
  return false;
}
