class MessageType {
  static const text = 1;
  static const image = 2;
  static const voice = 3;
}

class PostType {
  static const empty = 0;
  static const image = 1;
  static const video = 2;
  static const text = 3;
  static const gif = 7;
  static const album = 9;
  static const share = 12;
  static const checkin = 10;
  static const article = 11;
  static const poll = 8;
  static const livestream = 5;
  static const sharegroup = 13;
  static const tagfriend = 6;
  static const contentwarning = 14;
}

class FcmType {
  static const react = 1;
  static const tag = 2;
  static const invitegroup = 4;
  static const uninvitegroup = 7;
  static const requestgroup = 5;
  static const unrequestgroup = 6;
  static const joingroup = 8;
  static const requestfriend = 9;
}
