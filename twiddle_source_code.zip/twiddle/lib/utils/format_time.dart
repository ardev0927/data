import 'package:easy_localization/easy_localization.dart';

formatISOTime(DateTime date) {
  var val = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(date);
  var offset = date.timeZoneOffset;
  var hours = offset.inHours > 0 ? offset.inHours : 1; // For fixing divide by 0

  if (!offset.isNegative) {
    val = val +
        "+" +
        offset.inHours.toString().padLeft(2, '0') +
        ":" +
        (offset.inMinutes % (hours * 60)).toString().padLeft(2, '0');
  } else {
    val = val +
        "-" +
        (-offset.inHours).toString().padLeft(2, '0') +
        ":" +
        (offset.inMinutes % (hours * 60)).toString().padLeft(2, '0');
  }
  return val;
}
