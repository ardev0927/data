import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:twiddle/utils/snacbar.dart';
import 'package:uuid/uuid.dart';

import '../models/group.dart';

Future<String> uploadGroupCoverFile(context, File file, Group g) async {
  var downloadUrl = '';
  var uuid = Uuid();
  try {
    Reference storageReference = FirebaseStorage.instance
        .ref()
        .child('Group Cover Pictures/${g.id}/${uuid.v1()}');
    UploadTask uploadTask = storageReference.putFile(file);

    await uploadTask.whenComplete(() async {
      var url = await storageReference.getDownloadURL();
      downloadUrl = url;
    });
  } catch (e) {
    openSnacbar(context, e.toString());
  }
  return downloadUrl;
}
