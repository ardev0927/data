import 'package:flutter/material.dart';
import 'package:twiddle/config/config.dart';

class AppMiniButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final bool disabled;
  final FontWeight fontWeight;
  final Color? textColor;
  final Color? backgroundColor;

  AppMiniButton(
    this.text, {
    super.key,
    required this.onPressed,
    this.disabled = false,
    required this.fontWeight,
    this.textColor,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: disabled ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor ?? Config().primary4Color,
        minimumSize: const Size(40, 40),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .button!
            .copyWith(color: textColor, fontWeight: fontWeight, fontSize: 14),
      ),
    );
  }
}
