import 'dart:io';

import 'package:flutter/material.dart';
import 'package:twiddle/models/relationship.dart';

import '../config/config.dart';
import '../utils/cached_image.dart';

class AppRelationship extends StatelessWidget {
  final VoidCallback? onPressed;
  final Relationship relationship;
  final String? imageFilePath;
  final bool isEdit;

  const AppRelationship(
    this.relationship, {
    Key? key,
    required this.isEdit,
    this.onPressed,
    this.imageFilePath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8),
      child: Row(
        children: [
          imageFilePath == null
              ? relationship.avatar == null || relationship.avatar!.isEmpty
                  ? Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Config().primary4Color,
                      ),
                    )
                  : SizedBox(
                      width: 30,
                      height: 30,
                      child: CustomCacheImage(
                          imageUrl: relationship.avatar,
                          radius: 15,
                          circularShape: true),
                    )
              : CircleAvatar(
                  backgroundImage: Image.file(File(imageFilePath!)).image,
                ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  relationship.title ?? 'Name',
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Config().text90Color),
                ),
                Text(
                  relationship.description ?? 'Description',
                  maxLines: 2,
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                      color: Config().text90Color),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          isEdit == true
              ? IconButton(onPressed: onPressed, icon: const Icon(Icons.edit))
              : Container(),
        ],
      ),
    );
  }
}
