import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

elevatedButtonWidget({String? name, Function()? onPressed}) {
  return ElevatedButton(
    onPressed: onPressed,
    style: ElevatedButton.styleFrom(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      minimumSize: const Size.fromHeight(50), // NEW
    ),
    child: Text(
      name!,
      style: TextStyle(
          fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
    ).tr(),
  );
}
