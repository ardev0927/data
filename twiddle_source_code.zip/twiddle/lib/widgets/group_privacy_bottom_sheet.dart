import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../config/config.dart';

/// Bottom sheet for group privacy
showChooseGroupPrivacySheet(BuildContext context,
    {Function()? onPublicTap, Function()? onPrivateTap}) {
  showModalBottomSheet(
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(16), topRight: Radius.circular(16))),
    elevation: 10,
    context: context,
    builder: (context) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(Icons.clear)),
            ],
          ),
          // public
          InkWell(
            onTap: onPublicTap,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.public_outlined),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text(
                      'public'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // private
          InkWell(
            onTap: onPrivateTap,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Icon(Icons.lock_outline),
                  Padding(
                    padding: const EdgeInsets.only(left: 16),
                    child: Text(
                      'private'.tr(),
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Config().text90Color),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    },
  );
}
