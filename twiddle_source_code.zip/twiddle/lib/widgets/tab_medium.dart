import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:twiddle/blocs/friends_bloc.dart';
import 'package:twiddle/blocs/sign_in_bloc.dart';
import 'package:twiddle/blocs/suggestion_bloc.dart';
import 'package:twiddle/tabs/friends_tab.dart';
import 'package:twiddle/tabs/interests_tab.dart';
import 'package:twiddle/tabs/request_tab.dart';
import 'package:twiddle/tabs/suggestion_tab.dart';

import '../blocs/tab_index_bloc.dart';

class TabMedium extends StatefulWidget {
  final ScrollController? sc;
  final TabController? tc;
  // final List<String>? uids;

  const TabMedium({
    super.key,
    this.sc,
    this.tc,
    // this.uids,
  });

  @override
  State<TabMedium> createState() => _TabMediumState();
}

class _TabMediumState extends State<TabMedium> {
  @override
  void initState() {
    super.initState();
    widget.sc!.addListener(_scrollListener);
  }

  void _scrollListener() {
    final db = context.read<FriendsBloc>();
    final sgb = context.read<SuggestionBloc>();
    // final cb2 = context.read<CategoryTab2Bloc>();
    // final cb3 = context.read<CategoryTab3Bloc>();
    // final cb4 = context.read<CategoryTab4Bloc>();
    // final tib = context.read<TabIndexBloc>();
    final sib = context.read<SignInBloc>();

    // if (tib.tabIndex == 0) {
    //   if (!db.isLoading) {
    //     if (widget.sc!.offset >= widget.sc!.position.maxScrollExtent &&
    //         !widget.sc!.position.outOfRange) {
    //       print("reached the bottom");
    //       db.setLoading(true);
    //       db.getData(widget.uids!, mounted);
    //     }
    //   }
    // } else if (tib.tabIndex == 1) {
    //   if (!sgb.isLoading) {
    //     if (widget.sc!.offset >= widget.sc!.position.maxScrollExtent &&
    //         !widget.sc!.position.outOfRange) {
    //       print("reached the bottom -t1");
    //       sgb.setLoading(true);
    //       sgb.getSuggestionUid(sib.uid);
    //     }
    //   }
    // }
    // } else if (sb.tabIndex == 2) {
    //   if (!cb2.isLoading) {
    //     if (widget.sc!.offset >= widget.sc!.position.maxScrollExtent &&
    //         !widget.sc!.position.outOfRange) {
    //       print("reached the bottom -t2");
    //       cb2.setLoading(true);
    //       cb2.getData(
    //         mounted,
    //         Config().initialCategories[1],
    //       );
    //     }
    //   }
    // } else if (sb.tabIndex == 3) {
    //   if (!cb3.isLoading) {
    //     if (widget.sc!.offset >= widget.sc!.position.maxScrollExtent &&
    //         !widget.sc!.position.outOfRange) {
    //       print("reached the bottom -t3");
    //       cb3.setLoading(true);
    //       cb3.getData(
    //         mounted,
    //         Config().initialCategories[2],
    //       );
    //     }
    //   }
    // } else if (sb.tabIndex == 4) {
    //   if (!cb4.isLoading) {
    //     if (widget.sc!.offset >= widget.sc!.position.maxScrollExtent &&
    //         !widget.sc!.position.outOfRange) {
    //       print("reached the bottom -t4");
    //       cb4.setLoading(true);
    //       cb4.getData(
    //         mounted,
    //         Config().initialCategories[3],
    //       );
    //     }
    //   }
    // }
  }

  @override
  Widget build(BuildContext context) {
    return TabBarView(
      children: [
        // FriendsTab(),
        // SuggestionTab(),
        // InterestsTab(),
        // RequestTab(),
      ],
      controller: widget.tc,
    );
  }
}
